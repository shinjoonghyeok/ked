import * as $ from 'jquery';

export var answer = {
    loading: (status, divID) => {
        let loadingID = document.getElementById(divID + "_loadingID");
        let loadingIDHTML;

        if (!loadingID) {
            if (divID) {
                loadingIDHTML = "<div id=\"" + divID + "_loadingID\" style=\"position:absolute;top:48%;left:45%;display:none;margin:10px;text-align:center;z-index:99999;\">";
                loadingIDHTML += "<p>잠시만 기다려 주세요.</p>"
                $("#" + divID).append(loadingIDHTML);
            }
        }

        if (status) {
            $("#" + divID + "_loadingID").show();
        } else {
            $("#" + divID + "_loadingID").hide();
        }
    }
}