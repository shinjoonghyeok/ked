import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';

import * as Highcharts from 'highcharts';
require('highcharts/highcharts-more')(Highcharts);
require('highcharts/modules/no-data-to-display')(Highcharts);
require('highcharts/modules/treemap')(Highcharts);

@Component({
	selector: 'home',
	template: `
	<div id="container">
		<side-bar></side-bar>
		<section class="container">
		</section>
	</div>
	`,
	styleUrls: [`common.less`]
})
export class HomeComponent implements OnInit {
	constructor() {
	}

	ngOnInit(): void {
	}
}