import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home.component';
import { NotFoundComponent } from './not-found.component';
import { MenuComponent } from './menu.component';

import { RoutineSelectComponent } from './ts/routine-select.component';
import { RoutineCheckComponent } from './ts/routine-check.component';
import { RoutineReportComponent } from './ts/routine-report.component';
import { RoutineStatusComponent } from './ts/routine-status.component';
import { UsedHistoryComponent } from './ts/used-history.component';
import { RoutineAdminComponent } from './ts/routine-admin.component';


const routes: Routes = [
	// { path: '', component: RoutineSelectComponent },
	{ path: '', redirectTo: 'datalog-ked-cre/routine-select', pathMatch: 'full'},
	{ path: 'menu', component: MenuComponent },
	
	{ path: 'datalog-ked-cre/routine-select', component: RoutineSelectComponent },
	{ path: 'datalog-ked-cre/routine-check/:pIdx/:pType', component: RoutineCheckComponent},
	{ path: 'datalog-ked-cre/routine-report', component: RoutineReportComponent},
	{ path: 'datalog-ked-cre/routine-status/:pIdx/:pType', component: RoutineStatusComponent},
	{ path: 'datalog-ked-cre/used-history', component: UsedHistoryComponent},
	{ path: 'datalog-ked-cre/routine-admin', component: RoutineAdminComponent},
	
	{ path: 'msgbus-console', component: HomeComponent },
	{ path: '**', component: NotFoundComponent }
];

@NgModule({
	imports: [RouterModule.forRoot(routes)],
	exports: [RouterModule]
})
export class AppRoutingModule { }
