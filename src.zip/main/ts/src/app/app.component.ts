import { Component, OnInit } from '@angular/core';
// import { WebsocketService, MsgbusService } from 'sonar-angular5-sdk';
import { WebsocketService, MsgbusService, HostAuthService, Principal, HostNavigatorService } from 'sonar-angular5-sdk';
import * as appInfo from '../../../../../sonar_app.json';

@Component({
	selector: 'app-root',
	template: `
	<menu *ngIf="!isEmbedded"></menu>
	<!-- <div [ngStyle]="mainStyle"> -->
	<div [ngStyle]="{'position':'absolute', 'width':'100%', 'height': 'calc(100% - ' + appMenuHeight + 'px)', 'border': '0'}">
		<router-outlet></router-outlet>
	</div>
	`,
	styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
	title = 'app';
	appMenuHeight: number = 47;
	mainStyle:any = {
		'left': '0px',
		'width': 'calc(100% - 160px)',
		'height': 'calc(100% - 47px)',
		'position': 'absolute',
		'top': '47px',
		'right': '0px',
		'bottom': '0px',
		'overflow': 'auto',
		'min-width': '1120px',
		'border': '0'
	};

	constructor(
		private websocketService: WebsocketService,
		private msgbusService: MsgbusService,
		private authService: HostAuthService,
		private navigatorService: HostNavigatorService
	) {
		if (this.isEmbedded)
			this.appMenuHeight = 0;
	}

	get principal(): Principal {
		return this.authService.getPrincipal();
	}

	get isLoggedOn(): boolean {
		return this.authService.getPrincipal() != null;
	}

	get isEmbedded() {
		return !!window.parent['SONAR'];
	}
	

	ngOnInit() {
		if(!this.isLoggedOn) {
			this.navigatorService.navigateByUrl('/login');
		}
	}
}