import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
	selector: 'side-bar',
	template: `
	<section class="sidebar" style="border:1px solid #eee; height:100%" [ngStyle]="{'top': topOffset}">
	<ul>
		<li>
			<div class="header">
				<div class="title pull-left">오남용 관리</div>
				<div class="icon-box pull-right">
					<i class="fa fa-database"></i>
				</div>
			</div>
		</li>
		<li>
			<div class="body">
				<ul>
					<li class="menu" [class.active]="activeMenu === 'routine-select'" (click)="go('datalog-ked-cre/routine-select')">정기점검대상선정</li>
					<li class="menu" [class.active]="activeMenu === 'routine-check'" (click)="go('datalog-ked-cre/routine-check/0/0')">정기점검대상검토</li>
					<li class="menu" [class.active]="activeMenu === 'routine-status'" (click)="go('datalog-ked-cre/routine-status/0/0')">정기점검결과확인</li>

					<li class="menu" [class.active]="activeMenu === 'routine-report'" (click)="go('datalog-ked-cre/routine-report')">점검결과 리포트</li>

					<li class="menu" [class.active]="activeMenu === 'used-history'" (click)="go('datalog-ked-cre/used-history')">계약 및 이용정보</li>
					<!-- <li class="menu" [class.active]="activeMenu === 'routine-admin'" (click)="go('datalog-ked-cre/routine-admin')">점검대상관리현황</li> -->
					<!-- <li class="menu" style="font-size:10px;" [class.active]="activeMenu === 'routine-admin'" (click)="go('datalog-ked-cre/routine-admin')">정기점검1년이내점검대상관리</li> -->
					<li class="menu" [class.active]="activeMenu === 'routine-admin'" (click)="go('datalog-ked-cre/routine-admin')">최근1년점검현황</li>
				</ul>
			</div>
		</li>
	</ul>
	</section>
	`, styleUrls: ['../css/less/side-bar.less']
})
export class SideBarComponent implements OnInit {
	activeMenu: string;

	get topOffset(): number {
		let embedded = !!window.parent['SONAR'];
		return embedded ? 0 : 135;
	}

	constructor(private router: Router, private route: ActivatedRoute) { }

	ngOnInit() {
		this.route.url.subscribe(url => {
			const path: string = url.length > 1 ? url[1].path : null;
			this.activeMenu = path;
		})
	}

	go(route: string) {
		this.router.navigateByUrl(route);
	}
}
