import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'dateformat'
})

export class DateformatPipe implements PipeTransform {
    transform(value:string): string {
        let dateType = new Date(value);

        let year = dateType.getFullYear();
        let month = this.addZeroPadding(dateType.getMonth() + 1);
        let day = this.addZeroPadding(dateType.getDate());
        let hour = this.addZeroPadding(dateType.getHours());
        let minute = this.addZeroPadding(dateType.getMinutes());
        let second = this.addZeroPadding(dateType.getSeconds());

        return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
    }

    private addZeroPadding(dateStr) {
		  return `0${dateStr}`.slice(-2);
    }
}