import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'datestring'
})

export class DatestringPipe implements PipeTransform {
    transform(value:string): string {
        let year = value.substr(0,4);
        let month = value.substr(4,2);
        let day = value.substr(6,2);

        return `${year}년 ${month}월 ${day}일`;
    }

    private addZeroPadding(dateStr) {
		  return `0${dateStr}`.slice(-2);
    }
}