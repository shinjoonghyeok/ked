import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'duration'
})

export class DurationPipe implements PipeTransform {
    transform(value:number): string {
        if(typeof value === "undefined") value = 0;
        if(isNaN(value)) return value.toString();

        let hour:number = 0
        let min:number = 0;
        let sec:number = 0;

        let rhour:string = '00';
        let rmin:string = '00';
        let rsec:string = '00';

        hour = Math.floor(value / 3600);
        min = Math.floor((value % 3600) / 60);
        sec = value % 60;

        if(hour.toString().length==1) rhour="0" + hour.toString();
        else rhour = hour.toString();
        if(min.toString().length==1) rmin="0" + min.toString();
        else rmin = min.toString();
        if(sec.toString().length==1) rsec="0" + sec.toString();
        else rsec = sec.toString();

        return rhour + " 시간 " + rmin + " 분 " + rsec + " 초";
    }
}