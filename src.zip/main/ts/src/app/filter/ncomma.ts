import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'ncomma'
})

export class NcommaPipe implements PipeTransform {
    transform(value:number): string {
        if(isNaN(value)) return value.toString();
        return value.toLocaleString(undefined, {maximumFractionDigits:5})
    }
}