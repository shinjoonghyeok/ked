import { Component, OnInit, HostListener, OnDestroy, ChangeDetectorRef, Input } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { $ } from 'protractor';
import { Logger, LogService, QueryService, MsgbusService, getColumnDefs, HostAuthService, Principal } from 'sonar-angular5-sdk';

import { AuditRecordService } from './audit-record.service';


import * as Highcharts from 'highcharts';
require('highcharts/highcharts-more')(Highcharts);
require('highcharts/modules/no-data-to-display')(Highcharts);
require('highcharts/modules/treemap')(Highcharts);

import * as XLSX from 'xlsx';
import { HttpInterceptingHandler } from '@angular/common/http/src/module';

@Component ({
    selector: 'used-history',
    templateUrl: '../html/used-history.html',
    styleUrls: ['../common.less','../css/answer.css']
})


export class UsedHistoryComponent implements OnInit, OnDestroy {
    private logger: Logger;

    searchDate:Date = new Date();
    get searchMonthStr():string { return this.searchDate == null ? '' : this.convertDate(this.searchDate, 'month') }
    get searchYearStr():string { return this.searchDate == null ? '' : this.convertDate(this.searchDate, 'year') }

    get principal(): Principal {
		return this.authService.getPrincipal();
	}

    startYear:any = '2019';

    searchMonth:any = this.convertStringToPreDate(this.searchMonthStr);

	searchType:string = 'ID';
    searchTypeList:any = [
        {name:'ID',type:'ID'},
        {name:'고객명',type:'고객명'}
	];

	searchValue:string = '';

	mainTable:any = {
        fields: ['No','ID', '계약번호', '고객번호', '사업자번호', '고객명', '서비스명', '크레탑사용시간', '가격정책명', '납부구분', '해당ID최초이용시작일', '관리부점', '업태', '종목', '기업규모', '부서명', '성명', '전화번호', '팩스번호', '이메일', '3개월평균조회기업(개인)수', '계약상태'],
        value: []
	}

    isMainResultShow:boolean = false;
    mainHeight:number =  400;

    constructor(
        log: LogService, 
        private authService: HostAuthService,
		private msgbusService: MsgbusService,
		private queryService: QueryService,
		private cdr: ChangeDetectorRef,
		private router: Router, 
        private route: ActivatedRoute, 
        private AuditRecordService: AuditRecordService
    ) {
        this.logger = log.getLogger("Data Log");
        
        this.searchLogListStart = this.searchLogListStart.bind(this);
		this.searchLogListChange = this.searchLogListChange.bind(this);

		this.router.routeReuseStrategy.shouldReuseRoute = function() {
            return false;
        }
	}

    ngOnInit() {
        this.mainHeight = window.innerHeight - 193;
        this.searchLog();

        // console.log(this.principal)
    }

    @HostListener('window:beforeunload', ['$event'])
	beforeunloadHandler(event) {
		if(this.searchLogListQueryId) {
			this.queryService.removeQuery(this.searchLogListQueryId);
		}
    }
    
    @HostListener('window:resize', ['$event'])
    resizeHandler(event) {
        this.mainHeight = event.target.innerHeight - 193;
    }

    ngOnDestroy() {
		if (this.searchLogListQueryId) {
			this.queryService.removeQuery(this.searchLogListQueryId);
		}
    }
    
    convertPreDateArray (dateStr, n) {
        let parts = dateStr.split('-');
        let retArray = [];

        for(let i=0; i<n; i++) {
            let date = new Date(parts[0], parts[1] - i - 1).getTime();
            // let year = date.getFullYear();
            // let month = this.addZeroPadding(date.getMonth() + 1);
            // retArray.push(`${year}-${month}`);

            retArray.push(date / 1000);
        }
		return retArray;
    }

    convertStringToStamp(dateStr) {
		let parts = dateStr.split('-');
        return new Date(parts[0], parts[1] -1).getTime();
	}

	convertStringToTargetDate(dateStr, target) {
		let calDate = 1 + target
        let parts = dateStr.split('-');
        let date = new Date(parts[0], parts[1] - calDate);
        let year = date.getFullYear();
		let month = this.addZeroPadding(date.getMonth() + 1);
        
        return `${year}-${month}`;
    }

    convertStringToPreDate(dateStr) {
        let parts = dateStr.split('-');
        let date = new Date(parts[0], parts[1] -2);
        let year = date.getFullYear();
		let month = this.addZeroPadding(date.getMonth() + 1);
        
        return `${year}-${month}`;
    }

    convertCalDate(dateStr, target) {
        let parts = dateStr.split('-');
        let timeStamp = new Date(parts[0], parts[1] -1, parts[2]).getTime() + ((24*60*60*1000) * target);
        let calDate = new Date(timeStamp);
        return this.convertDate(calDate, 'day');
    }

    convertDateAdd(target) {
        let timeStamp = new Date().getTime() + ((24*60*60*1000) * target);
        return new Date(timeStamp);
    }
    
    convertStringToDatePlus(dateStr) {
        let parts = dateStr.split('-');
        let timeStamp = new Date(parts[0], parts[1] -1, parts[2]).getTime() + (1*24*60*60*1000);
        return new Date(timeStamp);
    }

    convertStringToDate(dateStr) {
        let parts = dateStr.split('-');
        return new Date(parts[0], parts[1] -1, parts[2])
    }

    convertDate(date: Date, format: string): any {
		// format - [year, month, day, hour, minute, second]
		if (!date) {
			return;
		}

		let year = date.getFullYear();
		let month = this.addZeroPadding(date.getMonth() + 1);
		let day = this.addZeroPadding(date.getDate());
		let hour = this.addZeroPadding(date.getHours());
		let minute = this.addZeroPadding(date.getMinutes());
		let second = this.addZeroPadding(date.getSeconds());

		switch (format) {
			case 'year':
				return `${year}`;
			case 'month':
				return `${year}-${month}`;
			case 'day':
				return `${year}-${month}-${day}`;
			case 'hour':
				return `${year}-${month}-${day} ${hour}`;
			case 'minute':
				return `${year}-${month}-${day} ${hour}:${minute}`;
			case 'second':
				return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
			default:
				return date;
		}
    }
    
    private addZeroPadding(dateStr) {
		return `0${dateStr}`.slice(-2);
    }

    random() {
        return Math.floor(Math.random() * 300);
    }
    
	baseQuery:string = '';
	searchLog () {
        this.baseQuery = "";

        let searchDateStr = "";
        let searchMonthArray = this.convertPreDateArray(this.searchMonth, 3);
        for(let i=0; i<searchMonthArray.length; i++) {
            searchDateStr += "crstamp==" + searchMonthArray[i]  + " or "
        }
        searchDateStr = searchDateStr.substr(0, searchDateStr.length-3);


        /** Paging 초기화  **/
        this.logListCurrentPage = 1;
        this.logListTotalItems = 0;
        this.logListMaxPageCount = 0;
        this.pagingArray = [];
        this.logListCurrentStart = 1;

		this.baseQuery += "table KS_CRETOP_LOG_R03";
		this.baseQuery += " | sort  -계약번호 | sort limit=1 -계약번호 by ID";
		this.baseQuery += " | eval 관리부점 = 관리처1";
		this.baseQuery += " | eval 관리부점 = if(isnotnull(관리처2), concat(관리부점, \" / \", 관리처2), 관리부점)";
		this.baseQuery += " | eval 관리부점 = if(isnotnull(관리처3), concat(관리부점, \" / \", 관리처3), 관리부점)";
		this.baseQuery += " | eval 해당ID최초이용시작일 = string(date(해당ID최초이용시작일,\"yyyyMMdd\"),\"yyyy-MM-dd\")";
        this.baseQuery += " | fields ID, 계약번호,고객번호,사업자번호,고객명,서비스명,크레탑사용시간,가격정책명,납부구분,해당ID최초이용시작일,관리부점,업태,종목,기업규모,부서명,성명,전화번호,팩스번호,이메일,계약상태";

        this.baseQuery += " | join type=left ID [ fulltext " + searchDateStr + " from KS_CRETOP_LOG_R01 | stats avg(IQENPCN) as avgValue by ID | fields ID, avgValue | eval 구분  = \"기업\" ]";
        this.baseQuery += " | join type=left ID [ fulltext " + searchDateStr + " from KS_CRETOP_LOG_R02 | stats avg(IQINDVCN) as avgValue by ID | fields ID, avgValue | eval 구분  = \"개인\" ]";

        this.baseQuery += " | rename avgValue as 3개월평균조회기업(개인)수";
        this.baseQuery += " | search 계약상태==\"개통\"";

		if(this.searchValue!="") {
			this.baseQuery += " | search " + this.searchType + " == \"" + this.searchValue + "\"";
        }
        
        // console.log(this.baseQuery)

        let auditDate:any = {};
        auditDate.menu = "계약및이용정보";
        auditDate.type = "조회";
        auditDate.searchType = this.searchType;
        auditDate.searchValue = this.searchValue;
        this.AuditRecordService.importAuditLogger(this.principal.login, auditDate);

		this.searchLogListStart();
	}


	searchLogStop () {
		this.isLogSearch = false;
        this.queryService.stopQuery(this.searchLogListQueryId);
    }
    

    getExportData(queryid, totalCount, callback) {
		this.queryService.getResult(queryid, 0, totalCount)
        .then((result) => {
            callback(result.records);
        })
        .catch(function (msg) {
            console.log('error', msg);
        });
	}

	exportExcel () {
		if(this.mainTable.value.length > 0) {
            let fileName = "계약 및 이용정보.xlsx";
            const wb: XLSX.WorkBook = XLSX.utils.book_new();
            // console.log("Excel Download Start")

			this.getExportData(this.searchLogListQueryId, this.logListTotalItems, (data) => {
				const approvalHeader = this.mainTable.fields;
                const ws: XLSX.WorkSheet =XLSX.utils.json_to_sheet(data, {header: approvalHeader});
                
                // console.log("Excel Download End")
	
				XLSX.utils.book_append_sheet(wb, ws, "계약 및 이용 정보");
				XLSX.writeFile(wb, fileName);
			});
		}
		else {
			alert("검색 내용이 없습니다");
		}
	}

	

	
	private searchLogListQueryId;
	isLogSearch:boolean = false;
	searchLogListStart () {
		if (!!this.searchLogListQueryId) {
			this.queryService.removeQuery(this.searchLogListQueryId);
			this.searchLogListQueryId = null;
        }
		this.mainTable.count = 0;

        this.queryService.createQuery(this.baseQuery, { onChanged: this.searchLogListChange })
        .then((query) => {
            this.queryService.startQuery(query.id)
			.then(() => {
                this.searchLogListQueryId = query.id;
                this.isLogSearch = true;
			})
			.catch((msg) => {
				console.log('error', msg);
			});
        })
        .catch((msg) => {
            console.log('error', msg);
        });
	}

	searchLogListChange (query) {
		if(!!query) {
			if(query.status=="Ended") this.isLogSearch = false;
			this.searchLogListResult(query.id, "normal");
		}
	}

	searchLogListResult (id, type) {
		const offset = (this.logListCurrentPage - 1) * this.logListPageSize;
        const limit = this.logListPageSize;

		this.queryService.getResult(id, offset, limit)
        .then((result) => {
            this.logListTotalItems = result.count;
            this.mainTable.value = this.addNumbering(result.records);

            this.makePagingInfo();
            this.cdr.detectChanges();
        })
        .catch(function (msg) {
            console.log('error', msg);
        });
	}

	addNumbering(arr) {
        for(let i=0; i<arr.length; i++) {
            arr[i]['No'] = i + 1 + ( (this.logListCurrentPage -1) * this.logListPageSize )
        }

        return arr;
    }






	/***** Pagination  *****/
	logListCurrentPage:number = 1;
    logListTotalItems:number = 0;

    logListMaxPageCount:number = 0;
    pagingArray:any = [];
    logListPageSize:number = 30;
    logListPageLength:number = 10;
    logListCurrentStart = 1;

    makePagingInfo () {
        this.pagingArray = [];
        let arrayCount = 0;
        if(this.logListTotalItems>0) this.logListMaxPageCount = Math.ceil(this.logListTotalItems / this.logListPageSize);
        else this.logListMaxPageCount = 0;

        if(this.logListMaxPageCount > this.logListPageLength) arrayCount = this.logListPageLength;
        else arrayCount = this.logListMaxPageCount;

        for(let i=0; i<arrayCount; i++) {
            let inputNum = i + this.logListCurrentStart;
            if(this.logListMaxPageCount >= inputNum) this.pagingArray.push(inputNum)
            else break;
        }
    }
    searchLogPageChanged (pNum) {
        this.logListCurrentPage = pNum;
        this.logListCurrentStart = (Math.ceil(this.logListCurrentPage / this.logListPageLength) - 1) * this.logListPageLength + 1;

        this.searchLogListResult(this.searchLogListQueryId ,"page");
    }
    searchLogPageNext () {
        let move = this.logListCurrentPage + 1;
        if(move > this.logListMaxPageCount) move = this.logListMaxPageCount;
        this.searchLogPageChanged(move)
    }
    searchLogPagePrev () {
        let move = this.logListCurrentPage - 1;
        if(move < 1) move = 1;
        this.searchLogPageChanged(move)
    }
    searchLogPageNextJump () {
        let move = this.logListCurrentPage + this.logListPageLength;
        if(move > this.logListMaxPageCount) move = this.logListMaxPageCount;
        this.searchLogPageChanged(move)
    }
    searchLogPagePrevJump () {
        let move = this.logListCurrentPage - this.logListPageLength;
        if(move < 1) move = 1;
        this.searchLogPageChanged(move)
    }

}