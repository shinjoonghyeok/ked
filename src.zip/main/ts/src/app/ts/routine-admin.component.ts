import { Component, OnInit, HostListener, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { $ } from 'protractor';
import { Logger, LogService, QueryService, MsgbusService, getColumnDefs, HostAuthService, Principal } from 'sonar-angular5-sdk';

import { AuditRecordService } from './audit-record.service';

import * as Highcharts from 'highcharts';
require('highcharts/highcharts-more')(Highcharts);
require('highcharts/modules/no-data-to-display')(Highcharts);
require('highcharts/modules/treemap')(Highcharts);

import * as XLSX from 'xlsx';
import { HttpInterceptingHandler } from '@angular/common/http/src/module';
import { NONE_TYPE } from '@angular/compiler/src/output/output_ast';

@Component ({
    selector: 'routine-admin',
    templateUrl: '../html/routine-admin.html',
    styleUrls: ['../common.less','../css/answer.css']
})

export class RoutineAdminComponent implements OnInit, OnDestroy {
    private logger: Logger;

    startDate:Date = new Date();
    endDate:Date = new Date();

    get startDateStr():string { return this.startDate == null ? '' : this.convertDate(this.startDate, 'second') }
    get endDateStr():string { return this.endDate == null ? '' : this.convertDate(this.endDate, 'second') }

	get principal(): Principal {
		return this.authService.getPrincipal();
	}

	searchType:string = 'total';
    searchTypeList:any = [
		{name:'전체',type:'total'},
        {name:'기업정보',type:'biz'},
        {name:'개인정보',type:'priv'}
	];

	searchSort:string = '등록날짜';
    searchSortList:any = [
        {name:'등록날짜',type:'등록날짜'},
		{name:'ID',type:'ID'},
		{name:'기업명',type:'기업명'}
	];
	
	
	importType:string = 'biz';
	importTypeList:any = [
        {name:'기업정보',type:'biz'},
        {name:'개인정보',type:'priv'}
	];

	mainTable:any = {
        fields: ['No','ID','기업명','제외사유','구분','등록날짜','등록자아이디'],
        value: []
	}

	isMainResultShow:boolean = false;
	mainHeight:number = 200;
	uuid:any = require('uuid/v4');

    constructor(
        log: LogService, 
        private authService: HostAuthService,
		private msgbusService: MsgbusService,
		private queryService: QueryService,
		private cdr: ChangeDetectorRef,
		private router: Router, 
		private route: ActivatedRoute,
		private AuditRecordService: AuditRecordService
    ) {
		this.logger = log.getLogger("Data Log");
		
		this.searchCheckListStart = this.searchCheckListStart.bind(this);
		this.searchCheckListChange = this.searchCheckListChange.bind(this);

		this.settingCheckTargetAction = this.settingCheckTargetAction.bind(this);
		this.settingCheckTargetResult = this.settingCheckTargetResult.bind(this);

		this.router.routeReuseStrategy.shouldReuseRoute = function() {
            return false;
        }
	}

    ngOnInit() {
		this.mainHeight = window.innerHeight - 193;

		this.searchLog()
	}
	
	@HostListener('window:resize', ['$event'])
    resizeHandler(event) {
        // console.log("resize", event.target.innerHeight)
        this.mainHeight = event.target.innerHeight - 193;
    }

	@HostListener('window:beforeunload', ['$event'])
	beforeunloadHandler(event) {
		if (this.searchCheckListQueryId) {
			this.queryService.removeQuery(this.searchCheckListQueryId);
		}

		if(this.settingCheckTargetQueryId) {
			this.queryService.removeQuery(this.settingCheckTargetQueryId);
		}
	}
    ngOnDestroy() {
		if (this.searchCheckListQueryId) {
			this.queryService.removeQuery(this.searchCheckListQueryId);
		}
		if(this.settingCheckTargetQueryId) {
			this.queryService.removeQuery(this.settingCheckTargetQueryId);
		}
	}

    convertDate(date: Date, format: string): any {
		// format - [year, month, day, hour, minute, second]
		if (!date) {
			return;
		}

		let year = date.getFullYear();
		let month = this.addZeroPadding(date.getMonth() + 1);
		let day = this.addZeroPadding(date.getDate());
		let hour = this.addZeroPadding(date.getHours());
		let minute = this.addZeroPadding(date.getMinutes());
		let second = this.addZeroPadding(date.getSeconds());

		switch (format) {
			case 'year':
				return `${year}`;
			case 'month':
				return `${year}-${month}`;
			case 'day':
				return `${year}-${month}-${day}`;
			case 'hour':
				return `${year}-${month}-${day} ${hour}`;
			case 'minute':
				return `${year}-${month}-${day} ${hour}:${minute}`;
			case 'second':
				return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
			default:
				return date;
		}
    }
    
    private addZeroPadding(dateStr) {
		return `0${dateStr}`.slice(-2);
    }
    
	baseQuery:string = '';
	isCheckSearch:boolean = false;
	selectedID:string = '';
	searchLog () {
		// console.log(this.searchType)
		this.baseQuery = "";
		if(this.selectedID=="") {
			this.baseQuery += "table duration=365d AS_CRETOP_EXCEPT";
			this.baseQuery += " | sort limit=1 -_time by ID, type";
			this.baseQuery += " | search status==\"O\"";
			this.baseQuery += " | rename writer as 등록자아이디, _time as 등록날짜, status as 상태, reason as 제외사유, type as 구분";
			this.baseQuery += " | eval ORG_TABLE = _table"
			this.baseQuery += " | fields ID, 기업명, 등록자아이디, 등록날짜, 상태, 제외사유, 구분, ORG_TABLE"
			
			if(this.searchType!="total") {
				this.baseQuery += " | search 구분==\"" + this.searchType + "\"";
			}
		}
		else {
			let tbName = "KS_CRETOP_LOG_R01, KS_CRETOP_LOG_R02";
			
			if(this.searchType=="total") tbName = "KS_CRETOP_LOG_R01, KS_CRETOP_LOG_R02";
			else if(this.searchType=="biz") tbName = "KS_CRETOP_LOG_R01";
			else tbName = "KS_CRETOP_LOG_R02";

			// 20201218 ID 특수문자 때문에 fulltext 검색에 오류가 나는경우가 있음
			//this.baseQuery += "fulltext \"" + this.selectedID + "\" from " + tbName;
			this.baseQuery += "table " + tbName;
			this.baseQuery += " | search ID==\"" + this.selectedID + "\" or ENPNM==\"" + this.selectedID + "\"";

			// this.baseQuery += " | rename _time as cretoptime";
			
			/** 20201218 예전데에터 import 문제 : 없는 고객 ID 
			this.baseQuery += " | stats count by _table, ID, ENPNM";
			this.baseQuery += " | eval ORG_TABLE = _table"
			this.baseQuery += " | eval type = if(ORG_TABLE==\"KS_CRETOP_LOG_R01\", \"biz\", \"priv\")";
			this.baseQuery += " | join type=left ID, type ["
			this.baseQuery += " table duration=365d AS_CRETOP_EXCEPT";
			this.baseQuery += " | sort limit=1 -_time by ID, type";
			this.baseQuery += " | search status==\"O\"";
			this.baseQuery += " ]";
			this.baseQuery += " | rename ENPNM as 기업명, writer as 등록자아이디, _time as 등록날짜, status as 상태, reason as 제외사유";
			this.baseQuery += " | eval 구분 = type";
			this.baseQuery += " | eval 구분 = if( isnull(구분), ORG_TABLE, type)"
			this.baseQuery += " | eval 구분 = case(구분==\"KS_CRETOP_LOG_R01\", \"biz\", 구분==\"KS_CRETOP_LOG_R02\", \"priv\", 구분)";
			this.baseQuery += " | fields ID, 기업명, 등록자아이디, 등록날짜, 상태, 제외사유, 구분, ORG_TABLE"
			**/

			this.baseQuery += " | stats count by _table, ID, ENPNM";
			this.baseQuery += " | eval ORG_TABLE = _table"
			this.baseQuery += " | eval type = if(ORG_TABLE==\"KS_CRETOP_LOG_R01\", \"biz\", \"priv\")";
			this.baseQuery += " | join type=full ID, type ["
			this.baseQuery += " table duration=365d AS_CRETOP_EXCEPT";
			this.baseQuery += " | sort limit=1 -_time by ID, type";
			//this.baseQuery += " | search status==\"O\"";
			this.baseQuery += " | search ID==\"" + this.selectedID + "\" or 기업명==\"" + this.selectedID + "\"";
			this.baseQuery += " ]";
			this.baseQuery += " | rename ENPNM as 기업명, writer as 등록자아이디, _time as 등록날짜, status as 상태, reason as 제외사유";
			this.baseQuery += " | eval 구분 = type";
			this.baseQuery += " | eval 구분 = if( isnull(구분), ORG_TABLE, type)"
			this.baseQuery += " | eval 구분 = case(구분==\"KS_CRETOP_LOG_R01\", \"biz\", 구분==\"KS_CRETOP_LOG_R02\", \"priv\", 구분)";
			this.baseQuery += " | fields ID, 기업명, 등록자아이디, 등록날짜, 상태, 제외사유, 구분, ORG_TABLE"
		}
		
		//this.baseQuery += " | sort -" + this.searchSort;
		if(this.searchSort=="등록날짜") this.baseQuery += " | sort -" + this.searchSort;
		else this.baseQuery += " | sort " + this.searchSort;

		this.baseQuery += " | eval 등록날짜 = string(등록날짜, \"yyyy-MM-dd HH:mm:ss\")";

		// console.log(this.baseQuery);

		let auditDate:any = {};
        auditDate.menu = "점검대상관리";
		auditDate.type = "조회";
		auditDate.searchType = this.searchType;
		auditDate.selectedID = this.selectedID;
        this.AuditRecordService.importAuditLogger(this.principal.login, auditDate);

		this.searchCheckListStart();

	}
	searchLogStop () {
        this.isCheckSearch = false;
        this.queryService.stopQuery(this.searchCheckListQueryId);
	}
	
	onSelectSearchType (type:string) {
		console.log("search Type")
        // this.searchLog();
    }

	private searchCheckListQueryId;
	searchCheckListStart () {
		if (!!this.searchCheckListQueryId) {
			this.queryService.removeQuery(this.searchCheckListQueryId);
			this.searchCheckListQueryId = null;
		}
		
		this.logListCurrentPage = 1;
		this.logListTotalItems = 0;
		this.pagingArray = [];
		this.logListCurrentStart = 1;

        this.queryService.createQuery(this.baseQuery, { onChanged: this.searchCheckListChange })
        .then((query) => {
            this.queryService.startQuery(query.id)
			.then(() => {
                this.searchCheckListQueryId = query.id;
                this.isCheckSearch = true;
			})
			.catch((msg) => {
				console.log('error', msg);
			});
        })
        .catch((msg) => {
            console.log('error', msg);
        });
	}

	searchCheckListChange (query) {
		if(!!query) {
			if(query.status=="Ended") this.isCheckSearch = false;

			this.searchCheckListResult(query.id, "normal");
		}
	}

	searchCheckListResult (id, type) {
		const offset = (this.logListCurrentPage - 1) * this.logListPageSize;
        const limit = this.logListPageSize;

		this.queryService.getResult(id, offset, limit)
        .then((result) => {
            this.mainTable.value = this.addNumbering(result.records);
            // if(typeof result.fieldOrder === "undefined") this.mainTable.fields = [];
			// else this.mainTable.fields = result.fieldOrder;
			this.logListTotalItems = result.count;

			this.makePagingInfo();
            this.cdr.detectChanges();
        })
        .catch(function (msg) {
            console.log('error', msg);
        });
	}

	addNumbering(arr) {
        for(let i=0; i<arr.length; i++) {
            arr[i]['No'] = i + 1 + ( (this.logListCurrentPage -1) * this.logListPageSize )
        }

        return arr;
	}
	
	// addNumbering(arr) {
    //     for(let i=0; i<arr.length; i++) {
    //         arr[i]['No'] = i + 1 
    //     }

    //     return arr;
	// }
	

	checkTargetRegist:string = "none";
	checkTargetRegistReason:string = "";
	checkTargetRegistItem:any;
	checkTargetRegistClose () {
		this.checkTargetRegist = "none";
	}



	settingCheckTarget (item, idx, actType) {
		// console.log(item);
		this.checkTargetRegistItem = item;
		this.checkTargetRegistReason = "";

		let actText:string = "";
		if(actType=="add") {
			if(item.ORG_TABLE=="KS_CRETOP_LOG_R01") this.importType = "biz"
			else this.importType = "priv"

			actText = "등록";
			this.checkTargetRegist = "inline-block";
		}
		else {
			actText = "삭제";
			if(confirm("[ " + item['기업명'] + " ] " + actText + " 하시겠습니까?")) {
				this.settingCheckTargetAction(item, actType);
			}
		}
	}
	checkTargetRegistAction () {
		this.checkTargetRegist = "none";
		this.settingCheckTargetAction(this.checkTargetRegistItem, "add");
	}

	private settingCheckTargetQueryId;
	settingCheckTargetAction(item, actType) {
		// console.log("item", item);
		let auditDate:any = {};
		auditDate.menu = "점검대상관리";
		if(actType=="add") auditDate.type = "등록";
		else auditDate.type = "삭제";
		auditDate.targetName = item['기업명'];
        this.AuditRecordService.importAuditLogger(this.principal.login, auditDate);

		let inputObj:any = {}
		inputObj['ID'] = item['ID'];
		inputObj['기업명'] = item['기업명'];
		
		if(actType=="add") {
			inputObj['type'] = this.importType;
			inputObj.status = 'O';
			inputObj.reason = this.checkTargetRegistReason;
		}
		else {
			inputObj.status = 'X';
			inputObj['type'] = (item['구분']=="biz") ? "biz" : "priv";
		}

		if (!!this.settingCheckTargetQueryId) {
			this.queryService.removeQuery(this.settingCheckTargetQueryId);
			this.settingCheckTargetQueryId = null;
		}

		let inputQuery = "json \"" + JSON.stringify(inputObj) + "\"";
		inputQuery += " | eval writer = \"" + this.principal.login + "\"";
		inputQuery += " | import AS_CRETOP_EXCEPT";

		this.queryService.createQuery(inputQuery, { onChanged: this.settingCheckTargetResult })
		.then((query) => {
			this.queryService.startQuery(query.id)
			.then(() => {
				this.settingCheckTargetQueryId = query.id;
			})
			.catch((msg) => {
				console.log('error', msg);
			});
		})
		.catch((msg) => {
			console.log('error', msg);
		});
	}

	settingCheckTargetResult (query) {
		if(!!query) {
            // console.log("query", query)
            if(query.status=="Ended") {
				alert("완료 했습니다.");
				this.queryService.removeQuery(this.settingCheckTargetQueryId);
				this.settingCheckTargetQueryId = null;

				this.selectedID = "";
				this.searchLog();
			}
        }
	}


	random() {
        return Math.floor(Math.random() * 300);
    }

    randomStr() {
        return Math.random().toString(36).substr(2,11);
    }
    uuidStr() {
        return this.uuid();
    }
	
	changeStatus () {

	}



	/***** Pagination  *****/
	logListCurrentPage:number = 1;
    logListTotalItems:number = 0;

    logListMaxPageCount:number = 0;
    pagingArray:any = [];
    logListPageSize:number = 15;
    logListPageLength:number = 10;
    logListCurrentStart = 1;

    makePagingInfo () {
        this.pagingArray = [];
        let arrayCount = 0;
		if(this.logListTotalItems>0) this.logListMaxPageCount = Math.ceil(this.logListTotalItems / this.logListPageSize);
		else this.logListMaxPageCount = 0;

        if(this.logListMaxPageCount > this.logListPageLength) arrayCount = this.logListPageLength;
        else arrayCount = this.logListMaxPageCount;

        for(let i=0; i<arrayCount; i++) {
            let inputNum = i + this.logListCurrentStart;
            if(this.logListMaxPageCount >= inputNum) this.pagingArray.push(inputNum)
            else break;
        }
    }
    searchLogPageChanged (pNum) {
        this.logListCurrentPage = pNum;
        this.logListCurrentStart = (Math.ceil(this.logListCurrentPage / this.logListPageLength) - 1) * this.logListPageLength + 1;

        this.searchCheckListResult(this.searchCheckListQueryId ,"page");
    }
    searchLogPageNext () {
        let move = this.logListCurrentPage + 1;
        if(move > this.logListMaxPageCount) move = this.logListMaxPageCount;
        this.searchLogPageChanged(move)
    }
    searchLogPagePrev () {
        let move = this.logListCurrentPage - 1;
        if(move < 1) move = 1;
        this.searchLogPageChanged(move)
    }
    searchLogPageNextJump () {
        let move = this.logListCurrentPage + this.logListPageLength;
        if(move > this.logListMaxPageCount) move = this.logListMaxPageCount;
        this.searchLogPageChanged(move)
    }
    searchLogPagePrevJump () {
        let move = this.logListCurrentPage - this.logListPageLength;
        if(move < 1) move = 1;
        this.searchLogPageChanged(move)
    }

}