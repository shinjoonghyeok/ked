import { Injectable } from '@angular/core';
import { Logger, LogService, MsgbusService } from 'sonar-angular5-sdk';

@Injectable()
export class AnswerService {
    private logger: Logger;

    constructor(log: LogService, private msgbus: MsgbusService) {
		this.logger = log.getLogger("Answer Service");
	}
    
    csvDownload(charset: string, filename: string, fields: any, offset: number, limit: number, query_id: number): Promise<string> {
		return this.msgbus.call('com.logpresso.core.msgbus.DbPlugin.prepareQueryResultDownload', {
            'charset': charset,
			'offset': offset,
			'limit': limit,
			'filetype': 'csv',
			'filename': filename,
			'fields': fields,
			'query_id': query_id
		}).then(msg => {
			return msg.params.token;
		});
	}

	remoteIPAddress() {
		return this.msgbus.call('com.answer.datalog.sonar.api.main.DatalogMainMsgBus.getLoginSessionIPAddress', {}).then(msg => {
			return msg;
		});
	}
}