import { Component, OnInit, HostListener, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { $ } from 'protractor';
import { Logger, LogService, QueryService, MsgbusService, getColumnDefs, HostAuthService, Principal, insertThousandSeperator, FileService } from 'sonar-angular5-sdk';

import { AuditRecordService } from './audit-record.service';
import { AnswerService } from './answer.service';

import * as Highcharts from 'highcharts';
require('highcharts/highcharts-more')(Highcharts);
require('highcharts/modules/no-data-to-display')(Highcharts);
require('highcharts/modules/treemap')(Highcharts);

import * as XLSX from 'xlsx';
import { HttpInterceptingHandler } from '@angular/common/http/src/module';
import { query } from '@angular/core/src/render3';

@Component ({
    selector: 'routine-check',
    templateUrl: '../html/routine-check.html',
    styleUrls: ['../common.less','../css/answer.css']
})

export class RoutineCheckComponent implements OnInit, OnDestroy {
	private logger: Logger;
	private pIdx: string;
	private pType: string;

    searchDate:Date = new Date();
    get searchMonthStr():string { return this.searchDate == null ? '' : this.convertDate(this.searchDate, 'month') }
    get searchYearStr():string { return this.searchDate == null ? '' : this.convertDate(this.searchDate, 'year') }

    get principal(): Principal {
		return this.authService.getPrincipal();
	}

    startYear:any = '2019';

    searchMonth:any = this.convertStringToPreDate(this.searchMonthStr);
    searchMonthList:any = [];
	
	searchType:string = 'biz';
    searchTypeList:any = [
        {name:'기업정보',type:'biz'},
        {name:'개인정보',type:'priv'}
	];

	searchSortDisplay:string = 'inline-block';
	
	searchSort:string = 'IQENPCN';
    searchSortList:any = [];
    searchSortListBiz:any = [
        {name:'조회기업수순',type:'IQENPCN'},
        {name:'이용시간순',type:'CNETTM'}
    ];
    searchSortListPriv:any = [
        {name:'조회개인수순',type:'IQINDVCN'},
        {name:'조회건수순',type:'IQCN'}
	];
	
	searchValue:string = "";

	// searchShowType:string = 'total';
	// searchShowTypeList:any = [
	// 	{name:'전체',type:'total'},
    //     {name:'1년 이내 점검대상 제외',type:'excep'},
	// ]
	// searchFilter1:string = 'total';
	// searchFilterList1:any = [
	// 	{name:'전체',type:'total'},
    //     {name:'기업명중복제거',type:'nameFilter'},
	// ]
	// searchFilter2:string = 'total';
	// searchFilterList2:any = [
	// 	{name:'전체',type:'total'},
    //     {name:'금융/공공/대기업제외',type:'bizFilter'},
	// ]

	// searchFilterList:any = {
	// 	filterYear: { name: '1년 이상 점검대상 제외', value: false, key: 'filterYear' },
	// 	filterName: { name: '기업명 중복 제거', value: false, key: 'filterName' },
	// 	filterFund: { name: '금융기관 제외', value: false, key: 'filterFund' },
	// 	filterMid: { name: '중소기업 제외', value: false, key: 'filterMid' },
	// 	filterBig: { name: '대기업 제외', value: false, key: 'filterBig' }
	// }

	searchFilterList:any = [
		{ name: '1년 이내 점검대상 제외 (ID)', value: false, key: 'filterYearID' },
		{ name: '1년 이내 점검대상 제외 (기업명)', value: false, key: 'filterYearName' },
		{ name: '기업명 중복 제거', value: false, key: 'filterName' },
		{ name: '금융기관 제외', value: false, key: 'filterFund' },
		// { name: '중소기업 제외', value: false, key: 'filterMid' },
		{ name: '대기업 제외', value: false, key: 'filterBig' }
	]

	// showFilterYear:boolean = false;
	// showFilterName:boolean = false;
	// showFilterFund:boolean = false;
	// showFilterMid:boolean = false;
	// showFilterBig:boolean = false;

	detailInfoDisplay:string = 'none';

	isMainResultShow:boolean = false;
	mainHeight:number = 200;
	modalHeight:number = 500;
	uuid:any = require('uuid/v4');

	filterStr:string = '검색조건 선택';
	mainTable:any = {
        fields: ['No','ID','기업명','기업구분','상품명','가격정책','라인수','조회건수','조회기업수','당월이용시간','Email'],
        value: [],
		count: 0
	}

	privDetailField = ['조회일시', '상품구분', '기업명', '부서명', '조회자', '이용정보', '조회대상자', '주민등록번호', '생년월일', '성별', '조회목적', '동의여부'];
	
	detailList:any = [];

    constructor(
        log: LogService, 
        private authService: HostAuthService,
		private msgbusService: MsgbusService,
		private queryService: QueryService,
		private cdr: ChangeDetectorRef,
		private router: Router, 
		private route: ActivatedRoute,
		private AuditRecordService: AuditRecordService,
		private fileService: FileService,
		private answerService: AnswerService
    ) {
		this.logger = log.getLogger("Data Log");
		this.pIdx = route.snapshot.params['pIdx'];
		this.pType = route.snapshot.params['pType'];

		// if(this.pIdx == "0") this.searchMonth = this.convertStringToPreDate(this.searchMonthStr);//this.convertDate(this.searchDate, 'month')
		// else this.searchMonth = this.pIdx;

		// if(this.pType== "0") this.searchType = 'biz';
		// else this.searchType = this.pType;
        
        
		this.searchCheckedStart = this.searchCheckedStart.bind(this);
		this.searchCheckedChange = this.searchCheckedChange.bind(this);

		this.importCretopCheckList = this.importCretopCheckList.bind(this);
		this.importCretopCheckResult = this.importCretopCheckResult.bind(this);

		this.importFinalStart = this.importFinalStart.bind(this);
		this.importFinalResult = this.importFinalResult.bind(this);

		this.detailSearchIPInfoStart = this.detailSearchIPInfoStart.bind(this);
		this.detailSearchIPInfoResult = this.detailSearchIPInfoResult.bind(this);

		this.detailSearchAvgInfoStart = this.detailSearchAvgInfoStart.bind(this);
		this.detailSearchAvgInfoResult = this.detailSearchAvgInfoResult.bind(this);

		this.detailSearchSumInfoStart = this.detailSearchSumInfoStart.bind(this);
		this.detailSearchSumInfoChange = this.detailSearchSumInfoChange.bind(this);

		this.router.routeReuseStrategy.shouldReuseRoute = function() {
            return false;
        }
	}

    ngOnInit() {
		this.mainHeight = window.innerHeight - 229;
		this.modalHeight = window.innerHeight - 350;

		for(let i=this.startYear; i<=this.searchYearStr; i++) {
            for(let j=1; j<13; j++) {
                let inputStr = i + "-" + this.addZeroPadding(j);
                this.searchMonthList.push({name:inputStr, type:inputStr});
            }
		}

		this.searchSortList = this.searchSortListBiz;

		if(this.pIdx == "0") this.searchMonth = this.convertStringToPreDate(this.searchMonthStr);//this.convertDate(this.searchDate, 'month')
		else this.searchMonth = this.pIdx;

		if(this.pType== "0") this.searchType = 'biz';
		else this.searchType = this.pType;


		this.detailInfo = {};

		this.detailInfo.usedIPCount = '';
		this.detailInfo.ipInfo = [];
		this.detailInfo.ipInfoCount = 0;
		this.detailInfo.userInfo = [];
		this.detailInfo.searchUserCount = '';
		this.detailInfo.loggedDepartCount = '';
		this.detailInfo.firstUseDate = '';
		this.detailInfo.avgCount = '';
		this.detailInfo.usedDuration = '';
		this.detailInfo.managerName = '';
		this.detailInfo.managerEmail = '';
		this.detailInfo.managerPhone = '';
		this.detailInfo.sumList = [];


		// if(this.pIdx != "0" && this.pType != "0") this.searchLog();
		this.searchLog();
		// this.cdr.detectChanges();
	}
	
	@HostListener('window:resize', ['$event'])
    resizeHandler(event) {
		this.mainHeight = event.target.innerHeight - 229;
		this.modalHeight = event.target.innerHeight - 350;
    }

	@HostListener('window:beforeunload', ['$event'])
	beforeunloadHandler(event) {
		if (this.searchCheckedQueryId) {
			this.queryService.removeQuery(this.searchCheckedQueryId);
		}
		if(this.importCretopCheckQueryId) {
			this.queryService.removeQuery(this.importCretopCheckQueryId);
		}
		if(this.importFinalQueryId) {
			this.queryService.removeQuery(this.importFinalQueryId);
		}

		if(this.chkecInterval!=null) {
			clearInterval(this.chkecInterval);
		}

		if(this.detailSearchIPInfoQueryId) {
			this.queryService.removeQuery(this.detailSearchIPInfoQueryId);
		}
		if(this.detailSearchAvgInfoQueryId) {
			this.queryService.removeQuery(this.detailSearchAvgInfoQueryId);
		}
		if(this.detailSearchSumInfoQueryId) {
			this.queryService.removeQuery(this.detailSearchSumInfoQueryId);
		}

	}
    ngOnDestroy() {
		if (this.searchCheckedQueryId) {
			this.queryService.removeQuery(this.searchCheckedQueryId);
		}
		if(this.importCretopCheckQueryId) {
			this.queryService.removeQuery(this.importCretopCheckQueryId);
		}
		if(this.importFinalQueryId) {
			this.queryService.removeQuery(this.importFinalQueryId);
		}

		if(this.chkecInterval!=null) {
			clearInterval(this.chkecInterval);
		}

		if(this.detailSearchIPInfoQueryId) {
			this.queryService.removeQuery(this.detailSearchIPInfoQueryId);
		}
		if(this.detailSearchAvgInfoQueryId) {
			this.queryService.removeQuery(this.detailSearchAvgInfoQueryId);
		}
		if(this.detailSearchSumInfoQueryId) {
			this.queryService.removeQuery(this.detailSearchSumInfoQueryId);
		}
	}

	convertStringToStamp(dateStr) {
		let parts = dateStr.split('-');
        return new Date(parts[0], parts[1] -1).getTime();
	}

	convertStringToTargetDate(dateStr, target) {
		let calDate = 1 + target
        let parts = dateStr.split('-');
        let date = new Date(parts[0], parts[1] - calDate);
        let year = date.getFullYear();
		let month = this.addZeroPadding(date.getMonth() + 1);
        
        return `${year}-${month}`;
    }

    convertStringToPreDate(dateStr) {
        let parts = dateStr.split('-');
        let date = new Date(parts[0], parts[1] -2);
        let year = date.getFullYear();
		let month = this.addZeroPadding(date.getMonth() + 1);
        
        return `${year}-${month}`;
    }

    convertCalDate(dateStr, target) {
        let parts = dateStr.split('-');
        let timeStamp = new Date(parts[0], parts[1] -1, parts[2]).getTime() + ((24*60*60*1000) * target);
        let calDate = new Date(timeStamp);
        return this.convertDate(calDate, 'day');
    }

    convertDateAdd(target) {
        let timeStamp = new Date().getTime() + ((24*60*60*1000) * target);
        return new Date(timeStamp);
    }
    
    convertStringToDatePlus(dateStr) {
        let parts = dateStr.split('-');
        let timeStamp = new Date(parts[0], parts[1] -1, parts[2]).getTime() + (1*24*60*60*1000);
        return new Date(timeStamp);
    }

    convertStringToDate(dateStr) {
        let parts = dateStr.split('-');
        return new Date(parts[0], parts[1] -1, parts[2])
	}

    convertDate(date: Date, format: string): any {
		// format - [year, month, day, hour, minute, second]
		if (!date) {
			return;
		}

		let year = date.getFullYear();
		let month = this.addZeroPadding(date.getMonth() + 1);
		let day = this.addZeroPadding(date.getDate());
		let hour = this.addZeroPadding(date.getHours());
		let minute = this.addZeroPadding(date.getMinutes());
		let second = this.addZeroPadding(date.getSeconds());

		switch (format) {
			case 'year':
				return `${year}`;
			case 'month':
				return `${year}-${month}`;
			case 'day':
				return `${year}-${month}-${day}`;
			case 'hour':
				return `${year}-${month}-${day} ${hour}`;
			case 'minute':
				return `${year}-${month}-${day} ${hour}:${minute}`;
			case 'second':
				return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
			default:
				return date;
		}
    }
    
    private addZeroPadding(dateStr) {
		return `0${dateStr}`.slice(-2);
    }

    random() {
        return Math.floor(Math.random() * 300);
    }

    randomStr() {
        return Math.random().toString(36).substr(2,11);
    }
    uuidStr() {
        return this.uuid();
    }
    
	baseQuery:string = '';
	isCheckedSearch:boolean = false;

	onSelectSearchSort (type:string) {
        this.searchLog();
    }
	
	onSelectSearchType (type:string) {
		if(type=='biz') {
            this.searchSortList = this.searchSortListBiz;
            this.searchSort = 'IQENPCN';
        }
        else {
            this.searchSortList = this.searchSortListPriv;
            this.searchSort = 'IQINDVCN';
		}
		
		this.detailInfo.sumList = [];
        this.searchLog();
    }

    onSelectSearchMonth (type:string) {
        this.searchLog();
	}
	
	testPopover () {
		// console.log("testPopover")
	}


    searchLog () {
		let tableName = "KS_CRETOP_LOG_R01";
        this.mainTable.fields = ['No','ID','기업명','기업구분','상품명','가격정책','라인수','조회건수','조회기업수','당월이용시간','이메일'];

        if(this.searchType=="priv") {
            tableName = "KS_CRETOP_LOG_R02";
            this.mainTable.fields = ['No','ID','기업명','기업구분','상품명','가격정책','라인수','조회건수','조회개인수','이메일'];
		}
		this.mainTable.value = [];

		//this.baseQuery = "fulltext crdate == \"" + this.searchMonth + "\" and type == \"" + this.searchType + "\" from AS_CRETOP_SELECT"
		this.baseQuery = "table AS_CRETOP_SELECT | search crdate == \"" + this.searchMonth + "\" and type == \"" + this.searchType + "\"";

		if(this.searchValue!="") this.baseQuery += " | search ID==\"" + this.searchValue + "\"";

		//this.baseQuery += " | join type=left ID [ table " + tableName + " |  search crdate == \"" + this.searchMonth + "\" ]"
		this.baseQuery += " | join type=left ID, crdate [ table " + tableName + " ]"
		this.baseQuery += " | join type=left ID [ table KS_CRETOP_LOG_R03 | sort limit=1 -계약번호 by ID | fields - crdate] ";

		this.baseQuery += " | eval 날짜 = crdate";

		if(this.searchType=="biz") {
			this.baseQuery += " | rename CNETTM as 당월이용시간, ENPNM as 기업명, INSTCLS as 기업구분, IQCN as 조회건수, IQENPCN as 조회기업수, LINECN as 라인수, SVCD as 상품명, USETMCD as 가격정책, IQINDVCN as 조회개인수";

		}
		else {
			this.baseQuery += " | rename CNETTM as 당월이용시간, ENPNM as 기업명, INSTCLS as 기업구분, IQCN as 조회건수OLD, IQENPCN as 조회기업수, LINECN as 라인수, SVCD as 상품명, USETMCD as 가격정책, IQINDVCN as 조회개인수OLD";
			this.baseQuery += " | join type=left ID, crdate [ table KS_CRETOP_LOG_R04 | stats count by ID, crdate | rename count as 조회건수 ]  ";
			this.baseQuery += " | join type=left ID, crdate [ table KS_CRETOP_LOG_R04 | stats count by ID, crdate, 조회대상자주민등록번호 | stats count by ID, crdate | rename count as 조회개인수 ]  ";
		}

		this.baseQuery += " | eval path=\"CHECK\"";
		//this.baseQuery += " | join type=left ID [ table AS_CRETOP_FINAL | search crdate == \"" + this.searchMonth + "\" and type == \"" + this.searchType + "\" | eval path=\"FINAL\" ]";
		this.baseQuery += " | join type=left ID, crdate [ table AS_CRETOP_FINAL | search type == \"" + this.searchType + "\" | eval path=\"FINAL\" ]";

		for(let i=0; i<this.searchFilterList.length; i++) {
			if(this.searchFilterList[i].value) {
				switch(this.searchFilterList[i].key) {
					case 'filterYearID':
						this.baseQuery += " | join type=leftonly ID,type [ table duration=365d AS_CRETOP_EXCEPT | sort limit=1 -_time by ID,type | search status==\"O\" | rename id as ID ]";
					break;
					case 'filterYearName':
						this.baseQuery += " | join type=leftonly 기업명,type [ table duration=365d AS_CRETOP_EXCEPT | sort limit=1 -_time by 기업명,type | search status==\"O\" ]";
					break;
					case 'filterName':
						this.baseQuery += " | sort limit=1 -조회건수 by 기업명"
					break;
					case 'filterFund':
						this.baseQuery += " | search 기업구분!=\"03\" and 기업구분!=\"04\""
					break;
					case 'filterMid':
						this.baseQuery += " | search 기업구분!=\"02\""
					break;
					case 'filterBig':
						this.baseQuery += " | search 기업구분!=\"01\""
					break;
					default:
					break;
				}
			}
		}
		this.baseQuery += " | eval 기업구분 = case(기업구분==\"01\",\"대기업\",기업구분==\"02\",\"중소기업\",기업구분==\"03\",\"제1금융기관\",기업구분==\"04\",\"기타금융기관\",기업구분==\"99\",\"구분없음\",기업구분)"
        this.baseQuery += " | eval 상품명 = case(상품명==\"01\",\"CRETOP\",상품명==\"03\",\"CRETOP+C-PATROL\",상품명==\"04\",\"EW\",상품명==\"05\",\"CRETOP+EW\",상품명==\"06\",\"CRETOP+NOTE\",상품명==\"07\",\"CRETOP+EW+NOTE\",상품명)";
		this.baseQuery += " | eval 가격정책 = case(가격정책==\"01\", \"무제한(정액제)\",가격정책==\"02\", \"월4시간(종량제)\",가격정책==\"03\", \"월12시간(종량제)\",가격정책)";

		if(this.searchType=="biz") {
			this.baseQuery += " | join type=left ID ["
			this.baseQuery += " table KS_CRETOP_LOG_R01 | search crstamp >= " + this.convertStringToStamp(this.convertStringToTargetDate(this.searchMonth, 2)) / 1000  + " and crstamp <= " + this.convertStringToStamp(this.searchMonth) / 1000;
			this.baseQuery += " | stats sum(IQCN) as 조회합계, sum(IQENPCN) as 조회기업수합계 by ID, crdate";
			this.baseQuery += " | stats avg(조회합계) as 3개월평균조회수, avg(조회기업수합계) as 3개월평균조회기업수 by ID"

			this.baseQuery += " ]"
		}

		this.baseQuery += " | sort limit=1 조회건수 by ID"
		this.baseQuery += " | fields ID, 기업명, 기업구분, 상품명, 가격정책, 라인수, 조회건수, 조회기업수, 조회개인수, 당월이용시간, 이메일, 관리자1, 전화번호, 해당ID최초이용시작일, 3개월평균조회수, 3개월평균조회기업수, 구분, path";

		switch(this.searchSort) {
            case "IQENPCN":
                this.baseQuery += " | sort -조회기업수";
            break;
            case "CNETTM":
                this.baseQuery += " | sort -당월이용시간";
            break;
            case "IQINDVCN":
                this.baseQuery += " | sort -조회개인수";
            break;
            case "IQCN":
                this.baseQuery += " | sort -조회건수";
            break;
            default:
            break;
        }

		// console.log(this.baseQuery)

		let auditDate:any = {};
        auditDate.menu = "정기점검대상검토";
        auditDate.type = "조회";
        auditDate.searchMonth = this.searchMonth;
		auditDate.searchType = this.searchType;
		auditDate.searchSort = this.searchSort;
		auditDate.filterYearID = this.searchFilterList[0].value;
		auditDate.filterYearName = this.searchFilterList[1].value;
		auditDate.filterName = this.searchFilterList[2].value;
		auditDate.filterFund = this.searchFilterList[3].value;
		// auditDate.filterMid = this.searchFilterList[3].value;
		auditDate.filterBig = this.searchFilterList[4].value;
		auditDate.searchValue = this.searchValue;
        this.AuditRecordService.importAuditLogger(this.principal.login, auditDate);

        this.searchCheckedStart();
	}


	getCretopList (callback) {
        this.queryService.getResult(this.searchCheckedQueryId, 0, this.mainTable.count)
        .then((result) => {
            callback(result.records);
        })
        .catch(function (msg) {
            console.log('error', msg);
        });
	}
	
	exportExcel () {
        let auditDate:any = {};
        auditDate.menu = "정기점검대상검토";
        auditDate.type = "조회";
        auditDate.searchMonth = this.searchMonth;
		auditDate.searchType = this.searchType;
		auditDate.searchSort = this.searchSort;
		auditDate.filterYearID = this.searchFilterList[0].value;
		auditDate.filterYearName = this.searchFilterList[1].value;
		auditDate.filterName = this.searchFilterList[2].value;
		auditDate.filterFund = this.searchFilterList[3].value;
		// auditDate.filterMid = this.searchFilterList[3].value;
		auditDate.filterBig = this.searchFilterList[4].value;
		auditDate.searchValue = this.searchValue;
		this.AuditRecordService.importAuditLogger(this.principal.login, auditDate);

		let fileName = "크래탑_점검대상검토(" + this.searchMonth + ").xlsx";
		const wb: XLSX.WorkBook = XLSX.utils.book_new();
		
		let defineHeader = [];
        if(this.searchType=="biz") {
			defineHeader = ['ID','기업명','기업구분','상품명','가격정책','라인수','조회건수','조회기업수','당월이용시간','이메일'];
		}
        else {
            defineHeader = ['ID','기업명','기업구분','상품명','가격정책','라인수','조회건수','조회개인수','이메일'];
		}
		
		if(this.logListTotalItems > 10000) {
            if(confirm("전체 10,000 건 이상의 데이터 경우 CSV 로 다운로드 해야 합니다.")) {
                let charset = 'MS949';
                let filename = "크래탑_점검대상검토(" + this.searchMonth + ").csv";
                let fields = defineHeader;
                let offset = 0;
                let limit = this.mainTotalCount;
                let query_id = this.searchCheckedQueryId;
                
                this.answerService.csvDownload(charset, filename, fields, offset, limit, query_id).then(token => {
                    this.fileService.download(token);
                });
            }
        }
        else {
            this.getCretopList((data) => {
				const ws: XLSX.WorkSheet =XLSX.utils.json_to_sheet(data, {header: defineHeader});
				XLSX.utils.book_append_sheet(wb, ws, '점검대상검토');
				XLSX.writeFile(wb, fileName);
			});
        }
    }


	private searchCheckedQueryId;
	mainTotalCount:number = 0;
	searchCheckedStart () {
		if (!!this.searchCheckedQueryId) {
			this.queryService.removeQuery(this.searchCheckedQueryId);
			this.searchCheckedQueryId = null;
        }
		this.mainTable.count = 0;

        this.queryService.createQuery(this.baseQuery, { onChanged: this.searchCheckedChange })
        .then((query) => {
            this.queryService.startQuery(query.id)
			.then(() => {
                this.searchCheckedQueryId = query.id;
                this.isCheckedSearch = true;
			})
			.catch((msg) => {
				console.log('error', msg);
			});
        })
        .catch((msg) => {
            console.log('error', msg);
        });
	}

	searchCheckedChange (query) {
		if (!!query) {
            if(query.status=="Ended") this.isCheckedSearch = false;
			this.searchCheckedResult(query.id);
		}
	}
	
	searchCheckedResult(id) {
		this.queryService.getResult(id, 0, 5000)
        .then((result) => {
            // this.mainTable.value = result.records
            // if(typeof result.fieldOrder === "undefined") this.mainTable.fields = [];
            // else this.mainTable.fields = result.fieldOrder;
			this.mainTable.count = result.count;
			this.mainTable.value = this.addNumbering(result.records);
			this.mainTotalCount = result.count;

            this.cdr.detectChanges();
        })
        .catch(function (msg) {
            console.log('error', msg);
        });
	}

	searchLogStop () {
        this.isCheckedSearch = false;
        this.queryService.stopQuery(this.searchCheckedQueryId);
	}
	
	addNumbering(arr) {
        for(let i=0; i<arr.length; i++) {
            arr[i]['No'] = i + 1;
        }
        return arr;
    }

	deleteCheckTarget(idx) {
		let name = this.mainTable.value[idx]['기업명'];
		if(confirm("[ " + name + " ] 삭제하시겠습니까?")) {
			
			let auditDate:any = {};
			auditDate.menu = "정기점검대상검토";
			auditDate.type = "점검제외";
			auditDate.detailName = name;
			this.AuditRecordService.importAuditLogger(this.principal.login, auditDate);

			this.mainTable.value.splice(idx, 1);
			this.mainTable.count--;
		}
	}

	detailInfo:any = {};
	showCheckedDetail (item) {
		// console.log(item)

		let auditDate:any = {};
        auditDate.menu = "정기점검대상검토";
        auditDate.type = "상세조회";
        auditDate.detailName = item['기업명'];
        this.AuditRecordService.importAuditLogger(this.principal.login, auditDate);

		this.detailInfoDisplay='inline-block';
		this.detailInfo = {};

		this.detailInfo.usedIPCount = 0;
		this.detailInfo.ipInfo = [];
		this.detailInfo.ipInfoCount = 0;
		this.detailInfo.userInfo = [];
		this.detailInfo.userInfoCount = 0;
		this.detailInfo.searchUserCount = 0;
		this.detailInfo.loggedDepartCount = 0;
		this.detailInfo.firstUseDate = item['해당ID최초이용시작일'];
		this.detailInfo.avgCount = 0;
		this.detailInfo.usedDuration = item['당월이용시간'];
		this.detailInfo.managerName = item['관리자1'];
		this.detailInfo.managerEmail = item['이메일'];
		this.detailInfo.managerPhone = item['전화번호'];

		this.detailInfo.avgSearchCount = item['3개월평균조회수'];
		this.detailInfo.avgBizCount = item['3개월평균조회기업수'];
		this.detailInfo.searchCount = item['조회건수'];
		this.detailInfo.bizCount = item['조회기업수'];

		this.detailInfo.privCount = item['조회개인수'];

		this.detailSearchIPInfoStart(item);
		this.detailSearchAvgInfoStart(item);
		if(this.searchType=="priv") this.detailSearchSumInfoStart(item);


		this.cdr.detectChanges();
	}

	

	private detailSearchAvgInfoQueryId;
	detailSearchAvgInfoStart (item) {
		if (!!this.detailSearchAvgInfoQueryId) {
			this.queryService.removeQuery(this.detailSearchAvgInfoQueryId);
			this.detailSearchAvgInfoQueryId = null;
		}

		let queryStr = "";
		queryStr += "table from=" + this.convertStringToTargetDate(this.searchMonth, 2).replace(/-/gi,'') + " to=" + this.convertStringToTargetDate(this.searchMonth, -1).replace(/-/gi,'') + " KS_CRETOP_TCP018 | search ID==\"" + item['ID'] + "\"";
		queryStr += " | eval month = substr(string(_time), 0, 7)"
		queryStr += " | fields month | stats count by month";
		queryStr += " | stats avg(count) as average | eval average = int(average)"

		// console.log(queryStr)

		this.queryService.createQuery(queryStr, { onChanged: this.detailSearchAvgInfoResult })
        .then((query) => {
            this.queryService.startQuery(query.id)
			.then(() => {
				this.detailSearchAvgInfoQueryId = query.id;
			})
			.catch((msg) => {
				console.log('error', msg);
			});
        })
        .catch((msg) => {
            console.log('error', msg);
        });

	}
	detailSearchAvgInfoResult (query) {
		if(!!query) {
			if(query.status=="Ended") {
				this.queryService.getResult(query.id, 0, 5)
				.then((result) => {
					// console.log("AVG", result)
					this.detailInfo.avgCount = result.records[0].average;
					this.cdr.detectChanges();
				})
				.catch(function (msg) {
					console.log('error', msg);
				});
			}
		}
	}


	
	private detailSearchIPInfoQueryId;
	isDetailShow:boolean = false;
	detailSearchIPInfoStart (item) {
		if (!!this.detailSearchIPInfoQueryId) {
			this.queryService.removeQuery(this.detailSearchIPInfoQueryId);
			this.detailSearchIPInfoQueryId = null;
		}
		
		let queryStr = "";
		if(this.searchType=="biz") {
			queryStr += "table from=" + this.searchMonth.replace(/-/gi,'') + " to=" + this.convertStringToTargetDate(this.searchMonth, -1).replace(/-/gi,'') + " KS_CRETOP_TCP017 | search ID==\"" + item['ID'] + "\"";
			queryStr += " | fields CNET_IP, INDV_ID";
			queryStr += " | stats count by INDV_ID, CNET_IP";
			queryStr += " | join type=left INDV_ID [ fulltext  ID==\"" + item['ID'] + "\" from  KS_CRETOP_TCP012 |  sort limit=1  -_time by INDV_ID ]";
			queryStr += " | eval IP = if(isnotnull(CNET_IP), concat(int(substr(CNET_IP,0,3)), \".\", int(substr(CNET_IP,3,6)), \".\", int(substr(CNET_IP,6,9)), \".\", int(substr(CNET_IP,9,12))), CNET_IP)";
			queryStr += " | rename count as  ipcount";

			queryStr += " | join type=left INDV_ID [ table from=" + this.searchMonth.replace(/-/gi,'') + " to=" + this.convertStringToTargetDate(this.searchMonth, -1).replace(/-/gi,'') + " KS_CRETOP_TCP103 ";
			queryStr += " | search ID==\"" + item['ID'] + "\" and IQ_ENP_CN != 0";
			queryStr += " | stats sum(IQ_CN) as usercount by INDV_ID ]"

			// queryStr += " | join type=left INDV_ID [ table from=" + this.searchMonth.replace(/-/gi,'') + " to=" + this.convertStringToTargetDate(this.searchMonth, -1).replace(/-/gi,'') + "  KS_CRETOP_TCP018 | search ID==\"" + item['ID'] + "\" | stats count by INDV_ID | rename count as usercount ] "
			// queryStr += " | fields INDV_ID, CNET_IP, D_NM, NAME, IP, ipcount, usercount";

			queryStr += " | sort INDV_ID";
		}
		else {
			// queryStr += "table from=" + this.searchMonth.replace(/-/gi,'') + " to=" + this.convertStringToTargetDate(this.searchMonth, -1).replace(/-/gi,'') + " KS_CRETOP_TCP017 | search ID==\"" + item['ID'] + "\"";
			// queryStr += " | fields INDV_ID";
			// queryStr += " | stats count by INDV_ID";
			// queryStr += " | join type=left INDV_ID [ fulltext  ID==\"" + item['ID'] + "\" from  KS_CRETOP_TCP012 |  sort limit=1  -_time by INDV_ID ]";
			// queryStr += " | fields INDV_ID, CNET_IP, D_NM, NAME";
			// queryStr += " | join type=left INDV_ID [ table from=" + this.searchMonth.replace(/-/gi,'') + " to=" + this.convertStringToTargetDate(this.searchMonth, -1).replace(/-/gi,'') + " KS_CRETOP_TCP103 ";
			// queryStr += " | search ID==\"" + item['ID'] + "\"";
			// queryStr += " | stats sum(MENU_ID1_CN) as MyCretop, sum(MENU_ID2_CN) as 조기경보, sum(MENU_ID3_CN) as 기업정보, sum(MENU_ID4_CN) as 기업인정보, sum(MENU_ID5_CN) as 신용정보, sum(MENU_ID6_CN) as 산업그룹정보, sum(MENU_ID7_CN) as 경영지원정보, sum(MENU_ID8_CN) as 기타 by INDV_ID  ]";
			// queryStr += " | sort INDV_ID";

			queryStr += "table from=" + this.searchMonth.replace(/-/gi,'') + " to=" + this.convertStringToTargetDate(this.searchMonth, -1).replace(/-/gi,'') + " KS_CRETOP_TCP017 | search ID==\"" + item['ID'] + "\"";
			queryStr += " | fields INDV_ID";
			queryStr += " | stats count by INDV_ID";
			queryStr += " | join type=left INDV_ID [ fulltext  ID==\"" + item['ID'] + "\" from  KS_CRETOP_TCP012 |  sort limit=1  -_time by INDV_ID ]";
			queryStr += " | fields INDV_ID, CNET_IP, D_NM, NAME";
			
			// queryStr += " | join type=left NAME [ table KS_CRETOP_LOG_R04 | search crdate == \"" + this.searchMonth + "\" | rename 조회자 as NAME | stats count by ID, NAME, 조회목적 | rename count as 조회개수 ] "
			// queryStr += " | join type=left NAME [ table KS_CRETOP_LOG_R04 | search crdate == \"" + this.searchMonth + "\" | rename 조회자 as NAME | stats count by ID, 조회대상자주민등록번호, NAME | stats count by ID, NAME |  rename count as 조회개인개수 ] "
			queryStr += " | join type=left INDV_ID [ table KS_CRETOP_LOG_R04 | search crdate == \"" + this.searchMonth + "\" and ID==\"" + item['ID'] + "\" | rename 조회자 as NAME, 개인ID as INDV_ID | stats count by ID, INDV_ID, 조회목적 | rename count as 조회개수 ] "
			queryStr += " | join type=left INDV_ID [ table KS_CRETOP_LOG_R04 | search crdate == \"" + this.searchMonth + "\" and ID==\"" + item['ID'] + "\" | rename 조회자 as NAME, 개인ID as INDV_ID | stats count by ID, 조회대상자주민등록번호, INDV_ID | stats count by ID, INDV_ID |  rename count as 조회개인개수 ] "
			queryStr += " | search isnotnull(ID)"
			queryStr += " | sort INDV_ID, 조회목적"
		}

		// console.log(queryStr)

        this.queryService.createQuery(queryStr, { onChanged: this.detailSearchIPInfoResult })
        .then((query) => {
            this.queryService.startQuery(query.id)
			.then(() => {
				this.detailSearchIPInfoQueryId = query.id;
				this.isDetailShow = true;
			})
			.catch((msg) => {
				console.log('error', msg);
			});
        })
        .catch((msg) => {
            console.log('error', msg);
        });
	}

	detailSearchIPInfoResult (query) {
		if(!!query) {
			if(query.status=="Ended") {
				this.isDetailShow = false;

				this.queryService.getResult(query.id, 0, 5000)
				.then((result) => {
					// console.log("result", result);

					if(this.searchType=="biz") this.makeBizVariable(result.records)
					else  this.makePriveValriabe(result.records);
					this.cdr.detectChanges();
				})
				.catch(function (msg) {
					console.log('error', msg);
				});
			}
		}
	}

	makePriveValriabe (result) {
		let userInfoArray:any = [];
		let userCountArray:any = [];
		let deptCountArray:any = [];

		for(let i=0; i<result.length; i++) {
			if(userCountArray.findIndex(x => x === result[i]['INDV_ID']) == -1) userCountArray.push(result[i]['INDV_ID'])
			if(deptCountArray.findIndex(x => x === result[i]['D_NM']) == -1) deptCountArray.push(result[i]['D_NM'])

			let inputObj:any = {};
			inputObj.idnum = "";
			inputObj.ipaddr = [];
			inputObj.pricount = [];

			let chkIdx = userInfoArray.findIndex(x => x.idnum == result[i]['INDV_ID']);
			// console.log(chkIdx);
			if(chkIdx == -1) {
				inputObj.idnum = result[i]['INDV_ID'];
				inputObj.depart = result[i]['D_NM'];
				inputObj.name = result[i]['NAME'];
				inputObj.pricount.push({name:result[i]['조회목적'], count:result[i]['조회개수']});

				userInfoArray.push(inputObj);
			}
			else {
				userInfoArray[chkIdx].pricount.push({name:result[i]['조회목적'], count:result[i]['조회개수']});
			}
			
		}

		this.detailInfo.loggedDepartCount = deptCountArray.length;
		this.detailInfo.searchUserCount = userCountArray.length;
		this.detailInfo.userInfo = userInfoArray;
		this.detailInfo.userInfoCount = result.length;
	}

	makeBizVariable (result) {
		let ipCountArray:any = []
		let ipInfoArray:any = [];

		let userInfoArray:any = [];
		let userCount:number = 0;

		for(let i=0; i<result.length; i++) {
			let inputObj:any = {};
			inputObj.idnum = "";
			inputObj.depart = "";
			inputObj.name = "";
			inputObj.ipaddr = [];
			inputObj.bizcount = 0;
			
			if(ipCountArray.findIndex(x => x === result[i]['IP']) == -1) ipCountArray.push(result[i]['IP'])

			let chkIdx = userInfoArray.findIndex(x => x.idnum == result[i]['INDV_ID']);
			if(chkIdx == -1) {
				inputObj.idnum = result[i]['INDV_ID'];
				inputObj.depart = result[i]['D_NM'];
				inputObj.name = result[i]['NAME'];
				inputObj.ipaddr.push(result[i]['IP']);
				inputObj.bizcount = result[i]['usercount'];

				ipInfoArray.push(inputObj);
				userInfoArray.push(inputObj);
				userCount++;
			}

			else {
				ipInfoArray[chkIdx].ipaddr.push(result[i]['IP']);
				//userInfoArray[chkIdx].bizcount = userInfoArray[chkIdx].bizcount + result[i]['count'];
			}
		}

		this.detailInfo.usedIPCount = ipCountArray.length;
		this.detailInfo.ipInfo = ipInfoArray;
		this.detailInfo.ipInfoCount = result.length;

		this.detailInfo.searchUserCount = userCount;
		this.detailInfo.userInfo = userInfoArray;
	}

	makeBizVariableBak (result) {
		let ipCountArray:any = []
		let ipInfoArray:any = [];

		let userInfoArray:any = [];
		let userCount:number = 0;

		let minusNum = 1

		for(let i=0; i<result.length; i++) {
			let inputObj:any = {};
			inputObj.depart = "";
			inputObj.name = "";
			inputObj.ipaddr = [];
			inputObj.count = 0;
			
			if(ipCountArray.findIndex(x => x === result[i]['IP']) == -1) ipCountArray.push(result[i]['IP'])
			if(i>0) {
				let checkIdx = i - minusNum;
				
				if(result[i]['INDV_ID'] == result[checkIdx]['INDV_ID']) {
					ipInfoArray[checkIdx].ipaddr.push(result[i]['IP']);
					userInfoArray[checkIdx].count = userInfoArray[checkIdx].count + result[i]['count'];

					minusNum++;
				}
				else {
					inputObj.depart = result[i]['D_NM'];
					inputObj.name = result[i]['NAME'];
					inputObj.ipaddr.push(result[i]['IP']);
					inputObj.count = result[i]['count'];

					ipInfoArray.push(inputObj);
					userInfoArray.push(inputObj);
					userCount++;
				}
			}
			else {
				inputObj.depart = result[i]['D_NM'];
				inputObj.name = result[i]['NAME'];
				inputObj.ipaddr.push(result[i]['IP']);
				inputObj.count = result[i]['count'];

				ipInfoArray.push(inputObj);
				userInfoArray.push(inputObj);
				userCount++;
			}
		}

		this.detailInfo.usedIPCount = ipCountArray.length;
		this.detailInfo.ipInfo = ipInfoArray;
		this.detailInfo.ipInfoCount = result.length;

		this.detailInfo.searchUserCount = userCount;
		this.detailInfo.userInfo = userInfoArray;
	}






































	chkeckImport () {
		this.chkecInterval = setInterval(() => {
			// console.log("interval...check")
			if(this.checkImportFlag.length>1) {
				alert("등록 했습니다.");
				clearInterval(this.chkecInterval);
				this.router.navigateByUrl(`datalog-ked-cre/routine-status/${this.searchMonth}/${this.searchType}`);
			}
		},1000)
	}

	checkImportFlag:any = [];
	chkecInterval:any = null;
	saveFinalRoutine () {
		if(this.mainTable.value.length==0) {
            alert("선택된 항목이 없습니다");
            return;
		}

		if(confirm("점검대상을 확정하시겠습니까?\n등록되어 있는 항목을 제외 후 등록 됩니다.")) {
			let cretopCheckList:any = [];
			this.checkImportFlag = [];

			let auditDate:any = {};
			auditDate.menu = "정기점검대상검토";
			auditDate.type = "점검확정";
			auditDate.searchMonth = this.searchMonth;
			auditDate.searchType = this.searchType;
			auditDate.searchSort = this.searchSort;
			auditDate.filterYearID = this.searchFilterList[0].value;
			auditDate.filterYearName = this.searchFilterList[1].value;
			auditDate.filterName = this.searchFilterList[2].value;
			auditDate.filterFund = this.searchFilterList[3].value;
			// auditDate.filterMid = this.searchFilterList[3].value;
			auditDate.filterBig = this.searchFilterList[4].value;
			auditDate.finalCount = this.mainTable.value.length;
			auditDate.searchValue = this.searchValue;
			this.AuditRecordService.importAuditLogger(this.principal.login, auditDate);
			
			for(let i=0; i<this.mainTable.value.length; i++) {
				if(this.mainTable.value[i]['path']!="FINAL") {
					let checkObj:any = {};
					checkObj['ID'] = this.mainTable.value[i]['ID'];
					checkObj['기업명'] = this.mainTable.value[i]['기업명'];
					cretopCheckList.push(checkObj);
				}
			}
			
			this.importFinalStart(cretopCheckList);
			this.importCretopCheckList(cretopCheckList);
			this.chkeckImport();
		}
	}



	private importCretopCheckQueryId;
	importCretopCheckList(target) {
		let inputQuery = "json \"" + JSON.stringify(target) + "\"";
		inputQuery += " | eval writer = \"" + this.principal.login + "\""
		inputQuery += " | eval reason = \"( " + this.searchMonth + " ) 점검대상\"";
		inputQuery += " | eval type = \"" + this.searchType + "\""
		inputQuery += " | eval status = \"O\"";
		inputQuery += " | import AS_CRETOP_EXCEPT";

		if (!!this.importCretopCheckQueryId) {
			this.queryService.removeQuery(this.importCretopCheckQueryId);
			this.importCretopCheckQueryId = null;
		}

		this.queryService.createQuery(inputQuery, { onChanged: this.importCretopCheckResult })
		.then((query) => {
			this.queryService.startQuery(query.id)
			.then(() => {
				this.importCretopCheckQueryId = query.id;
			})
			.catch((msg) => {
				console.log('error', msg);
			});
		})
		.catch((msg) => {
			console.log('error', msg);
		});
	}

	importCretopCheckResult(query) {
		if(!!query) {
            // console.log("query", query)
            if(query.status=="Ended") this.checkImportFlag.push(0);	//this.router.navigateByUrl(`datalog-ked-cre/routine-report/${this.searchMonth}/${this.searchType}`);
        }
	}

	private importFinalQueryId;
	importFinalStart (target) {
		let inputQuery = "json \"" + JSON.stringify(target) + "\"";
		inputQuery += " | eval writer = \"" + this.principal.login + "\""
		inputQuery += " | eval crdate = \"" + this.searchMonth + "\""
        inputQuery += " | eval type = \"" + this.searchType + "\""
		inputQuery += " | import AS_CRETOP_FINAL";

		if (!!this.importFinalQueryId) {
			this.queryService.removeQuery(this.importFinalQueryId);
			this.importFinalQueryId = null;
		}

		this.queryService.createQuery(inputQuery, { onChanged: this.importFinalResult })
		.then((query) => {
			this.queryService.startQuery(query.id)
			.then(() => {
				this.importFinalQueryId = query.id;
			})
			.catch((msg) => {
				console.log('error', msg);
			});
		})
		.catch((msg) => {
			console.log('error', msg);
		});
	}
	importFinalResult (query) {
		if(!!query) {
            // console.log("query", query)
            if(query.status=="Ended") this.checkImportFlag.push(0);	//this.router.navigateByUrl(`datalog-ked-cre/routine-report/${this.searchMonth}/${this.searchType}`);
        }
	}

	

	

	onDetailInfoClose () {
		this.detailInfoDisplay='none';
	}

	changeFilterCondition (ev, key) {
		if(key=="filterYearID" && ev) this.searchFilterList[1].value = false;
		if(key=="filterYearName" && ev) this.searchFilterList[0].value = false;
		
		this.filterStr = '';
		for(let i=0; i<this.searchFilterList.length; i++) {
			if(this.searchFilterList[i].value) this.filterStr += this.searchFilterList[i].name + ',';
		}
		if(this.filterStr=='') this.filterStr = '검색조건 선택';
		else this.filterStr = this.filterStr.substr(0, this.filterStr.length -1);

		this.searchLog();
	}




	private detailSearchSumInfoQueryId;
	detailSearchSumInfoStart (item) {
		if (!!this.detailSearchSumInfoQueryId) {
			this.queryService.removeQuery(this.detailSearchSumInfoQueryId);
			this.detailSearchSumInfoQueryId = null;
		}

		this.detailInfo.sumList = [];

		this.logListCurrentPage = 1;
		this.logListTotalItems = 0;
		this.logListCurrentStart = 1;
		this.pagingArray = [];

		let queryStr = "";
		// queryStr += "fulltext \"" + item['ID'] + "\" from KS_CRETOP_LOG_R04";
		queryStr += "table KS_CRETOP_LOG_R04 | search ID==\"" + item['ID'] + "\"";
		queryStr += " | search crdate == \"" + this.searchMonth + "\"";
		queryStr += " | rename 조회대상자주민등록번호 as 주민등록번호, 조회동의여부 as 동의여부"
		queryStr += " | eval 생년월일 = substr(주민등록번호, 0, 6)"
		queryStr += " | eval 성별 = if( mod(int(substr(주민등록번호, 7, 8)), 2 ) == 0 , \"여\", \"남\")"
		queryStr += " | fields 조회일시, 상품구분, 기업명, 부서명, 조회자, 이용정보, 조회대상자, 주민등록번호, 생년월일, 성별, 조회목적, 동의여부"

		// console.log(queryStr)

		this.queryService.createQuery(queryStr, { onChanged: this.detailSearchSumInfoChange })
        .then((query) => {
            this.queryService.startQuery(query.id)
			.then(() => {
				this.detailSearchSumInfoQueryId = query.id;
			})
			.catch((msg) => {
				console.log('error', msg);
			});
        })
        .catch((msg) => {
            console.log('error', msg);
        });
	}

	detailSearchSumInfoChange (query) {
		if(!!query) {
			this.detailSearchSumInfoResult(query.id, "normal");
		}
	}

	detailSearchSumInfoResult (id, type) {
		const offset = (this.logListCurrentPage - 1) * this.logListPageSize;
		const limit = this.logListPageSize;
		
		this.queryService.getResult(id, offset, limit)
		.then((result) => {
			// console.log(result)
			this.detailInfo.sumList = result.records;
			this.logListTotalItems = result.count;
			
			this.makePagingInfo();
            this.cdr.detectChanges();
		})
		.catch(function (msg) {
			console.log('error', msg);
		});
	}



	/***** Pagination  *****/
	logListCurrentPage:number = 1;
    logListTotalItems:number = 0;

    logListMaxPageCount:number = 0;
    pagingArray:any = [];
    logListPageSize:number = 15;
    logListPageLength:number = 10;
    logListCurrentStart = 1;

    makePagingInfo () {
        this.pagingArray = [];
        let arrayCount = 0;
		if(this.logListTotalItems>0) this.logListMaxPageCount = Math.ceil(this.logListTotalItems / this.logListPageSize);
		else this.logListMaxPageCount = 0;

        if(this.logListMaxPageCount > this.logListPageLength) arrayCount = this.logListPageLength;
		else arrayCount = this.logListMaxPageCount;
		
        for(let i=0; i<arrayCount; i++) {
            let inputNum = i + this.logListCurrentStart;
            if(this.logListMaxPageCount >= inputNum) this.pagingArray.push(inputNum)
            else break;
        }
    }
    searchLogPageChanged (pNum) {
        this.logListCurrentPage = pNum;
        this.logListCurrentStart = (Math.ceil(this.logListCurrentPage / this.logListPageLength) - 1) * this.logListPageLength + 1;

        this.detailSearchSumInfoResult(this.detailSearchSumInfoQueryId ,"page");
    }
    searchLogPageNext () {
        let move = this.logListCurrentPage + 1;
        if(move > this.logListMaxPageCount) move = this.logListMaxPageCount;
        this.searchLogPageChanged(move)
    }
    searchLogPagePrev () {
        let move = this.logListCurrentPage - 1;
        if(move < 1) move = 1;
        this.searchLogPageChanged(move)
    }
    searchLogPageNextJump () {
        let move = this.logListCurrentPage + this.logListPageLength;
        if(move > this.logListMaxPageCount) move = this.logListMaxPageCount;
        this.searchLogPageChanged(move)
    }
    searchLogPagePrevJump () {
        let move = this.logListCurrentPage - this.logListPageLength;
        if(move < 1) move = 1;
        this.searchLogPageChanged(move)
	}
	

	
	getExportData(queryid, totalCount, callback) {
		this.queryService.getResult(queryid, 0, totalCount)
        .then((result) => {
            callback(result.records);
        })
        .catch(function (msg) {
            console.log('error', msg);
        });
	}

	downloadCSV:string = "none";
	detailDownload (searchType) {
		let fileName = "정기점검대상검토.xlsx";

		if(this.logListTotalItems > 10000) {
			this.downloadCSV = "inline-block";
		}
		else {
			let element = document.getElementById('table-detail-info');
			const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
			const wb: XLSX.WorkBook = XLSX.utils.book_new();
			XLSX.utils.book_append_sheet(wb, ws, '점검대상상세정보');

			if(searchType=="priv") {
				this.getExportData(this.detailSearchSumInfoQueryId, this.logListTotalItems, (data) => {
					const ws: XLSX.WorkSheet =XLSX.utils.json_to_sheet(data, {header: this.privDetailField});
					
					XLSX.utils.book_append_sheet(wb, ws, "점검대상조회내역");
					XLSX.writeFile(wb, fileName);
				});
			}
			else {
				XLSX.writeFile(wb, fileName);
			}
		}

	}

	downloadDetailExcel () {
		let fileName = "점검대상상세정보.xlsx";

		let element = document.getElementById('table-detail-info');
		const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
		const wb: XLSX.WorkBook = XLSX.utils.book_new();
		XLSX.utils.book_append_sheet(wb, ws, '점검대상상세정보');
		
		XLSX.writeFile(wb, fileName);
	}

	downloadDetailCSV () {
		let charset = 'MS949';
		let filename = "점검대상조회내역.csv";
		let fields = this.privDetailField;
		let offset = 0;
		let limit = this.logListTotalItems;
		let query_id = this.detailSearchSumInfoQueryId;
		
		this.answerService.csvDownload(charset, filename, fields, offset, limit, query_id).then(token => {
			this.fileService.download(token);
		});
	}

}