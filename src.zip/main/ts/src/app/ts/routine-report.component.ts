import { Component, OnInit, HostListener, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { $ } from 'protractor';
import { Logger, LogService, QueryService, MsgbusService, getColumnDefs, HostAuthService, Principal } from 'sonar-angular5-sdk';

import { AuditRecordService } from './audit-record.service';

import * as Highcharts from 'highcharts';
require('highcharts/highcharts-more')(Highcharts);
require('highcharts/modules/no-data-to-display')(Highcharts);
require('highcharts/modules/treemap')(Highcharts);

import * as XLSX from 'xlsx';
import { HttpInterceptingHandler } from '@angular/common/http/src/module';

@Component ({
    selector: 'routine-report',
    templateUrl: '../html/routine-report.html',
    styleUrls: ['../common.less','../css/answer.css']
})

export class RoutineReportComponent implements OnInit, OnDestroy {
	private logger: Logger;

    searchDate:Date = new Date();
    get searchMonthStr():string { return this.searchDate == null ? '' : this.convertDate(this.searchDate, 'month') }
	get searchYearStr():string { return this.searchDate == null ? '' : this.convertDate(this.searchDate, 'year') }
	
	get principal(): Principal {
		return this.authService.getPrincipal();
	}
	
	startYear:any = '2019';
	
	searchType:string = 'biz';
    searchTypeList:any = [
        {name:'기업정보',type:'biz'},
        {name:'개인정보',type:'priv'}
    ];

    searchMonth:any = this.convertStringToPreDate(this.searchMonthStr);
	searchMonthList:any = [];

	mainTable:any = {
		fields: [],
        value: [],
		count: 0
	}

	isMainResultShow:boolean = false;
	mainHeight:number = 200;

    constructor(
        log: LogService, 
        private authService: HostAuthService,
		private msgbusService: MsgbusService,
		private queryService: QueryService,
		private cdr: ChangeDetectorRef,
		private router: Router, 
		private route: ActivatedRoute,
		private AuditRecordService: AuditRecordService
    ) {
		this.logger = log.getLogger("Data Log");

		this.searchReportStart = this.searchReportStart.bind(this);
		this.searchReportResult = this.searchReportResult.bind(this);
	}

    ngOnInit() {
		this.mainHeight = window.innerHeight - 180;

		for(let i=this.startYear; i<=this.searchYearStr; i++) {
            for(let j=1; j<13; j++) {
                let inputStr = i + "-" + this.addZeroPadding(j);
                this.searchMonthList.push({name:inputStr, type:inputStr});
            }
		}
		this.searchLog();
		this.cdr.detectChanges();
	}
	
	@HostListener('window:resize', ['$event'])
    resizeHandler(event) {
        this.mainHeight = event.target.innerHeight - 180;
    }

	@HostListener('window:beforeunload', ['$event'])
	beforeunloadHandler(event) {
		if(this.searchReportQueryId) {
			this.queryService.removeQuery(this.searchReportQueryId);
		}
	}
	ngOnDestroy() {
		if(this.searchReportQueryId) {
			this.queryService.removeQuery(this.searchReportQueryId);
		}
	}

	convertStringToStamp(dateStr) {
		let parts = dateStr.split('-');
        return new Date(parts[0], parts[1] -1).getTime();
	}

	convertStringToTargetDate(dateStr, target) {
		let calDate = 1 + target
        let parts = dateStr.split('-');
        let date = new Date(parts[0], parts[1] - calDate);
        let year = date.getFullYear();
		let month = this.addZeroPadding(date.getMonth() + 1);
        
        return `${year}-${month}`;
    }

    convertStringToPreDate(dateStr) {
        let parts = dateStr.split('-');
        let date = new Date(parts[0], parts[1] -2);
        let year = date.getFullYear();
		let month = this.addZeroPadding(date.getMonth() + 1);
        
        return `${year}-${month}`;
    }

    convertCalDate(dateStr, target) {
        let parts = dateStr.split('-');
        let timeStamp = new Date(parts[0], parts[1] -1, parts[2]).getTime() + ((24*60*60*1000) * target);
        let calDate = new Date(timeStamp);
        return this.convertDate(calDate, 'day');
    }

    convertDateAdd(target) {
        let timeStamp = new Date().getTime() + ((24*60*60*1000) * target);
        return new Date(timeStamp);
    }
    
    convertStringToDatePlus(dateStr) {
        let parts = dateStr.split('-');
        let timeStamp = new Date(parts[0], parts[1] -1, parts[2]).getTime() + (1*24*60*60*1000);
        return new Date(timeStamp);
    }

    convertStringToDate(dateStr) {
        let parts = dateStr.split('-');
        return new Date(parts[0], parts[1] -1, parts[2])
    }

    convertDate(date: Date, format: string): any {
		// format - [year, month, day, hour, minute, second]
		if (!date) {
			return;
		}

		let year = date.getFullYear();
		let month = this.addZeroPadding(date.getMonth() + 1);
		let day = this.addZeroPadding(date.getDate());
		let hour = this.addZeroPadding(date.getHours());
		let minute = this.addZeroPadding(date.getMinutes());
		let second = this.addZeroPadding(date.getSeconds());

		switch (format) {
			case 'year':
				return `${year}`;
			case 'month':
				return `${year}-${month}`;
			case 'day':
				return `${year}-${month}-${day}`;
			case 'hour':
				return `${year}-${month}-${day} ${hour}`;
			case 'minute':
				return `${year}-${month}-${day} ${hour}:${minute}`;
			case 'second':
				return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
			default:
				return date;
		}
    }
    
    private addZeroPadding(dateStr) {
		return `0${dateStr}`.slice(-2);
    }

    random() {
        return Math.floor(Math.random() * 300);
	}
	
	onSelectSearchType (type:string) {
        this.searchLog();
    }

    onSelectSearchMonth (type:string) {
        this.searchLog();
	}
    
	baseQuery:string = '';
	searchLog () {
		this.baseQuery = "table AS_CRETOP_FINAL";
		this.baseQuery += " | search crdate == \"" + this.searchMonth + "\" and type == \"" + this.searchType + "\"";

		if(this.searchType=="biz") {
			this.baseQuery += " | join type=left ID ["
			this.baseQuery += " table KS_CRETOP_LOG_R01 | search crdate == \"" + this.searchMonth + "\" | fields IQCN, IQENPCN, USETMCD, CNETTM, ID"
			this.baseQuery += " ] | join type=left ID [";
			// this.baseQuery += " table KS_CRETOP_LOG_R03 | search crdate == \"" + this.searchMonth + "\" | sort limit=1 -계약번호 by ID | fields 관리처1, 관리처2, 관리처3, 해당ID최초이용시작일, 종목, 업태, ID"
			this.baseQuery += " table KS_CRETOP_LOG_R03 | sort limit=1 -계약번호 by ID | fields 관리처1, 관리처2, 관리처3, 해당ID최초이용시작일, 종목, 업태, ID"
			this.baseQuery += " ] | join type=left ID [";
			this.baseQuery += " table from=" + this.searchMonth.replace(/-/gi,'') + " to=" + this.convertStringToTargetDate(this.searchMonth, -1).replace(/-/gi,'') + " KS_CRETOP_TCP018 | stats count by INDV_ID, ID | stats count by ID | rename count as usercount"
			this.baseQuery += " ] | join type=left ID [";
			this.baseQuery += " table from=" + this.searchMonth.replace(/-/gi,'') + " to=" + this.convertStringToTargetDate(this.searchMonth, -1).replace(/-/gi,'') + " KS_CRETOP_TCP017 | stats count by CNET_IP, ID | stats count by ID | rename count as ipcount";
			this.baseQuery += " ]";
		}

		else {
			// this.baseQuery += " | join type=left ID ["
			// this.baseQuery += " table KS_CRETOP_LOG_R02  | search crdate == \"" + this.searchMonth + "\" | fields IQCN, IQINDVCN, USETMCD, CNETTM, ID";
			// this.baseQuery += " ] | join type=left ID [";
			// this.baseQuery += " table KS_CRETOP_LOG_R03 | search crdate == \"" + this.searchMonth + "\" | sort limit=1 -계약번호 by ID | fields 관리처1, 관리처2, 관리처3, 해당ID최초이용시작일, 종목, 업태, ID"
			// this.baseQuery += " ] | join type=left ID [";
			// this.baseQuery += " table from=" + this.searchMonth.replace(/-/gi,'') + " to=" + this.convertStringToTargetDate(this.searchMonth, -1).replace(/-/gi,'') + " KS_CRETOP_TCP103 "
			// this.baseQuery += " | stats sum(MENU_ID1_CN) as MyCretop, sum(MENU_ID2_CN) as 조기경보, sum(MENU_ID3_CN) as 기업정보, sum(MENU_ID4_CN) as 기업인정보, sum(MENU_ID5_CN) as 신용정보, sum(MENU_ID6_CN) as 산업그룹정보, sum(MENU_ID7_CN) as 경영지원정보, sum(MENU_ID8_CN) as 기타 by ID"
			// this.baseQuery += " ]";

			this.baseQuery += " | join type=left ID [ table TCP018_MONTH | search crdate == \"" + this.searchMonth + "\" | stats count by ID, INDV_ID ] "
			this.baseQuery += " | stats count by ID, 기업명 | rename count as usercount";
			this.baseQuery += " | join type=left ID [ table TCP012_MONTH | search crdate == \"" + this.searchMonth + "\" | stats count by ID, D_NM ] ";
			this.baseQuery += " | stats count by ID, 기업명, usercount | rename count as deptcount";

			this.baseQuery += " | join type=left ID ["
			this.baseQuery += " table KS_CRETOP_LOG_R02  | search crdate == \"" + this.searchMonth + "\" | fields IQCN, IQINDVCN, USETMCD, CNETTM, ID";
			this.baseQuery += " ] | join type=left ID [";
			// this.baseQuery += " table KS_CRETOP_LOG_R03 | search crdate == \"" + this.searchMonth + "\" | sort limit=1 -계약번호 by ID | fields 관리처1, 관리처2, 관리처3, 해당ID최초이용시작일, 종목, 업태, ID"
			this.baseQuery += " table KS_CRETOP_LOG_R03 | sort limit=1 -계약번호 by ID | fields 관리처1, 관리처2, 관리처3, 해당ID최초이용시작일, 종목, 업태, ID"
			
			// this.baseQuery += " ] | join type=left ID [";
			// this.baseQuery += " table KS_CRETOP_LOG_R04 | search crdate == \"" + this.searchMonth + "\"  | stats count by ID, 조회목적 | rename count as 조회개수";
			this.baseQuery += " ]";

			this.baseQuery += " | join type=left ID [";
			this.baseQuery += " table KS_CRETOP_LOG_R04 | search crdate == \"" + this.searchMonth + "\"  | stats count by ID, 조회목적 | rename count as 조회개수";
			this.baseQuery += " ]";

			this.baseQuery += " | join type=left ID [";
			this.baseQuery += " table KS_CRETOP_LOG_R04 | search crdate == \"" + this.searchMonth + "\" | stats count by ID, 조회대상자주민등록번호 | stats count by ID |  rename count as 조회개인개수";
			this.baseQuery += " ]"
		}
		this.baseQuery += " | eval 가격정책 = case(USETMCD==\"01\", \"무제한(정액제)\",USETMCD==\"02\", \"월4시간(종량제)\",USETMCD==\"03\", \"월12시간(종량제)\",USETMCD)";

		// console.log("query", this.baseQuery)

		let auditDate:any = {};
        auditDate.menu = "점검결과리포트";
        auditDate.type = "조회";
        auditDate.searchMonth = this.searchMonth;
		auditDate.searchType = this.searchType;
        this.AuditRecordService.importAuditLogger(this.principal.login, auditDate);

		this.searchReportStart();
	}

	searchLogStop () {
		this.isReportdSearch = false;
        this.queryService.stopQuery(this.searchReportQueryId);
	}


	private searchReportQueryId;
	isReportdSearch:boolean = false;
	searchReportStart () {
		if (!!this.searchReportQueryId) {
			this.queryService.removeQuery(this.searchReportQueryId);
			this.searchReportQueryId = null;
        }
		this.mainTable.count = 0;
		this.mainTable.value = [];

        this.queryService.createQuery(this.baseQuery, { onChanged: this.searchReportResult })
        .then((query) => {
            this.queryService.startQuery(query.id)
			.then(() => {
                this.searchReportQueryId = query.id;
                this.isReportdSearch = true;
			})
			.catch((msg) => {
				console.log('error', msg);
			});
        })
        .catch((msg) => {
            console.log('error', msg);
        });
	}
	searchReportResult (query) {
		if (!!query) {
            if(query.status=="Ended") this.isReportdSearch = false;
			this.queryService.getResult(query.id, 0, 5000)
			.then((result) => {
				// console.log(result)
				if(this.searchType=="priv") this.mainTable.value = this.makePrivReport(result.records)
				else this.mainTable.value = result.records

				if(typeof result.fieldOrder === "undefined") this.mainTable.fields = [];
				else this.mainTable.fields = result.fieldOrder;

				this.mainTable.count = result.count;
				
				// console.log(this.mainTable);

				this.cdr.detectChanges();
			})
			.catch(function (msg) {
				console.log('error', msg);
			});
		}
	}

	makePrivReport (arr:any) {
		let retArr:any = [];
		if(arr.length == 0) return retArr;

		for(let i=0; i<arr.length; i++) {
			let chkIdx = retArr.findIndex(x => x.ID == arr[i].ID);
			if(chkIdx == -1) {
				arr[i].purpose = [];
				arr[i].purpose.push({name:arr[i]['조회목적'], count:arr[i]['조회개수']});
				retArr.push(arr[i]);
			}
			else {
				retArr[chkIdx].purpose.push({name:arr[i]['조회목적'], count:arr[i]['조회개수']});
			}
		}

		return retArr;
	}
	
	exportExcel () {
		if(this.mainTable.value.length > 0) {
			let auditDate:any = {};
			auditDate.menu = "점검결과리포트";
			auditDate.type = "다운로드";
			auditDate.searchMonth = this.searchMonth;
			auditDate.searchType = this.searchType;
			this.AuditRecordService.importAuditLogger(this.principal.login, auditDate);
		
			let fileName = "오남용 점검결과(" + this.searchMonth + ").xlsx";

			let element = document.getElementById('routine-report');
			const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
			const wb: XLSX.WorkBook = XLSX.utils.book_new();
			XLSX.utils.book_append_sheet(wb, ws, '오남용 점검결과');
			XLSX.writeFile(wb, fileName);
		}
		else {
			alert("검색 내용이 없습니다");
		}
		
	}

}