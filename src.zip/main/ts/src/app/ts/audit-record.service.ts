import { Injectable } from '@angular/core';
import { query } from '@angular/core/src/render3';
import { Logger, LogService, QueryService, MsgbusService, getColumnDefs, HostAuthService, Principal } from 'sonar-angular5-sdk';
import { AnswerService } from './answer.service';

@Injectable()
export class AuditRecordService {
    private logger: Logger;

    private ipAddress:string = null;
    get principal(): Principal {
		return this.authService.getPrincipal();
    }
    
    

    constructor(
        log: LogService, 
        private msgbus: MsgbusService,
        private authService: HostAuthService,
        private queryService: QueryService,
        private answerService: AnswerService
    ) {
        this.logger = log.getLogger("audit logger");

        this.importAuditLogStart = this.importAuditLogStart.bind(this);
        this.importAuditLogResult = this.importAuditLogResult.bind(this);
    }

    async importAuditLogger(actor: string, params: any) {
        let queryStr = "";

        // console.log("principal", this.principal)

        let menu = params.menu;
        let type = params.type;

        delete  params.menu;
        delete  params.type;

        if(this.ipAddress==null) {
            let ipaddr = await this.answerService.remoteIPAddress();
            this.ipAddress = ipaddr.params.success.replace("/","");
        }

        if(this.ipAddress==null) {
            this.ipAddress = "0.0.0.0";
            // this.getUserSession()
            // .then(userList => {
            //     let userInfo:any = userList.find(x => x.guid === this.principal.userGuid);
            //     if(typeof userInfo !== 'undefined') this.ipAddress = userInfo.remote_ip;
            //     else this.ipAddress = "0.0.0.0";

            //     queryStr += "json \"{}\"";
            //     queryStr += " | eval actor = \"" + actor + "\"";
            //     queryStr += " | eval ipadr = \"" + this.ipAddress + "\"";
            //     queryStr += " | eval menu = \"" + menu + "\"";
            //     queryStr += " | eval type = \"" + type + "\"";
            //     queryStr += " | eval params = \"" + JSON.stringify(params).replace(/"/gi,"'") + "\"";
            //     queryStr += " | import AS_AUDIT_LOG";

            //     this.importAuditLogStart(queryStr);
            // })
        }

        queryStr += "json \"{}\"";
        queryStr += " | eval actor = \"" + actor + "\"";
        queryStr += " | eval ipadr = \"" + this.ipAddress + "\"";
        queryStr += " | eval menu = \"" + menu + "\"";
        queryStr += " | eval type = \"" + type + "\"";
        queryStr += " | eval params = \"" + JSON.stringify(params).replace(/"/gi,"'") + "\"";
        queryStr += " | import AS_AUDIT_LOG";

        this.importAuditLogStart(queryStr);
    }

    private importAuditQueryId;
    importAuditLogStart (queryStr) {
        if (!!this.importAuditQueryId) {
            this.queryService.removeQuery(this.importAuditQueryId);
            this.importAuditQueryId = null;
        }

        this.queryService.createQuery(queryStr, { onChanged: this.importAuditLogResult })
        .then((query) => {
            this.queryService.startQuery(query.id)
            .then(() => {
                this.importAuditQueryId = query.id;
            })
            .catch((msg) => {
                console.log('error', msg);
            });
        })
        .catch((msg) => {
            console.log('error', msg);
        });
    }

    importAuditLogResult (query) {
        if(!!query) {
            if(query.status=="Ended") {
                this.queryService.getResult(query.id, 0, 1)
                .then((result) => {
                    this.queryService.removeQuery(this.importAuditQueryId);
                    this.importAuditQueryId = null;
                })
                .catch(function (msg) {
                    console.log('error', msg);
                });
            }
        }
    }


    getUserSession(): Promise<any> {
		return this.msgbus.call('com.logpresso.core.msgbus.SessionPlugin.getSessions', {
		}).then(msg => {
			return msg.params.sessions;
		});
	}
}