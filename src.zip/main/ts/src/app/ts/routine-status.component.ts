import { Component, OnInit, HostListener, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { $ } from 'protractor';
import { Logger, LogService, QueryService, MsgbusService, getColumnDefs, HostAuthService, Principal, FileService } from 'sonar-angular5-sdk';

import { AuditRecordService } from './audit-record.service';
import { AnswerService } from './answer.service';

import * as Highcharts from 'highcharts';
require('highcharts/highcharts-more')(Highcharts);
require('highcharts/modules/no-data-to-display')(Highcharts);
require('highcharts/modules/treemap')(Highcharts);

import * as XLSX from 'xlsx';
import { HttpInterceptingHandler } from '@angular/common/http/src/module';

@Component ({
    selector: 'routine-status',
    templateUrl: '../html/routine-status.html',
    styleUrls: ['../common.less','../css/answer.css']
})

export class RoutineStatusComponent implements OnInit, OnDestroy {
	private logger: Logger;
	private pIdx: string;
	private pType: string;

    searchDate:Date = new Date();
    get searchMonthStr():string { return this.searchDate == null ? '' : this.convertDate(this.searchDate, 'month') }
    get searchYearStr():string { return this.searchDate == null ? '' : this.convertDate(this.searchDate, 'year') }
	startYear:any = '2019';

	get principal(): Principal {
		return this.authService.getPrincipal();
	}
	
	// searchStartMonth:any = this.convertStringToPreDate(this.searchMonthStr);
	// searchEndMonth:any = this.convertStringToPreDate(this.searchMonthStr);
	searchStartMonth:any = this.searchMonthStr;
	searchEndMonth:any = this.searchMonthStr;
	searchMonthList:any = [];

	searchType:string = 'biz';
    searchTypeList:any = [
        {name:'기업정보',type:'biz'},
        {name:'개인정보',type:'priv'}
	];
	
	searchValue:string = '';
	dateRange:any = [];

	isMainResultShow:boolean = false;
	mainHeight:number = 200;
	
	mainTable:any = {
        fields: ['No','점검대상월','ID','기업명','기업구분','업종','상품명','요금제','조회건수','조회기업','이용시간','이용현황','검토의견','관리부점'],
		value: [],
		count: 0
	}
	

    constructor(
        log: LogService, 
        private authService: HostAuthService,
		private msgbusService: MsgbusService,
		private queryService: QueryService,
		private cdr: ChangeDetectorRef,
		private router: Router, 
		private route: ActivatedRoute,
		private AuditRecordService: AuditRecordService,
		private fileService: FileService,
		private answerService: AnswerService
    ) {
		this.logger = log.getLogger("Data Log");

		this.pIdx = route.snapshot.params['pIdx'];
		this.pType = route.snapshot.params['pType'];
		
		this.searchLogListStart = this.searchLogListStart.bind(this);
		this.searchLogListChange = this.searchLogListChange.bind(this);
        
		this.router.routeReuseStrategy.shouldReuseRoute = function() {
            return false;
        }
	}

    ngOnInit() {
		this.mainHeight = window.innerHeight - 193;

		if(this.pIdx == "0") {
			this.searchStartMonth = this.convertStringToPreDate(this.searchStartMonth);//this.convertDate(this.searchDate, 'month')
			this.searchEndMonth = this.convertStringToPreDate(this.searchEndMonth);//this.convertDate(this.searchDate, 'month')
		}
		else {
			this.searchStartMonth = this.pIdx;
			this.searchEndMonth = this.pIdx;
		}

		if(this.pType== "0") this.searchType = 'biz';
		else this.searchType = this.pType;

		for(let i=this.startYear; i<=this.searchYearStr; i++) {
            for(let j=1; j<13; j++) {
                let inputStr = i + "-" + this.addZeroPadding(j);
                this.searchMonthList.push({name:inputStr, type:inputStr});
            }
		}
		
		this.searchLog();
	}
	
	@HostListener('window:resize', ['$event'])
    resizeHandler(event) {
        // console.log("resize", event.target.innerHeight)
        this.mainHeight = event.target.innerHeight - 193;
    }

	@HostListener('window:beforeunload', ['$event'])
	beforeunloadHandler(event) {
		if(this.searchLogListQueryId) {
			this.queryService.removeQuery(this.searchLogListQueryId);
		}
	}
    ngOnDestroy() {
		if (this.searchLogListQueryId) {
			this.queryService.removeQuery(this.searchLogListQueryId);
		}
	}

	convertStringToDateMonth(dateStr) {
		let parts = dateStr.split('-');
        return new Date(parts[0], parts[1] -1);
	}
	convertStringToStamp(dateStr) {
		let parts = dateStr.split('-');
        return new Date(parts[0], parts[1] -1).getTime();
	}

	convertStringToTargetDate(dateStr, target) {
		let calDate = 1 + target
        let parts = dateStr.split('-');
        let date = new Date(parts[0], parts[1] - calDate);
        let year = date.getFullYear();
		let month = this.addZeroPadding(date.getMonth() + 1);
        
        return `${year}-${month}`;
    }

    convertStringToPreDate(dateStr) {
        let parts = dateStr.split('-');
        let date = new Date(parts[0], parts[1] -2);
        let year = date.getFullYear();
		let month = this.addZeroPadding(date.getMonth() + 1);
        
        return `${year}-${month}`;
    }

    convertCalDate(dateStr, target) {
        let parts = dateStr.split('-');
        let timeStamp = new Date(parts[0], parts[1] -1, parts[2]).getTime() + ((24*60*60*1000) * target);
        let calDate = new Date(timeStamp);
        return this.convertDate(calDate, 'day');
    }

    convertDateAdd(target) {
        let timeStamp = new Date().getTime() + ((24*60*60*1000) * target);
        return new Date(timeStamp);
    }
    
    convertStringToDatePlus(dateStr) {
        let parts = dateStr.split('-');
        let timeStamp = new Date(parts[0], parts[1] -1, parts[2]).getTime() + (1*24*60*60*1000);
        return new Date(timeStamp);
    }

    convertStringToDate(dateStr) {
        let parts = dateStr.split('-');
        return new Date(parts[0], parts[1] -1, parts[2])
    }

    convertDate(date: Date, format: string): any {
		// format - [year, month, day, hour, minute, second]
		if (!date) {
			return;
		}

		let year = date.getFullYear();
		let month = this.addZeroPadding(date.getMonth() + 1);
		let day = this.addZeroPadding(date.getDate());
		let hour = this.addZeroPadding(date.getHours());
		let minute = this.addZeroPadding(date.getMinutes());
		let second = this.addZeroPadding(date.getSeconds());

		switch (format) {
			case 'year':
				return `${year}`;
			case 'month':
				return `${year}-${month}`;
			case 'day':
				return `${year}-${month}-${day}`;
			case 'hour':
				return `${year}-${month}-${day} ${hour}`;
			case 'minute':
				return `${year}-${month}-${day} ${hour}:${minute}`;
			case 'second':
				return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
			default:
				return date;
		}
    }
    
    private addZeroPadding(dateStr) {
		return `0${dateStr}`.slice(-2);
	}

	onSelectSearchType (type:string) {
        this.searchLog();
	}
	

	getDateRange(startDate, endDate) {
        for(var arr=[], dt=new Date(startDate); dt<=new Date(endDate); dt.setMonth(dt.getMonth() + 1)) {
            arr.push(this.convertDate(new Date(dt), 'month'));
        }

        return arr;
    }
	
	baseQuery:string = "";
	searchLog () {
		this.dateRange = this.getDateRange(this.convertStringToDateMonth(this.searchStartMonth), this.convertStringToDateMonth(this.searchEndMonth));
		if(this.dateRange.length > 12) {
            alert("1년 이상은 조회할 수 없습니다.");
            return;
        }

        if(this.dateRange.length < 1) {
            alert("날짜 조건을 확인해 주세요.");
            return;
        }


		let tbName = "KS_CRETOP_LOG_R01";
		if(this.searchType == "biz") {
			tbName = "KS_CRETOP_LOG_R01";
			this.mainTable.fields = ['No','점검대상월','ID','기업명','기업구분','업종','상품명','요금제','조회건수','조회기업수','이용시간','이용현황','검토의견','관리부점'];
		}
		else {
			tbName = "KS_CRETOP_LOG_R02";
			this.mainTable.fields = ['No','점검대상월','ID','기업명','기업구분','업종','상품명','요금제','조회건수','조회개인수','이용현황','검토의견','관리부점'];
		}

		let searchStr:string = "search crstamp >= " + this.convertStringToStamp(this.searchStartMonth) / 1000  + " and crstamp <= " + this.convertStringToStamp(this.searchEndMonth) / 1000;
		this.baseQuery = "";

		this.baseQuery += "table AS_CRETOP_FINAL | eval crstamp = datepart(date(crdate,\"yyyy-MM\"),\"epoch\") | " + searchStr;
		this.baseQuery += " | search type ==\"" + this.searchType +"\"";
		this.baseQuery += " | join type=left ID, crdate [";
		this.baseQuery += " table " + tbName + " | " + searchStr;
		this.baseQuery += " | fields crdate , ID, ENPNM, INSTCLS,SVCD,USETMCD,IQCN,IQENPCN,CNETTM,IQINDVCN ]";
		this.baseQuery += " | join type=left ID [";
		//this.baseQuery += " table KS_CRETOP_LOG_R03 | " + searchStr;
		this.baseQuery += " table KS_CRETOP_LOG_R03 ";
		this.baseQuery += " | sort  -crdate | sort limit=1 -crdate by ID | fields ID,업태,종목,관리처1,관리처2,관리처3 ]";
		this.baseQuery += " | eval 이용현황 = \"정상이용\", 검토의견=\"제재없음\"";

		this.baseQuery += " | eval 기업구분 = case(INSTCLS==\"01\",\"대기업\",INSTCLS==\"02\",\"중소기업\",INSTCLS==\"03\",\"제1금융기관\",INSTCLS==\"04\",\"기타금융기관\",INSTCLS==\"99\",\"구분없음\",INSTCLS)"
		this.baseQuery += " | eval 상품명 = case(SVCD==\"01\",\"CRETOP\",SVCD==\"03\",\"CRETOP+C-PATROL\",SVCD==\"04\",\"EW\",SVCD==\"05\",\"CRETOP+EW\",SVCD==\"06\",\"CRETOP+NOTE\",SVCD==\"07\",\"CRETOP+EW+NOTE\",SVCD)";
		this.baseQuery += " | eval 요금제 = case(USETMCD==\"01\", \"무제한(정액제)\",USETMCD==\"02\", \"월4시간(종량제)\",USETMCD==\"03\", \"월12시간(종량제)\",USETMCD)";

		this.baseQuery += " | eval 관리부점 = 관리처1";
		this.baseQuery += " | eval 관리부점 = if(isnotnull(관리처2), concat(관리부점, \" / \", 관리처2), 관리부점)";
		this.baseQuery += " | eval 관리부점 = if(isnotnull(관리처3), concat(관리부점, \" / \", 관리처3), 관리부점)";

		if(this.searchType=="biz") {
			this.baseQuery += " | rename 업태 as 업종, crdate as 점검대상월, CNETTM as 이용시간, crdate as 점검일자, IQCN as 조회건수, IQENPCN as 조회기업수, IQINDVCN as 조회개인수"
		}
		else {
			this.baseQuery += " | join type=left ID, crdate [ table KS_CRETOP_LOG_R04 | stats count by ID, crdate | rename count as 조회건수 ]  ";
			this.baseQuery += " | join type=left ID, crdate [ table KS_CRETOP_LOG_R04 | stats count by ID, crdate, 조회대상자주민등록번호 | stats count by ID, crdate | rename count as 조회개인수 ]  ";

			this.baseQuery += " | rename 업태 as 업종, crdate as 점검대상월, CNETTM as 이용시간, crdate as 점검일자"
		}

		

		if(this.searchValue!="") this.baseQuery += " | search ID == \"" + this.searchValue + "\""

		this.baseQuery += " | sort 점검대상월"

		// console.log(this.baseQuery)

		let auditDate:any = {};
        auditDate.menu = "점검결과현황";
        auditDate.type = "조회";
		auditDate.searchStartMonth = this.searchStartMonth;
		auditDate.searchEndMonth = this.searchEndMonth;
		auditDate.searchType = this.searchType;
		auditDate.searchValue = this.searchValue;
        this.AuditRecordService.importAuditLogger(this.principal.login, auditDate);

		this.searchLogListStart();
	}

	searchLogStop () {
		this.isLogSearch = false;
        this.queryService.stopQuery(this.searchLogListQueryId);
	}


	getCretopList (callback) {
        this.queryService.getResult(this.searchLogListQueryId, 0, this.logListTotalItems)
        .then((result) => {
            callback(result.records);
        })
        .catch(function (msg) {
            console.log('error', msg);
        });
	}
	
	exportExcel () {
		if(this.mainTable.value.length > 0) {
			let auditDate:any = {};
			auditDate.menu = "점검결과현황";
			auditDate.type = "다운로드";
			auditDate.searchStartMonth = this.searchStartMonth;
			auditDate.searchEndMonth = this.searchEndMonth;
			auditDate.searchType = this.searchType;
			auditDate.searchValue = this.searchValue;
			this.AuditRecordService.importAuditLogger(this.principal.login, auditDate);
			
			let fileName = "오남용 점검현황.xlsx";
			const wb: XLSX.WorkBook = XLSX.utils.book_new();
			let defineHeader = [];
			if(this.searchType=="biz") {
				defineHeader = ['점검대상월','ID','기업명','기업구분','업종','상품명','요금제','조회건수','조회기업수','이용시간','이용현황','검토의견','관리부점'];
			}
			else {
				defineHeader = ['점검대상월','ID','기업명','기업구분','업종','상품명','요금제','조회건수','조회개인수','이용현황','검토의견','관리부점'];
			}

			if(this.logListTotalItems > 10000) {
				if(confirm("전체 10,000 건 이상의 데이터 경우 CSV 로 다운로드 해야 합니다.")) {
					let charset = 'MS949';
					let filename = "오남용 점검현황.csv";
					let fields = defineHeader;
					let offset = 0;
					let limit = this.logListTotalItems;
					let query_id = this.searchLogListQueryId;
					
					this.answerService.csvDownload(charset, filename, fields, offset, limit, query_id).then(token => {
						this.fileService.download(token);
					});
				}
			}
			else {
				this.getCretopList((data) => {
					const ws: XLSX.WorkSheet =XLSX.utils.json_to_sheet(data, {header: defineHeader});
					XLSX.utils.book_append_sheet(wb, ws, '오남용 점검현황');
					XLSX.writeFile(wb, fileName);
				});
			}
			// let element = document.getElementById('routine-status');
			// const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
			// const wb: XLSX.WorkBook = XLSX.utils.book_new();
			// XLSX.utils.book_append_sheet(wb, ws, '오남용 점검현황');
			// XLSX.writeFile(wb, fileName);
		}
		else {
			alert("검색 내용이 없습니다");
		}
	}

	

	
	private searchLogListQueryId;
	isLogSearch:boolean = false;
	searchLogListStart () {
		if (!!this.searchLogListQueryId) {
			this.queryService.removeQuery(this.searchLogListQueryId);
			this.searchLogListQueryId = null;
        }
		this.mainTable.count = 0;

        this.queryService.createQuery(this.baseQuery, { onChanged: this.searchLogListChange })
        .then((query) => {
            this.queryService.startQuery(query.id)
			.then(() => {
                this.searchLogListQueryId = query.id;
                this.isLogSearch = true;
			})
			.catch((msg) => {
				console.log('error', msg);
			});
        })
        .catch((msg) => {
            console.log('error', msg);
        });
	}

	searchLogListChange (query) {
		if(!!query) {
			if(query.status=="Ended") this.isLogSearch = false;
			this.searchLogListResult(query.id, "normal");
		}
	}

	searchLogListResult (id, type) {
		const offset = (this.logListCurrentPage - 1) * this.logListPageSize;
        const limit = this.logListPageSize;

		this.queryService.getResult(id, offset, limit)
        .then((result) => {
            this.logListTotalItems = result.count;
            this.mainTable.value = this.addNumbering(result.records);

            this.makePagingInfo();
            this.cdr.detectChanges();
        })
        .catch(function (msg) {
            console.log('error', msg);
        });
	}

	addNumbering(arr) {
        for(let i=0; i<arr.length; i++) {
            arr[i]['No'] = i + 1 + ( (this.logListCurrentPage -1) * this.logListPageSize )
        }

        return arr;
    }


	/***** Pagination  *****/
	logListCurrentPage:number = 1;
    logListTotalItems:number = 0;

    logListMaxPageCount:number = 0;
    pagingArray:any = [];
    logListPageSize:number = 50;
    logListPageLength:number = 10;
    logListCurrentStart = 1;

    makePagingInfo () {
        this.pagingArray = [];
        let arrayCount = 0;
		if(this.logListTotalItems>0) this.logListMaxPageCount = Math.ceil(this.logListTotalItems / this.logListPageSize);
		else this.logListMaxPageCount = 0;

        if(this.logListMaxPageCount > this.logListPageLength) arrayCount = this.logListPageLength;
        else arrayCount = this.logListMaxPageCount;

        for(let i=0; i<arrayCount; i++) {
            let inputNum = i + this.logListCurrentStart;
            if(this.logListMaxPageCount >= inputNum) this.pagingArray.push(inputNum)
            else break;
        }
    }
    searchLogPageChanged (pNum) {
        this.logListCurrentPage = pNum;
        this.logListCurrentStart = (Math.ceil(this.logListCurrentPage / this.logListPageLength) - 1) * this.logListPageLength + 1;

        this.searchLogListResult(this.searchLogListQueryId ,"page");
    }
    searchLogPageNext () {
        let move = this.logListCurrentPage + 1;
        if(move > this.logListMaxPageCount) move = this.logListMaxPageCount;
        this.searchLogPageChanged(move)
    }
    searchLogPagePrev () {
        let move = this.logListCurrentPage - 1;
        if(move < 1) move = 1;
        this.searchLogPageChanged(move)
    }
    searchLogPageNextJump () {
        let move = this.logListCurrentPage + this.logListPageLength;
        if(move > this.logListMaxPageCount) move = this.logListMaxPageCount;
        this.searchLogPageChanged(move)
    }
    searchLogPagePrevJump () {
        let move = this.logListCurrentPage - this.logListPageLength;
        if(move < 1) move = 1;
        this.searchLogPageChanged(move)
    }

}