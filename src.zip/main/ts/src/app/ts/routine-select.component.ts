import { Component, OnInit, HostListener, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { $ } from 'protractor';
import { Logger, LogService, QueryService, MsgbusService, getColumnDefs, HostAuthService, Principal, HostNavigatorService, FileService } from 'sonar-angular5-sdk';

import { AuditRecordService } from './audit-record.service';
import { AnswerService } from './answer.service';

import * as Highcharts from 'highcharts';
require('highcharts/highcharts-more')(Highcharts);
require('highcharts/modules/no-data-to-display')(Highcharts);
require('highcharts/modules/treemap')(Highcharts);

import * as XLSX from 'xlsx';
import { HttpInterceptingHandler } from '@angular/common/http/src/module';

@Component ({
    selector: 'routine-select',
    templateUrl: '../html/routine-select.html',
    styleUrls: ['../common.less','../css/answer.css']
})

export class RoutineSelectComponent implements OnInit, OnDestroy {
    private logger: Logger;
    
    searchDate:Date = new Date();
    get searchMonthStr():string { return this.searchDate == null ? '' : this.convertDate(this.searchDate, 'month') }
    get searchYearStr():string { return this.searchDate == null ? '' : this.convertDate(this.searchDate, 'year') }

    get principal(): Principal {
		return this.authService.getPrincipal();
    }

    startYear:any = '2019';

    searchMonth:any = this.convertStringToPreDate(this.searchMonthStr);
    searchMonthList:any = [];

    searchSortDisplay:string = 'inline-block';
    searchServiceDisplay:string = 'inline-block';

    searchType:string = 'biz';
    searchTypeList:any = [
        {name:'기업정보',type:'biz'},
        {name:'개인정보',type:'priv'}
    ];
    searchSort:string = 'IQENPCN';
    searchSortList:any = [];
    searchSortListBiz:any = [
        {name:'조회기업수순',type:'IQENPCN'},
        {name:'이용시간순',type:'CNETTM'}
    ];
    searchSortListPriv:any = [
        {name:'조회개인수순',type:'IQINDVCN'},
        {name:'조회건수순',type:'IQCN'}
    ];
    searchService:string = 'total';
    searchServiceList:any = [
        {name:'전체',type:'total'},
        {name:'기업서비스',type:'bizserv'},
        {name:'금융서비스',type:'finserv'},
    ]

    searchCount:number = 50;
    searchValue:string = '';

    mainTable:any = {
        fields: ['ID','기업명','기업구분','상품명','라인수','조회건수','조회기업수','이용시간','구분'],
        value: [],
        count: 0
    }

    mainHeight:number = 200;

    isMainResultShow:boolean = false;
    uuid:any = require('uuid/v4');

    constructor(
        log: LogService, 
        private authService: HostAuthService,
		private msgbusService: MsgbusService,
		private queryService: QueryService,
        private cdr: ChangeDetectorRef,
        private router: Router, 
        private ActivatedRoute: ActivatedRoute,
        private navigatorService: HostNavigatorService,
        private AuditRecordService: AuditRecordService,
        private fileService: FileService,
		private answerService: AnswerService
    ) {
        this.logger = log.getLogger("Data Log");
        
        this.searchCretopStart = this.searchCretopStart.bind(this);
        this.searchCretopChange = this.searchCretopChange.bind(this);
        
        this.importCretopList = this.importCretopList.bind(this);
        this.importCretopChange = this.importCretopChange.bind(this);

        this.selectCretopDetectedList = this.selectCretopDetectedList.bind(this);
        this.selectCretopDetectedResult = this.selectCretopDetectedResult.bind(this);

        this.selectCretopCompletedList = this.selectCretopCompletedList.bind(this);
        this.selectCretopCompletedResult = this.selectCretopCompletedResult.bind(this);

        this.router.routeReuseStrategy.shouldReuseRoute = function() {
            return false;
        }
    }
    

    
    ngOnInit() {
        this.mainHeight = window.innerHeight - 193;

        for(let i=this.startYear; i<=this.searchYearStr; i++) {
            for(let j=1; j<13; j++) {
                let inputStr = i + "-" + this.addZeroPadding(j);
                this.searchMonthList.push({name:inputStr, type:inputStr});
            }
        }

        this.selectCretopDetectedList();
        this.searchSortList = this.searchSortListBiz;
        
        this.searchLog();
    }
    @HostListener('window:resize', ['$event'])
    resizeHandler(event) {
        this.mainHeight = event.target.innerHeight - 193;
    }


    @HostListener('window:beforeunload', ['$event'])
	beforeunloadHandler(event) {
		if (this.searchCretopQueryId) {
			this.queryService.removeQuery(this.searchCretopQueryId);
        }
        if (this.importCretopQueryId) {
			this.queryService.removeQuery(this.importCretopQueryId);
        }
        
        if(this.selectCretopDetectedQueryId) {
            this.queryService.removeQuery(this.selectCretopDetectedQueryId);
        }
        if(this.selectCretopCompletedQueryId) {
            this.queryService.removeQuery(this.selectCretopCompletedQueryId);
        }

        if(this.importInterval != null) {
            clearInterval(this.importInterval);
        }
	}
    ngOnDestroy() {
		if (this.searchCretopQueryId) {
			this.queryService.removeQuery(this.searchCretopQueryId);
        }
        if (this.importCretopQueryId) {
			this.queryService.removeQuery(this.importCretopQueryId);
        }
        
        if(this.selectCretopDetectedQueryId) {
            this.queryService.removeQuery(this.selectCretopDetectedQueryId);
        }
        if(this.selectCretopCompletedQueryId) {
            this.queryService.removeQuery(this.selectCretopCompletedQueryId);
        }

        if(this.importInterval != null) {
            clearInterval(this.importInterval);
        }
    }
    
    convertStringToPreDate(dateStr) {
        let parts = dateStr.split('-');
        let date = new Date(parts[0], parts[1] -2);
        let year = date.getFullYear();
		let month = this.addZeroPadding(date.getMonth() + 1);
        
        return `${year}-${month}`;
    }

    convertCalDate(dateStr, target) {
        let parts = dateStr.split('-');
        let timeStamp = new Date(parts[0], parts[1] -1, parts[2]).getTime() + ((24*60*60*1000) * target);
        let calDate = new Date(timeStamp);
        return this.convertDate(calDate, 'day');
    }

    convertDateAdd(target) {
        let timeStamp = new Date().getTime() + ((24*60*60*1000) * target);
        return new Date(timeStamp);
    }
    
    convertStringToDatePlus(dateStr) {
        let parts = dateStr.split('-');
        let timeStamp = new Date(parts[0], parts[1] -1, parts[2]).getTime() + (1*24*60*60*1000);
        return new Date(timeStamp);
    }

    convertStringToDate(dateStr) {
        let parts = dateStr.split('-');
        return new Date(parts[0], parts[1] -1, parts[2])
    }

    convertDate(date: Date, format: string): any {
		// format - [year, month, day, hour, minute, second]
		if (!date) {
			return;
		}

		let year = date.getFullYear();
		let month = this.addZeroPadding(date.getMonth() + 1);
		let day = this.addZeroPadding(date.getDate());
		let hour = this.addZeroPadding(date.getHours());
		let minute = this.addZeroPadding(date.getMinutes());
		let second = this.addZeroPadding(date.getSeconds());

		switch (format) {
			case 'year':
				return `${year}`;
			case 'month':
				return `${year}-${month}`;
			case 'day':
				return `${year}-${month}-${day}`;
			case 'hour':
				return `${year}-${month}-${day} ${hour}`;
			case 'minute':
				return `${year}-${month}-${day} ${hour}:${minute}`;
			case 'second':
				return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
			default:
				return date;
		}
    }
    
    private addZeroPadding(dateStr) {
		return `0${dateStr}`.slice(-2);
    }

    random() {
        return Math.floor(Math.random() * 300);
    }

    randomStr() {
        return Math.random().toString(36).substr(2,11);
    }
    uuidStr() {
        return this.uuid();
    }
    
    baseQuery:string = '';
    searchLog () {
        // console.log(this.searchMonth)
        // console.log(this.searchType)
        // console.log(this.searchSort)
        // console.log(this.searchService)
        // console.log(this.searchValue)
        // console.log(this.searchCount)
        // console.log(this.principal)

        this.isCheckedAll = false;

        let tableName = "KS_CRETOP_LOG_R01";
        this.mainTable.fields = ['No','ID','기업명','기업구분','상품명','가격정책','라인수','조회건수','조회기업수','이용시간','구분'];

        if(this.searchType=="priv") {
            tableName = "KS_CRETOP_LOG_R02";
            this.mainTable.fields = ['No','ID','기업명','기업구분','상품명','가격정책','라인수','조회건수','조회개인수','구분'];
        }

        // this.baseQuery = "fulltext _tt=t crdate==\"" + this.searchMonth + "\" from " + tableName;
        this.baseQuery = "table " + tableName + " | search crdate==\"" + this.searchMonth + "\"";
        
        if(this.searchValue != "" ) this.baseQuery += " | search ID == \"*" + this.searchValue + "*\"";
        this.baseQuery += " | sort -" + this.searchSort;
        if(this.searchCount > 0) this.baseQuery += " | limit " + this.searchCount;

        if(this.searchType=="biz") {
            if(this.searchService=="bizserv") this.baseQuery += " | search INSTCLS == \"01\" or INSTCLS == \"02\"  or INSTCLS == \"99\"";
            if(this.searchService=="finserv") this.baseQuery += " | search INSTCLS == \"03\" or INSTCLS == \"04\"";

            this.baseQuery += " | rename CNETTM as 이용시간, ENPNM as 기업명, INSTCLS as 기업구분, IQCN as 조회건수, IQENPCN as 조회기업수, LINECN as 라인수, SVCD as 상품명, USETMCD as 가격정책, crdate as 날짜, IQINDVCN as 조회개인수";
        }

        else {
            this.baseQuery += " | join type=left ID, crdate [ table KS_CRETOP_LOG_R04 | stats count by ID, crdate | rename count as 조회건수 ]  ";
            this.baseQuery += " | join type=left ID, crdate [ table KS_CRETOP_LOG_R04 | stats count by ID, crdate, 조회대상자주민등록번호 | stats count by ID, crdate | rename count as 조회개인수 ]  ";
            
            this.baseQuery += " | rename CNETTM as 이용시간, ENPNM as 기업명, INSTCLS as 기업구분,  IQENPCN as 조회기업수, LINECN as 라인수, SVCD as 상품명, USETMCD as 가격정책, crdate as 날짜";
        }

        // this.baseQuery += " | rename CNETTM as 이용시간, ENPNM as 기업명, INSTCLS as 기업구분, IQCN as 조회건수, IQENPCN as 조회기업수, LINECN as 라인수, SVCD as 상품명, USETMCD as 가격정책, crdate as 날짜, IQINDVCN as 조회개인수";
        this.baseQuery += " | eval 구분 = \"\"";
        this.baseQuery += " | fields ID, 기업명, 기업구분, 상품명, 가격정책, 라인수, 조회건수, 조회기업수, 조회개인수, 이용시간, 구분";

        

        this.baseQuery += " | join type=left ID [ table KED_SCR_COMPANY |  search 시간==\"" + this.searchMonth + "\" | eval 구분=\"탐지\" | fields ID, 기업명, 구분 ]"
        this.baseQuery += " | join type=left ID [ table AS_CRETOP_SELECT |  search crdate==\"" + this.searchMonth + "\" and type==\"" + this.searchType + "\"  | eval 구분=\"완료\" | fields ID, 기업명, 구분 ]"

        this.baseQuery += " | eval 기업구분 = case(기업구분==\"01\",\"대기업\",기업구분==\"02\",\"중소기업\",기업구분==\"03\",\"제1금융기관\",기업구분==\"04\",\"기타금융기관\",기업구분==\"99\",\"구분없음\",기업구분)"
        this.baseQuery += " | eval 상품명 = case(상품명==\"01\",\"CRETOP\",상품명==\"03\",\"CRETOP+C-PATROL\",상품명==\"04\",\"EW\",상품명==\"05\",\"CRETOP+EW\",상품명==\"06\",\"CRETOP+NOTE\",상품명==\"07\",\"CRETOP+EW+NOTE\",상품명)";
        this.baseQuery += " | eval 가격정책 = case(가격정책==\"01\", \"무제한(정액제)\",가격정책==\"02\", \"월4시간(종량제)\",가격정책==\"03\", \"월12시간(종량제)\",가격정책)";

        this.baseQuery += " | sort limit=1 조회건수 by ID"

        if(this.searchType=="biz") {
            this.baseQuery += " | fields ID, 기업명, 기업구분, 상품명, 가격정책, 라인수, 조회건수, 조회기업수, 이용시간, 구분";
        }
        else {
            this.baseQuery += " | fields ID, 기업명, 기업구분, 상품명, 가격정책, 라인수, 조회건수, 조회개인수, 구분";
        }

        switch(this.searchSort) {
            case "IQENPCN":
                this.baseQuery += " | sort -조회기업수";
            break;
            case "CNETTM":
                this.baseQuery += " | sort -이용시간";
            break;
            case "IQINDVCN":
                this.baseQuery += " | sort -조회개인수";
            break;
            case "IQCN":
                this.baseQuery += " | sort -조회건수";
            break;
            default:
            break;
        }

        // console.log("Search Query : ", this.baseQuery);

        let auditDate:any = {};
        auditDate.menu = "정기점검대상선정";
        auditDate.type = "조회";
        auditDate.searchMonth = this.searchMonth;
        auditDate.searchType = this.searchType;
        auditDate.searchSort = this.searchSort;
        auditDate.searchService = this.searchService;
        auditDate.searchCount = this.searchCount;
        auditDate.searchValue = this.searchValue;
        this.AuditRecordService.importAuditLogger(this.principal.login, auditDate);

        this.searchCretopStart();
    }
    searchLogStop () {
        this.isCretopSearch = false;
        this.queryService.stopQuery(this.searchCretopQueryId);
    }

    onSelectSearchType (type:string) {
        if(type=='biz') {
            this.searchServiceDisplay = 'inline-block';
            this.searchSortList = this.searchSortListBiz;
            this.searchSort = 'IQENPCN';
        }
        else {
            this.searchServiceDisplay = 'none';
            this.searchSortList = this.searchSortListPriv;
            this.searchSort = 'IQINDVCN';
        }

        this.searchLog();
    }

    onSelectSearchMonth (type:string) {
        this.searchLog();
    }
    onSelectSearchSort (type:string) {
        this.searchLog();
    }
    onSelectSearchService (type:string) {
        this.searchLog();
    }
    onSelectSearchRange () {
        this.searchLog();
    }

    private searchCretopQueryId;
    isCretopSearch:boolean = false;
    searchCretopStart () {
        if (!!this.searchCretopQueryId) {
			this.queryService.removeQuery(this.searchCretopQueryId);
			this.searchCretopQueryId = null;
        }
        this.logListCurrentPage = 1;
        this.logListTotalItems = 0;

        this.selectTargetItem = [];

        if(this.searchCount > 0) this.logListPageSize = this.searchCount;
        else this.logListPageSize = 50;

        this.queryService.createQuery(this.baseQuery, { onChanged: this.searchCretopChange })
        .then((query) => {
            this.queryService.startQuery(query.id)
			.then(() => {
                this.searchCretopQueryId = query.id;
                this.isCretopSearch = true;
			})
			.catch((msg) => {
				console.log('error', msg);
			});
        })
        .catch((msg) => {
            console.log('error', msg);
        });
    }
    searchCretopChange (query) {
        if (!!query) {
            if(query.status=="Ended") this.isCretopSearch = false;
			this.searchCretopResult(query.id, "normal");
		}
    }
    searchCretopResult (id, type) {
        const offset = (this.logListCurrentPage - 1) * this.logListPageSize;
        const limit = this.logListPageSize;

		this.queryService.getResult(id, offset, limit)
        .then((result) => {
            this.logListTotalItems = result.count;
            this.mainTable.value = this.addNumbering(result.records);
            // if(typeof result.fieldOrder === "undefined") this.mainTable.fields = [];
            // else this.mainTable.fields = result.fieldOrder;

            if(this.searchCount > 0) this.makeChkedData(result.records)
            else {
                if(type=="normal") this.makeChkedDataAll(id, this.logListTotalItems)
            }

            this.makePagingInfo();
            this.cdr.detectChanges();
        })
        .catch(function (msg) {
            console.log('error', msg);
        });
    }

    addNumbering(arr) {
        for(let i=0; i<arr.length; i++) {
            arr[i]['No'] = i + 1 + ( (this.logListCurrentPage -1) * this.logListPageSize )
        }

        return arr;
    }

    makeChkedData (arr) {
        for(let i=0; i<arr.length; i++) {
            if(arr[i]['구분']=="탐지") this.selectTargetItem.push({ID:arr[i]['ID'],기업명:arr[i]['기업명']})
        }
    }
    makeChkedDataAll (id, limit) {
        this.queryService.getResult(id, 0, limit)
        .then((result) => {
            for(let i=0; i<result.records.length; i++) {
                if(result.records[i]['구분']=="탐지") this.selectTargetItem.push({ID:result.records[i]['ID'],기업명:result.records[i]['기업명']})
            }
        })
        .catch(function (msg) {
            console.log('error', msg);
        });
    }

    selectTargetItem:any = [];
    selectAction (item) {
        if(item['구분']!='완료') {
            let chkIdx = this.selectTargetItem.findIndex(x => x.ID == item['ID']);
            if(chkIdx == -1 ) this.selectTargetItem.push({ID:item['ID'],기업명:item['기업명']})
            else this.selectTargetItem.splice(chkIdx, 1)
        }
        else {
            alert("완료된 항목은 수정 할 수 없습니다.")
        }
        

        // console.log(this.selectTargetItem)
    }

    chkSelectClass (type, id) {
        // if(this.selectTargetItem.findIndex(x => x.ID == id)!=-1) return 'answer-cretop-selected';
        // else if(this.detectTargetItem.findIndex(x => x.ID == id)!=-1) return 'answer-cretop-detected';
        // else return '';

        if(this.selectTargetItem.findIndex(x => x.ID == id)!=-1) return 'answer-cretop-selected';
        else {
            if(type=="탐지") return 'answer-cretop-detected';
            else if(type=="완료") return 'answer-cretop-completed';
            else return '';
        }
    }
    findCheckedValue (type, id) {
        if(this.selectTargetItem.findIndex(x => x.ID == id)!=-1) return true;
        else {
            //if(type=="탐지") return true;
            if(type=="완료") return true;
            else return false;
        }
    }
    
    initSelectCretop () {
        this.selectTargetItem = [];
    }

    isCheckedAll:boolean = false;
    selectActionAll () {
        this.isCheckedAll = !this.isCheckedAll;

        if(this.isCheckedAll) {
            for(let i =0; i<this.mainTable.value.length; i++) {
                let item = this.mainTable.value[i];
                if(item['구분']!='완료') {
                    let chkIdx = this.selectTargetItem.findIndex(x => x.ID == item['ID']);
                    if(chkIdx == -1 ) this.selectTargetItem.push({ID:item['ID'],기업명:item['기업명']})
                }
            }
        }
        else {
            // this.selectTargetItem = [];
            for(let i =0; i<this.mainTable.value.length; i++) {
                let item = this.mainTable.value[i];
                if(item['구분']!='완료') {
                    
                    let chkIdx = this.selectTargetItem.findIndex(x => x.ID == item['ID']);
                    if(chkIdx != -1 ) this.selectTargetItem.splice(chkIdx,1);
                }
            }
        }
    }









    /***** Pagination  *****/
	logListCurrentPage:number = 1;
    logListTotalItems:number = 0;

    logListMaxPageCount:number = 0;
    pagingArray:any = [];
    logListPageSize:number = 50;
    logListPageLength:number = 10;
    logListCurrentStart = 1;

    makePagingInfo () {
        this.pagingArray = [];
        let arrayCount = 0;
        if(this.logListTotalItems>0) this.logListMaxPageCount = Math.ceil(this.logListTotalItems / this.logListPageSize);

        if(this.logListMaxPageCount > this.logListPageSize) arrayCount = this.logListPageLength;
        else arrayCount = this.logListMaxPageCount;

        for(let i=0; i<arrayCount; i++) {
            let inputNum = i + this.logListCurrentStart;
            if(this.logListMaxPageCount >= inputNum) this.pagingArray.push(inputNum)
            else break;
        }
    }
    searchLogPageChanged (pNum) {
        this.logListCurrentPage = pNum;
        this.logListCurrentStart = (Math.ceil(this.logListCurrentPage / this.logListPageLength) - 1) * this.logListPageLength + 1;

        this.isCheckedAll = false;
        this.searchCretopResult(this.searchCretopQueryId ,"page");
    }
    searchLogPageNext () {
        let move = this.logListCurrentPage + 1;
        if(move > this.logListMaxPageCount) move = this.logListMaxPageCount;
        this.searchLogPageChanged(move)
    }
    searchLogPagePrev () {
        let move = this.logListCurrentPage - 1;
        if(move < 1) move = 1;
        this.searchLogPageChanged(move)
    }
    searchLogPageNextJump () {
        let move = this.logListCurrentPage + this.logListPageLength;
        if(move > this.logListMaxPageCount) move = this.logListMaxPageCount;
        this.searchLogPageChanged(move)
    }
    searchLogPagePrevJump () {
        let move = this.logListCurrentPage - this.logListPageLength;
        if(move < 1) move = 1;
        this.searchLogPageChanged(move)
    }





    getCretopList (callback) {
        this.queryService.getResult(this.searchCretopQueryId, 0, this.logListTotalItems)
        .then((result) => {
            callback(result.records);
        })
        .catch(function (msg) {
            console.log('error', msg);
        });
    }

    exportExcel () {
        let auditDate:any = {};
        auditDate.menu = "정기점검대상선정";
        auditDate.type = "다운로드";
        auditDate.searchMonth = this.searchMonth;
        auditDate.searchType = this.searchType;
        auditDate.searchSort = this.searchSort;
        auditDate.searchService = this.searchService;
        auditDate.searchCount = this.searchCount;
        auditDate.searchValue = this.searchValue;
        this.AuditRecordService.importAuditLogger(this.principal.login, auditDate);

        let fileName = "크래탑_점검대상(" + this.searchMonth + ").xlsx";
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        let defineHeader = [];
        if(this.searchType=="biz") {
            defineHeader = ['ID','기업명','기업구분','상품명','가격정책','라인수','조회건수','조회기업수','이용시간','구분'];
        }
        else {
            defineHeader = ['ID','기업명','기업구분','상품명','가격정책','라인수','조회건수','조회개인수','구분'];
        }

        if(this.logListTotalItems > 10000) {
            if(confirm("전체 10,000 건 이상의 데이터 경우 CSV 로 다운로드 해야 합니다.")) {
                let charset = 'MS949';
                let filename = "크래탑_점검대상(" + this.searchMonth + ").csv";
                let fields = defineHeader;
                let offset = 0;
                let limit = this.logListTotalItems;
                let query_id = this.searchCretopQueryId;
                
                this.answerService.csvDownload(charset, filename, fields, offset, limit, query_id).then(token => {
                    this.fileService.download(token);
                });
            }
        }
        else {
            this.getCretopList((data) => {
                const ws: XLSX.WorkSheet =XLSX.utils.json_to_sheet(data, {header: defineHeader});
                XLSX.utils.book_append_sheet(wb, ws, '점검대상');
                XLSX.writeFile(wb, fileName);
            });
        }
    }

    private importCretopQueryId;
    isImport:boolean = false;
    importInterval:any = null;
    importCretopLista () {
        this.go('datalog-ked-cre/routine-status')
    }
    importCretopList () {
        if(this.selectTargetItem.length==0) {
            alert("선택된 항목이 없습니다");
            return;
        }

        this.importCretopListStart();
        this.importCretopFinal();
    }

    
    importCretopListStart () {
        // console.log("Save and First Routine", this.selectTargetItem);

        if(confirm("선택된 항목을 저장하시겠습니까?")) {
            let inputQuery = "json \"" + JSON.stringify(this.selectTargetItem) + "\"";
            inputQuery += " | eval writer = \"" + this.principal.login + "\""
            inputQuery += " | eval crdate = \"" + this.searchMonth + "\""
            inputQuery += " | eval type = \"" + this.searchType + "\""
            inputQuery += " | import AS_CRETOP_SELECT";

            let auditDate:any = {};
            auditDate.menu = "정기점검대상선정";
            auditDate.type = "검토";
            auditDate.searchMonth = this.searchMonth;
            auditDate.searchType = this.searchType;
            auditDate.searchSort = this.searchSort;
            auditDate.searchService = this.searchService;
            auditDate.searchCount = this.searchCount;
            auditDate.searchValue = this.searchValue;
            auditDate.checkCount = this.selectTargetItem.lengths;
            this.AuditRecordService.importAuditLogger(this.principal.login, auditDate);

            // console.log(inputQuery)

            if (!!this.importCretopQueryId) {
                this.queryService.removeQuery(this.importCretopQueryId);
                this.importCretopQueryId = null;
            }

            this.isImport = true;

            this.queryService.createQuery(inputQuery, { onChanged: this.importCretopChange })
            .then((query) => {
                this.queryService.startQuery(query.id)
                .then(() => {
                    this.importCretopQueryId = query.id;
                })
                .catch((msg) => {
                    console.log('error', msg);
                });
            })
            .catch((msg) => {
                console.log('error', msg);
            });
        }
    }

    importCretopChange (query) {
        if(!!query) {
            if(query.status=="Ended") {
                this.isImport = false;
                // this.router.routeReuseStrategy.shouldReuseRoute = function() {
                //     return false;
                // }
                // this.router.onSameUrlNavigation = 'reload';
                
                //this.router.navigate(['/datalog-ked-cre/routine-check', this.searchMonth, this.searchType])
                //this.router.navigateByUrl(`datalog-ked-cre/routine-check/${this.searchMonth}/${this.searchType}`);
            }
        }
    }
    importCretopFinal () {
        this.importInterval = setInterval(() => {
            // console.log("CHECK")
            if(!this.isImport) {
                clearInterval(this.importInterval);
                this.go(`datalog-ked-cre/routine-check/${this.searchMonth}/${this.searchType}`)
            }
        }, 1000)
    }

    go(route: string) {
		this.router.navigateByUrl(route);
	}



    private selectCretopDetectedQueryId;
    private selectCretopCompletedQueryId;

    detectTargetItem:any = [];
    selectCretopDetectedList () {
        if (!!this.selectCretopDetectedQueryId) {
			this.queryService.removeQuery(this.selectCretopDetectedQueryId);
			this.selectCretopDetectedQueryId = null;
        }

        // let queryStr = "fulltext _tt=t crdate==\"" + this.searchMonth + "\" from " + tableName;
        let queryStr = "table KED_SCR_COMPANY | search 시간==\"" + this.searchMonth + "\"";

        this.queryService.createQuery(queryStr, { onChanged: this.selectCretopDetectedResult })
        .then((query) => {
            this.queryService.startQuery(query.id)
			.then(() => {
                this.selectCretopDetectedQueryId = query.id;
			})
			.catch((msg) => {
				console.log('error', msg);
			});
        })
        .catch((msg) => {
            console.log('error', msg);
        });
    }

    selectCretopDetectedResult (query) {
        if(!!query) {
            
            this.queryService.getResult(query.id, 0, query.totalCount)
            .then((result) => {
                // console.log(result);
                this.detectTargetItem = result.records;

                this.cdr.detectChanges();
            })
            .catch(function (msg) {
                console.log('error', msg);
            });
        }
    }

    selectCretopCompletedList () {

    }

    selectCretopCompletedResult () {

    }

}