import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
	selector: 'not-found',
	template: `
	<body>
		<h1>404 Not Found</h1><pre></pre><hr/>
		<address>Logpresso Sonar</address>
	</body>
	`
})
export class NotFoundComponent implements OnInit {
	constructor(
		private route: ActivatedRoute,
		private router: Router) {
	}

	ngOnInit(): void {

	}

	run(): void {
	}

}
