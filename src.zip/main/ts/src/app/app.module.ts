import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SonarAppModule } from 'sonar-angular5-sdk';
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { HomeComponent } from './home.component';
import { NotFoundComponent } from './not-found.component';
import { MenuComponent } from './menu.component';
import { SideBarComponent } from './side-bar.component';

import { RoutineSelectComponent } from './ts/routine-select.component';
import { RoutineCheckComponent } from './ts/routine-check.component';
import { RoutineReportComponent } from './ts/routine-report.component';
import { RoutineStatusComponent } from './ts/routine-status.component';

import { UsedHistoryComponent } from './ts/used-history.component';
import { RoutineAdminComponent } from './ts/routine-admin.component';

import { AuditRecordService } from './ts/audit-record.service';
import { AnswerService } from './ts/answer.service';

import { OrdinalPipe } from './filter/ordinal';
import { BytePipe } from './filter/byte';
import { DateformatPipe } from './filter/dateformat';
import { NcommaPipe } from './filter/ncomma'
import { DurationPipe } from './filter/duration'
import { DatestringPipe } from './filter/datestring'

import { ResizeColumnDirective } from './directive/resize-column.directive';

@NgModule({
	imports: [
		BrowserModule,
		AppRoutingModule,
		SonarAppModule.forRoot({
			// websocketUrl: 'ws://172.29.211.234:8080/websocket'
			websocketUrl: 'wss://localhost/websocket'
		})
	],
	declarations: [
		HomeComponent,
		MenuComponent,
		SideBarComponent,

		RoutineSelectComponent,
		RoutineCheckComponent,
		RoutineReportComponent,
		RoutineStatusComponent,
		UsedHistoryComponent,
		RoutineAdminComponent,

		OrdinalPipe,
		BytePipe,
		DateformatPipe,
		NcommaPipe,
		DurationPipe,
		DatestringPipe,

		ResizeColumnDirective,
		
		NotFoundComponent,
		AppComponent
	],
	providers: [
		AuditRecordService,
		AnswerService
	],
	bootstrap: [AppComponent]
})
export class AppModule { }
