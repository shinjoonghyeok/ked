import { Component, OnInit, Input, ViewChild, NgZone, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import {
	QueryService, MsgbusService, WebsocketService, HostNavigatorService,
	MenuService, TopMenu, Logger, LogService, HostAuthService, Principal
} from 'sonar-angular5-sdk';
import { DomSanitizer, Title } from '@angular/platform-browser';

@Component({
	selector: 'menu',
	template: `
	<div class="gnb" *ngIf="!hideMenubar" style="position: static;">
		<!-- <div class="menu-container" style="background-color:#593196;"> -->
		<div class="menu-container">
			<div class="sonar-container" [ngClass]="{'fluid': !isHomePage()}">
				<!-- <div class="logo-box pull-left" (click)="goHome()"> -->
				<div class="logo-box pull-left">
				<span class="logo"></span>
					<!-- <span class="logo" *ngIf="!isCustom"></span>
					<span class="logo-custom" *ngIf="isCustom"></span> -->
				</div>
				<div class="menu pull-left">
					<ul class="apps">
						<ng-container *ngFor="let topMenu of topMenus; index as i">
							<li class="app" *ngIf="topMenu.visible">
								<a (click)="onClickMenu(topMenu.route)" [class.active]="isActive(topMenu)">
									<img *ngIf="topMenu.icon!=null" [src]="convertSafeImgUrl(topMenu.icon)"/>
									<i *ngIf="topMenu.icon==null" [ngClass]="topMenu.className"></i>
									{{topMenu.nameKo}}
								</a>
							</li>
						</ng-container>
					</ul>
				</div>
				<div class="profile pull-right" *ngIf="!isLoggedOn && !isLoginPage()">
					<form class="login" novalidate>
						<div class="pull-left">
							<input [(ngModel)]="loginName" placeholder="계정" [ngModelOptions]="{standalone: true}" />
						</div>
						<div class="pull-left">
							<input [(ngModel)]="password" type="password" placeholder="암호" [ngModelOptions]="{standalone: true}" />
						</div>
						<button (click)="tryLogin()" class="btn btn-sonar-blue">로그인</button>
					</form>
				</div>
				<div class="profile pull-right" *ngIf="isLoggedOn">
					<div class="user-img pull-left"><img src="/img/profile.png"></div>
					<!-- <div class="user-login pull-left" edmTooltip="bottom">{{principal.userName}} -->
					<div class="user-login pull-left">{{principal.userName}}
						<ng-template #tooltipTemplate>{{principal.roleName}}</ng-template>
					</div>
					<!-- <div class="icon-box pull-left">
						<div class="user-box">
							<i class="fa fa-lg fa-ticket"></i>
						</div>
					</div>
					<div class="icon-box pull-left">
						<div class="user-box" (click)="viewMyInfo()" edmTooltip="bottom">
							<i class="fa fa-lg fa-user-o"></i>
							<ng-template #tooltipTemplate>내 정보</ng-template>
						</div>
					</div> -->
					<div class="icon-box pull-left">
						<!-- <div class="user-box" (click)="logout()" edmTooltip="bottom"> -->
						<div class="user-box" (click)="logout()">
							<i class="fa fa-lg fa-sign-out"></i>
							<ng-template #tooltipTemplate>로그아웃</ng-template>
						</div>
					</div>
				</div>				
			</div>
		</div>
	</div>`,
	styles: [`:host { padding:0; margin:0 }`]
})
export class MenuComponent implements OnInit {

	connected: boolean;
	topMenus: TopMenu[];

	loginName: string;
	password: string;
	private logger: Logger;
	private currentTopMenu: TopMenu;


	constructor(
		log: LogService,
		private zone: NgZone,
		private detector: ChangeDetectorRef,
		private route: ActivatedRoute,
		private router: Router,
		private websocketService: WebsocketService,
		private msgbusService: MsgbusService,
		private sanitize: DomSanitizer,
		private menuService: MenuService,
		private authService: HostAuthService,
		private navigatorService: HostNavigatorService) {
		this.logger = log.getLogger('sample.menu.component');

	}

	ngOnInit(): void {
		if (this.websocketService.isConnected()) {
			this.logger.info('sample app menu: check connect status, ' + this.websocketService.isConnected());
			this.connected = true;
			this.reload();
		} else {
			this.websocketService.watchConnected().subscribe(isConnected => {
				this.logger.info('sample app menu: connect signal, ' + isConnected);
				this.connected = isConnected;
				this.reload();
			});
		}
	}

	get principal(): Principal {
		return this.authService.getPrincipal();
	}

	get hideMenubar(): boolean {
		return false;
	}

	reload(): void {
		this.menuService.reload()
			.then(() => {
				this.zone.run(() => {
					this.logger.info('sample app menu: reloaded');

					this.topMenus = this.menuService.getTopMenus();
					console.log("topMenus", this.topMenus);
					for (let t of this.topMenus)
						this.logger.info('sample app menu: top menu' + t.nameKo + ' route ' + t.route + ' visible ' + t.visible);

					this.setCurrentTopMenu();
					this.logger.info('sample app menu: current principal ' + this.principal);
				});
			})
			.catch((msg) => console.warn('reload failed', msg));
	}


	isHomePage() {
		return this.router.url === '/home';
	}

	isLoginPage() {
		if(typeof window.parent['SONAR'] === "undefined") return false;

		if(window.parent['SONAR'].path=="/login") return true;
		else return false;
	}

	goHome() {
		this.navigatorService.navigateByUrl('/app-loader/datalog-ked-sec');
	}

	search() {

	}

	tryLogin() {
		this.logger.info('trying to login ' + this.loginName);
		this.authService.login(this.loginName, this.password).then((msg) => {
			let result: boolean = msg.params.result;
			if (result) {
				this.navigatorService.navigateByUrl('/');
				this.reload();
			} else {
				this.navigatorService.navigateByUrl('/login');
			}
		}).catch((reason) => {
			console.log('login failed', reason);
		});

		// clear password from memory immediately
		this.password = null;
	}

	viewMyInfo() {
		this.navigatorService.navigateByUrl(`/users/${this.principal.userGuid}`);
	}

	logout() {
		this.authService.logout().then(() => {
			this.reload();
			//this.navigatorService.navigateByUrl('/');
		});
	}

	isActive(topMenu: TopMenu): boolean {
		if (!this.currentTopMenu) {
			return false;
		}

		return this.currentTopMenu.route == topMenu.route;
	}

	get isLoggedOn(): boolean {
		return this.authService.getPrincipal() != null;
	}

	onClickMenu(route: string) {
		this.navigatorService.navigateByUrl(route).then(() => {
			this.setCurrentTopMenu();
		});
	}

	convertSafeImgUrl(url) {
		return this.sanitize.bypassSecurityTrustUrl('data:image/png;base64,' + url);
	}

	setCurrentTopMenu() {
		this.zone.run(() => {
			let path = this.router.url;
			if (!!window.parent && !!window.parent['SONAR'].path)
				path = window.parent['SONAR'].path;

			if (path == '/'){
				path = '/home';
			} else if(path.startsWith('/app-loader/') && path[path.length] != '/'){
				path = path + '/'
			}

			this.logger.info('sample app menu: check path ' + path);

			this.currentTopMenu = this.menuService.getTopMenuByMenuRoute(path);
			this.logger.info('sample app menu: current top menu for ' + path + ' ' + this.currentTopMenu);
		});
	}

}