function earcut(data, holeIndices, dim) {

    dim = dim || 2;

    var hasHoles = holeIndices && holeIndices.length,
        outerLen = hasHoles ? holeIndices[0] * dim : data.length,
        outerNode = linkedList(data, 0, outerLen, dim, true),
        triangles = [];

    if (!outerNode) return triangles;

    var minX, minY, maxX, maxY, x, y, size;

    if (hasHoles) outerNode = eliminateHoles(data, holeIndices, outerNode, dim);

    // if the shape is not too simple, we'll use z-order curve hash later; calculate polygon bbox
    if (data.length > 80 * dim) {
        minX = maxX = data[0];
        minY = maxY = data[1];

        for (var i = dim; i < outerLen; i += dim) {
            x = data[i];
            y = data[i + 1];
            if (x < minX) minX = x;
            if (y < minY) minY = y;
            if (x > maxX) maxX = x;
            if (y > maxY) maxY = y;
        }

        // minX, minY and size are later used to transform coords into integers for z-order calculation
        size = Math.max(maxX - minX, maxY - minY);
    }

    earcutLinked(outerNode, triangles, dim, minX, minY, size);

    return triangles;
}

// create a circular doubly linked list from polygon points in the specified winding order
function linkedList(data, start, end, dim, clockwise) {
    var sum = 0,
        i, j, last;

    // calculate original winding order of a polygon ring
    for (i = start, j = end - dim; i < end; i += dim) {
        sum += (data[j] - data[i]) * (data[i + 1] + data[j + 1]);
        j = i;
    }

    // link points into circular doubly-linked list in the specified winding order
    if (clockwise === (sum > 0)) {
        for (i = start; i < end; i += dim) last = insertNode(i, data[i], data[i + 1], last);
    } else {
        for (i = end - dim; i >= start; i -= dim) last = insertNode(i, data[i], data[i + 1], last);
    }

    return last;
}

// eliminate colinear or duplicate points
function filterPoints(start, end) {
    if (!start) return start;
    if (!end) end = start;

    var p = start,
        again;
    do {
        again = false;

        if (!p.steiner && (equals(p, p.next) || area(p.prev, p, p.next) === 0)) {
            removeNode(p);
            p = end = p.prev;
            if (p === p.next) return null;
            again = true;

        } else {
            p = p.next;
        }
    } while (again || p !== end);

    return end;
}

// main ear slicing loop which triangulates a polygon (given as a linked list)
function earcutLinked(ear, triangles, dim, minX, minY, size, pass) {
    if (!ear) return;

    // interlink polygon nodes in z-order
    if (!pass && size) indexCurve(ear, minX, minY, size);

    var stop = ear,
        prev, next;

    // iterate through ears, slicing them one by one
    while (ear.prev !== ear.next) {
        prev = ear.prev;
        next = ear.next;

        if (size ? isEarHashed(ear, minX, minY, size) : isEar(ear)) {
            // cut off the triangle
            triangles.push(prev.i / dim);
            triangles.push(ear.i / dim);
            triangles.push(next.i / dim);

            removeNode(ear);

            // skipping the next vertice leads to less sliver triangles
            ear = next.next;
            stop = next.next;

            continue;
        }

        ear = next;

        // if we looped through the whole remaining polygon and can't find any more ears
        if (ear === stop) {
            // try filtering points and slicing again
            if (!pass) {
                earcutLinked(filterPoints(ear), triangles, dim, minX, minY, size, 1);

            // if this didn't work, try curing all small self-intersections locally
            } else if (pass === 1) {
                ear = cureLocalIntersections(ear, triangles, dim);
                earcutLinked(ear, triangles, dim, minX, minY, size, 2);

            // as a last resort, try splitting the remaining polygon into two
            } else if (pass === 2) {
                splitEarcut(ear, triangles, dim, minX, minY, size);
            }

            break;
        }
    }
}

// check whether a polygon node forms a valid ear with adjacent nodes
function isEar(ear) {
    var a = ear.prev,
        b = ear,
        c = ear.next;

    if (area(a, b, c) >= 0) return false; // reflex, can't be an ear

    // now make sure we don't have other points inside the potential ear
    var p = ear.next.next;

    while (p !== ear.prev) {
        if (pointInTriangle(a.x, a.y, b.x, b.y, c.x, c.y, p.x, p.y) &&
            area(p.prev, p, p.next) >= 0) return false;
        p = p.next;
    }

    return true;
}

function isEarHashed(ear, minX, minY, size) {
    var a = ear.prev,
        b = ear,
        c = ear.next;

    if (area(a, b, c) >= 0) return false; // reflex, can't be an ear

    // triangle bbox; min & max are calculated like this for speed
    var minTX = a.x < b.x ? (a.x < c.x ? a.x : c.x) : (b.x < c.x ? b.x : c.x),
        minTY = a.y < b.y ? (a.y < c.y ? a.y : c.y) : (b.y < c.y ? b.y : c.y),
        maxTX = a.x > b.x ? (a.x > c.x ? a.x : c.x) : (b.x > c.x ? b.x : c.x),
        maxTY = a.y > b.y ? (a.y > c.y ? a.y : c.y) : (b.y > c.y ? b.y : c.y);

    // z-order range for the current triangle bbox;
    var minZ = zOrder(minTX, minTY, minX, minY, size),
        maxZ = zOrder(maxTX, maxTY, minX, minY, size);

    // first look for points inside the triangle in increasing z-order
    var p = ear.nextZ;

    while (p && p.z <= maxZ) {
        if (p !== ear.prev && p !== ear.next &&
            pointInTriangle(a.x, a.y, b.x, b.y, c.x, c.y, p.x, p.y) &&
            area(p.prev, p, p.next) >= 0) return false;
        p = p.nextZ;
    }

    // then look for points in decreasing z-order
    p = ear.prevZ;

    while (p && p.z >= minZ) {
        if (p !== ear.prev && p !== ear.next &&
            pointInTriangle(a.x, a.y, b.x, b.y, c.x, c.y, p.x, p.y) &&
            area(p.prev, p, p.next) >= 0) return false;
        p = p.prevZ;
    }

    return true;
}

// go through all polygon nodes and cure small local self-intersections
function cureLocalIntersections(start, triangles, dim) {
    var p = start;
    do {
        var a = p.prev,
            b = p.next.next;

        // a self-intersection where edge (v[i-1],v[i]) intersects (v[i+1],v[i+2])
        if (intersects(a, p, p.next, b) && locallyInside(a, b) && locallyInside(b, a)) {

            triangles.push(a.i / dim);
            triangles.push(p.i / dim);
            triangles.push(b.i / dim);

            // remove two nodes involved
            removeNode(p);
            removeNode(p.next);

            p = start = b;
        }
        p = p.next;
    } while (p !== start);

    return p;
}

// try splitting polygon into two and triangulate them independently
function splitEarcut(start, triangles, dim, minX, minY, size) {
    // look for a valid diagonal that divides the polygon into two
    var a = start;
    do {
        var b = a.next.next;
        while (b !== a.prev) {
            if (a.i !== b.i && isValidDiagonal(a, b)) {
                // split the polygon in two by the diagonal
                var c = splitPolygon(a, b);

                // filter colinear points around the cuts
                a = filterPoints(a, a.next);
                c = filterPoints(c, c.next);

                // run earcut on each half
                earcutLinked(a, triangles, dim, minX, minY, size);
                earcutLinked(c, triangles, dim, minX, minY, size);
                return;
            }
            b = b.next;
        }
        a = a.next;
    } while (a !== start);
}

// link every hole into the outer loop, producing a single-ring polygon without holes
function eliminateHoles(data, holeIndices, outerNode, dim) {
    var queue = [],
        i, len, start, end, list;

    for (i = 0, len = holeIndices.length; i < len; i++) {
        start = holeIndices[i] * dim;
        end = i < len - 1 ? holeIndices[i + 1] * dim : data.length;
        list = linkedList(data, start, end, dim, false);
        if (list === list.next) list.steiner = true;
        queue.push(getLeftmost(list));
    }

    queue.sort(compareX);

    // process holes from left to right
    for (i = 0; i < queue.length; i++) {
        eliminateHole(queue[i], outerNode);
        outerNode = filterPoints(outerNode, outerNode.next);
    }

    return outerNode;
}

function compareX(a, b) {
    return a.x - b.x;
}

// find a bridge between vertices that connects hole with an outer ring and and link it
function eliminateHole(hole, outerNode) {
    outerNode = findHoleBridge(hole, outerNode);
    if (outerNode) {
        var b = splitPolygon(outerNode, hole);
        filterPoints(b, b.next);
    }
}

// David Eberly's algorithm for finding a bridge between hole and outer polygon
function findHoleBridge(hole, outerNode) {
    var p = outerNode,
        hx = hole.x,
        hy = hole.y,
        qx = -Infinity,
        m;

    // find a segment intersected by a ray from the hole's leftmost point to the left;
    // segment's endpoint with lesser x will be potential connection point
    do {
        if (hy <= p.y && hy >= p.next.y) {
            var x = p.x + (hy - p.y) * (p.next.x - p.x) / (p.next.y - p.y);
            if (x <= hx && x > qx) {
                qx = x;
                m = p.x < p.next.x ? p : p.next;
            }
        }
        p = p.next;
    } while (p !== outerNode);

    if (!m) return null;

    // look for points inside the triangle of hole point, segment intersection and endpoint;
    // if there are no points found, we have a valid connection;
    // otherwise choose the point of the minimum angle with the ray as connection point

    var stop = m,
        tanMin = Infinity,
        tan;

    p = m.next;

    while (p !== stop) {
        if (hx >= p.x && p.x >= m.x &&
                pointInTriangle(hy < m.y ? hx : qx, hy, m.x, m.y, hy < m.y ? qx : hx, hy, p.x, p.y)) {

            tan = Math.abs(hy - p.y) / (hx - p.x); // tangential

            if ((tan < tanMin || (tan === tanMin && p.x > m.x)) && locallyInside(p, hole)) {
                m = p;
                tanMin = tan;
            }
        }

        p = p.next;
    }

    return m;
}

// interlink polygon nodes in z-order
function indexCurve(start, minX, minY, size) {
    var p = start;
    do {
        if (p.z === null) p.z = zOrder(p.x, p.y, minX, minY, size);
        p.prevZ = p.prev;
        p.nextZ = p.next;
        p = p.next;
    } while (p !== start);

    p.prevZ.nextZ = null;
    p.prevZ = null;

    sortLinked(p);
}

// Simon Tatham's linked list merge sort algorithm
// http://www.chiark.greenend.org.uk/~sgtatham/algorithms/listsort.html
function sortLinked(list) {
    var i, p, q, e, tail, numMerges, pSize, qSize,
        inSize = 1;

    do {
        p = list;
        list = null;
        tail = null;
        numMerges = 0;

        while (p) {
            numMerges++;
            q = p;
            pSize = 0;
            for (i = 0; i < inSize; i++) {
                pSize++;
                q = q.nextZ;
                if (!q) break;
            }

            qSize = inSize;

            while (pSize > 0 || (qSize > 0 && q)) {

                if (pSize === 0) {
                    e = q;
                    q = q.nextZ;
                    qSize--;
                } else if (qSize === 0 || !q) {
                    e = p;
                    p = p.nextZ;
                    pSize--;
                } else if (p.z <= q.z) {
                    e = p;
                    p = p.nextZ;
                    pSize--;
                } else {
                    e = q;
                    q = q.nextZ;
                    qSize--;
                }

                if (tail) tail.nextZ = e;
                else list = e;

                e.prevZ = tail;
                tail = e;
            }

            p = q;
        }

        tail.nextZ = null;
        inSize *= 2;

    } while (numMerges > 1);

    return list;
}

// z-order of a point given coords and size of the data bounding box
function zOrder(x, y, minX, minY, size) {
    // coords are transformed into non-negative 15-bit integer range
    x = 32767 * (x - minX) / size;
    y = 32767 * (y - minY) / size;

    x = (x | (x << 8)) & 0x00FF00FF;
    x = (x | (x << 4)) & 0x0F0F0F0F;
    x = (x | (x << 2)) & 0x33333333;
    x = (x | (x << 1)) & 0x55555555;

    y = (y | (y << 8)) & 0x00FF00FF;
    y = (y | (y << 4)) & 0x0F0F0F0F;
    y = (y | (y << 2)) & 0x33333333;
    y = (y | (y << 1)) & 0x55555555;

    return x | (y << 1);
}

// find the leftmost node of a polygon ring
function getLeftmost(start) {
    var p = start,
        leftmost = start;
    do {
        if (p.x < leftmost.x) leftmost = p;
        p = p.next;
    } while (p !== start);

    return leftmost;
}

// check if a point lies within a convex triangle
function pointInTriangle(ax, ay, bx, by, cx, cy, px, py) {
    return (cx - px) * (ay - py) - (ax - px) * (cy - py) >= 0 &&
           (ax - px) * (by - py) - (bx - px) * (ay - py) >= 0 &&
           (bx - px) * (cy - py) - (cx - px) * (by - py) >= 0;
}

// check if a diagonal between two polygon nodes is valid (lies in polygon interior)
function isValidDiagonal(a, b) {
    return equals(a, b) || a.next.i !== b.i && a.prev.i !== b.i && !intersectsPolygon(a, b) &&
           locallyInside(a, b) && locallyInside(b, a) && middleInside(a, b);
}

// signed area of a triangle
function area(p, q, r) {
    return (q.y - p.y) * (r.x - q.x) - (q.x - p.x) * (r.y - q.y);
}

// check if two points are equal
function equals(p1, p2) {
    return p1.x === p2.x && p1.y === p2.y;
}

// check if two segments intersect
function intersects(p1, q1, p2, q2) {
    return area(p1, q1, p2) > 0 !== area(p1, q1, q2) > 0 &&
           area(p2, q2, p1) > 0 !== area(p2, q2, q1) > 0;
}

// check if a polygon diagonal intersects any polygon segments
function intersectsPolygon(a, b) {
    var p = a;
    do {
        if (p.i !== a.i && p.next.i !== a.i && p.i !== b.i && p.next.i !== b.i &&
                intersects(p, p.next, a, b)) return true;
        p = p.next;
    } while (p !== a);

    return false;
}

// check if a polygon diagonal is locally inside the polygon
function locallyInside(a, b) {
    return area(a.prev, a, a.next) < 0 ?
        area(a, b, a.next) >= 0 && area(a, a.prev, b) >= 0 :
        area(a, b, a.prev) < 0 || area(a, a.next, b) < 0;
}

// check if the middle point of a polygon diagonal is inside the polygon
function middleInside(a, b) {
    var p = a,
        inside = false,
        px = (a.x + b.x) / 2,
        py = (a.y + b.y) / 2;
    do {
        if (((p.y > py) !== (p.next.y > py)) && (px < (p.next.x - p.x) * (py - p.y) / (p.next.y - p.y) + p.x))
            inside = !inside;
        p = p.next;
    } while (p !== a);

    return inside;
}

// link two polygon vertices with a bridge; if the vertices belong to the same ring, it splits polygon into two;
// if one belongs to the outer ring and another to a hole, it merges it into a single ring
function splitPolygon(a, b) {
    var a2 = new Node(a.i, a.x, a.y),
        b2 = new Node(b.i, b.x, b.y),
        an = a.next,
        bp = b.prev;

    a.next = b;
    b.prev = a;

    a2.next = an;
    an.prev = a2;

    b2.next = a2;
    a2.prev = b2;

    bp.next = b2;
    b2.prev = bp;

    return b2;
}

// create a node and optionally link it with previous one (in a circular doubly linked list)
function insertNode(i, x, y, last) {
    var p = new Node(i, x, y);

    if (!last) {
        p.prev = p;
        p.next = p;

    } else {
        p.next = last.next;
        p.prev = last;
        last.next.prev = p;
        last.next = p;
    }
    return p;
}

function removeNode(p) {
    p.next.prev = p.prev;
    p.prev.next = p.next;

    if (p.prevZ) p.prevZ.nextZ = p.nextZ;
    if (p.nextZ) p.nextZ.prevZ = p.prevZ;
}

function Node(i, x, y) {
    // vertice index in coordinates array
    this.i = i;

    // vertex coordinates
    this.x = x;
    this.y = y;

    // previous and next vertice nodes in a polygon ring
    this.prev = null;
    this.next = null;

    // z-order curve value
    this.z = null;

    // previous and next nodes in z-order
    this.prevZ = null;
    this.nextZ = null;

    // indicates whether this is a steiner point
    this.steiner = false;
}

if(typeof module !== 'undefined') {
    module.exports = earcut;
}
// glMatrix v0.9.5
glMatrixArrayType = typeof Float32Array != "undefined" ? Float32Array : typeof WebGLFloatArray != "undefined" ? WebGLFloatArray : Array;
var vec3 = {};
vec3.create = function(a) {
    var b = new glMatrixArrayType(3);
    if (a) {
        b[0] = a[0];
        b[1] = a[1];
        b[2] = a[2]
    }
    return b
};
vec3.set = function(a, b) {
    b[0] = a[0];
    b[1] = a[1];
    b[2] = a[2];
    return b
};
vec3.add = function(a, b, c) {
    if (!c || a == c) {
        a[0] += b[0];
        a[1] += b[1];
        a[2] += b[2];
        return a
    }
    c[0] = a[0] + b[0];
    c[1] = a[1] + b[1];
    c[2] = a[2] + b[2];
    return c
};
vec3.subtract = function(a, b, c) {
    if (!c || a == c) {
        a[0] -= b[0];
        a[1] -= b[1];
        a[2] -= b[2];
        return a
    }
    c[0] = a[0] - b[0];
    c[1] = a[1] - b[1];
    c[2] = a[2] - b[2];
    return c
};
vec3.negate = function(a, b) {
    b || (b = a);
    b[0] =- a[0];
    b[1] =- a[1];
    b[2] =- a[2];
    return b
};
vec3.scale = function(a, b, c) {
    if (!c || a == c) {
        a[0]*=b;
        a[1]*=b;
        a[2]*=b;
        return a
    }
    c[0] = a[0] * b;
    c[1] = a[1] * b;
    c[2] = a[2] * b;
    return c
};
vec3.normalize = function(a, b) {
    b || (b = a);
    var c = a[0], d = a[1], e = a[2], g = Math.sqrt(c * c + d * d + e * e);
    if (g) {
        if (g == 1) {
            b[0] = c;
            b[1] = d;
            b[2] = e;
            return b
        }
    } else {
        b[0] = 0;
        b[1] = 0;
        b[2] = 0;
        return b
    }
    g = 1 / g;
    b[0] = c * g;
    b[1] = d * g;
    b[2] = e * g;
    return b
};
vec3.cross = function(a, b, c) {
    c || (c = a);
    var d = a[0], e = a[1];
    a = a[2];
    var g = b[0], f = b[1];
    b = b[2];
    c[0] = e * b - a * f;
    c[1] = a * g - d * b;
    c[2] = d * f - e * g;
    return c
};
vec3.length = function(a) {
    var b = a[0], c = a[1];
    a = a[2];
    return Math.sqrt(b * b + c * c + a * a)
};
vec3.dot = function(a, b) {
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
};
vec3.direction = function(a, b, c) {
    c || (c = a);
    var d = a[0] - b[0], e = a[1] - b[1];
    a = a[2] - b[2];
    b = Math.sqrt(d * d + e * e + a * a);
    if (!b) {
        c[0] = 0;
        c[1] = 0;
        c[2] = 0;
        return c
    }
    b = 1 / b;
    c[0] = d * b;
    c[1] = e * b;
    c[2] = a * b;
    return c
};
vec3.lerp = function(a, b, c, d) {
    d || (d = a);
    d[0] = a[0] + c * (b[0] - a[0]);
    d[1] = a[1] + c * (b[1] - a[1]);
    d[2] = a[2] + c * (b[2] - a[2]);
    return d
};
vec3.str = function(a) {
    return "[" + a[0] + ", " + a[1] + ", " + a[2] + "]"
};
var mat3 = {};
mat3.create = function(a) {
    var b = new glMatrixArrayType(9);
    if (a) {
        b[0] = a[0];
        b[1] = a[1];
        b[2] = a[2];
        b[3] = a[3];
        b[4] = a[4];
        b[5] = a[5];
        b[6] = a[6];
        b[7] = a[7];
        b[8] = a[8];
        b[9] = a[9]
    }
    return b
};
mat3.set = function(a, b) {
    b[0] = a[0];
    b[1] = a[1];
    b[2] = a[2];
    b[3] = a[3];
    b[4] = a[4];
    b[5] = a[5];
    b[6] = a[6];
    b[7] = a[7];
    b[8] = a[8];
    return b
};
mat3.identity = function(a) {
    a[0] = 1;
    a[1] = 0;
    a[2] = 0;
    a[3] = 0;
    a[4] = 1;
    a[5] = 0;
    a[6] = 0;
    a[7] = 0;
    a[8] = 1;
    return a
};
mat3.transpose = function(a, b) {
    if (!b || a == b) {
        var c = a[1], d = a[2], e = a[5];
        a[1] = a[3];
        a[2] = a[6];
        a[3] = c;
        a[5] = a[7];
        a[6] = d;
        a[7] = e;
        return a
    }
    b[0] = a[0];
    b[1] = a[3];
    b[2] = a[6];
    b[3] = a[1];
    b[4] = a[4];
    b[5] = a[7];
    b[6] = a[2];
    b[7] = a[5];
    b[8] = a[8];
    return b
};
mat3.toMat4 = function(a, b) {
    b || (b = mat4.create());
    b[0] = a[0];
    b[1] = a[1];
    b[2] = a[2];
    b[3] = 0;
    b[4] = a[3];
    b[5] = a[4];
    b[6] = a[5];
    b[7] = 0;
    b[8] = a[6];
    b[9] = a[7];
    b[10] = a[8];
    b[11] = 0;
    b[12] = 0;
    b[13] = 0;
    b[14] = 0;
    b[15] = 1;
    return b
};
mat3.str = function(a) {
    return "[" + a[0] + ", " + a[1] + ", " + a[2] + ", " + a[3] + ", " + a[4] + ", " + a[5] + ", " + a[6] + ", " + a[7] + ", " + a[8] + "]"
};
var mat4 = {};
mat4.create = function(a) {
    var b = new glMatrixArrayType(16);
    if (a) {
        b[0] = a[0];
        b[1] = a[1];
        b[2] = a[2];
        b[3] = a[3];
        b[4] = a[4];
        b[5] = a[5];
        b[6] = a[6];
        b[7] = a[7];
        b[8] = a[8];
        b[9] = a[9];
        b[10] = a[10];
        b[11] = a[11];
        b[12] = a[12];
        b[13] = a[13];
        b[14] = a[14];
        b[15] = a[15]
    }
    return b
};
mat4.set = function(a, b) {
    b[0] = a[0];
    b[1] = a[1];
    b[2] = a[2];
    b[3] = a[3];
    b[4] = a[4];
    b[5] = a[5];
    b[6] = a[6];
    b[7] = a[7];
    b[8] = a[8];
    b[9] = a[9];
    b[10] = a[10];
    b[11] = a[11];
    b[12] = a[12];
    b[13] = a[13];
    b[14] = a[14];
    b[15] = a[15];
    return b
};
mat4.identity = function(a) {
    a[0] = 1;
    a[1] = 0;
    a[2] = 0;
    a[3] = 0;
    a[4] = 0;
    a[5] = 1;
    a[6] = 0;
    a[7] = 0;
    a[8] = 0;
    a[9] = 0;
    a[10] = 1;
    a[11] = 0;
    a[12] = 0;
    a[13] = 0;
    a[14] = 0;
    a[15] = 1;
    return a
};
mat4.transpose = function(a, b) {
    if (!b || a == b) {
        var c = a[1], d = a[2], e = a[3], g = a[6], f = a[7], h = a[11];
        a[1] = a[4];
        a[2] = a[8];
        a[3] = a[12];
        a[4] = c;
        a[6] = a[9];
        a[7] = a[13];
        a[8] = d;
        a[9] = g;
        a[11] = a[14];
        a[12] = e;
        a[13] = f;
        a[14] = h;
        return a
    }
    b[0] = a[0];
    b[1] = a[4];
    b[2] = a[8];
    b[3] = a[12];
    b[4] = a[1];
    b[5] = a[5];
    b[6] = a[9];
    b[7] = a[13];
    b[8] = a[2];
    b[9] = a[6];
    b[10] = a[10];
    b[11] = a[14];
    b[12] = a[3];
    b[13] = a[7];
    b[14] = a[11];
    b[15] = a[15];
    return b
};
mat4.determinant = function(a) {
    var b = a[0], c = a[1], d = a[2], e = a[3], g = a[4], f = a[5], h = a[6], i = a[7], j = a[8], k = a[9], l = a[10], o = a[11], m = a[12], n = a[13], p = a[14];
    a = a[15];
    return m * k * h * e - j * n * h * e - m * f * l * e + g * n * l * e + j * f * p * e - g * k * p * e - m * k * d * i + j * n * d * i + m * c * l * i - b * n * l * i - j * c * p * i + b * k * p * i + m * f * d * o - g * n * d * o - m * c * h * o + b * n * h * o + g * c * p * o - b * f * p * o - j * f * d * a + g * k * d * a + j * c * h * a - b * k * h * a - g * c * l * a + b * f * l * a
};
mat4.inverse = function(a, b) {
    b || (b = a);
    var c = a[0], d = a[1], e = a[2], g = a[3], f = a[4], h = a[5], i = a[6], j = a[7], k = a[8], l = a[9], o = a[10], m = a[11], n = a[12], p = a[13], r = a[14], s = a[15], A = c * h - d * f, B = c * i - e * f, t = c * j - g * f, u = d * i - e * h, v = d * j - g * h, w = e * j - g * i, x = k * p - l * n, y = k * r - o * n, z = k * s - m * n, C = l * r - o * p, D = l * s - m * p, E = o * s - m * r, q = 1 / (A * E - B * D + t * C + u * z - v * y + w * x);
    b[0] = (h * E - i * D + j * C) * q;
    b[1] = ( - d * E + e * D - g * C) * q;
    b[2] = (p * w - r * v + s * u) * q;
    b[3] = ( - l * w + o * v - m * u) * q;
    b[4] = ( - f * E + i * z - j * y) * q;
    b[5] = (c * E - e * z + g * y) * q;
    b[6] = ( - n * w + r * t - s * B) * q;
    b[7] = (k * w - o * t + m * B) * q;
    b[8] = (f * D - h * z + j * x) * q;
    b[9] = ( - c * D + d * z - g * x) * q;
    b[10] = (n * v - p * t + s * A) * q;
    b[11] = ( - k * v + l * t - m * A) * q;
    b[12] = ( - f * C + h * y - i * x) * q;
    b[13] = (c * C - d * y + e * x) * q;
    b[14] = ( - n * u + p * B - r * A) * q;
    b[15] = (k * u - l * B + o * A) * q;
    return b
};
mat4.toRotationMat = function(a, b) {
    b || (b = mat4.create());
    b[0] = a[0];
    b[1] = a[1];
    b[2] = a[2];
    b[3] = a[3];
    b[4] = a[4];
    b[5] = a[5];
    b[6] = a[6];
    b[7] = a[7];
    b[8] = a[8];
    b[9] = a[9];
    b[10] = a[10];
    b[11] = a[11];
    b[12] = 0;
    b[13] = 0;
    b[14] = 0;
    b[15] = 1;
    return b
};
mat4.toMat3 = function(a, b) {
    b || (b = mat3.create());
    b[0] = a[0];
    b[1] = a[1];
    b[2] = a[2];
    b[3] = a[4];
    b[4] = a[5];
    b[5] = a[6];
    b[6] = a[8];
    b[7] = a[9];
    b[8] = a[10];
    return b
};
mat4.toInverseMat3 = function(a, b) {
    var c = a[0], d = a[1], e = a[2], g = a[4], f = a[5], h = a[6], i = a[8], j = a[9], k = a[10], l = k * f - h * j, o =- k * g + h * i, m = j * g - f * i, n = c * l + d * o + e * m;
    if (!n)
        return null;
    n = 1 / n;
    b || (b = mat3.create());
    b[0] = l * n;
    b[1] = ( - k * d + e * j) * n;
    b[2] = (h * d - e * f) * n;
    b[3] = o * n;
    b[4] = (k * c - e * i) * n;
    b[5] = ( - h * c + e * g) * n;
    b[6] = m * n;
    b[7] = ( - j * c + d * i) * n;
    b[8] = (f * c - d * g) * n;
    return b
};
mat4.multiply = function(a, b, c) {
    c || (c = a);
    var d = a[0], e = a[1], g = a[2], f = a[3], h = a[4], i = a[5], j = a[6], k = a[7], l = a[8], o = a[9], m = a[10], n = a[11], p = a[12], r = a[13], s = a[14];
    a = a[15];
    var A = b[0], B = b[1], t = b[2], u = b[3], v = b[4], w = b[5], x = b[6], y = b[7], z = b[8], C = b[9], D = b[10], E = b[11], q = b[12], F = b[13], G = b[14];
    b = b[15];
    c[0] = A * d + B * h + t * l + u * p;
    c[1] = A * e + B * i + t * o + u * r;
    c[2] = A * g + B * j + t * m + u * s;
    c[3] = A * f + B * k + t * n + u * a;
    c[4] = v * d + w * h + x * l + y * p;
    c[5] = v * e + w * i + x * o + y * r;
    c[6] = v * g + w * j + x * m + y * s;
    c[7] = v * f + w * k + x * n + y * a;
    c[8] = z * d + C * h + D * l + E * p;
    c[9] = z * e + C * i + D * o + E * r;
    c[10] = z *
    g + C * j + D * m + E * s;
    c[11] = z * f + C * k + D * n + E * a;
    c[12] = q * d + F * h + G * l + b * p;
    c[13] = q * e + F * i + G * o + b * r;
    c[14] = q * g + F * j + G * m + b * s;
    c[15] = q * f + F * k + G * n + b * a;
    return c
};
mat4.multiplyVec3 = function(a, b, c) {
    c || (c = b);
    var d = b[0], e = b[1];
    b = b[2];
    c[0] = a[0] * d + a[4] * e + a[8] * b + a[12];
    c[1] = a[1] * d + a[5] * e + a[9] * b + a[13];
    c[2] = a[2] * d + a[6] * e + a[10] * b + a[14];
    return c
};
mat4.multiplyVec4 = function(a, b, c) {
    c || (c = b);
    var d = b[0], e = b[1], g = b[2];
    b = b[3];
    c[0] = a[0] * d + a[4] * e + a[8] * g + a[12] * b;
    c[1] = a[1] * d + a[5] * e + a[9] * g + a[13] * b;
    c[2] = a[2] * d + a[6] * e + a[10] * g + a[14] * b;
    c[3] = a[3] * d + a[7] * e + a[11] * g + a[15] * b;
    return c
};
mat4.translate = function(a, b, c) {
    var d = b[0], e = b[1];
    b = b[2];
    if (!c || a == c) {
        a[12] = a[0] * d + a[4] * e + a[8] * b + a[12];
        a[13] = a[1] * d + a[5] * e + a[9] * b + a[13];
        a[14] = a[2] * d + a[6] * e + a[10] * b + a[14];
        a[15] = a[3] * d + a[7] * e + a[11] * b + a[15];
        return a
    }
    var g = a[0], f = a[1], h = a[2], i = a[3], j = a[4], k = a[5], l = a[6], o = a[7], m = a[8], n = a[9], p = a[10], r = a[11];
    c[0] = g;
    c[1] = f;
    c[2] = h;
    c[3] = i;
    c[4] = j;
    c[5] = k;
    c[6] = l;
    c[7] = o;
    c[8] = m;
    c[9] = n;
    c[10] = p;
    c[11] = r;
    c[12] = g * d + j * e + m * b + a[12];
    c[13] = f * d + k * e + n * b + a[13];
    c[14] = h * d + l * e + p * b + a[14];
    c[15] = i * d + o * e + r * b + a[15];
    return c
};
mat4.scale = function(a, b, c) {
    var d = b[0], e = b[1];
    b = b[2];
    if (!c || a == c) {
        a[0]*=d;
        a[1]*=d;
        a[2]*=d;
        a[3]*=d;
        a[4]*=e;
        a[5]*=e;
        a[6]*=e;
        a[7]*=e;
        a[8]*=b;
        a[9]*=b;
        a[10]*=b;
        a[11]*=b;
        return a
    }
    c[0] = a[0] * d;
    c[1] = a[1] * d;
    c[2] = a[2] * d;
    c[3] = a[3] * d;
    c[4] = a[4] * e;
    c[5] = a[5] * e;
    c[6] = a[6] * e;
    c[7] = a[7] * e;
    c[8] = a[8] * b;
    c[9] = a[9] * b;
    c[10] = a[10] * b;
    c[11] = a[11] * b;
    c[12] = a[12];
    c[13] = a[13];
    c[14] = a[14];
    c[15] = a[15];
    return c
};
mat4.rotate = function(a, b, c, d) {
    var e = c[0], g = c[1];
    c = c[2];
    var f = Math.sqrt(e * e + g * g + c * c);
    if (!f)
        return null;
    if (f != 1) {
        f = 1 / f;
        e*=f;
        g*=f;
        c*=f
    }
    var h = Math.sin(b), i = Math.cos(b), j = 1 - i;
    b = a[0];
    f = a[1];
    var k = a[2], l = a[3], o = a[4], m = a[5], n = a[6], p = a[7], r = a[8], s = a[9], A = a[10], B = a[11], t = e * e * j + i, u = g * e * j + c * h, v = c * e * j - g * h, w = e * g * j - c * h, x = g * g * j + i, y = c * g * j + e * h, z = e * c * j + g * h;
    e = g * c * j - e * h;
    g = c * c * j + i;
    if (d) {
        if (a != d) {
            d[12] = a[12];
            d[13] = a[13];
            d[14] = a[14];
            d[15] = a[15]
        }
    } else 
        d = a;
    d[0] = b * t + o * u + r * v;
    d[1] = f * t + m * u + s * v;
    d[2] = k * t + n * u + A * v;
    d[3] = l * t + p * u + B *
    v;
    d[4] = b * w + o * x + r * y;
    d[5] = f * w + m * x + s * y;
    d[6] = k * w + n * x + A * y;
    d[7] = l * w + p * x + B * y;
    d[8] = b * z + o * e + r * g;
    d[9] = f * z + m * e + s * g;
    d[10] = k * z + n * e + A * g;
    d[11] = l * z + p * e + B * g;
    return d
};
mat4.rotateX = function(a, b, c) {
    var d = Math.sin(b);
    b = Math.cos(b);
    var e = a[4], g = a[5], f = a[6], h = a[7], i = a[8], j = a[9], k = a[10], l = a[11];
    if (c) {
        if (a != c) {
            c[0] = a[0];
            c[1] = a[1];
            c[2] = a[2];
            c[3] = a[3];
            c[12] = a[12];
            c[13] = a[13];
            c[14] = a[14];
            c[15] = a[15]
        }
    } else 
        c = a;
    c[4] = e * b + i * d;
    c[5] = g * b + j * d;
    c[6] = f * b + k * d;
    c[7] = h * b + l * d;
    c[8] = e*-d + i * b;
    c[9] = g*-d + j * b;
    c[10] = f*-d + k * b;
    c[11] = h*-d + l * b;
    return c
};
mat4.rotateY = function(a, b, c) {
    var d = Math.sin(b);
    b = Math.cos(b);
    var e = a[0], g = a[1], f = a[2], h = a[3], i = a[8], j = a[9], k = a[10], l = a[11];
    if (c) {
        if (a != c) {
            c[4] = a[4];
            c[5] = a[5];
            c[6] = a[6];
            c[7] = a[7];
            c[12] = a[12];
            c[13] = a[13];
            c[14] = a[14];
            c[15] = a[15]
        }
    } else 
        c = a;
    c[0] = e * b + i*-d;
    c[1] = g * b + j*-d;
    c[2] = f * b + k*-d;
    c[3] = h * b + l*-d;
    c[8] = e * d + i * b;
    c[9] = g * d + j * b;
    c[10] = f * d + k * b;
    c[11] = h * d + l * b;
    return c
};
mat4.rotateZ = function(a, b, c) {
    var d = Math.sin(b);
    b = Math.cos(b);
    var e = a[0], g = a[1], f = a[2], h = a[3], i = a[4], j = a[5], k = a[6], l = a[7];
    if (c) {
        if (a != c) {
            c[8] = a[8];
            c[9] = a[9];
            c[10] = a[10];
            c[11] = a[11];
            c[12] = a[12];
            c[13] = a[13];
            c[14] = a[14];
            c[15] = a[15]
        }
    } else 
        c = a;
    c[0] = e * b + i * d;
    c[1] = g * b + j * d;
    c[2] = f * b + k * d;
    c[3] = h * b + l * d;
    c[4] = e*-d + i * b;
    c[5] = g*-d + j * b;
    c[6] = f*-d + k * b;
    c[7] = h*-d + l * b;
    return c
};
mat4.frustum = function(a, b, c, d, e, g, f) {
    f || (f = mat4.create());
    var h = b - a, i = d - c, j = g - e;
    f[0] = e * 2 / h;
    f[1] = 0;
    f[2] = 0;
    f[3] = 0;
    f[4] = 0;
    f[5] = e * 2 / i;
    f[6] = 0;
    f[7] = 0;
    f[8] = (b + a) / h;
    f[9] = (d + c) / i;
    f[10] =- (g + e) / j;
    f[11] =- 1;
    f[12] = 0;
    f[13] = 0;
    f[14] =- (g * e * 2) / j;
    f[15] = 0;
    return f
};
mat4.perspective = function(a, b, c, d, e) {
    a = c * Math.tan(a * Math.PI / 360);
    b = a * b;
    return mat4.frustum( - b, b, - a, a, c, d, e)
};
mat4.ortho = function(a, b, c, d, e, g, f) {
    f || (f = mat4.create());
    var h = b - a, i = d - c, j = g - e;
    f[0] = 2 / h;
    f[1] = 0;
    f[2] = 0;
    f[3] = 0;
    f[4] = 0;
    f[5] = 2 / i;
    f[6] = 0;
    f[7] = 0;
    f[8] = 0;
    f[9] = 0;
    f[10] =- 2 / j;
    f[11] = 0;
    f[12] =- (a + b) / h;
    f[13] =- (d + c) / i;
    f[14] =- (g + e) / j;
    f[15] = 1;
    return f
};
mat4.lookAt = function(a, b, c, d) {
    d || (d = mat4.create());
    var e = a[0], g = a[1];
    a = a[2];
    var f = c[0], h = c[1], i = c[2];
    c = b[1];
    var j = b[2];
    if (e == b[0] && g == c && a == j)
        return mat4.identity(d);
    var k, l, o, m;
    c = e - b[0];
    j = g - b[1];
    b = a - b[2];
    m = 1 / Math.sqrt(c * c + j * j + b * b);
    c*=m;
    j*=m;
    b*=m;
    k = h * b - i * j;
    i = i * c - f * b;
    f = f * j - h * c;
    if (m = Math.sqrt(k * k + i * i + f * f)) {
        m = 1 / m;
        k*=m;
        i*=m;
        f*=m
    } else 
        f = i = k = 0;
    h = j * f - b * i;
    l = b * k - c * f;
    o = c * i - j * k;
    if (m = Math.sqrt(h * h + l * l + o * o)) {
        m = 1 / m;
        h*=m;
        l*=m;
        o*=m
    } else 
        o = l = h = 0;
    d[0] = k;
    d[1] = h;
    d[2] = c;
    d[3] = 0;
    d[4] = i;
    d[5] = l;
    d[6] = j;
    d[7] = 0;
    d[8] = f;
    d[9] =
    o;
    d[10] = b;
    d[11] = 0;
    d[12] =- (k * e + i * g + f * a);
    d[13] =- (h * e + l * g + o * a);
    d[14] =- (c * e + j * g + b * a);
    d[15] = 1;
    return d
};
mat4.str = function(a) {
    return "[" + a[0] + ", " + a[1] + ", " + a[2] + ", " + a[3] + ", " + a[4] + ", " + a[5] + ", " + a[6] + ", " + a[7] + ", " + a[8] + ", " + a[9] + ", " + a[10] + ", " + a[11] + ", " + a[12] + ", " + a[13] + ", " + a[14] + ", " + a[15] + "]"
};
quat4 = {};
quat4.create = function(a) {
    var b = new glMatrixArrayType(4);
    if (a) {
        b[0] = a[0];
        b[1] = a[1];
        b[2] = a[2];
        b[3] = a[3]
    }
    return b
};
quat4.set = function(a, b) {
    b[0] = a[0];
    b[1] = a[1];
    b[2] = a[2];
    b[3] = a[3];
    return b
};
quat4.calculateW = function(a, b) {
    var c = a[0], d = a[1], e = a[2];
    if (!b || a == b) {
        a[3] =- Math.sqrt(Math.abs(1 - c * c - d * d - e * e));
        return a
    }
    b[0] = c;
    b[1] = d;
    b[2] = e;
    b[3] =- Math.sqrt(Math.abs(1 - c * c - d * d - e * e));
    return b
};
quat4.inverse = function(a, b) {
    if (!b || a == b) {
        a[0]*=1;
        a[1]*=1;
        a[2]*=1;
        return a
    }
    b[0] =- a[0];
    b[1] =- a[1];
    b[2] =- a[2];
    b[3] = a[3];
    return b
};
quat4.length = function(a) {
    var b = a[0], c = a[1], d = a[2];
    a = a[3];
    return Math.sqrt(b * b + c * c + d * d + a * a)
};
quat4.normalize = function(a, b) {
    b || (b = a);
    var c = a[0], d = a[1], e = a[2], g = a[3], f = Math.sqrt(c * c + d * d + e * e + g * g);
    if (f == 0) {
        b[0] = 0;
        b[1] = 0;
        b[2] = 0;
        b[3] = 0;
        return b
    }
    f = 1 / f;
    b[0] = c * f;
    b[1] = d * f;
    b[2] = e * f;
    b[3] = g * f;
    return b
};
quat4.multiply = function(a, b, c) {
    c || (c = a);
    var d = a[0], e = a[1], g = a[2];
    a = a[3];
    var f = b[0], h = b[1], i = b[2];
    b = b[3];
    c[0] = d * b + a * f + e * i - g * h;
    c[1] = e * b + a * h + g * f - d * i;
    c[2] = g * b + a * i + d * h - e * f;
    c[3] = a * b - d * f - e * h - g * i;
    return c
};
quat4.multiplyVec3 = function(a, b, c) {
    c || (c = b);
    var d = b[0], e = b[1], g = b[2];
    b = a[0];
    var f = a[1], h = a[2];
    a = a[3];
    var i = a * d + f * g - h * e, j = a * e + h * d - b * g, k = a * g + b * e - f * d;
    d =- b * d - f * e - h * g;
    c[0] = i * a + d*-b + j*-h - k*-f;
    c[1] = j * a + d*-f + k*-b - i*-h;
    c[2] = k * a + d*-h + i*-f - j*-b;
    return c
};
quat4.toMat3 = function(a, b) {
    b || (b = mat3.create());
    var c = a[0], d = a[1], e = a[2], g = a[3], f = c + c, h = d + d, i = e + e, j = c * f, k = c * h;
    c = c * i;
    var l = d * h;
    d = d * i;
    e = e * i;
    f = g * f;
    h = g * h;
    g = g * i;
    b[0] = 1 - (l + e);
    b[1] = k - g;
    b[2] = c + h;
    b[3] = k + g;
    b[4] = 1 - (j + e);
    b[5] = d - f;
    b[6] = c - h;
    b[7] = d + f;
    b[8] = 1 - (j + l);
    return b
};
quat4.toMat4 = function(a, b) {
    b || (b = mat4.create());
    var c = a[0], d = a[1], e = a[2], g = a[3], f = c + c, h = d + d, i = e + e, j = c * f, k = c * h;
    c = c * i;
    var l = d * h;
    d = d * i;
    e = e * i;
    f = g * f;
    h = g * h;
    g = g * i;
    b[0] = 1 - (l + e);
    b[1] = k - g;
    b[2] = c + h;
    b[3] = 0;
    b[4] = k + g;
    b[5] = 1 - (j + e);
    b[6] = d - f;
    b[7] = 0;
    b[8] = c - h;
    b[9] = d + f;
    b[10] = 1 - (j + l);
    b[11] = 0;
    b[12] = 0;
    b[13] = 0;
    b[14] = 0;
    b[15] = 1;
    return b
};
quat4.slerp = function(a, b, c, d) {
    d || (d = a);
    var e = c;
    if (a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3] < 0)
        e =- 1 * c;
    d[0] = 1 - c * a[0] + e * b[0];
    d[1] = 1 - c * a[1] + e * b[1];
    d[2] = 1 - c * a[2] + e * b[2];
    d[3] = 1 - c * a[3] + e * b[3];
    return d
};
quat4.str = function(a) {
    return "[" + a[0] + ", " + a[1] + ", " + a[2] + ", " + a[3] + "]"
};

if (typeof module !== 'undefined') {
	module.exports = [vec3, mat3, mat4, quat4];
}

var worldData={
"type": "FeatureCollection",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
                                                                                
"features": [
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Afghanistan", "sov_a3": "AFG", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Afghanistan", "adm0_a3": "AFG", "geou_dif": 0.000000, "geounit": "Afghanistan", "gu_a3": "AFG", "su_dif": 0.000000, "subunit": "Afghanistan", "su_a3": "AFG", "brk_diff": 0.000000, "name": "Afghanistan", "name_long": "Afghanistan", "brk_a3": "AFG", "brk_name": "Afghanistan", "brk_group": null, "abbrev": "Afg.", "postal": "AF", "formal_en": "Islamic State of Afghanistan", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Afghanistan", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 6.000000, "mapcolor9": 8.000000, "mapcolor13": 7.000000, "pop_est": 28400000.000000, "gdp_md_est": 22270.000000, "pop_year": -99.000000, "lastcensus": 1979.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "AF", "iso_a3": "AFG", "iso_n3": "004", "un_a3": "004", "wb_a2": "AF", "wb_a3": "AFG", "woe_id": -99.000000, "adm0_a3_is": "AFG", "adm0_a3_us": "AFG", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Southern Asia", "region_wb": "South Asia", "name_len": 11.000000, "long_len": 11.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 74.98000248, 37.41999014 ], [ 75.15802779, 37.13303091 ], [ 74.57589278, 37.02084138 ], [ 74.06755171, 36.83617565 ], [ 72.92002486, 36.72000703 ], [ 71.84629195, 36.50994233 ], [ 71.26234826, 36.07438752 ], [ 71.49876794, 35.65056326 ], [ 71.61307621, 35.15320344 ], [ 71.11501875, 34.73312572 ], [ 71.15677331, 34.34891144 ], [ 70.88180301, 33.9888559 ], [ 69.93054325, 34.02012014 ], [ 70.32359419, 33.35853262 ], [ 69.68714725, 33.10549897 ], [ 69.26252201, 32.50194408 ], [ 69.31776411, 31.90141226 ], [ 68.92667687, 31.62018911 ], [ 68.556932, 31.71331004 ], [ 67.79268924, 31.58293041 ], [ 67.68339359, 31.3031542 ], [ 66.93889123, 31.3049112 ], [ 66.38145755, 30.73889924 ], [ 66.34647261, 29.88794343 ], [ 65.04686201, 29.47218069 ], [ 64.35041874, 29.56003063 ], [ 64.14800215, 29.3408192 ], [ 63.55026086, 29.4683308 ], [ 62.54985681, 29.3185725 ], [ 60.87424849, 29.829239 ], [ 61.78122155, 30.73585033 ], [ 61.69931441, 31.37950613 ], [ 60.94194461, 31.54807465 ], [ 60.86365482, 32.18291962 ], [ 60.53607792, 32.98126883 ], [ 60.96370039, 33.5288323 ], [ 60.5284298, 33.67644603 ], [ 60.80319339, 34.40410187 ], [ 61.21081709, 35.65007233 ], [ 62.23065148, 35.27066397 ], [ 62.98466231, 35.40404084 ], [ 63.19353845, 35.85716564 ], [ 63.98289595, 36.00795747 ], [ 64.54647912, 36.31207327 ], [ 64.74610518, 37.11181774 ], [ 65.58894779, 37.30521678 ], [ 65.74563073, 37.66116405 ], [ 66.21738488, 37.39379019 ], [ 66.51860681, 37.36278433 ], [ 67.0757821, 37.35614391 ], [ 67.82999963, 37.144994 ], [ 68.13556237, 37.02311514 ], [ 68.85944584, 37.34433584 ], [ 69.19627282, 37.1511435 ], [ 69.51878543, 37.60899669 ], [ 70.1165784, 37.58822276 ], [ 70.27057417, 37.7351647 ], [ 70.37630415, 38.1383959 ], [ 70.80682051, 38.48628164 ], [ 71.34813114, 38.25890534 ], [ 71.23940392, 37.95326508 ], [ 71.54191776, 37.90577444 ], [ 71.44869348, 37.06564484 ], [ 71.8446383, 36.73817129 ], [ 72.19304081, 36.94828767 ], [ 72.63688968, 37.04755809 ], [ 73.26005578, 37.49525686 ], [ 73.94869592, 37.42156627 ], [ 74.98000248, 37.41999014 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Angola", "sov_a3": "AGO", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Angola", "adm0_a3": "AGO", "geou_dif": 0.000000, "geounit": "Angola", "gu_a3": "AGO", "su_dif": 0.000000, "subunit": "Angola", "su_a3": "AGO", "brk_diff": 0.000000, "name": "Angola", "name_long": "Angola", "brk_a3": "AGO", "brk_name": "Angola", "brk_group": null, "abbrev": "Ang.", "postal": "AO", "formal_en": "People's Republic of Angola", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Angola", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 2.000000, "mapcolor9": 6.000000, "mapcolor13": 1.000000, "pop_est": 12799293.000000, "gdp_md_est": 110300.000000, "pop_year": -99.000000, "lastcensus": 1970.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "AO", "iso_a3": "AGO", "iso_n3": "024", "un_a3": "024", "wb_a2": "AO", "wb_a3": "AGO", "woe_id": -99.000000, "adm0_a3_is": "AGO", "adm0_a3_us": "AGO", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Middle Africa", "region_wb": "Sub-Saharan Africa", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 16.32652835, -5.87747039 ], [ 16.57317997, -6.62264455 ], [ 16.86019087, -7.22229787 ], [ 17.08999597, -7.54568898 ], [ 17.47297, -8.06855112 ], [ 18.13422163, -7.9876775 ], [ 18.46417565, -7.84701426 ], [ 19.01675174, -7.98824594 ], [ 19.1666134, -7.73818369 ], [ 19.41750248, -7.15542856 ], [ 20.03772302, -7.11636118 ], [ 20.09162153, -6.9430901 ], [ 20.60182295, -6.93931772 ], [ 20.51474816, -7.29960581 ], [ 21.72811079, -7.29087249 ], [ 21.74645593, -7.92008473 ], [ 21.94913089, -8.30590097 ], [ 21.80180139, -8.90870656 ], [ 21.87518192, -9.52370778 ], [ 22.20875329, -9.89479624 ], [ 22.15526818, -11.08480112 ], [ 22.40279829, -10.99307545 ], [ 22.83734541, -11.01762176 ], [ 23.45679081, -10.86786346 ], [ 23.9122152, -10.92682627 ], [ 24.01789351, -11.23729827 ], [ 23.90415368, -11.72228159 ], [ 24.07990523, -12.19129689 ], [ 23.93092207, -12.56584767 ], [ 24.01613651, -12.91104624 ], [ 21.93388635, -12.89843719 ], [ 21.88784264, -16.08031015 ], [ 22.56247847, -16.89845143 ], [ 23.21504846, -17.52311614 ], [ 21.37717614, -17.93063649 ], [ 18.95618696, -17.78909474 ], [ 18.26330936, -17.30995086 ], [ 14.20970666, -17.35310068 ], [ 14.05850142, -17.42338063 ], [ 13.46236209, -16.97121185 ], [ 12.81408125, -16.94134287 ], [ 12.21546146, -17.11166839 ], [ 11.73419885, -17.30188934 ], [ 11.64009606, -16.67314219 ], [ 11.77853722, -15.79381601 ], [ 12.12358076, -14.87831634 ], [ 12.17561893, -14.44914357 ], [ 12.50009525, -13.54769988 ], [ 12.73847863, -13.13790578 ], [ 13.31291385, -12.48363047 ], [ 13.63372114, -12.03864471 ], [ 13.73872765, -11.29786305 ], [ 13.68637943, -10.73107594 ], [ 13.38732792, -10.37357838 ], [ 13.12098758, -9.76689707 ], [ 12.8753695, -9.16693369 ], [ 12.92906131, -8.95909108 ], [ 13.23643273, -8.56262949 ], [ 12.9330404, -7.59653859 ], [ 12.72829837, -6.92712208 ], [ 12.22734704, -6.29444752 ], [ 12.32243167, -6.10009246 ], [ 12.73517134, -5.96568206 ], [ 13.02486942, -5.98438893 ], [ 13.37559736, -5.86424122 ], [ 16.32652835, -5.87747039 ] ] ], [ [ [ 12.43668827, -5.68430389 ], [ 12.18233687, -5.78993052 ], [ 11.91496301, -5.03798675 ], [ 12.31860762, -4.60623016 ], [ 12.62075972, -4.43802337 ], [ 12.99551721, -4.7811032 ], [ 12.63161177, -4.99127125 ], [ 12.46800418, -5.2483615 ], [ 12.43668827, -5.68430389 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Albania", "sov_a3": "ALB", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Albania", "adm0_a3": "ALB", "geou_dif": 0.000000, "geounit": "Albania", "gu_a3": "ALB", "su_dif": 0.000000, "subunit": "Albania", "su_a3": "ALB", "brk_diff": 0.000000, "name": "Albania", "name_long": "Albania", "brk_a3": "ALB", "brk_name": "Albania", "brk_group": null, "abbrev": "Alb.", "postal": "AL", "formal_en": "Republic of Albania", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Albania", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 4.000000, "mapcolor9": 1.000000, "mapcolor13": 6.000000, "pop_est": 3639453.000000, "gdp_md_est": 21810.000000, "pop_year": -99.000000, "lastcensus": 2001.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "AL", "iso_a3": "ALB", "iso_n3": "008", "un_a3": "008", "wb_a2": "AL", "wb_a3": "ALB", "woe_id": -99.000000, "adm0_a3_is": "ALB", "adm0_a3_us": "ALB", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Southern Europe", "region_wb": "Europe & Central Asia", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 19.73805139, 42.68824738 ], [ 19.8016134, 42.50009349 ], [ 20.0707, 42.58863 ], [ 20.28375451, 42.32025951 ], [ 20.52295, 42.21787 ], [ 20.59024655, 41.85540892 ], [ 20.59024743, 41.85540416 ], [ 20.46317508, 41.51508902 ], [ 20.60518192, 41.0862263 ], [ 21.02004032, 40.84272696 ], [ 20.99998986, 40.58000397 ], [ 20.67499678, 40.4349999 ], [ 20.61500044, 40.11000682 ], [ 20.1500159, 39.62499767 ], [ 19.98000044, 39.69499339 ], [ 19.96000166, 39.91500581 ], [ 19.40608198, 40.25077342 ], [ 19.31905887, 40.72723013 ], [ 19.40354984, 41.40956574 ], [ 19.5400273, 41.71998607 ], [ 19.37176883, 41.87754751 ], [ 19.37176816, 41.87755068 ], [ 19.30448612, 42.19574514 ], [ 19.73805139, 42.68824738 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "United Arab Emirates", "sov_a3": "ARE", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "United Arab Emirates", "adm0_a3": "ARE", "geou_dif": 0.000000, "geounit": "United Arab Emirates", "gu_a3": "ARE", "su_dif": 0.000000, "subunit": "United Arab Emirates", "su_a3": "ARE", "brk_diff": 0.000000, "name": "United Arab Emirates", "name_long": "United Arab Emirates", "brk_a3": "ARE", "brk_name": "United Arab Emirates", "brk_group": null, "abbrev": "U.A.E.", "postal": "AE", "formal_en": "United Arab Emirates", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "United Arab Emirates", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 1.000000, "mapcolor9": 3.000000, "mapcolor13": 3.000000, "pop_est": 4798491.000000, "gdp_md_est": 184300.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "2. High income: nonOECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "AE", "iso_a3": "ARE", "iso_n3": "784", "un_a3": "784", "wb_a2": "AE", "wb_a3": "ARE", "woe_id": -99.000000, "adm0_a3_is": "ARE", "adm0_a3_us": "ARE", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Western Asia", "region_wb": "Middle East & North Africa", "name_len": 20.000000, "long_len": 20.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 56.2610417, 25.71460643 ], [ 56.39684737, 24.92473216 ], [ 55.88623254, 24.92083059 ], [ 55.80411869, 24.26960419 ], [ 55.98121382, 24.13054291 ], [ 55.52863163, 23.93360403 ], [ 55.5258411, 23.52486929 ], [ 55.23448937, 23.11099274 ], [ 55.2083411, 22.70832998 ], [ 55.00680301, 22.49694754 ], [ 52.00073327, 23.00115449 ], [ 51.61770755, 24.01421927 ], [ 51.57951867, 24.24549714 ], [ 51.75744063, 24.29407298 ], [ 51.79438928, 24.01982616 ], [ 52.57708052, 24.17743928 ], [ 53.40400679, 24.15131684 ], [ 54.00800093, 24.12175792 ], [ 54.69302372, 24.79789236 ], [ 55.43902469, 25.43914521 ], [ 56.07082075, 26.05546418 ], [ 56.2610417, 25.71460643 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Argentina", "sov_a3": "ARG", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Argentina", "adm0_a3": "ARG", "geou_dif": 0.000000, "geounit": "Argentina", "gu_a3": "ARG", "su_dif": 0.000000, "subunit": "Argentina", "su_a3": "ARG", "brk_diff": 0.000000, "name": "Argentina", "name_long": "Argentina", "brk_a3": "ARG", "brk_name": "Argentina", "brk_group": null, "abbrev": "Arg.", "postal": "AR", "formal_en": "Argentine Republic", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Argentina", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 1.000000, "mapcolor9": 3.000000, "mapcolor13": 13.000000, "pop_est": 40913584.000000, "gdp_md_est": 573900.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "5. Emerging region: G20", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "AR", "iso_a3": "ARG", "iso_n3": "032", "un_a3": "032", "wb_a2": "AR", "wb_a3": "ARG", "woe_id": -99.000000, "adm0_a3_is": "ARG", "adm0_a3_us": "ARG", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "South America", "region_un": "Americas", "subregion": "South America", "region_wb": "Latin America & Caribbean", "name_len": 9.000000, "long_len": 9.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -65.5, -55.2 ], [ -66.45, -55.25 ], [ -66.95992, -54.89681 ], [ -67.56244, -54.87001 ], [ -68.63335, -54.8695 ], [ -68.63401023, -52.63637046 ], [ -68.25, -53.1 ], [ -67.75, -53.85 ], [ -66.45, -54.45 ], [ -65.05, -54.7 ], [ -65.5, -55.2 ] ] ], [ [ [ -64.96489214, -22.0758615 ], [ -64.37702104, -22.79809132 ], [ -63.98683814, -21.9936443 ], [ -62.84646847, -22.03498545 ], [ -62.68505714, -22.24902923 ], [ -60.8465647, -23.88071258 ], [ -60.02896603, -24.03279632 ], [ -58.80712847, -24.77145924 ], [ -57.77721717, -25.16233978 ], [ -57.63366004, -25.60365651 ], [ -58.61817359, -27.12371876 ], [ -57.60975969, -27.39589853 ], [ -56.48670163, -27.54849904 ], [ -55.69584551, -27.38783701 ], [ -54.78879493, -26.62178558 ], [ -54.6252907, -25.73925547 ], [ -54.13004961, -25.54763926 ], [ -53.62834897, -26.124865 ], [ -53.64873532, -26.92347259 ], [ -54.49072527, -27.47475677 ], [ -55.16228634, -27.88191538 ], [ -56.29089962, -28.85276051 ], [ -57.62513343, -30.21629485 ], [ -57.8749373, -31.01655608 ], [ -58.14244036, -32.04450368 ], [ -58.13264767, -33.04056691 ], [ -58.34961117, -33.26318898 ], [ -58.42707414, -33.90945444 ], [ -58.49544206, -34.43148976 ], [ -57.22582964, -35.28802663 ], [ -57.36235877, -35.97739023 ], [ -56.73748735, -36.41312591 ], [ -56.78828529, -36.90157155 ], [ -57.74915687, -38.18387054 ], [ -59.23185706, -38.72022023 ], [ -61.23744524, -38.92842457 ], [ -62.335957, -38.82770721 ], [ -62.12576311, -39.42410491 ], [ -62.33053097, -40.17258636 ], [ -62.14599443, -40.67689666 ], [ -62.74580278, -41.02876149 ], [ -63.77049476, -41.16678924 ], [ -64.73208981, -40.8026771 ], [ -65.11803524, -41.06431487 ], [ -64.97856055, -42.05800099 ], [ -64.30340797, -42.35901621 ], [ -63.75594784, -42.04368662 ], [ -63.45805905, -42.56313812 ], [ -64.37880388, -42.87355844 ], [ -65.18180396, -43.49538095 ], [ -65.32882341, -44.50136606 ], [ -65.56526893, -45.03678558 ], [ -66.50996579, -45.03962778 ], [ -67.29379391, -45.55189625 ], [ -67.58054643, -46.30177296 ], [ -66.59706641, -47.03392466 ], [ -65.64102658, -47.23613454 ], [ -65.98508826, -48.13328908 ], [ -67.16617896, -48.69733733 ], [ -67.81608761, -49.86966888 ], [ -68.72874508, -50.26421844 ], [ -69.13853919, -50.73251027 ], [ -68.81556149, -51.77110401 ], [ -68.14999488, -52.34998341 ], [ -68.57154538, -52.29944386 ], [ -69.49836219, -52.14276091 ], [ -71.91480384, -52.00902231 ], [ -72.32940386, -51.42595631 ], [ -72.30997352, -50.67700978 ], [ -72.97574683, -50.74145029 ], [ -73.32805091, -50.37878509 ], [ -73.41543576, -49.31843637 ], [ -72.64824744, -48.87861826 ], [ -72.33116085, -48.24423838 ], [ -72.44735531, -47.73853281 ], [ -71.91725847, -46.88483815 ], [ -71.55200945, -45.56073292 ], [ -71.65931556, -44.97368865 ], [ -71.2227789, -44.78424285 ], [ -71.32980079, -44.40752166 ], [ -71.79362261, -44.20717213 ], [ -71.46405616, -43.78761118 ], [ -71.91542396, -43.40856455 ], [ -72.14889808, -42.2548882 ], [ -71.74680376, -42.05138641 ], [ -71.91573402, -40.83233937 ], [ -71.68076128, -39.80816416 ], [ -71.41351661, -38.91602223 ], [ -70.81466427, -38.55299529 ], [ -71.11862505, -37.57682749 ], [ -71.12188066, -36.65812387 ], [ -70.36476925, -36.0050888 ], [ -70.38804949, -35.1696876 ], [ -69.81730913, -34.19357147 ], [ -69.81477698, -33.273886 ], [ -70.07439938, -33.09120981 ], [ -70.53506894, -31.36501027 ], [ -69.91900835, -30.33633921 ], [ -70.01355038, -29.36792287 ], [ -69.65613034, -28.45914113 ], [ -69.00123491, -27.52121388 ], [ -68.29554155, -26.89933969 ], [ -68.59479977, -26.50690887 ], [ -68.38600115, -26.18501637 ], [ -68.41765296, -24.51855478 ], [ -67.32844296, -24.02530324 ], [ -66.98523393, -22.98634857 ], [ -67.10667355, -22.73592457 ], [ -66.2733394, -21.83231048 ], [ -64.96489214, -22.0758615 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Armenia", "sov_a3": "ARM", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Armenia", "adm0_a3": "ARM", "geou_dif": 0.000000, "geounit": "Armenia", "gu_a3": "ARM", "su_dif": 0.000000, "subunit": "Armenia", "su_a3": "ARM", "brk_diff": 0.000000, "name": "Armenia", "name_long": "Armenia", "brk_a3": "ARM", "brk_name": "Armenia", "brk_group": null, "abbrev": "Arm.", "postal": "ARM", "formal_en": "Republic of Armenia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Armenia", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 1.000000, "mapcolor9": 2.000000, "mapcolor13": 10.000000, "pop_est": 2967004.000000, "gdp_md_est": 18770.000000, "pop_year": -99.000000, "lastcensus": 2001.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "AM", "iso_a3": "ARM", "iso_n3": "051", "un_a3": "051", "wb_a2": "AM", "wb_a3": "ARM", "woe_id": -99.000000, "adm0_a3_is": "ARM", "adm0_a3_us": "ARM", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Western Asia", "region_wb": "Europe & Central Asia", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 46.50571984, 38.77060537 ], [ 46.14362308, 38.74120148 ], [ 45.73537927, 39.31971914 ], [ 45.73997847, 39.47399913 ], [ 45.29814497, 39.47175121 ], [ 45.00198734, 39.74000357 ], [ 44.7939897, 39.71300263 ], [ 44.40000858, 40.00500031 ], [ 43.6564364, 40.25356395 ], [ 43.75265791, 40.74020091 ], [ 43.5827458, 41.09214326 ], [ 44.9724801, 41.24812857 ], [ 45.17949588, 40.98535391 ], [ 45.56035119, 40.81228954 ], [ 45.35917484, 40.56150381 ], [ 45.89190718, 40.21847565 ], [ 45.61001224, 39.8999938 ], [ 46.03453413, 39.62802074 ], [ 46.48349898, 39.46415477 ], [ 46.50571984, 38.77060537 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Antarctica", "sov_a3": "ATA", "adm0_dif": 0.000000, "level": 2.000000, "type": "Indeterminate", "admin": "Antarctica", "adm0_a3": "ATA", "geou_dif": 0.000000, "geounit": "Antarctica", "gu_a3": "ATA", "su_dif": 0.000000, "subunit": "Antarctica", "su_a3": "ATA", "brk_diff": 0.000000, "name": "Antarctica", "name_long": "Antarctica", "brk_a3": "ATA", "brk_name": "Antarctica", "brk_group": null, "abbrev": "Ant.", "postal": "AQ", "formal_en": null, "formal_fr": null, "note_adm0": null, "note_brk": "Multiple claims held in abeyance", "name_sort": "Antarctica", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 5.000000, "mapcolor9": 1.000000, "mapcolor13": -99.000000, "pop_est": 3802.000000, "gdp_md_est": 760.400000, "pop_year": -99.000000, "lastcensus": -99.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "2. High income: nonOECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "AQ", "iso_a3": "ATA", "iso_n3": "010", "un_a3": "-099", "wb_a2": "-99", "wb_a3": "-99", "woe_id": -99.000000, "adm0_a3_is": "ATA", "adm0_a3_us": "ATA", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Antarctica", "region_un": "Antarctica", "subregion": "Antarctica", "region_wb": "Antarctica", "name_len": 10.000000, "long_len": 10.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -59.57209469, -80.04017873 ], [ -59.86584937, -80.54965667 ], [ -60.15965573, -81.00032684 ], [ -62.25539344, -80.86317759 ], [ -64.48812537, -80.92193369 ], [ -65.74166643, -80.58882741 ], [ -65.74166643, -80.54965667 ], [ -66.29003089, -80.2557728 ], [ -64.03768775, -80.29494354 ], [ -61.88324561, -80.39287038 ], [ -61.1389758, -79.98137095 ], [ -60.61011919, -79.62867929 ], [ -59.57209469, -80.04017873 ] ] ], [ [ [ -159.20818356, -79.49705942 ], [ -161.12760128, -79.63420867 ], [ -162.43984677, -79.28146535 ], [ -163.0274078, -78.9287737 ], [ -163.06660438, -78.86996592 ], [ -163.71289568, -78.59566741 ], [ -163.71289568, -78.59566661 ], [ -163.10580095, -78.22333791 ], [ -161.24511349, -78.38017588 ], [ -160.24620806, -78.69364512 ], [ -159.48240455, -79.04633758 ], [ -159.20818356, -79.49705942 ] ] ], [ [ [ -45.15475766, -78.0470696 ], [ -43.92082781, -78.47810272 ], [ -43.48994971, -79.08555999 ], [ -43.37243751, -79.51664479 ], [ -43.33326677, -80.02612274 ], [ -44.88053667, -80.33964365 ], [ -46.50617388, -80.59435678 ], [ -48.38642086, -80.82948455 ], [ -50.4821069, -81.02544158 ], [ -52.85198808, -80.96668548 ], [ -54.16425941, -80.63352752 ], [ -53.9879911, -80.22202809 ], [ -51.85313432, -79.94772959 ], [ -50.99132646, -79.61462331 ], [ -50.36459469, -79.18348683 ], [ -49.91413123, -78.811209 ], [ -49.30695899, -78.45856903 ], [ -48.66061601, -78.04701792 ], [ -48.66061601, -78.04701873 ], [ -48.15139645, -78.0470696 ], [ -46.66285682, -77.83147553 ], [ -45.15475766, -78.0470696 ] ] ], [ [ [ -121.21151139, -73.5009905 ], [ -119.91885128, -73.65772512 ], [ -118.72414303, -73.48135345 ], [ -119.2921187, -73.83409678 ], [ -120.23221716, -74.08880992 ], [ -121.62282996, -74.01046844 ], [ -122.62173459, -73.6577776 ], [ -122.62173539, -73.65777679 ], [ -122.40624467, -73.32461884 ], [ -121.21151139, -73.5009905 ] ] ], [ [ [ -125.55956641, -73.48135345 ], [ -124.03188188, -73.87326752 ], [ -124.61946875, -73.83409678 ], [ -125.91218054, -73.73611827 ], [ -127.28312965, -73.46176889 ], [ -127.28313045, -73.46176809 ], [ -126.55847184, -73.24622569 ], [ -125.55956641, -73.48135345 ] ] ], [ [ [ -98.98154965, -71.93333425 ], [ -97.88474321, -72.07053518 ], [ -96.78793677, -71.95297129 ], [ -96.2003499, -72.52120534 ], [ -96.98376461, -72.44286387 ], [ -98.19808326, -72.48203461 ], [ -99.43201311, -72.44286387 ], [ -100.78345517, -72.50161997 ], [ -101.80186846, -72.30566294 ], [ -102.33072506, -71.89416432 ], [ -102.33072506, -71.89416351 ], [ -101.70396745, -71.71779185 ], [ -100.43091855, -71.85499278 ], [ -98.98154965, -71.93333425 ] ] ], [ [ [ -68.45134599, -70.95582286 ], [ -68.33383379, -71.40649302 ], [ -68.51012794, -71.79840708 ], [ -68.78429725, -72.17073578 ], [ -69.95947099, -72.30788503 ], [ -71.07588864, -72.50384206 ], [ -72.38813412, -72.48425669 ], [ -71.89849993, -72.09234263 ], [ -73.073622, -72.22949188 ], [ -74.19003964, -72.36669281 ], [ -74.95389482, -72.07275726 ], [ -75.01262509, -71.66125783 ], [ -73.91581865, -71.26934458 ], [ -73.91581865, -71.26934377 ], [ -73.23033078, -71.15177989 ], [ -72.07471656, -71.19095062 ], [ -71.78096188, -70.68147268 ], [ -71.72217994, -70.30919566 ], [ -71.74179114, -69.50578217 ], [ -71.17381548, -69.03547496 ], [ -70.25325151, -68.87874034 ], [ -69.72444658, -69.25101735 ], [ -69.48942217, -69.62334605 ], [ -69.05851824, -70.07401622 ], [ -68.72554114, -70.50515269 ], [ -68.45134599, -70.95582286 ] ] ], [ [ [ -58.61414283, -64.15246713 ], [ -59.0450726, -64.36800953 ], [ -59.78934241, -64.21122323 ], [ -60.61192786, -64.30920175 ], [ -61.29741574, -64.54432952 ], [ -62.02210019, -64.79909433 ], [ -62.51176022, -65.09302987 ], [ -62.64885779, -65.48494232 ], [ -62.59012753, -65.85721934 ], [ -62.1200787, -66.19032562 ], [ -62.80556658, -66.42550507 ], [ -63.74569007, -66.50384654 ], [ -64.29410621, -66.8370045 ], [ -64.88169308, -67.15047373 ], [ -65.50842485, -67.58161021 ], [ -65.66508196, -67.95388723 ], [ -65.31254534, -68.36533498 ], [ -64.78371457, -68.67890757 ], [ -63.96110328, -68.91398366 ], [ -63.19729977, -69.22755625 ], [ -62.78595537, -69.61941864 ], [ -62.57051632, -69.99174733 ], [ -62.27673581, -70.3836614 ], [ -61.80666114, -70.71676768 ], [ -61.51290646, -71.0890447 ], [ -61.37580889, -72.01007375 ], [ -61.08197669, -72.38235077 ], [ -61.00366106, -72.77426483 ], [ -60.69026933, -73.16617889 ], [ -60.82736691, -73.69524221 ], [ -61.37580889, -74.10674164 ], [ -61.96336992, -74.43984792 ], [ -63.29520077, -74.57699717 ], [ -63.74569007, -74.9297405 ], [ -64.35283647, -75.26284678 ], [ -65.86098731, -75.6351238 ], [ -67.19281816, -75.7919101 ], [ -68.4462817, -76.00745249 ], [ -69.79772376, -76.22299489 ], [ -70.60072384, -76.63449432 ], [ -72.20677568, -76.67366506 ], [ -73.9695363, -76.63449432 ], [ -75.55597694, -76.71288747 ], [ -77.24037025, -76.71288747 ], [ -76.92697852, -77.10480153 ], [ -75.39929399, -77.28106984 ], [ -74.28287635, -77.55542002 ], [ -73.65611874, -77.90811167 ], [ -74.77253638, -78.22163259 ], [ -76.49610043, -78.12365407 ], [ -77.92585812, -78.37841888 ], [ -77.9846659, -78.78991831 ], [ -78.02378496, -79.18183318 ], [ -76.84863705, -79.51493947 ], [ -76.63322384, -79.88721649 ], [ -75.36009742, -80.25954518 ], [ -73.24485185, -80.41633148 ], [ -71.44294634, -80.69062998 ], [ -70.01316281, -81.00415089 ], [ -68.19164608, -81.31767181 ], [ -65.70427853, -81.4744581 ], [ -63.25603004, -81.74875661 ], [ -61.55202552, -82.04269215 ], [ -59.69141557, -82.37585011 ], [ -58.71212134, -82.84610565 ], [ -58.22248715, -83.21843434 ], [ -57.00811683, -82.86569101 ], [ -55.36289425, -82.57175547 ], [ -53.61977068, -82.25823455 ], [ -51.54364417, -82.00352142 ], [ -49.76134986, -81.72917124 ], [ -47.27393063, -81.70958587 ], [ -44.82570797, -81.84673512 ], [ -42.80836341, -82.08191456 ], [ -42.16202043, -81.65082977 ], [ -40.77143348, -81.35689422 ], [ -38.24481767, -81.33730885 ], [ -36.26666968, -81.12171478 ], [ -34.38639686, -80.90617238 ], [ -32.31029619, -80.76902313 ], [ -30.09709795, -80.59265146 ], [ -28.54980221, -80.33793833 ], [ -29.25490129, -79.985195 ], [ -29.68580522, -79.63250335 ], [ -29.68580522, -79.26022633 ], [ -31.62480832, -79.29939707 ], [ -33.68132362, -79.45613169 ], [ -35.63991208, -79.45613169 ], [ -35.91410723, -79.08385467 ], [ -35.77700965, -78.33924815 ], [ -35.32654619, -78.12365407 ], [ -33.89676266, -77.88852631 ], [ -32.21236935, -77.65345022 ], [ -30.99805071, -77.35951467 ], [ -29.78373206, -77.06557912 ], [ -28.8827793, -76.67366506 ], [ -27.51175188, -76.49734507 ], [ -26.16033566, -76.36014414 ], [ -25.47482195, -76.28180267 ], [ -23.92755205, -76.24258026 ], [ -22.45859778, -76.10543101 ], [ -21.22469377, -75.90947398 ], [ -20.01037513, -75.67434621 ], [ -18.91354285, -75.43921844 ], [ -17.52298174, -75.12569753 ], [ -16.64158851, -74.79253957 ], [ -15.70149085, -74.49860402 ], [ -15.40771033, -74.10674164 ], [ -16.4653202, -73.87161387 ], [ -16.11278358, -73.46011444 ], [ -15.44685523, -73.14654185 ], [ -14.4088049, -72.95058482 ], [ -13.31197262, -72.71545705 ], [ -12.29350766, -72.40193614 ], [ -11.5100671, -72.01007375 ], [ -11.02043291, -71.53976654 ], [ -10.2957743, -71.26541636 ], [ -9.10101518, -71.32422414 ], [ -8.61138099, -71.65733042 ], [ -7.41662187, -71.69650116 ], [ -7.37745114, -71.32422414 ], [ -6.86823157, -70.93231008 ], [ -5.79098467, -71.03028859 ], [ -5.53637488, -71.40261729 ], [ -4.34166745, -71.46137339 ], [ -3.04898149, -71.28505341 ], [ -1.79549211, -71.16743785 ], [ -0.6594891, -71.22624563 ], [ -0.22863685, -71.63774506 ], [ 0.86819543, -71.30463877 ], [ 1.88668623, -71.12826711 ], [ 3.02263757, -70.99111786 ], [ 4.13905521, -70.85391693 ], [ 5.15754601, -70.61878916 ], [ 6.27391198, -70.46205455 ], [ 7.13571984, -70.24651215 ], [ 7.74286625, -69.89376882 ], [ 8.48711022, -70.14853363 ], [ 9.52513472, -70.0113327 ], [ 10.249845, -70.48163991 ], [ 10.81782067, -70.83433156 ], [ 11.95382368, -70.63837453 ], [ 12.40428714, -70.24651215 ], [ 13.42277795, -69.97216197 ], [ 14.73499759, -70.03091807 ], [ 15.12675663, -70.40324677 ], [ 15.94934208, -70.03091807 ], [ 17.02658898, -69.91335419 ], [ 18.20171105, -69.87418345 ], [ 19.25937259, -69.89376882 ], [ 20.37573856, -70.0113327 ], [ 21.45298547, -70.07014048 ], [ 21.9230343, -70.40324677 ], [ 22.56940311, -70.69718231 ], [ 23.66618371, -70.52081065 ], [ 24.84135746, -70.48163991 ], [ 25.97730879, -70.48163991 ], [ 27.09372643, -70.46205455 ], [ 28.09258019, -70.32485362 ], [ 29.15024173, -70.20728973 ], [ 30.03158329, -69.93293955 ], [ 30.97173262, -69.75661957 ], [ 31.99017175, -69.65864105 ], [ 32.75405277, -69.38429087 ], [ 33.30244307, -68.83564219 ], [ 33.87041874, -68.50258759 ], [ 34.90849491, -68.65927053 ], [ 35.30020226, -69.01201386 ], [ 36.16201013, -69.24714162 ], [ 37.20003462, -69.16874847 ], [ 37.90510786, -69.52144012 ], [ 38.64940352, -69.77620494 ], [ 39.66789432, -69.54107717 ], [ 40.02043094, -69.10994069 ], [ 40.92135786, -68.93362071 ], [ 41.95943404, -68.60051442 ], [ 42.93870243, -68.4633135 ], [ 44.11387617, -68.26740814 ], [ 44.89729089, -68.05186574 ], [ 45.71992801, -67.81673798 ], [ 46.50334273, -67.60119558 ], [ 47.44344038, -67.71875946 ], [ 48.34441898, -67.36606781 ], [ 48.99073612, -67.09171763 ], [ 49.93088545, -67.111303 ], [ 50.7534709, -66.87617523 ], [ 50.94932458, -66.52348358 ], [ 51.79154707, -66.2491334 ], [ 52.61413252, -66.05317637 ], [ 53.61303796, -65.89639008 ], [ 54.53355025, -65.8180486 ], [ 55.41494348, -65.87680471 ], [ 56.35504113, -65.97478322 ], [ 57.15809289, -66.2491334 ], [ 57.25596805, -66.6802182 ], [ 58.13736128, -67.01332448 ], [ 58.74450768, -67.28767466 ], [ 59.93931848, -67.40523855 ], [ 60.60522098, -67.67958872 ], [ 61.42780643, -67.95388723 ], [ 62.38748946, -68.01269501 ], [ 63.19048954, -67.81673798 ], [ 64.05234907, -67.40523855 ], [ 64.99244673, -67.62072927 ], [ 65.97171512, -67.73834483 ], [ 66.91186446, -67.85590871 ], [ 67.89113285, -67.93430186 ], [ 68.89003828, -67.93430186 ], [ 69.71262373, -68.97279144 ], [ 69.673453, -69.22755625 ], [ 69.55594079, -69.67822642 ], [ 68.59625777, -69.93293955 ], [ 67.8127397, -70.30526825 ], [ 67.94988895, -70.69718231 ], [ 69.06630659, -70.67754527 ], [ 68.92915734, -71.06945933 ], [ 68.41998946, -71.44178803 ], [ 67.94988895, -71.85328746 ], [ 68.71376997, -72.16680837 ], [ 69.86930668, -72.26478689 ], [ 71.02489505, -72.08841522 ], [ 71.57328535, -71.69650116 ], [ 71.90628828, -71.32422414 ], [ 72.45462691, -71.01070323 ], [ 73.08141035, -70.71676768 ], [ 73.33602014, -70.36402435 ], [ 73.86487674, -69.87418345 ], [ 74.49155684, -69.77620494 ], [ 75.62755985, -69.7370342 ], [ 76.62646529, -69.61941864 ], [ 77.64490441, -69.46268402 ], [ 78.13453861, -69.07076996 ], [ 78.4283708, -68.69844126 ], [ 79.11385868, -68.32621592 ], [ 80.09312707, -68.07150279 ], [ 80.93534956, -67.87554576 ], [ 81.48379154, -67.5423878 ], [ 82.05176721, -67.36606781 ], [ 82.77642582, -67.20928151 ], [ 83.77533125, -67.30726003 ], [ 84.6762065, -67.20928151 ], [ 85.65552656, -67.09171763 ], [ 86.75235884, -67.15047373 ], [ 87.47701745, -66.87617523 ], [ 87.98628869, -66.20991099 ], [ 88.35841068, -66.48426117 ], [ 88.82840783, -66.95456838 ], [ 89.67063032, -67.15047373 ], [ 90.63036502, -67.22886688 ], [ 91.59009973, -67.111303 ], [ 92.60853885, -67.18969615 ], [ 93.54863651, -67.20928151 ], [ 94.17541996, -67.111303 ], [ 95.01759077, -67.17011078 ], [ 95.7814718, -67.38565318 ], [ 96.68239872, -67.24850393 ], [ 97.75964562, -67.24850393 ], [ 98.68020959, -67.111303 ], [ 99.71818241, -67.24850393 ], [ 100.38418827, -66.91534597 ], [ 100.89335615, -66.58223969 ], [ 101.57889571, -66.30788951 ], [ 102.83241092, -65.56328379 ], [ 103.47867639, -65.70048472 ], [ 104.24255741, -65.97478322 ], [ 104.90845991, -66.32752655 ], [ 106.1815605, -66.93493134 ], [ 107.16088057, -66.95456838 ], [ 108.08139286, -66.95456838 ], [ 109.15863976, -66.8370045 ], [ 110.235835, -66.69980357 ], [ 111.05847212, -66.42550507 ], [ 111.74396, -66.13156952 ], [ 112.86037764, -66.09234711 ], [ 113.60467329, -65.87680471 ], [ 114.38808801, -66.07276174 ], [ 114.89730757, -66.38628265 ], [ 115.60238081, -66.69980357 ], [ 116.69916141, -66.66063283 ], [ 117.38470096, -66.91534597 ], [ 118.57946008, -67.17011078 ], [ 119.83292362, -67.26808929 ], [ 120.87099979, -67.18969615 ], [ 121.6544145, -66.87617523 ], [ 122.32036869, -66.56265432 ], [ 123.22129561, -66.48426117 ], [ 124.1222742, -66.6214621 ], [ 125.16024702, -66.71938894 ], [ 126.10039636, -66.56265432 ], [ 127.00142663, -66.56265432 ], [ 127.88276818, -66.66063283 ], [ 128.80328047, -66.75861135 ], [ 129.70425907, -66.58223969 ], [ 130.7814543, -66.42550507 ], [ 131.7999451, -66.38628265 ], [ 132.93589644, -66.38628265 ], [ 133.8564604, -66.28830414 ], [ 134.75738732, -66.20996267 ], [ 135.03158247, -65.72007009 ], [ 135.07075321, -65.30857066 ], [ 135.69748498, -65.58286916 ], [ 135.87380497, -66.033591 ], [ 136.20670454, -66.44509043 ], [ 136.61804894, -66.77819672 ], [ 137.46027144, -66.95456838 ], [ 138.59622277, -66.8957606 ], [ 139.90844242, -66.87617523 ], [ 140.80942101, -66.81736745 ], [ 142.12169234, -66.81736745 ], [ 143.06184167, -66.79778208 ], [ 144.37406131, -66.8370045 ], [ 145.49042728, -66.91534597 ], [ 146.1955522, -67.22886688 ], [ 145.99969852, -67.60119558 ], [ 146.64606734, -67.89513112 ], [ 147.72326257, -68.13025889 ], [ 148.83962853, -68.3850237 ], [ 150.13231449, -68.56129201 ], [ 151.48370487, -68.71812998 ], [ 152.50224735, -68.87481293 ], [ 153.63819868, -68.89450165 ], [ 154.2845675, -68.56129201 ], [ 155.16585738, -68.83564219 ], [ 155.92979007, -69.14921478 ], [ 156.81113163, -69.38429087 ], [ 158.02552779, -69.48226939 ], [ 159.18101281, -69.59983327 ], [ 159.67069868, -69.99174733 ], [ 160.80665002, -70.2268751 ], [ 161.57047936, -70.57961843 ], [ 162.68689701, -70.73635305 ], [ 163.84243371, -70.71676768 ], [ 164.91968062, -70.77552378 ], [ 166.11443973, -70.75593842 ], [ 167.30909549, -70.83433156 ], [ 168.42561649, -70.97148081 ], [ 169.46358931, -71.20666026 ], [ 170.50166548, -71.40261729 ], [ 171.2067904, -71.69650116 ], [ 171.08922652, -72.08841522 ], [ 170.56042158, -72.44115855 ], [ 170.10995812, -72.89182872 ], [ 169.75736983, -73.24452037 ], [ 169.287321, -73.6560198 ], [ 167.97510135, -73.81280609 ], [ 167.38748864, -74.16549774 ], [ 166.09480269, -74.38104014 ], [ 165.6443909, -74.7729542 ], [ 164.95885135, -75.1452829 ], [ 164.23419274, -75.45880381 ], [ 163.82279667, -75.87030324 ], [ 163.56823856, -76.24258026 ], [ 163.47026004, -76.6933021 ], [ 163.48989709, -77.06557912 ], [ 164.05787276, -77.45744151 ], [ 164.27336348, -77.8297702 ], [ 164.74346398, -78.18251353 ], [ 166.6041256, -78.3196111 ], [ 166.99578128, -78.75074758 ], [ 165.19387577, -78.90748301 ], [ 163.66621708, -79.1230254 ], [ 161.76638472, -79.16224782 ], [ 160.92416223, -79.73048187 ], [ 160.74789392, -80.2007374 ], [ 160.31696415, -80.57306609 ], [ 159.78821089, -80.94539479 ], [ 161.1200159, -81.27850107 ], [ 161.62928714, -81.6900005 ], [ 162.49099165, -82.06227752 ], [ 163.70533614, -82.39543548 ], [ 165.09594893, -82.70895639 ], [ 166.6041256, -83.02247731 ], [ 168.89566532, -83.33599822 ], [ 169.40478153, -83.8258908 ], [ 172.28393395, -84.0414332 ], [ 172.47704878, -84.11791432 ], [ 173.22408329, -84.41371022 ], [ 175.98567183, -84.15899708 ], [ 178.27721154, -84.472518 ], [ 180.0, -84.71338 ], [ 180.0, -90.0 ], [ -180.0, -90.0 ], [ -180.0, -84.71338 ], [ -179.94249936, -84.72144337 ], [ -179.05867733, -84.13941172 ], [ -177.25677182, -84.45293263 ], [ -177.14080667, -84.41794123 ], [ -176.08467282, -84.09925913 ], [ -175.94723461, -84.11044871 ], [ -175.82988217, -84.11791432 ], [ -174.38250281, -84.53432301 ], [ -173.11655941, -84.11791432 ], [ -172.8891056, -84.06101857 ], [ -169.95122291, -83.88464691 ], [ -168.99998898, -84.11791432 ], [ -168.53019853, -84.23739023 ], [ -167.02209937, -84.57049651 ], [ -164.18214352, -84.82520965 ], [ -161.92977454, -85.13873056 ], [ -158.07137956, -85.37391001 ], [ -155.19225298, -85.09955983 ], [ -150.94209897, -85.29551686 ], [ -148.53307288, -85.60903777 ], [ -145.88891823, -85.31510223 ], [ -143.10771848, -85.04075205 ], [ -142.89227943, -84.57049651 ], [ -146.82906837, -84.5312741 ], [ -150.06073157, -84.29614634 ], [ -150.90292823, -83.90423227 ], [ -153.58620114, -83.68868987 ], [ -153.40990699, -83.23801971 ], [ -153.03775916, -82.82652028 ], [ -152.66563717, -82.45419158 ], [ -152.86151669, -82.04269215 ], [ -154.52629879, -81.76839365 ], [ -155.29017982, -81.41565032 ], [ -156.83744971, -81.10212941 ], [ -154.40878659, -81.16093719 ], [ -152.09766151, -81.00415089 ], [ -150.64829261, -81.33730885 ], [ -148.8659983, -81.04337331 ], [ -147.22074989, -80.67104461 ], [ -146.417749, -80.33793833 ], [ -146.77028642, -79.9264389 ], [ -148.06294654, -79.65208872 ], [ -149.5319008, -79.35820485 ], [ -151.5884161, -79.29939707 ], [ -153.39032162, -79.16224782 ], [ -155.32937639, -79.0642693 ], [ -155.97566769, -78.6919398 ], [ -157.26830197, -78.37841888 ], [ -158.05176836, -78.02567556 ], [ -158.36513424, -76.88920746 ], [ -157.87547421, -76.98723765 ], [ -156.97457313, -77.30075857 ], [ -155.32937639, -77.20272837 ], [ -153.7428324, -77.06557912 ], [ -152.92024696, -77.49666392 ], [ -151.33378048, -77.39873708 ], [ -150.00194963, -77.18314301 ], [ -148.74848609, -76.9088445 ], [ -147.61248308, -76.57573822 ], [ -146.10440895, -76.4777597 ], [ -146.14352801, -76.10543101 ], [ -146.49609127, -75.73315399 ], [ -146.20230995, -75.38041067 ], [ -144.909624, -75.204039 ], [ -144.32203712, -75.53719696 ], [ -142.79435259, -75.34123993 ], [ -141.63876421, -75.08647512 ], [ -140.20900652, -75.06688975 ], [ -138.8575903, -74.96891123 ], [ -137.50619992, -74.73378347 ], [ -136.42890134, -74.51824107 ], [ -135.2145827, -74.30269867 ], [ -134.43119382, -74.36145477 ], [ -133.74565427, -74.43984792 ], [ -132.25716793, -74.30269867 ], [ -130.92531124, -74.47901866 ], [ -129.55428381, -74.45943329 ], [ -128.24203833, -74.32228404 ], [ -126.89062211, -74.42026255 ], [ -125.40208248, -74.51824107 ], [ -124.01149552, -74.47901866 ], [ -122.56215247, -74.49860402 ], [ -121.07361283, -74.51824107 ], [ -119.70255957, -74.47901866 ], [ -118.68414547, -74.18508311 ], [ -117.46980099, -74.02834849 ], [ -116.21631161, -74.24389089 ], [ -115.0215525, -74.06751923 ], [ -113.94433143, -73.71482758 ], [ -113.29798845, -74.02834849 ], [ -112.94545183, -74.38104014 ], [ -112.29908301, -74.7141981 ], [ -111.26105852, -74.42026255 ], [ -110.06632524, -74.79253957 ], [ -108.71490902, -74.91010345 ], [ -107.55934648, -75.18445363 ], [ -106.14914832, -75.12569753 ], [ -104.87607357, -74.94932587 ], [ -103.36794857, -74.9884966 ], [ -102.01650652, -75.12569753 ], [ -100.64553077, -75.30201752 ], [ -100.1167, -74.87093272 ], [ -100.76304298, -74.53782644 ], [ -101.25270301, -74.18508311 ], [ -102.54533729, -74.10674164 ], [ -103.11331295, -73.73441294 ], [ -103.328752, -73.36208425 ], [ -103.68128862, -72.61753021 ], [ -102.91748511, -72.75467946 ], [ -101.60523963, -72.81343557 ], [ -100.31252784, -72.75467946 ], [ -99.13737993, -72.91141408 ], [ -98.11888913, -73.20534963 ], [ -97.68803687, -73.55804128 ], [ -96.33659481, -73.61684906 ], [ -95.04396054, -73.47969981 ], [ -93.67290727, -73.28374278 ], [ -92.43900326, -73.16617889 ], [ -91.42056413, -73.40130666 ], [ -90.08873328, -73.32291351 ], [ -89.22695126, -72.55872243 ], [ -88.42395118, -73.0093926 ], [ -87.26833696, -73.18576426 ], [ -86.01482174, -73.08778575 ], [ -85.19223629, -73.47969981 ], [ -83.87999081, -73.51887054 ], [ -82.66564633, -73.63643443 ], [ -81.47091305, -73.85197683 ], [ -80.68744666, -73.47969981 ], [ -80.29579098, -73.12695648 ], [ -79.29688555, -73.51887054 ], [ -77.92585812, -73.42089203 ], [ -76.90736732, -73.63643443 ], [ -76.22187944, -73.96954071 ], [ -74.89004859, -73.87161387 ], [ -73.8520241, -73.6560198 ], [ -72.83353329, -73.40130666 ], [ -71.61921465, -73.26415741 ], [ -70.20904232, -73.14654185 ], [ -68.9359159, -73.0093926 ], [ -67.95662167, -72.7938502 ], [ -67.36906064, -72.48032928 ], [ -67.13403622, -72.04924449 ], [ -67.25154843, -71.63774506 ], [ -67.56494015, -71.24583099 ], [ -67.91747677, -70.85391693 ], [ -68.23084266, -70.46205455 ], [ -68.48545244, -70.10931122 ], [ -68.54420854, -69.71739716 ], [ -68.4462817, -69.32553477 ], [ -67.97623288, -68.95320608 ], [ -67.58449968, -68.54170664 ], [ -67.42784258, -68.14984426 ], [ -67.62367042, -67.71875946 ], [ -67.74118262, -67.3268454 ], [ -67.25154843, -66.87617523 ], [ -66.70318397, -66.58223969 ], [ -66.05681515, -66.20996267 ], [ -65.37132728, -65.89639008 ], [ -64.56827552, -65.60250621 ], [ -64.17654232, -65.17142302 ], [ -63.62815202, -64.89707284 ], [ -63.00139442, -64.64230803 ], [ -62.04168555, -64.58355193 ], [ -61.41492794, -64.27003101 ], [ -60.7098547, -64.07407398 ], [ -59.88726925, -63.9565101 ], [ -59.1625848, -63.70174529 ], [ -58.59455746, -63.38822437 ], [ -57.81114275, -63.27066049 ], [ -57.22358171, -63.5254253 ], [ -57.59572954, -63.85853158 ], [ -58.61414283, -64.15246713 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 3, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "France", "sov_a3": "FR1", "adm0_dif": 1.000000, "level": 2.000000, "type": "Dependency", "admin": "French Southern and Antarctic Lands", "adm0_a3": "ATF", "geou_dif": 0.000000, "geounit": "French Southern and Antarctic Lands", "gu_a3": "ATF", "su_dif": 0.000000, "subunit": "French Southern and Antarctic Lands", "su_a3": "ATF", "brk_diff": 0.000000, "name": "Fr. S. Antarctic Lands", "name_long": "French Southern and Antarctic Lands", "brk_a3": "ATF", "brk_name": "Fr. S. and Antarctic Lands", "brk_group": null, "abbrev": "Fr. S.A.L.", "postal": "TF", "formal_en": "Territory of the French Southern and Antarctic Lands", "formal_fr": null, "note_adm0": "Fr.", "note_brk": null, "name_sort": "French Southern and Antarctic Lands", "name_alt": null, "mapcolor7": 7.000000, "mapcolor8": 5.000000, "mapcolor9": 9.000000, "mapcolor13": 11.000000, "pop_est": 140.000000, "gdp_md_est": 16.000000, "pop_year": -99.000000, "lastcensus": -99.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "2. High income: nonOECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "TF", "iso_a3": "ATF", "iso_n3": "260", "un_a3": "-099", "wb_a2": "-99", "wb_a3": "-99", "woe_id": -99.000000, "adm0_a3_is": "ATF", "adm0_a3_us": "ATF", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Seven seas (open ocean)", "region_un": "Seven seas (open ocean)", "subregion": "Seven seas (open ocean)", "region_wb": "Sub-Saharan Africa", "name_len": 22.000000, "long_len": 35.000000, "abbrev_len": 10.000000, "tiny": 2.000000, "homepart": -99.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 70.28, -49.71 ], [ 68.745, -49.775 ], [ 68.72, -49.2425 ], [ 68.8675, -48.83 ], [ 68.935, -48.625 ], [ 69.58, -48.94 ], [ 70.525, -49.065 ], [ 70.56, -49.255 ], [ 70.28, -49.71 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Australia", "sov_a3": "AU1", "adm0_dif": 1.000000, "level": 2.000000, "type": "Country", "admin": "Australia", "adm0_a3": "AUS", "geou_dif": 0.000000, "geounit": "Australia", "gu_a3": "AUS", "su_dif": 0.000000, "subunit": "Australia", "su_a3": "AUS", "brk_diff": 0.000000, "name": "Australia", "name_long": "Australia", "brk_a3": "AUS", "brk_name": "Australia", "brk_group": null, "abbrev": "Auz.", "postal": "AU", "formal_en": "Commonwealth of Australia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Australia", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 2.000000, "mapcolor9": 2.000000, "mapcolor13": 7.000000, "pop_est": 21262641.000000, "gdp_md_est": 800200.000000, "pop_year": -99.000000, "lastcensus": 2006.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "AU", "iso_a3": "AUS", "iso_n3": "036", "un_a3": "036", "wb_a2": "AU", "wb_a3": "AUS", "woe_id": -99.000000, "adm0_a3_is": "AUS", "adm0_a3_us": "AUS", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Oceania", "region_un": "Oceania", "subregion": "Australia and New Zealand", "region_wb": "East Asia & Pacific", "name_len": 9.000000, "long_len": 9.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 145.39797814, -40.79254852 ], [ 146.36412072, -41.13769541 ], [ 146.90858361, -41.00054616 ], [ 147.68925947, -40.80825815 ], [ 148.28906782, -40.87543751 ], [ 148.35986454, -42.06244516 ], [ 148.01730147, -42.40702361 ], [ 147.91405196, -43.21152231 ], [ 147.56456424, -42.9376889 ], [ 146.87034305, -43.63459726 ], [ 146.66332726, -43.58085377 ], [ 146.04837772, -43.54974456 ], [ 145.43192956, -42.69377614 ], [ 145.29509037, -42.03360971 ], [ 144.71807132, -41.16255177 ], [ 144.74375451, -40.70397511 ], [ 145.39797814, -40.79254852 ] ] ], [ [ [ 143.56181115, -13.76365569 ], [ 143.92209924, -14.54831064 ], [ 144.56371382, -14.17117604 ], [ 144.89490808, -14.5944577 ], [ 145.37472375, -14.9849765 ], [ 145.271991, -15.42820525 ], [ 145.48525964, -16.2856723 ], [ 145.63703332, -16.78491831 ], [ 145.88890425, -16.90692636 ], [ 146.16030887, -17.76165455 ], [ 146.06367394, -18.28007252 ], [ 146.38747847, -18.95827402 ], [ 147.47108158, -19.48072275 ], [ 148.17760176, -19.95593922 ], [ 148.84841353, -20.39120981 ], [ 148.71746545, -20.63346893 ], [ 149.2894202, -21.26051076 ], [ 149.67833703, -22.3425119 ], [ 150.07738244, -22.12278371 ], [ 150.48293908, -22.55614227 ], [ 150.72726525, -22.40240488 ], [ 150.89955448, -23.46223683 ], [ 151.60917525, -24.0762562 ], [ 152.07353967, -24.45788665 ], [ 152.85519738, -25.26750132 ], [ 153.13616214, -26.07117319 ], [ 153.16194868, -26.64131927 ], [ 153.09290897, -27.26029957 ], [ 153.56946903, -28.11006683 ], [ 153.51210819, -28.99507741 ], [ 153.33909549, -29.45820159 ], [ 153.06924116, -30.35024017 ], [ 153.08960168, -30.92364186 ], [ 152.89157759, -31.64044565 ], [ 152.45000248, -32.55000254 ], [ 151.70911747, -33.04134205 ], [ 151.3439718, -33.81602345 ], [ 151.01055545, -34.3103602 ], [ 150.71413944, -35.17345997 ], [ 150.32821984, -35.67187916 ], [ 150.07521203, -36.42020558 ], [ 149.9461243, -37.10905242 ], [ 149.99728397, -37.42526051 ], [ 149.42388228, -37.77268117 ], [ 148.30462243, -37.80906137 ], [ 147.38173303, -38.21921722 ], [ 146.92212284, -38.60653208 ], [ 146.31792199, -39.03575652 ], [ 145.48965213, -38.593768 ], [ 144.87697635, -38.41744801 ], [ 145.03221236, -37.89618784 ], [ 144.48568241, -38.08532358 ], [ 143.60997359, -38.80946543 ], [ 142.74542687, -38.53826751 ], [ 142.17832971, -38.38003428 ], [ 141.60658166, -38.30851409 ], [ 140.63857873, -38.01933278 ], [ 139.99215824, -37.40293629 ], [ 139.80658817, -36.6436028 ], [ 139.57414758, -36.13836232 ], [ 139.08280806, -35.732754 ], [ 138.12074792, -35.61229624 ], [ 138.4494617, -35.12726124 ], [ 138.20756433, -34.38472259 ], [ 137.71917036, -35.07682505 ], [ 136.82940555, -35.26053476 ], [ 137.35237105, -34.70733856 ], [ 137.50388635, -34.13026784 ], [ 137.890116, -33.64047861 ], [ 137.81032759, -32.90000701 ], [ 136.99683719, -33.7527715 ], [ 136.37206913, -34.09476613 ], [ 135.98904341, -34.8901181 ], [ 135.20821252, -34.47867034 ], [ 135.23921838, -33.94795338 ], [ 134.61341678, -33.22277801 ], [ 134.08590376, -32.8480722 ], [ 134.27390262, -32.61723358 ], [ 132.99077681, -32.01122405 ], [ 132.28808068, -31.98264699 ], [ 131.3263306, -31.49580332 ], [ 129.5357939, -31.59042287 ], [ 128.24093753, -31.94848886 ], [ 127.10286747, -32.28226694 ], [ 126.14871382, -32.21596608 ], [ 125.08862349, -32.72875132 ], [ 124.22164798, -32.95948659 ], [ 124.02894657, -33.48384734 ], [ 123.65966678, -33.89017913 ], [ 122.81103641, -33.91446705 ], [ 122.18306441, -34.00340219 ], [ 121.29919071, -33.82103607 ], [ 120.58026818, -33.93017669 ], [ 119.8936951, -33.97606536 ], [ 119.29889937, -34.50936614 ], [ 119.00734094, -34.46414927 ], [ 118.50571781, -34.74681935 ], [ 118.02497196, -35.06473276 ], [ 117.29550744, -35.02545867 ], [ 116.62510908, -35.02509694 ], [ 115.56434696, -34.38642791 ], [ 115.02680871, -34.19651702 ], [ 115.04861616, -33.62342539 ], [ 115.54512333, -33.48725799 ], [ 115.7146737, -33.25957163 ], [ 115.6793787, -32.90036875 ], [ 115.80164514, -32.20506235 ], [ 115.68961063, -31.61243703 ], [ 115.16090905, -30.60159433 ], [ 114.99704308, -30.03072479 ], [ 115.04003788, -29.46109547 ], [ 114.64197432, -28.81023081 ], [ 114.61649784, -28.51639861 ], [ 114.17357914, -28.11807667 ], [ 114.04888391, -27.33476531 ], [ 113.47749759, -26.54313405 ], [ 113.33895308, -26.1165451 ], [ 113.77835778, -26.54902516 ], [ 113.44096236, -25.62127817 ], [ 113.93690108, -25.91123463 ], [ 114.232852, -26.29844614 ], [ 114.21616052, -25.78628102 ], [ 113.72125532, -24.9989389 ], [ 113.62534387, -24.68397104 ], [ 113.39352339, -24.3847645 ], [ 113.5020439, -23.80635019 ], [ 113.70699263, -23.56021535 ], [ 113.84341841, -23.05998748 ], [ 113.73655155, -22.47547536 ], [ 114.1497563, -21.75588104 ], [ 114.22530724, -22.5174883 ], [ 114.64776208, -21.82951995 ], [ 115.46016727, -21.49517344 ], [ 115.94737267, -21.06868784 ], [ 116.71161543, -20.70168182 ], [ 117.16631636, -20.62359873 ], [ 117.44154504, -20.7468987 ], [ 118.22955895, -20.37420827 ], [ 118.83608524, -20.26331064 ], [ 118.98780724, -20.04420257 ], [ 119.25249393, -19.95294199 ], [ 119.80522505, -19.97650644 ], [ 120.85622033, -19.68370778 ], [ 121.3998564, -19.23975555 ], [ 121.65513797, -18.70531789 ], [ 122.24166548, -18.19764861 ], [ 122.28662398, -17.7986032 ], [ 122.31277225, -17.25496714 ], [ 123.0125745, -16.40519988 ], [ 123.4337891, -17.26855804 ], [ 123.85934452, -17.06903533 ], [ 123.50324222, -16.59650604 ], [ 123.8170732, -16.11131601 ], [ 124.25828657, -16.32794362 ], [ 124.37972619, -15.56705983 ], [ 124.92615279, -15.07510019 ], [ 125.16727502, -14.6803956 ], [ 125.6700867, -14.51007008 ], [ 125.68579634, -14.23065561 ], [ 126.12514937, -14.347341 ], [ 126.14282271, -14.09598683 ], [ 126.58258915, -13.95279144 ], [ 127.06586714, -13.81796762 ], [ 127.80463342, -14.27690602 ], [ 128.35968998, -14.86916961 ], [ 128.98554325, -14.8759909 ], [ 129.62147342, -14.96978362 ], [ 129.40960005, -14.42066985 ], [ 129.88864058, -13.6187033 ], [ 130.33946577, -13.35737558 ], [ 130.1835063, -13.10752003 ], [ 130.61779504, -12.5363921 ], [ 131.2234945, -12.18364878 ], [ 131.73509118, -12.30245289 ], [ 132.57529829, -12.11404062 ], [ 132.55721154, -11.60301238 ], [ 131.82469811, -11.27378183 ], [ 132.35722375, -11.12851938 ], [ 133.01956058, -11.37641123 ], [ 133.55084598, -11.78651539 ], [ 134.39306848, -12.04236541 ], [ 134.67863244, -11.94118296 ], [ 135.29849125, -12.24860605 ], [ 135.88269331, -11.96226694 ], [ 136.25838098, -12.04934173 ], [ 136.49247521, -11.85720875 ], [ 136.95162031, -12.35195892 ], [ 136.68512495, -12.8872234 ], [ 136.30540653, -13.29122975 ], [ 135.96175825, -13.32450937 ], [ 136.07761682, -13.72427825 ], [ 135.7838363, -14.22398935 ], [ 135.42866418, -14.71543222 ], [ 135.50018436, -14.99774057 ], [ 136.2951746, -15.55026499 ], [ 137.06536014, -15.87076222 ], [ 137.58047082, -16.21508229 ], [ 138.3032174, -16.80760426 ], [ 138.58516402, -16.80662241 ], [ 139.10854292, -17.06267913 ], [ 139.26057499, -17.37160084 ], [ 140.2152454, -17.71080495 ], [ 140.8754635, -17.3690687 ], [ 141.07111047, -16.83204721 ], [ 141.27409549, -16.38887013 ], [ 141.39822228, -15.84053151 ], [ 141.70218306, -15.04492116 ], [ 141.56338016, -14.5613331 ], [ 141.63552046, -14.27039479 ], [ 141.51986861, -13.6980783 ], [ 141.65092004, -12.9446876 ], [ 141.84269128, -12.74154754 ], [ 141.68699019, -12.40761443 ], [ 141.92862919, -11.87746592 ], [ 142.1184884, -11.32804209 ], [ 142.1437065, -11.0427365 ], [ 142.51526004, -10.66818572 ], [ 142.79731001, -11.15735483 ], [ 142.86676314, -11.78470672 ], [ 143.11594689, -11.90562957 ], [ 143.15863163, -12.32565561 ], [ 143.52212365, -12.83435841 ], [ 143.59715783, -13.40042205 ], [ 143.56181115, -13.76365569 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Austria", "sov_a3": "AUT", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Austria", "adm0_a3": "AUT", "geou_dif": 0.000000, "geounit": "Austria", "gu_a3": "AUT", "su_dif": 0.000000, "subunit": "Austria", "su_a3": "AUT", "brk_diff": 0.000000, "name": "Austria", "name_long": "Austria", "brk_a3": "AUT", "brk_name": "Austria", "brk_group": null, "abbrev": "Aust.", "postal": "A", "formal_en": "Republic of Austria", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Austria", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 1.000000, "mapcolor9": 3.000000, "mapcolor13": 4.000000, "pop_est": 8210281.000000, "gdp_md_est": 329500.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "AT", "iso_a3": "AUT", "iso_n3": "040", "un_a3": "040", "wb_a2": "AT", "wb_a3": "AUT", "woe_id": -99.000000, "adm0_a3_is": "AUT", "adm0_a3_us": "AUT", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Western Europe", "region_wb": "Europe & Central Asia", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 16.96028812, 48.59698233 ], [ 16.87998294, 48.47001333 ], [ 16.97966678, 48.12349702 ], [ 16.9037541, 47.71486563 ], [ 16.34058434, 47.71290192 ], [ 16.53426761, 47.49617097 ], [ 16.20229821, 46.85238597 ], [ 16.01166385, 46.68361074 ], [ 15.13709191, 46.6587027 ], [ 14.63247155, 46.43181733 ], [ 13.80647546, 46.50930614 ], [ 12.37648522, 46.76755911 ], [ 12.15308801, 47.11539317 ], [ 11.16482792, 46.94157949 ], [ 11.04855594, 46.75135855 ], [ 10.44270145, 46.89354625 ], [ 9.93244836, 46.92072805 ], [ 9.47996952, 47.10280996 ], [ 9.63293176, 47.34760122 ], [ 9.59422611, 47.52505809 ], [ 9.89606815, 47.58019685 ], [ 10.40208377, 47.3024877 ], [ 10.54450402, 47.56639924 ], [ 11.42641402, 47.52376618 ], [ 12.14135746, 47.7030834 ], [ 12.62075972, 47.6723876 ], [ 12.93262699, 47.46764558 ], [ 13.02585127, 47.63758352 ], [ 12.88410282, 48.28914582 ], [ 13.24335737, 48.41611481 ], [ 13.59594567, 48.87717194 ], [ 14.33889774, 48.55530528 ], [ 14.90144738, 48.96440176 ], [ 15.25341556, 49.03907421 ], [ 16.02964725, 48.73389903 ], [ 16.49928267, 48.78580801 ], [ 16.96028812, 48.59698233 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Azerbaijan", "sov_a3": "AZE", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Azerbaijan", "adm0_a3": "AZE", "geou_dif": 0.000000, "geounit": "Azerbaijan", "gu_a3": "AZE", "su_dif": 0.000000, "subunit": "Azerbaijan", "su_a3": "AZE", "brk_diff": 0.000000, "name": "Azerbaijan", "name_long": "Azerbaijan", "brk_a3": "AZE", "brk_name": "Azerbaijan", "brk_group": null, "abbrev": "Aze.", "postal": "AZ", "formal_en": "Republic of Azerbaijan", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Azerbaijan", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 6.000000, "mapcolor9": 5.000000, "mapcolor13": 8.000000, "pop_est": 8238672.000000, "gdp_md_est": 77610.000000, "pop_year": -99.000000, "lastcensus": 2009.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "AZ", "iso_a3": "AZE", "iso_n3": "031", "un_a3": "031", "wb_a2": "AZ", "wb_a3": "AZE", "woe_id": -99.000000, "adm0_a3_is": "AZE", "adm0_a3_us": "AZE", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Western Asia", "region_wb": "Europe & Central Asia", "name_len": 10.000000, "long_len": 10.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 45.00198734, 39.74000357 ], [ 45.29814497, 39.47175121 ], [ 45.73997847, 39.47399913 ], [ 45.73537927, 39.31971914 ], [ 46.14362308, 38.74120148 ], [ 45.4577218, 38.87413911 ], [ 44.95268802, 39.33576468 ], [ 44.7939897, 39.71300263 ], [ 45.00198734, 39.74000357 ] ] ], [ [ [ 47.37331546, 41.21973237 ], [ 47.81566572, 41.15141612 ], [ 47.98728316, 41.4058192 ], [ 48.58435265, 41.80886953 ], [ 48.5843534, 41.80886879 ], [ 49.11026371, 41.28228669 ], [ 49.61891483, 40.5729243 ], [ 50.08482954, 40.52615713 ], [ 50.39282108, 40.25656118 ], [ 49.5692021, 40.17610098 ], [ 49.39525923, 39.39948172 ], [ 49.22322839, 39.04921886 ], [ 48.85653242, 38.81548636 ], [ 48.88324914, 38.32024527 ], [ 48.63437544, 38.27037751 ], [ 48.01074426, 38.7940148 ], [ 48.35552941, 39.28876496 ], [ 48.06009525, 39.58223542 ], [ 47.68507938, 39.50836396 ], [ 46.50571984, 38.77060537 ], [ 46.48349898, 39.46415477 ], [ 46.03453413, 39.62802074 ], [ 45.61001224, 39.8999938 ], [ 45.89190718, 40.21847565 ], [ 45.35917484, 40.56150381 ], [ 45.56035119, 40.81228954 ], [ 45.17949588, 40.98535391 ], [ 44.9724801, 41.24812857 ], [ 45.21742639, 41.41145193 ], [ 45.96260054, 41.12387259 ], [ 46.5016374, 41.06444469 ], [ 46.63790816, 41.18167268 ], [ 46.14543176, 41.72280244 ], [ 46.4049508, 41.86067516 ], [ 46.68607059, 41.82713715 ], [ 47.37331546, 41.21973237 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Burundi", "sov_a3": "BDI", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Burundi", "adm0_a3": "BDI", "geou_dif": 0.000000, "geounit": "Burundi", "gu_a3": "BDI", "su_dif": 0.000000, "subunit": "Burundi", "su_a3": "BDI", "brk_diff": 0.000000, "name": "Burundi", "name_long": "Burundi", "brk_a3": "BDI", "brk_name": "Burundi", "brk_group": null, "abbrev": "Bur.", "postal": "BI", "formal_en": "Republic of Burundi", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Burundi", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 2.000000, "mapcolor9": 5.000000, "mapcolor13": 8.000000, "pop_est": 8988091.000000, "gdp_md_est": 3102.000000, "pop_year": -99.000000, "lastcensus": 2008.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "BI", "iso_a3": "BDI", "iso_n3": "108", "un_a3": "108", "wb_a2": "BI", "wb_a3": "BDI", "woe_id": -99.000000, "adm0_a3_is": "BDI", "adm0_a3_us": "BDI", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Eastern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 30.52767704, -2.80763193 ], [ 30.74301273, -3.03428476 ], [ 30.75226281, -3.35932952 ], [ 30.50555952, -3.5685674 ], [ 30.11633264, -4.09013763 ], [ 29.7535124, -4.45238942 ], [ 29.6476907, -4.4645691 ], [ 29.65258833, -4.42014332 ], [ 29.28552136, -3.4671476 ], [ 29.2763839, -3.29390716 ], [ 29.02492639, -2.83925791 ], [ 29.63217614, -2.91785776 ], [ 29.938359, -2.34848683 ], [ 30.46967365, -2.41385476 ], [ 30.46969608, -2.41385752 ], [ 30.52767704, -2.80763193 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Belgium", "sov_a3": "BEL", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Belgium", "adm0_a3": "BEL", "geou_dif": 0.000000, "geounit": "Belgium", "gu_a3": "BEL", "su_dif": 0.000000, "subunit": "Belgium", "su_a3": "BEL", "brk_diff": 0.000000, "name": "Belgium", "name_long": "Belgium", "brk_a3": "BEL", "brk_name": "Belgium", "brk_group": null, "abbrev": "Belg.", "postal": "B", "formal_en": "Kingdom of Belgium", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Belgium", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 2.000000, "mapcolor9": 1.000000, "mapcolor13": 8.000000, "pop_est": 10414336.000000, "gdp_md_est": 389300.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "BE", "iso_a3": "BEL", "iso_n3": "056", "un_a3": "056", "wb_a2": "BE", "wb_a3": "BEL", "woe_id": -99.000000, "adm0_a3_is": "BEL", "adm0_a3_us": "BEL", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Western Europe", "region_wb": "Europe & Central Asia", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 4.97399133, 51.47502371 ], [ 5.60697595, 51.03729849 ], [ 6.15665816, 50.80372102 ], [ 6.04307336, 50.12805166 ], [ 5.78241743, 50.09032787 ], [ 5.67405195, 49.52948355 ], [ 4.79922163, 49.98537303 ], [ 4.28602298, 49.90749665 ], [ 3.58818444, 50.37899242 ], [ 3.12325158, 50.78036327 ], [ 2.65842207, 50.79684805 ], [ 2.51357303, 51.14850617 ], [ 3.31497114, 51.34578095 ], [ 3.31501148, 51.34577662 ], [ 4.04707116, 51.26725861 ], [ 4.97399133, 51.47502371 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Benin", "sov_a3": "BEN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Benin", "adm0_a3": "BEN", "geou_dif": 0.000000, "geounit": "Benin", "gu_a3": "BEN", "su_dif": 0.000000, "subunit": "Benin", "su_a3": "BEN", "brk_diff": 0.000000, "name": "Benin", "name_long": "Benin", "brk_a3": "BEN", "brk_name": "Benin", "brk_group": null, "abbrev": "Benin", "postal": "BJ", "formal_en": "Republic of Benin", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Benin", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 2.000000, "mapcolor9": 2.000000, "mapcolor13": 12.000000, "pop_est": 8791832.000000, "gdp_md_est": 12830.000000, "pop_year": -99.000000, "lastcensus": 2002.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "BJ", "iso_a3": "BEN", "iso_n3": "204", "un_a3": "204", "wb_a2": "BJ", "wb_a3": "BEN", "woe_id": -99.000000, "adm0_a3_is": "BEN", "adm0_a3_us": "BEN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Western Africa", "region_wb": "Sub-Saharan Africa", "name_len": 5.000000, "long_len": 5.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 3.61118045, 11.66016714 ], [ 3.57221642, 11.32793936 ], [ 3.79711226, 10.73474559 ], [ 3.60007002, 10.33218618 ], [ 3.70543827, 10.06321035 ], [ 3.2203516, 9.44415253 ], [ 2.91230838, 9.13760794 ], [ 2.72379276, 8.5068454 ], [ 2.74906253, 7.87073436 ], [ 2.69170169, 6.25881725 ], [ 1.86524051, 6.1421577 ], [ 1.61895064, 6.83203807 ], [ 1.66447757, 9.1285904 ], [ 1.46304284, 9.33462434 ], [ 1.42506066, 9.82539541 ], [ 1.07779504, 10.17560659 ], [ 0.77233565, 10.47080821 ], [ 0.89956302, 10.99733938 ], [ 1.24346968, 11.11051077 ], [ 1.44717818, 11.54771922 ], [ 1.93598555, 11.64115021 ], [ 2.1544735, 11.94015005 ], [ 2.49016361, 12.23305207 ], [ 2.84864302, 12.23563589 ], [ 3.61118045, 11.66016714 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Burkina Faso", "sov_a3": "BFA", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Burkina Faso", "adm0_a3": "BFA", "geou_dif": 0.000000, "geounit": "Burkina Faso", "gu_a3": "BFA", "su_dif": 0.000000, "subunit": "Burkina Faso", "su_a3": "BFA", "brk_diff": 0.000000, "name": "Burkina Faso", "name_long": "Burkina Faso", "brk_a3": "BFA", "brk_name": "Burkina Faso", "brk_group": null, "abbrev": "B.F.", "postal": "BF", "formal_en": "Burkina Faso", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Burkina Faso", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 1.000000, "mapcolor9": 5.000000, "mapcolor13": 11.000000, "pop_est": 15746232.000000, "gdp_md_est": 17820.000000, "pop_year": -99.000000, "lastcensus": 2006.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "BF", "iso_a3": "BFA", "iso_n3": "854", "un_a3": "854", "wb_a2": "BF", "wb_a3": "BFA", "woe_id": -99.000000, "adm0_a3_is": "BFA", "adm0_a3_us": "BFA", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Western Africa", "region_wb": "Sub-Saharan Africa", "name_len": 12.000000, "long_len": 12.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 0.37489221, 14.92890819 ], [ 0.2956464, 14.44423493 ], [ 0.42992761, 13.98873302 ], [ 0.99304569, 13.33574962 ], [ 1.02410322, 12.85182567 ], [ 2.17710778, 12.62501781 ], [ 2.1544735, 11.94015005 ], [ 1.93598555, 11.64115021 ], [ 1.44717818, 11.54771922 ], [ 1.24346968, 11.11051077 ], [ 0.89956302, 10.99733938 ], [ 0.02380252, 11.01868175 ], [ -0.43870154, 11.09834097 ], [ -0.76157589, 10.93692963 ], [ -1.20335771, 11.00981924 ], [ -2.94040931, 10.96269033 ], [ -2.96389625, 10.39533478 ], [ -2.8274963, 9.64246084 ], [ -3.51189897, 9.90032624 ], [ -3.98044918, 9.86234406 ], [ -4.33024695, 9.61083487 ], [ -4.77988359, 9.82198477 ], [ -4.95465329, 10.15271393 ], [ -5.4043416, 10.3707368 ], [ -5.47056495, 10.95126984 ], [ -5.19784258, 11.37514578 ], [ -5.22094194, 11.71385895 ], [ -4.4271661, 12.54264558 ], [ -4.28040504, 13.22844351 ], [ -4.00639075, 13.47248546 ], [ -3.5228027, 13.33766165 ], [ -3.10370683, 13.54126679 ], [ -2.96769446, 13.79815034 ], [ -2.19182451, 14.24641755 ], [ -2.00103512, 14.55900829 ], [ -1.06636349, 14.97381501 ], [ -0.51585446, 15.11615774 ], [ -0.26625729, 14.92430899 ], [ 0.37489221, 14.92890819 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Bangladesh", "sov_a3": "BGD", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Bangladesh", "adm0_a3": "BGD", "geou_dif": 0.000000, "geounit": "Bangladesh", "gu_a3": "BGD", "su_dif": 0.000000, "subunit": "Bangladesh", "su_a3": "BGD", "brk_diff": 0.000000, "name": "Bangladesh", "name_long": "Bangladesh", "brk_a3": "BGD", "brk_name": "Bangladesh", "brk_group": null, "abbrev": "Bang.", "postal": "BD", "formal_en": "People's Republic of Bangladesh", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Bangladesh", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 4.000000, "mapcolor9": 7.000000, "mapcolor13": 7.000000, "pop_est": 156050883.000000, "gdp_md_est": 224000.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "BD", "iso_a3": "BGD", "iso_n3": "050", "un_a3": "050", "wb_a2": "BD", "wb_a3": "BGD", "woe_id": -99.000000, "adm0_a3_is": "BGD", "adm0_a3_us": "BGD", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Southern Asia", "region_wb": "South Asia", "name_len": 10.000000, "long_len": 10.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 92.67272098, 22.04123892 ], [ 92.65225711, 21.32404755 ], [ 92.30323449, 21.47548534 ], [ 92.3685535, 20.67088329 ], [ 92.08288618, 21.19219514 ], [ 92.02521529, 21.70156973 ], [ 91.83489099, 22.1829357 ], [ 91.41708703, 22.76501903 ], [ 90.4960063, 22.80501659 ], [ 90.58695682, 22.39279369 ], [ 90.27297082, 21.8363677 ], [ 89.84746708, 22.03914602 ], [ 89.7020496, 21.85711579 ], [ 89.41886275, 21.9661789 ], [ 89.0319613, 22.05570832 ], [ 88.87631188, 22.87914643 ], [ 88.52976973, 23.63114187 ], [ 88.69994022, 24.23371491 ], [ 88.08442224, 24.50165721 ], [ 88.30637251, 24.86607941 ], [ 88.93155399, 25.23869233 ], [ 88.20978926, 25.7680657 ], [ 88.56304935, 26.44652558 ], [ 89.35509403, 26.01440725 ], [ 89.83248091, 25.9650821 ], [ 89.92069258, 25.26974986 ], [ 90.87221073, 25.13260061 ], [ 91.79959598, 25.14743175 ], [ 92.37620161, 24.97669282 ], [ 91.91509281, 24.13041372 ], [ 91.46772993, 24.07263947 ], [ 91.15896325, 23.50352692 ], [ 91.70647505, 22.98526398 ], [ 91.86992761, 23.62434642 ], [ 92.14603478, 23.62749868 ], [ 92.67272098, 22.04123892 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Bulgaria", "sov_a3": "BGR", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Bulgaria", "adm0_a3": "BGR", "geou_dif": 0.000000, "geounit": "Bulgaria", "gu_a3": "BGR", "su_dif": 0.000000, "subunit": "Bulgaria", "su_a3": "BGR", "brk_diff": 0.000000, "name": "Bulgaria", "name_long": "Bulgaria", "brk_a3": "BGR", "brk_name": "Bulgaria", "brk_group": null, "abbrev": "Bulg.", "postal": "BG", "formal_en": "Republic of Bulgaria", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Bulgaria", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 5.000000, "mapcolor9": 1.000000, "mapcolor13": 8.000000, "pop_est": 7204687.000000, "gdp_md_est": 93750.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "BG", "iso_a3": "BGR", "iso_n3": "100", "un_a3": "100", "wb_a2": "BG", "wb_a3": "BGR", "woe_id": -99.000000, "adm0_a3_is": "BGR", "adm0_a3_us": "BGR", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Eastern Europe", "region_wb": "Europe & Central Asia", "name_len": 8.000000, "long_len": 8.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 28.5580815, 43.70746166 ], [ 28.03909509, 43.2931717 ], [ 27.67389774, 42.57789236 ], [ 27.99672041, 42.00735871 ], [ 27.13573937, 42.14148489 ], [ 26.11704186, 41.82690461 ], [ 26.10613814, 41.32889883 ], [ 25.19720137, 41.23448599 ], [ 24.49264489, 41.58389619 ], [ 23.6920736, 41.30908092 ], [ 22.95237715, 41.33799388 ], [ 22.88137373, 41.99929719 ], [ 22.38052575, 42.32025951 ], [ 22.54501183, 42.46136201 ], [ 22.43659468, 42.58032115 ], [ 22.60480147, 42.89851879 ], [ 22.98601851, 43.2111612 ], [ 22.50015669, 43.64281444 ], [ 22.4104464, 44.00806346 ], [ 22.65714969, 44.234923 ], [ 22.94483239, 43.82378531 ], [ 23.33230228, 43.89701081 ], [ 24.10067915, 43.74105134 ], [ 25.56927168, 43.68844473 ], [ 26.06515873, 43.94349376 ], [ 27.24239953, 44.17598603 ], [ 27.97010705, 43.81246817 ], [ 28.5580815, 43.70746166 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "The Bahamas", "sov_a3": "BHS", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "The Bahamas", "adm0_a3": "BHS", "geou_dif": 0.000000, "geounit": "The Bahamas", "gu_a3": "BHS", "su_dif": 0.000000, "subunit": "The Bahamas", "su_a3": "BHS", "brk_diff": 0.000000, "name": "Bahamas", "name_long": "Bahamas", "brk_a3": "BHS", "brk_name": "Bahamas", "brk_group": null, "abbrev": "Bhs.", "postal": "BS", "formal_en": "Commonwealth of the Bahamas", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Bahamas, The", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 1.000000, "mapcolor9": 2.000000, "mapcolor13": 5.000000, "pop_est": 309156.000000, "gdp_md_est": 9093.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "2. High income: nonOECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "BS", "iso_a3": "BHS", "iso_n3": "044", "un_a3": "044", "wb_a2": "BS", "wb_a3": "BHS", "woe_id": -99.000000, "adm0_a3_is": "BHS", "adm0_a3_us": "BHS", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "North America", "region_un": "Americas", "subregion": "Caribbean", "region_wb": "Latin America & Caribbean", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -77.53466, 23.75975 ], [ -77.78, 23.71 ], [ -78.03405, 24.28615 ], [ -78.40848, 24.57564 ], [ -78.19087, 25.2103 ], [ -77.89, 25.17 ], [ -77.54, 24.34 ], [ -77.53466, 23.75975 ] ] ], [ [ [ -77.82, 26.58 ], [ -78.91, 26.42 ], [ -78.98, 26.79 ], [ -78.51, 26.87 ], [ -77.85, 26.84 ], [ -77.82, 26.58 ] ] ], [ [ [ -77.0, 26.59 ], [ -77.17255, 25.87918 ], [ -77.35641, 26.00735 ], [ -77.34, 26.53 ], [ -77.78802, 26.92516 ], [ -77.79, 27.04 ], [ -77.0, 26.59 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Bosnia and Herzegovina", "sov_a3": "BIH", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Bosnia and Herzegovina", "adm0_a3": "BIH", "geou_dif": 0.000000, "geounit": "Bosnia and Herzegovina", "gu_a3": "BIH", "su_dif": 0.000000, "subunit": "Bosnia and Herzegovina", "su_a3": "BIH", "brk_diff": 0.000000, "name": "Bosnia and Herz.", "name_long": "Bosnia and Herzegovina", "brk_a3": "BIH", "brk_name": "Bosnia and Herz.", "brk_group": null, "abbrev": "B.H.", "postal": "BiH", "formal_en": "Bosnia and Herzegovina", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Bosnia and Herzegovina", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 1.000000, "mapcolor9": 1.000000, "mapcolor13": 2.000000, "pop_est": 4613414.000000, "gdp_md_est": 29700.000000, "pop_year": -99.000000, "lastcensus": 1991.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "BA", "iso_a3": "BIH", "iso_n3": "070", "un_a3": "070", "wb_a2": "BA", "wb_a3": "BIH", "woe_id": -99.000000, "adm0_a3_is": "BIH", "adm0_a3_us": "BIH", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Southern Europe", "region_wb": "Europe & Central Asia", "name_len": 16.000000, "long_len": 22.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 17.00214603, 45.23377676 ], [ 17.86178348, 45.06774038 ], [ 18.55321415, 45.08158967 ], [ 19.0054846, 44.86023449 ], [ 19.00548628, 44.86023367 ], [ 19.36803, 44.863 ], [ 19.11761, 44.42307 ], [ 19.59976, 44.03847 ], [ 19.454, 43.5681 ], [ 19.21852, 43.52384 ], [ 19.03165, 43.43253 ], [ 18.70648, 43.20011 ], [ 18.56, 42.65 ], [ 17.6749215, 43.02856253 ], [ 17.29737349, 43.44634064 ], [ 16.91615645, 43.66772248 ], [ 16.45644291, 44.04123973 ], [ 16.23966027, 44.3511433 ], [ 15.75002608, 44.81871166 ], [ 15.9593673, 45.23377676 ], [ 16.31815677, 45.0041267 ], [ 16.53493941, 45.21160757 ], [ 17.00214603, 45.23377676 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Belarus", "sov_a3": "BLR", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Belarus", "adm0_a3": "BLR", "geou_dif": 0.000000, "geounit": "Belarus", "gu_a3": "BLR", "su_dif": 0.000000, "subunit": "Belarus", "su_a3": "BLR", "brk_diff": 0.000000, "name": "Belarus", "name_long": "Belarus", "brk_a3": "BLR", "brk_name": "Belarus", "brk_group": null, "abbrev": "Bela.", "postal": "BY", "formal_en": "Republic of Belarus", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Belarus", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 1.000000, "mapcolor9": 5.000000, "mapcolor13": 11.000000, "pop_est": 9648533.000000, "gdp_md_est": 114100.000000, "pop_year": -99.000000, "lastcensus": 2009.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "BY", "iso_a3": "BLR", "iso_n3": "112", "un_a3": "112", "wb_a2": "BY", "wb_a3": "BLR", "woe_id": -99.000000, "adm0_a3_is": "BLR", "adm0_a3_us": "BLR", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Eastern Europe", "region_wb": "Europe & Central Asia", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 29.22951338, 55.91834422 ], [ 29.37157189, 55.67009064 ], [ 29.89629439, 55.7894632 ], [ 30.87390913, 55.55097647 ], [ 30.97183597, 55.08154776 ], [ 30.75753381, 54.81177094 ], [ 31.38447228, 54.15705638 ], [ 31.79142419, 53.97463858 ], [ 31.73127282, 53.79402945 ], [ 32.40559859, 53.61804536 ], [ 32.69364302, 53.3514208 ], [ 32.30451948, 53.13272614 ], [ 31.49764367, 53.16742687 ], [ 31.30520064, 53.07399588 ], [ 31.54001834, 52.74205231 ], [ 31.78599816, 52.10167796 ], [ 31.78599245, 52.10167757 ], [ 30.92754927, 52.04235342 ], [ 30.61945438, 51.8228061 ], [ 30.55511722, 51.31950349 ], [ 30.15736372, 51.41613841 ], [ 29.25493819, 51.36823436 ], [ 28.99283532, 51.60204438 ], [ 28.61761275, 51.42771393 ], [ 28.24161502, 51.57222708 ], [ 27.4540662, 51.59230337 ], [ 26.33795861, 51.83228872 ], [ 25.32778771, 51.91065603 ], [ 24.55310632, 51.88846101 ], [ 24.00507775, 51.61744396 ], [ 23.52707075, 51.57845409 ], [ 23.50800215, 52.02364655 ], [ 23.19949385, 52.48697744 ], [ 23.79919885, 52.69109935 ], [ 23.80493493, 53.08973135 ], [ 23.52753584, 53.47012157 ], [ 23.48412764, 53.91249767 ], [ 24.45068363, 53.90570222 ], [ 25.53635379, 54.28242341 ], [ 25.76843265, 54.84696259 ], [ 26.58827925, 55.1671756 ], [ 26.4943315, 55.61510692 ], [ 27.10245975, 55.78331371 ], [ 28.17670943, 56.16912995 ], [ 29.22951338, 55.91834422 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Belize", "sov_a3": "BLZ", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Belize", "adm0_a3": "BLZ", "geou_dif": 0.000000, "geounit": "Belize", "gu_a3": "BLZ", "su_dif": 0.000000, "subunit": "Belize", "su_a3": "BLZ", "brk_diff": 0.000000, "name": "Belize", "name_long": "Belize", "brk_a3": "BLZ", "brk_name": "Belize", "brk_group": null, "abbrev": "Belize", "postal": "BZ", "formal_en": "Belize", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Belize", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 4.000000, "mapcolor9": 5.000000, "mapcolor13": 7.000000, "pop_est": 307899.000000, "gdp_md_est": 2536.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "BZ", "iso_a3": "BLZ", "iso_n3": "084", "un_a3": "084", "wb_a2": "BZ", "wb_a3": "BLZ", "woe_id": -99.000000, "adm0_a3_is": "BLZ", "adm0_a3_us": "BLZ", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "North America", "region_un": "Americas", "subregion": "Central America", "region_wb": "Latin America & Caribbean", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -88.93061276, 15.88727346 ], [ -89.22912167, 15.88693757 ], [ -89.15080604, 17.01557669 ], [ -89.14308041, 17.808319 ], [ -89.15090939, 17.95546764 ], [ -89.02985735, 18.00151134 ], [ -88.84834388, 17.88319815 ], [ -88.49012285, 18.48683055 ], [ -88.30003109, 18.4999822 ], [ -88.29633623, 18.35327281 ], [ -88.10681291, 18.34867361 ], [ -88.12347856, 18.07667471 ], [ -88.28535499, 17.64414297 ], [ -88.19786679, 17.48947541 ], [ -88.30264075, 17.13169363 ], [ -88.23951799, 17.03606639 ], [ -88.35542823, 16.53077424 ], [ -88.55182451, 16.26546743 ], [ -88.73243364, 16.23363475 ], [ -88.93061276, 15.88727346 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Bolivia", "sov_a3": "BOL", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Bolivia", "adm0_a3": "BOL", "geou_dif": 0.000000, "geounit": "Bolivia", "gu_a3": "BOL", "su_dif": 0.000000, "subunit": "Bolivia", "su_a3": "BOL", "brk_diff": 0.000000, "name": "Bolivia", "name_long": "Bolivia", "brk_a3": "BOL", "brk_name": "Bolivia", "brk_group": null, "abbrev": "Bolivia", "postal": "BO", "formal_en": "Plurinational State of Bolivia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Bolivia", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 5.000000, "mapcolor9": 2.000000, "mapcolor13": 3.000000, "pop_est": 9775246.000000, "gdp_md_est": 43270.000000, "pop_year": -99.000000, "lastcensus": 2001.000000, "gdp_year": -99.000000, "economy": "5. Emerging region: G20", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "BO", "iso_a3": "BOL", "iso_n3": "068", "un_a3": "068", "wb_a2": "BO", "wb_a3": "BOL", "woe_id": -99.000000, "adm0_a3_is": "BOL", "adm0_a3_us": "BOL", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "South America", "region_un": "Americas", "subregion": "South America", "region_wb": "Latin America & Caribbean", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 7.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -58.16639238, -20.17670094 ], [ -58.18347144, -19.86839935 ], [ -59.11504249, -19.35690602 ], [ -60.04356462, -19.34274668 ], [ -61.78632646, -19.63373667 ], [ -62.26596127, -20.51373463 ], [ -62.29117937, -21.05163462 ], [ -62.68505714, -22.24902923 ], [ -62.84646847, -22.03498545 ], [ -63.98683814, -21.9936443 ], [ -64.37702104, -22.79809132 ], [ -64.96489214, -22.0758615 ], [ -66.2733394, -21.83231048 ], [ -67.10667355, -22.73592457 ], [ -67.8281799, -22.8729188 ], [ -68.21991309, -21.49434661 ], [ -68.75716712, -20.37265797 ], [ -68.4422251, -19.40506845 ], [ -68.96681841, -18.98168344 ], [ -69.10024696, -18.26012542 ], [ -69.59042375, -17.5800119 ], [ -68.95963538, -16.50069793 ], [ -69.38976417, -15.66012908 ], [ -69.16034665, -15.32397389 ], [ -69.33953467, -14.95319549 ], [ -68.94888668, -14.45363942 ], [ -68.9292238, -13.60268361 ], [ -68.88007952, -12.8997291 ], [ -68.66507972, -12.56130014 ], [ -69.52967811, -10.95173431 ], [ -68.7861576, -11.0363803 ], [ -68.27125363, -11.01452117 ], [ -68.04819231, -10.71205901 ], [ -67.17380124, -10.30681243 ], [ -66.64690833, -9.93133148 ], [ -65.33843523, -9.76198781 ], [ -65.444837, -10.5114511 ], [ -65.32189877, -10.89587208 ], [ -65.40228146, -11.56627044 ], [ -64.31635291, -12.46197804 ], [ -63.19649879, -12.62703257 ], [ -62.80306027, -13.00065317 ], [ -62.12708086, -13.19878061 ], [ -61.71320431, -13.48920216 ], [ -61.08412126, -13.47938364 ], [ -60.503304, -13.77595469 ], [ -60.45919817, -14.35400726 ], [ -60.26432634, -14.6459791 ], [ -60.25114885, -15.07721893 ], [ -60.54296566, -15.09391041 ], [ -60.15838966, -16.25828379 ], [ -58.24121986, -16.29957326 ], [ -58.38805844, -16.87710906 ], [ -58.280804, -17.2717103 ], [ -57.73455827, -17.55246836 ], [ -57.49837114, -18.17418751 ], [ -57.67600888, -18.96183969 ], [ -57.94999732, -19.40000416 ], [ -57.85380164, -19.96999521 ], [ -58.16639238, -20.17670094 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Brazil", "sov_a3": "BRA", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Brazil", "adm0_a3": "BRA", "geou_dif": 0.000000, "geounit": "Brazil", "gu_a3": "BRA", "su_dif": 0.000000, "subunit": "Brazil", "su_a3": "BRA", "brk_diff": 0.000000, "name": "Brazil", "name_long": "Brazil", "brk_a3": "BRA", "brk_name": "Brazil", "brk_group": null, "abbrev": "Brazil", "postal": "BR", "formal_en": "Federative Republic of Brazil", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Brazil", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 6.000000, "mapcolor9": 5.000000, "mapcolor13": 7.000000, "pop_est": 198739269.000000, "gdp_md_est": 1993000.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "3. Emerging region: BRIC", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "BR", "iso_a3": "BRA", "iso_n3": "076", "un_a3": "076", "wb_a2": "BR", "wb_a3": "BRA", "woe_id": -99.000000, "adm0_a3_is": "BRA", "adm0_a3_us": "BRA", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "South America", "region_un": "Americas", "subregion": "South America", "region_wb": "Latin America & Caribbean", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -56.53938575, 1.89952261 ], [ -55.995698, 1.81766714 ], [ -55.90560015, 2.02199575 ], [ -56.07334184, 2.22079499 ], [ -55.97332211, 2.51036388 ], [ -55.56975501, 2.42150625 ], [ -55.09758745, 2.52374807 ], [ -54.5247542, 2.31184886 ], [ -54.08806251, 2.10555655 ], [ -53.77852068, 2.37670279 ], [ -53.55483924, 2.33489655 ], [ -53.41846514, 2.05338919 ], [ -52.93965715, 2.12485769 ], [ -52.55642473, 2.50470531 ], [ -52.24933753, 3.24109447 ], [ -51.65779741, 4.15623241 ], [ -51.31714637, 4.20349051 ], [ -51.06977129, 3.65039765 ], [ -50.50887529, 1.90156383 ], [ -49.97407589, 1.73648347 ], [ -49.9471008, 1.04618968 ], [ -50.69925127, 0.22298412 ], [ -50.38821082, -0.07844451 ], [ -48.62056678, -0.23548919 ], [ -48.58449663, -1.23780527 ], [ -47.82495643, -0.58161793 ], [ -46.56658362, -0.94102752 ], [ -44.90570309, -1.5517396 ], [ -44.41761919, -2.13775034 ], [ -44.58158851, -2.69130828 ], [ -43.41879127, -2.38311004 ], [ -41.47265683, -2.91201832 ], [ -39.97866533, -2.87305429 ], [ -38.50038347, -3.70065236 ], [ -37.22325212, -4.82094573 ], [ -36.45293738, -5.10940358 ], [ -35.59779578, -5.14950449 ], [ -35.23538896, -5.46493743 ], [ -34.89602983, -6.73819305 ], [ -34.72999346, -7.34322072 ], [ -35.12821204, -8.99640146 ], [ -35.63696652, -9.64928151 ], [ -37.04651872, -11.04072112 ], [ -37.68361162, -12.17119476 ], [ -38.42387651, -13.03811858 ], [ -38.67388709, -13.05765228 ], [ -38.95327572, -13.79336964 ], [ -38.88229814, -15.66705372 ], [ -39.1610925, -17.20840667 ], [ -39.26733924, -17.86774627 ], [ -39.58352149, -18.26229583 ], [ -39.76082333, -19.59911346 ], [ -40.77474077, -20.90451181 ], [ -40.94475623, -21.93731699 ], [ -41.75416419, -22.37067555 ], [ -41.98828427, -22.97007049 ], [ -43.07470374, -22.96769337 ], [ -44.64781186, -23.35195932 ], [ -45.35213579, -23.79684173 ], [ -46.47209327, -24.0889686 ], [ -47.64897234, -24.88519907 ], [ -48.49545814, -25.87702483 ], [ -48.64100481, -26.62369761 ], [ -48.47473589, -27.17591196 ], [ -48.66152035, -28.18613454 ], [ -48.8884574, -28.67411509 ], [ -49.58732947, -29.22446909 ], [ -50.69687415, -30.98446502 ], [ -51.57622616, -31.77769826 ], [ -52.25608131, -32.24536997 ], [ -52.71209998, -33.19657806 ], [ -53.37366167, -33.76837778 ], [ -53.65054399, -33.20200408 ], [ -53.209589, -32.72766611 ], [ -53.78795163, -32.04724253 ], [ -54.57245154, -31.49451141 ], [ -55.60151018, -30.85387868 ], [ -55.97324459, -30.88307586 ], [ -56.97602576, -30.10968637 ], [ -57.62513343, -30.21629485 ], [ -56.29089962, -28.85276051 ], [ -55.16228634, -27.88191538 ], [ -54.49072527, -27.47475677 ], [ -53.64873532, -26.92347259 ], [ -53.62834897, -26.124865 ], [ -54.13004961, -25.54763926 ], [ -54.6252907, -25.73925547 ], [ -54.42894609, -25.16218475 ], [ -54.29347633, -24.57079966 ], [ -54.29295956, -24.02101409 ], [ -54.65283424, -23.83957814 ], [ -55.02790178, -24.0012737 ], [ -55.40074724, -23.95693532 ], [ -55.51763933, -23.57199757 ], [ -55.61068275, -22.6556194 ], [ -55.79795814, -22.35692962 ], [ -56.47331743, -22.08630014 ], [ -56.88150957, -22.28215382 ], [ -57.93715573, -22.09017588 ], [ -57.870674, -20.73268768 ], [ -58.16639238, -20.17670094 ], [ -57.85380164, -19.96999521 ], [ -57.94999732, -19.40000416 ], [ -57.67600888, -18.96183969 ], [ -57.49837114, -18.17418751 ], [ -57.73455827, -17.55246836 ], [ -58.280804, -17.2717103 ], [ -58.38805844, -16.87710906 ], [ -58.24121986, -16.29957326 ], [ -60.15838966, -16.25828379 ], [ -60.54296566, -15.09391041 ], [ -60.25114885, -15.07721893 ], [ -60.26432634, -14.6459791 ], [ -60.45919817, -14.35400726 ], [ -60.503304, -13.77595469 ], [ -61.08412126, -13.47938364 ], [ -61.71320431, -13.48920216 ], [ -62.12708086, -13.19878061 ], [ -62.80306027, -13.00065317 ], [ -63.19649879, -12.62703257 ], [ -64.31635291, -12.46197804 ], [ -65.40228146, -11.56627044 ], [ -65.32189877, -10.89587208 ], [ -65.444837, -10.5114511 ], [ -65.33843523, -9.76198781 ], [ -66.64690833, -9.93133148 ], [ -67.17380124, -10.30681243 ], [ -68.04819231, -10.71205901 ], [ -68.27125363, -11.01452117 ], [ -68.7861576, -11.0363803 ], [ -69.52967811, -10.95173431 ], [ -70.0937522, -11.12397186 ], [ -70.54868568, -11.00914682 ], [ -70.48189389, -9.4901181 ], [ -71.30241228, -10.07943613 ], [ -72.18489071, -10.05359791 ], [ -72.56303301, -9.52019378 ], [ -73.22671343, -9.46221282 ], [ -73.01538266, -9.03283335 ], [ -73.57105933, -8.42444671 ], [ -73.98723548, -7.52382985 ], [ -73.72340146, -7.34099863 ], [ -73.72448666, -6.91859547 ], [ -73.12002743, -6.62993092 ], [ -73.21971127, -6.08918873 ], [ -72.96450721, -5.74125132 ], [ -72.89192766, -5.27456146 ], [ -71.74840573, -4.59398284 ], [ -70.92884335, -4.40159149 ], [ -70.79476885, -4.25126474 ], [ -69.89363522, -4.29818694 ], [ -69.44410194, -1.55628712 ], [ -69.42048581, -1.1226185 ], [ -69.5770654, -0.54999196 ], [ -70.02065589, -0.18515635 ], [ -70.01556576, 0.54141429 ], [ -69.452396, 0.70615876 ], [ -69.25243405, 0.60265087 ], [ -69.21863766, 0.98567658 ], [ -69.80459673, 1.08908112 ], [ -69.81697323, 1.7148052 ], [ -67.86856503, 1.69245515 ], [ -67.53781002, 2.03716279 ], [ -67.25999752, 1.71999868 ], [ -67.06504818, 1.13011221 ], [ -66.87632585, 1.2533605 ], [ -66.32576514, 0.72445222 ], [ -65.54826738, 0.78925446 ], [ -65.3547133, 1.09528229 ], [ -64.61101193, 1.32873058 ], [ -64.19930579, 1.49285493 ], [ -64.0830855, 1.91636913 ], [ -63.36878801, 2.20089956 ], [ -63.4228674, 2.41106761 ], [ -64.26999915, 2.49700552 ], [ -64.40882789, 3.1267862 ], [ -64.36849443, 3.79721039 ], [ -64.81606401, 4.05644522 ], [ -64.62865943, 4.14848094 ], [ -63.88834286, 4.0205301 ], [ -63.0931976, 3.77057119 ], [ -62.80453305, 4.00696503 ], [ -62.08542965, 4.16212352 ], [ -60.96689328, 4.5364676 ], [ -60.60117917, 4.91809805 ], [ -60.73357418, 5.20027721 ], [ -60.21368344, 5.2444864 ], [ -59.98095862, 5.01406118 ], [ -60.11100237, 4.57496654 ], [ -59.76740577, 4.42350292 ], [ -59.53803992, 3.9588026 ], [ -59.81541317, 3.60649852 ], [ -59.97452491, 2.75523265 ], [ -59.7185457, 2.24963044 ], [ -59.64604367, 1.78689383 ], [ -59.03086158, 1.31769766 ], [ -58.54001299, 1.26808828 ], [ -58.4294771, 1.46394196 ], [ -58.11344988, 1.50719514 ], [ -57.66097104, 1.68258495 ], [ -57.33582292, 1.94853771 ], [ -56.78270423, 1.86371084 ], [ -56.53938575, 1.89952261 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Brunei", "sov_a3": "BRN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Brunei", "adm0_a3": "BRN", "geou_dif": 0.000000, "geounit": "Brunei", "gu_a3": "BRN", "su_dif": 0.000000, "subunit": "Brunei", "su_a3": "BRN", "brk_diff": 0.000000, "name": "Brunei", "name_long": "Brunei Darussalam", "brk_a3": "BRN", "brk_name": "Brunei", "brk_group": null, "abbrev": "Brunei", "postal": "BN", "formal_en": "Negara Brunei Darussalam", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Brunei", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 6.000000, "mapcolor9": 6.000000, "mapcolor13": 12.000000, "pop_est": 388190.000000, "gdp_md_est": 20250.000000, "pop_year": -99.000000, "lastcensus": 2001.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "2. High income: nonOECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "BN", "iso_a3": "BRN", "iso_n3": "096", "un_a3": "096", "wb_a2": "BN", "wb_a3": "BRN", "woe_id": -99.000000, "adm0_a3_is": "BRN", "adm0_a3_us": "BRN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "South-Eastern Asia", "region_wb": "East Asia & Pacific", "name_len": 6.000000, "long_len": 17.000000, "abbrev_len": 6.000000, "tiny": 2.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 114.20401655, 4.52587393 ], [ 114.59996138, 4.9000113 ], [ 115.45071048, 5.4477298 ], [ 115.40570031, 4.95522757 ], [ 115.34746097, 4.31663605 ], [ 114.86955733, 4.34831371 ], [ 114.65959598, 4.00763683 ], [ 114.20401655, 4.52587393 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Bhutan", "sov_a3": "BTN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Bhutan", "adm0_a3": "BTN", "geou_dif": 0.000000, "geounit": "Bhutan", "gu_a3": "BTN", "su_dif": 0.000000, "subunit": "Bhutan", "su_a3": "BTN", "brk_diff": 0.000000, "name": "Bhutan", "name_long": "Bhutan", "brk_a3": "BTN", "brk_name": "Bhutan", "brk_group": null, "abbrev": "Bhutan", "postal": "BT", "formal_en": "Kingdom of Bhutan", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Bhutan", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 6.000000, "mapcolor9": 1.000000, "mapcolor13": 8.000000, "pop_est": 691141.000000, "gdp_md_est": 3524.000000, "pop_year": -99.000000, "lastcensus": 2005.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "BT", "iso_a3": "BTN", "iso_n3": "064", "un_a3": "064", "wb_a2": "BT", "wb_a3": "BTN", "woe_id": -99.000000, "adm0_a3_is": "BTN", "adm0_a3_us": "BTN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Southern Asia", "region_wb": "South Asia", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 91.69665653, 27.77174185 ], [ 92.10371179, 27.45261404 ], [ 92.03348351, 26.83831045 ], [ 91.21751265, 26.80864818 ], [ 90.37327477, 26.87572419 ], [ 89.74452762, 26.71940298 ], [ 88.83564253, 27.09896638 ], [ 88.81424849, 27.2993159 ], [ 89.47581017, 28.0427589 ], [ 90.01582889, 28.2964385 ], [ 90.73051395, 28.06495393 ], [ 91.25885379, 28.04061433 ], [ 91.69665653, 27.77174185 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Botswana", "sov_a3": "BWA", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Botswana", "adm0_a3": "BWA", "geou_dif": 0.000000, "geounit": "Botswana", "gu_a3": "BWA", "su_dif": 0.000000, "subunit": "Botswana", "su_a3": "BWA", "brk_diff": 0.000000, "name": "Botswana", "name_long": "Botswana", "brk_a3": "BWA", "brk_name": "Botswana", "brk_group": null, "abbrev": "Bwa.", "postal": "BW", "formal_en": "Republic of Botswana", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Botswana", "name_alt": null, "mapcolor7": 6.000000, "mapcolor8": 5.000000, "mapcolor9": 7.000000, "mapcolor13": 3.000000, "pop_est": 1990876.000000, "gdp_md_est": 27060.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "BW", "iso_a3": "BWA", "iso_n3": "072", "un_a3": "072", "wb_a2": "BW", "wb_a3": "BWA", "woe_id": -99.000000, "adm0_a3_is": "BWA", "adm0_a3_us": "BWA", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Southern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 8.000000, "long_len": 8.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 25.2642257, -17.73653981 ], [ 25.64916345, -18.53602589 ], [ 25.85039147, -18.71441294 ], [ 26.16479089, -19.29308563 ], [ 27.29650475, -20.39151987 ], [ 27.72474735, -20.49905853 ], [ 27.72722782, -20.85180185 ], [ 28.02137007, -21.48597503 ], [ 28.7946562, -21.63945403 ], [ 29.43218835, -22.09131276 ], [ 28.01723596, -22.82775359 ], [ 27.11940962, -23.57432301 ], [ 26.78640669, -24.24069061 ], [ 26.48575321, -24.61632659 ], [ 25.94165205, -24.69637339 ], [ 25.76584883, -25.17484547 ], [ 25.66466638, -25.48681609 ], [ 25.02517053, -25.7196701 ], [ 24.21126672, -25.67021575 ], [ 23.73356978, -25.39012949 ], [ 23.3120968, -25.26868987 ], [ 22.82427127, -25.50045867 ], [ 22.57953169, -25.97944752 ], [ 22.10596887, -26.28025604 ], [ 21.60589603, -26.72653371 ], [ 20.889609, -26.82854298 ], [ 20.66647017, -26.4774533 ], [ 20.75860925, -25.86813649 ], [ 20.16572554, -24.91796193 ], [ 19.89576786, -24.76779022 ], [ 19.8954578, -21.849157 ], [ 20.88113407, -21.81432708 ], [ 20.91064131, -18.25221893 ], [ 21.65504032, -18.21914601 ], [ 23.19685835, -17.86903818 ], [ 23.57900557, -18.28126108 ], [ 24.21736454, -17.88934702 ], [ 24.52070519, -17.88712493 ], [ 25.08444339, -17.66181569 ], [ 25.2642257, -17.73653981 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Central African Republic", "sov_a3": "CAF", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Central African Republic", "adm0_a3": "CAF", "geou_dif": 0.000000, "geounit": "Central African Republic", "gu_a3": "CAF", "su_dif": 0.000000, "subunit": "Central African Republic", "su_a3": "CAF", "brk_diff": 0.000000, "name": "Central African Rep.", "name_long": "Central African Republic", "brk_a3": "CAF", "brk_name": "Central African Rep.", "brk_group": null, "abbrev": "C.A.R.", "postal": "CF", "formal_en": "Central African Republic", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Central African Republic", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 6.000000, "mapcolor9": 6.000000, "mapcolor13": 9.000000, "pop_est": 4511488.000000, "gdp_md_est": 3198.000000, "pop_year": -99.000000, "lastcensus": 2003.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "CF", "iso_a3": "CAF", "iso_n3": "140", "un_a3": "140", "wb_a2": "CF", "wb_a3": "CAF", "woe_id": -99.000000, "adm0_a3_is": "CAF", "adm0_a3_us": "CAF", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Middle Africa", "region_wb": "Sub-Saharan Africa", "name_len": 20.000000, "long_len": 24.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 23.88697958, 8.61972971 ], [ 24.56736901, 8.22918793 ], [ 25.11493249, 7.82510407 ], [ 25.12413089, 7.50008515 ], [ 25.79664798, 6.9793159 ], [ 26.21341841, 6.5466033 ], [ 26.46590946, 5.94671743 ], [ 27.21340905, 5.55095348 ], [ 27.37422611, 5.2339444 ], [ 27.04406538, 5.12785269 ], [ 26.40276086, 5.15087454 ], [ 25.65045536, 5.25608775 ], [ 25.27879846, 5.17040823 ], [ 25.12883345, 4.92724478 ], [ 24.80502892, 4.89724661 ], [ 24.41053104, 5.10878408 ], [ 23.29721398, 4.6096931 ], [ 22.84147953, 4.71012625 ], [ 22.70412357, 4.63305085 ], [ 22.40512373, 4.02916006 ], [ 21.65912276, 4.22434195 ], [ 20.92759118, 4.32278555 ], [ 20.29067915, 4.69167776 ], [ 19.46778364, 5.03152782 ], [ 18.93231245, 4.70950613 ], [ 18.54298221, 4.20178518 ], [ 18.45306522, 3.50438589 ], [ 17.80990034, 3.56019644 ], [ 17.13304243, 3.72819652 ], [ 16.53705814, 3.19825471 ], [ 16.01285241, 2.26763968 ], [ 15.90738081, 2.55738943 ], [ 15.86273237, 3.0135373 ], [ 15.40539595, 3.3353006 ], [ 15.03621952, 3.8513673 ], [ 14.9509534, 4.21038931 ], [ 14.47837243, 4.7326055 ], [ 14.55893599, 5.03059764 ], [ 14.45940718, 5.45176057 ], [ 14.53656009, 6.22695873 ], [ 14.77654544, 6.40849803 ], [ 15.27946048, 7.42192455 ], [ 16.10623172, 7.49708792 ], [ 16.29056156, 7.75430736 ], [ 16.45618452, 7.73477367 ], [ 16.7059884, 7.50832754 ], [ 17.96492964, 7.89091401 ], [ 18.38955488, 8.28130362 ], [ 18.91102176, 8.63089468 ], [ 18.81200972, 8.98291454 ], [ 19.09400801, 9.07484691 ], [ 20.0596855, 9.012706 ], [ 21.00086836, 9.47598522 ], [ 21.72382165, 10.56705557 ], [ 22.23112918, 10.97188874 ], [ 22.86416548, 11.14239513 ], [ 22.97754357, 10.71446259 ], [ 23.55430423, 10.08925528 ], [ 23.55724979, 9.68121817 ], [ 23.39477909, 9.26506786 ], [ 23.45901289, 8.95428579 ], [ 23.80581343, 8.66631887 ], [ 23.88697958, 8.61972971 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Canada", "sov_a3": "CAN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Canada", "adm0_a3": "CAN", "geou_dif": 0.000000, "geounit": "Canada", "gu_a3": "CAN", "su_dif": 0.000000, "subunit": "Canada", "su_a3": "CAN", "brk_diff": 0.000000, "name": "Canada", "name_long": "Canada", "brk_a3": "CAN", "brk_name": "Canada", "brk_group": null, "abbrev": "Can.", "postal": "CA", "formal_en": "Canada", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Canada", "name_alt": null, "mapcolor7": 6.000000, "mapcolor8": 6.000000, "mapcolor9": 2.000000, "mapcolor13": 2.000000, "pop_est": 33487208.000000, "gdp_md_est": 1300000.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "1. Developed region: G7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "CA", "iso_a3": "CAN", "iso_n3": "124", "un_a3": "124", "wb_a2": "CA", "wb_a3": "CAN", "woe_id": -99.000000, "adm0_a3_is": "CAN", "adm0_a3_us": "CAN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "North America", "region_un": "Americas", "subregion": "Northern America", "region_wb": "North America", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -63.6645, 46.55001 ], [ -62.9393, 46.41587 ], [ -62.01208, 46.44314 ], [ -62.50391, 46.03339 ], [ -62.87433, 45.96818 ], [ -64.1428, 46.39265 ], [ -64.39261, 46.72747 ], [ -64.01486, 47.03601 ], [ -63.6645, 46.55001 ] ] ], [ [ [ -61.806305, 49.10506 ], [ -62.29318, 49.08717 ], [ -63.58926, 49.40069 ], [ -64.51912, 49.87304 ], [ -64.17322, 49.95718 ], [ -62.85829, 49.70641 ], [ -61.835585, 49.28855 ], [ -61.806305, 49.10506 ] ] ], [ [ [ -123.51000159, 48.51001089 ], [ -124.01289079, 48.37084626 ], [ -125.65501278, 48.82500458 ], [ -125.95499447, 49.17999584 ], [ -126.85000444, 49.53000031 ], [ -127.02999345, 49.81499584 ], [ -128.0593363, 49.99495901 ], [ -128.44458411, 50.53913768 ], [ -128.35841366, 50.7706481 ], [ -127.3085811, 50.55257355 ], [ -126.69500098, 50.40090323 ], [ -125.75500667, 50.29501822 ], [ -125.41500159, 49.95000052 ], [ -124.92076819, 49.47527497 ], [ -123.92250871, 49.06248363 ], [ -123.51000159, 48.51001089 ] ] ], [ [ [ -56.13403581, 50.68700979 ], [ -56.79588172, 49.81230866 ], [ -56.14310503, 50.1501175 ], [ -55.47149228, 49.93581533 ], [ -55.82240109, 49.58712861 ], [ -54.93514258, 49.31301097 ], [ -54.4737754, 49.55669119 ], [ -53.47654945, 49.2491389 ], [ -53.78601376, 48.5167805 ], [ -53.086134, 48.68780366 ], [ -52.95864824, 48.15716421 ], [ -52.64809872, 47.53554841 ], [ -53.06915829, 46.65549877 ], [ -53.52145626, 46.61829173 ], [ -54.17893551, 46.80706574 ], [ -53.96186866, 47.62520702 ], [ -54.24048214, 47.75227936 ], [ -55.40077308, 46.8849938 ], [ -55.99748084, 46.91972036 ], [ -55.29121904, 47.38956249 ], [ -56.25079871, 47.63254507 ], [ -57.32522925, 47.57280712 ], [ -59.26601518, 47.60334789 ], [ -59.41949419, 47.89945384 ], [ -58.79658647, 48.25152538 ], [ -59.23162452, 48.52318838 ], [ -58.39180498, 49.12558055 ], [ -57.35868974, 50.71827403 ], [ -56.73865007, 51.28743826 ], [ -55.87097694, 51.63209422 ], [ -55.40697425, 51.58827261 ], [ -55.60021827, 51.31707469 ], [ -56.13403581, 50.68700979 ] ] ], [ [ [ -133.18000404, 54.16997549 ], [ -132.71000788, 54.04000932 ], [ -131.74998958, 54.12000438 ], [ -132.04948035, 52.98462149 ], [ -131.17904252, 52.18043285 ], [ -131.57782955, 52.18237071 ], [ -132.18042843, 52.63970714 ], [ -132.54999243, 53.10001496 ], [ -133.05461118, 53.41146882 ], [ -133.23966448, 53.85108023 ], [ -133.18000404, 54.16997549 ] ] ], [ [ [ -79.26582, 62.158675 ], [ -79.65752, 61.63308 ], [ -80.09956, 61.7181 ], [ -80.36215, 62.01649 ], [ -80.315395, 62.085565 ], [ -79.92939, 62.3856 ], [ -79.52002, 62.36371 ], [ -79.26582, 62.158675 ] ] ], [ [ [ -81.89825, 62.7108 ], [ -83.06857, 62.15922 ], [ -83.77462, 62.18231 ], [ -83.99367, 62.4528 ], [ -83.25048, 62.91409 ], [ -81.87699, 62.90458 ], [ -81.89825, 62.7108 ] ] ], [ [ [ -85.16130795, 65.65728465 ], [ -84.97576372, 65.21751822 ], [ -84.46401201, 65.37177237 ], [ -83.88262631, 65.10961782 ], [ -82.78757687, 64.76669302 ], [ -81.64201372, 64.45513581 ], [ -81.55344031, 63.97960928 ], [ -80.81736121, 64.05748566 ], [ -80.1034513, 63.72598135 ], [ -80.99101986, 63.41124604 ], [ -82.54717811, 63.65172232 ], [ -83.10879757, 64.10187572 ], [ -84.10041663, 63.56971182 ], [ -85.52340471, 63.05237906 ], [ -85.86676876, 63.63725292 ], [ -87.2219832, 63.5412381 ], [ -86.35275977, 64.03583324 ], [ -86.22488644, 64.82291698 ], [ -85.88384783, 65.73877839 ], [ -85.16130795, 65.65728465 ] ] ], [ [ [ -75.86588, 67.14886 ], [ -76.98687, 67.09873 ], [ -77.2364, 67.58809 ], [ -76.81166, 68.14856 ], [ -75.89521, 68.28721 ], [ -75.1145, 68.01036 ], [ -75.10333, 67.58202 ], [ -75.21597, 67.44425 ], [ -75.86588, 67.14886 ] ] ], [ [ [ -95.6476812, 69.10769036 ], [ -96.2695212, 68.75704036 ], [ -97.6174012, 69.06003036 ], [ -98.4318012, 68.95070036 ], [ -99.7974012, 69.40003036 ], [ -98.9174012, 69.71003036 ], [ -98.2182612, 70.14354036 ], [ -97.1574012, 69.86003036 ], [ -96.5574012, 69.68003036 ], [ -96.2574012, 69.49003036 ], [ -95.6476812, 69.10769036 ] ] ], [ [ [ -90.5471, 69.49766 ], [ -90.55151, 68.47499 ], [ -89.21515, 69.25873 ], [ -88.01966, 68.61508 ], [ -88.31749, 67.87338 ], [ -87.35017, 67.19872 ], [ -86.30607, 67.92146 ], [ -85.57664, 68.78456 ], [ -85.52197, 69.88211 ], [ -84.10081, 69.80539 ], [ -82.62258, 69.65826 ], [ -81.28043, 69.16202 ], [ -81.2202, 68.66567 ], [ -81.96436, 68.13253 ], [ -81.25928, 67.59716 ], [ -81.38653, 67.11078 ], [ -83.34456, 66.41154 ], [ -84.73542, 66.2573 ], [ -85.76943, 66.55833 ], [ -86.0676, 66.05625 ], [ -87.03143, 65.21297 ], [ -87.32324, 64.77563 ], [ -88.48296, 64.09897 ], [ -89.91444, 64.03273 ], [ -90.70398, 63.61017 ], [ -90.77004, 62.96021 ], [ -91.93342, 62.83508 ], [ -93.15698, 62.02469 ], [ -94.24153, 60.89865 ], [ -94.62931, 60.11021 ], [ -94.6846, 58.94882 ], [ -93.21502, 58.78212 ], [ -92.76462, 57.84571 ], [ -92.29703, 57.08709 ], [ -90.89769, 57.28468 ], [ -89.03953, 56.85172 ], [ -88.03978, 56.47162 ], [ -87.32421, 55.99914 ], [ -86.07121, 55.72383 ], [ -85.01181, 55.3026 ], [ -83.36055, 55.24489 ], [ -82.27285, 55.14832 ], [ -82.4362, 54.28227 ], [ -82.12502, 53.27703 ], [ -81.40075, 52.15788 ], [ -79.91289, 51.20842 ], [ -79.14301, 51.53393 ], [ -78.60191, 52.56208 ], [ -79.12421, 54.14145 ], [ -79.82958, 54.66772 ], [ -78.22874, 55.13645 ], [ -77.0956, 55.83741 ], [ -76.54137, 56.53423 ], [ -76.62319, 57.20263 ], [ -77.30226, 58.05209 ], [ -78.51688, 58.80458 ], [ -77.33676, 59.85261 ], [ -77.77272, 60.75788 ], [ -78.10687, 62.31964 ], [ -77.41067, 62.55053 ], [ -75.69621, 62.2784 ], [ -74.6682, 62.18111 ], [ -73.83988, 62.4438 ], [ -72.90853, 62.10507 ], [ -71.67708, 61.52535 ], [ -71.37369, 61.13717 ], [ -69.59042, 61.06141 ], [ -69.62033, 60.22125 ], [ -69.2879, 58.95736 ], [ -68.37455, 58.80106 ], [ -67.64976, 58.21206 ], [ -66.20178, 58.76731 ], [ -65.24517, 59.87071 ], [ -64.58352, 60.33558 ], [ -63.80475, 59.4426 ], [ -62.50236, 58.16708 ], [ -61.39655, 56.96745 ], [ -61.79866, 56.33945 ], [ -60.46853, 55.77548 ], [ -59.56962, 55.20407 ], [ -57.97508, 54.94549 ], [ -57.3332, 54.6265 ], [ -56.93689, 53.78032 ], [ -56.15811, 53.64749 ], [ -55.75632, 53.27036 ], [ -55.68338, 52.14664 ], [ -56.40916, 51.7707 ], [ -57.12691, 51.41972 ], [ -58.77482, 51.0643 ], [ -60.03309, 50.24277 ], [ -61.72366, 50.08046 ], [ -63.86251, 50.29099 ], [ -65.36331, 50.2982 ], [ -66.39905, 50.22897 ], [ -67.23631, 49.51156 ], [ -68.51114, 49.06836 ], [ -69.95362, 47.74488 ], [ -71.10458, 46.82171 ], [ -70.25522, 46.98606 ], [ -68.65, 48.3 ], [ -66.55243, 49.1331 ], [ -65.05626, 49.23278 ], [ -64.17099, 48.74248 ], [ -65.11545, 48.07085 ], [ -64.79854, 46.99297 ], [ -64.47219, 46.23849 ], [ -63.17329, 45.73902 ], [ -61.52072, 45.88377 ], [ -60.51815, 47.00793 ], [ -60.4486, 46.28264 ], [ -59.80287, 45.9204 ], [ -61.03988, 45.26525 ], [ -63.25471, 44.67014 ], [ -64.24656, 44.26553 ], [ -65.36406, 43.54523 ], [ -66.1234, 43.61867 ], [ -66.16173, 44.46512 ], [ -64.42549, 45.29204 ], [ -66.02605, 45.25931 ], [ -67.13741, 45.13753 ], [ -67.79134, 45.70281 ], [ -67.79046, 47.06636 ], [ -68.23444, 47.35486 ], [ -68.905, 47.185 ], [ -69.237216, 47.447781 ], [ -69.99997, 46.69307 ], [ -70.305, 45.915 ], [ -70.66, 45.46 ], [ -71.08482, 45.30524 ], [ -71.405, 45.255 ], [ -71.50506, 45.0082 ], [ -73.34783, 45.00738 ], [ -74.867, 45.00048 ], [ -75.31821, 44.81645 ], [ -76.34161477, 44.11906006 ], [ -76.35303423, 44.13467072 ], [ -76.56555355, 44.20802542 ], [ -76.88269182, 44.06945506 ], [ -77.16148617, 43.85014029 ], [ -77.60536089, 44.0393277 ], [ -78.45052894, 43.90318614 ], [ -79.15617062, 43.75743277 ], [ -79.46116492, 43.63919709 ], [ -79.76047482, 43.29720246 ], [ -79.36168779, 43.20237621 ], [ -79.05630592, 43.25410432 ], [ -79.00870152, 43.26559959 ], [ -78.92, 42.965 ], [ -78.92000453, 42.96497627 ], [ -78.92000932, 42.96500052 ], [ -79.79135149, 42.84203644 ], [ -80.27917701, 42.71566173 ], [ -80.54515561, 42.56008983 ], [ -81.09496701, 42.66075552 ], [ -81.39226152, 42.61517691 ], [ -81.82918576, 42.33552989 ], [ -82.57123349, 42.0170222 ], [ -83.11999152, 42.0800135 ], [ -82.9, 42.43 ], [ -82.43, 42.98 ], [ -82.42999111, 42.98001798 ], [ -81.78272864, 43.31084504 ], [ -81.70017554, 43.5900528 ], [ -81.75265296, 44.06464916 ], [ -81.27567949, 44.6201708 ], [ -81.40233843, 45.25005484 ], [ -80.89769223, 44.63164297 ], [ -80.08500281, 44.49392528 ], [ -79.76292945, 44.82460277 ], [ -80.41056434, 45.59013744 ], [ -80.73679765, 45.90381338 ], [ -81.63136837, 46.09754833 ], [ -82.44199073, 46.19963512 ], [ -83.20251278, 46.21015127 ], [ -83.95257036, 46.33427806 ], [ -84.14870826, 46.55576325 ], [ -84.33670581, 46.40877067 ], [ -84.6049, 46.4396 ], [ -84.60411309, 46.44087504 ], [ -84.39559241, 46.77683503 ], [ -84.81528256, 46.90233124 ], [ -84.64500871, 47.2822047 ], [ -85.04061764, 47.575701 ], [ -84.86422014, 47.8600764 ], [ -85.9865289, 48.01035147 ], [ -86.32103044, 48.57729361 ], [ -86.5600081, 48.71108389 ], [ -87.24903581, 48.73511343 ], [ -88.17895321, 48.93670319 ], [ -88.40423662, 48.80632355 ], [ -88.62641944, 48.56251415 ], [ -89.19405921, 48.40546947 ], [ -89.59999266, 48.01000022 ], [ -89.6, 48.01 ], [ -90.83, 48.27 ], [ -91.64, 48.14 ], [ -92.61, 48.45 ], [ -93.63087, 48.60926 ], [ -94.32914, 48.67074 ], [ -94.64, 48.84 ], [ -94.81758, 49.38905 ], [ -95.15609, 49.38425 ], [ -95.15906951, 49.0 ], [ -97.22872, 49.0007 ], [ -100.65, 49.0 ], [ -104.04826, 48.99986 ], [ -107.05, 49.0 ], [ -110.05, 49.0 ], [ -113.0, 49.0 ], [ -116.04818, 49.0 ], [ -117.03121, 49.0 ], [ -120.0, 49.0 ], [ -122.84, 49.0 ], [ -122.97421, 49.00253778 ], [ -124.91024, 49.98456 ], [ -125.62461, 50.41656 ], [ -127.43561, 50.83061 ], [ -127.99276, 51.71583 ], [ -127.85032, 52.32961 ], [ -129.12979, 52.75538 ], [ -129.30523, 53.56159 ], [ -130.51497, 54.28757 ], [ -130.53610895, 54.80275448 ], [ -130.53611, 54.80278 ], [ -129.98, 55.285 ], [ -130.00778, 55.91583 ], [ -131.70781, 56.55212 ], [ -132.73042, 57.69289 ], [ -133.35556, 58.41028 ], [ -134.27111, 58.86111 ], [ -134.945, 59.27056 ], [ -135.47583, 59.78778 ], [ -136.47972, 59.46389 ], [ -137.4525, 58.905 ], [ -138.34089, 59.56211 ], [ -139.039, 60.0 ], [ -140.013, 60.27682 ], [ -140.99778, 60.30639 ], [ -140.9925, 66.00003 ], [ -140.986, 69.712 ], [ -140.98598752, 69.71199839 ], [ -139.12052, 69.47102 ], [ -137.54636, 68.99002 ], [ -136.50358, 68.89804 ], [ -135.62576, 69.31512 ], [ -134.41464, 69.62743 ], [ -132.92925, 69.50534 ], [ -131.43136, 69.94451 ], [ -129.79471, 70.19369 ], [ -129.10773, 69.77927 ], [ -128.36156, 70.01286 ], [ -128.13817, 70.48384 ], [ -127.44712, 70.37721 ], [ -125.75632, 69.48058 ], [ -124.42483, 70.1584 ], [ -124.28968, 69.39969 ], [ -123.06108, 69.56372 ], [ -122.6835, 69.85553 ], [ -121.47226, 69.79778 ], [ -119.94288, 69.37786 ], [ -117.60268, 69.01128 ], [ -116.22643, 68.84151 ], [ -115.2469, 68.90591 ], [ -113.89794, 68.3989 ], [ -115.30489, 67.90261 ], [ -113.49727, 67.68815 ], [ -110.798, 67.80612 ], [ -109.94619, 67.98104 ], [ -108.8802, 67.38144 ], [ -107.79239, 67.88736 ], [ -108.81299, 68.31164 ], [ -108.16721, 68.65392 ], [ -106.95, 68.7 ], [ -106.15, 68.8 ], [ -105.34282, 68.56122 ], [ -104.33791, 68.018 ], [ -103.22115, 68.09775 ], [ -101.45433, 67.64689 ], [ -99.90195, 67.80566 ], [ -98.4432, 67.78165 ], [ -98.5586, 68.40394 ], [ -97.66948, 68.57864 ], [ -96.11991, 68.23939 ], [ -96.12588, 67.29338 ], [ -95.48943, 68.0907 ], [ -94.685, 68.06383 ], [ -94.23282, 69.06903 ], [ -95.30408, 69.68571 ], [ -96.47131, 70.08976 ], [ -96.39115, 71.19482 ], [ -95.2088, 71.92053 ], [ -93.88997, 71.76015 ], [ -92.87818, 71.31869 ], [ -91.51964, 70.19129 ], [ -92.40692, 69.69997 ], [ -90.5471, 69.49766 ] ] ], [ [ [ -114.16717, 73.12145 ], [ -114.66634, 72.65277 ], [ -112.44102, 72.9554 ], [ -111.05039, 72.4504 ], [ -109.92035, 72.96113 ], [ -109.00654, 72.63335 ], [ -108.18835, 71.65089 ], [ -107.68599, 72.06548 ], [ -108.39639, 73.08953 ], [ -107.51645, 73.23598 ], [ -106.52259, 73.07601 ], [ -105.40246, 72.67259 ], [ -104.77484, 71.6984 ], [ -104.46476, 70.99297 ], [ -102.78537, 70.49776 ], [ -100.98078, 70.02432 ], [ -101.08929, 69.58447 ], [ -102.73116, 69.50402 ], [ -102.09329, 69.11962 ], [ -102.43024, 68.75282 ], [ -104.24, 68.91 ], [ -105.96, 69.18 ], [ -107.12254, 69.11922 ], [ -109.0, 68.78 ], [ -111.53414888, 68.63005916 ], [ -113.3132, 68.53554 ], [ -113.85496, 69.00744 ], [ -115.22, 69.28 ], [ -116.10794, 69.16821 ], [ -117.34, 69.96 ], [ -116.67473, 70.06655 ], [ -115.13112, 70.2373 ], [ -113.72141, 70.19237 ], [ -112.4161, 70.36638 ], [ -114.35, 70.6 ], [ -116.48684, 70.52045 ], [ -117.9048, 70.54056 ], [ -118.43238, 70.9092 ], [ -116.11311, 71.30918 ], [ -117.65568, 71.2952 ], [ -119.40199, 71.55859 ], [ -118.56267, 72.30785 ], [ -117.86642, 72.70594 ], [ -115.18909, 73.31459 ], [ -114.16717, 73.12145 ] ] ], [ [ [ -104.5, 73.42 ], [ -105.38, 72.76 ], [ -106.94, 73.46 ], [ -106.6, 73.6 ], [ -105.26, 73.64 ], [ -104.5, 73.42 ] ] ], [ [ [ -76.34, 73.10268499 ], [ -76.25140381, 72.8263855 ], [ -77.31443787, 72.85554504 ], [ -78.39167023, 72.87665558 ], [ -79.48625183, 72.74220276 ], [ -79.77583313, 72.80290222 ], [ -80.87609863, 73.33318329 ], [ -80.83388519, 73.6931839 ], [ -80.35305786, 73.75971985 ], [ -78.06443787, 73.65193176 ], [ -76.34, 73.10268499 ] ] ], [ [ [ -86.56217851, 73.15744701 ], [ -85.7743713, 72.53412588 ], [ -84.85011247, 73.34027823 ], [ -82.31559018, 73.75095083 ], [ -80.60008765, 72.71654369 ], [ -80.74894162, 72.06190664 ], [ -78.7706386, 72.35217316 ], [ -77.82462399, 72.7496166 ], [ -75.60584469, 72.24367849 ], [ -74.2286161, 71.76714427 ], [ -74.09914079, 71.33084016 ], [ -72.24222571, 71.55692455 ], [ -71.20001543, 70.92001252 ], [ -68.78605425, 70.52502371 ], [ -67.91497047, 70.12194754 ], [ -66.96903337, 69.18608735 ], [ -68.80512285, 68.72019847 ], [ -66.4498661, 68.0671634 ], [ -64.86231442, 67.84753856 ], [ -63.42493445, 66.92847321 ], [ -61.85198137, 66.86212067 ], [ -62.16317685, 66.16025137 ], [ -63.91844438, 64.99866852 ], [ -65.14886024, 65.42603262 ], [ -66.72121904, 66.38804108 ], [ -68.01501604, 66.26272574 ], [ -68.1412874, 65.68978913 ], [ -67.08964617, 65.10845511 ], [ -65.73208045, 64.64840567 ], [ -65.32016761, 64.38273713 ], [ -64.6694063, 63.39292674 ], [ -65.01380388, 62.67418509 ], [ -66.27504473, 62.94509878 ], [ -68.7831862, 63.74567007 ], [ -67.36968075, 62.88396556 ], [ -66.32829729, 62.28007477 ], [ -66.1655682, 61.93089712 ], [ -68.8773665, 62.33014924 ], [ -71.02343706, 62.91070812 ], [ -72.23537859, 63.39783601 ], [ -71.88627845, 63.67998933 ], [ -73.37830624, 64.19396312 ], [ -74.83441891, 64.67907563 ], [ -74.81850257, 64.38909333 ], [ -77.70997982, 64.22954234 ], [ -78.55594886, 64.5729064 ], [ -77.89728105, 65.30919221 ], [ -76.0182743, 65.3269689 ], [ -73.95979529, 65.45476472 ], [ -74.29388343, 65.81177135 ], [ -73.94491248, 66.31057811 ], [ -72.65116716, 67.28457551 ], [ -72.92605994, 67.72692577 ], [ -73.3116178, 68.06943716 ], [ -74.84330726, 68.55462718 ], [ -76.86910092, 68.89473562 ], [ -76.22864905, 69.14776927 ], [ -77.28736996, 69.76954011 ], [ -78.168634, 69.82648754 ], [ -78.95724219, 70.16688019 ], [ -79.492455, 69.87180777 ], [ -81.30547095, 69.74318513 ], [ -84.94470618, 69.96663402 ], [ -87.06000342, 70.26000113 ], [ -88.68171322, 70.41074128 ], [ -89.51341956, 70.76203767 ], [ -88.46772112, 71.21818553 ], [ -89.88815121, 71.22255219 ], [ -90.20516029, 72.23507437 ], [ -89.43657671, 73.12946422 ], [ -88.40824154, 73.5378889 ], [ -85.82615109, 73.80381582 ], [ -86.56217851, 73.15744701 ] ] ], [ [ [ -100.35642, 73.84389 ], [ -99.16387, 73.63339 ], [ -97.38, 73.76 ], [ -97.12, 73.47 ], [ -98.05359, 72.99052 ], [ -96.54, 72.56 ], [ -96.72, 71.66 ], [ -98.35966, 71.27285 ], [ -99.32286, 71.35639 ], [ -100.01482, 71.73827 ], [ -102.5, 72.51 ], [ -102.48, 72.83 ], [ -100.43836, 72.70588 ], [ -101.54, 73.36 ], [ -100.35642, 73.84389 ] ] ], [ [ [ -93.19629554, 72.7719925 ], [ -94.2690466, 72.02459626 ], [ -95.40985552, 72.06188081 ], [ -96.03374508, 72.9402768 ], [ -96.01826799, 73.43742992 ], [ -95.49579342, 73.8624169 ], [ -94.5036576, 74.13490672 ], [ -92.42001217, 74.10002513 ], [ -90.50979285, 73.85673249 ], [ -92.00396522, 72.96624421 ], [ -93.19629554, 72.7719925 ] ] ], [ [ [ -120.46, 71.38360179 ], [ -123.09219, 70.90164 ], [ -123.62, 71.34 ], [ -125.92894874, 71.86868846 ], [ -125.5, 72.29226081 ], [ -124.80729, 73.02256 ], [ -123.94, 73.68 ], [ -124.91775, 74.29275 ], [ -121.53788, 74.44893 ], [ -120.10978, 74.24135 ], [ -117.55564, 74.18577 ], [ -116.58442, 73.89607 ], [ -115.51081, 73.47519 ], [ -116.76794, 73.22292 ], [ -119.22, 72.52 ], [ -120.46, 71.82 ], [ -120.46, 71.38360179 ] ] ], [ [ [ -93.61275591, 74.97999726 ], [ -94.15690874, 74.5923465 ], [ -95.60868059, 74.66686392 ], [ -96.82093218, 74.9276232 ], [ -96.28858741, 75.37782827 ], [ -94.85081987, 75.64721752 ], [ -93.97774655, 75.29648957 ], [ -93.61275591, 74.97999726 ] ] ], [ [ [ -98.5, 76.72 ], [ -97.735585, 76.25656 ], [ -97.704415, 75.74344 ], [ -98.16, 75.0 ], [ -99.80874, 74.89744 ], [ -100.88366, 75.05736 ], [ -100.86292, 75.64075 ], [ -102.50209, 75.5638 ], [ -102.56552, 76.3366 ], [ -101.48973, 76.30537 ], [ -99.98349, 76.64634 ], [ -98.57699, 76.58859 ], [ -98.5, 76.72 ] ] ], [ [ [ -108.21141, 76.20168 ], [ -107.81943, 75.84552 ], [ -106.92893, 76.01282 ], [ -105.881, 75.9694 ], [ -105.70498, 75.47951 ], [ -106.31347, 75.00527 ], [ -109.7, 74.85 ], [ -112.22307, 74.41696 ], [ -113.74381, 74.39427 ], [ -113.87135, 74.72029 ], [ -111.79421, 75.1625 ], [ -116.31221, 75.04343 ], [ -117.7104, 75.2222 ], [ -116.34602, 76.19903 ], [ -115.40487, 76.47887 ], [ -112.59056, 76.14134 ], [ -110.81422, 75.54919 ], [ -109.0671, 75.47321 ], [ -110.49726, 76.42982 ], [ -109.5811, 76.79417 ], [ -108.54859, 76.67832 ], [ -108.21141, 76.20168 ] ] ], [ [ [ -94.68408586, 77.09787832 ], [ -93.57392107, 76.77629588 ], [ -91.60502316, 76.77851797 ], [ -90.74184587, 76.44959748 ], [ -90.96966142, 76.07401317 ], [ -89.82223792, 75.84777375 ], [ -89.18708289, 75.61016551 ], [ -87.83827633, 75.56618887 ], [ -86.37919227, 75.48242137 ], [ -84.78962521, 75.69920401 ], [ -82.75344459, 75.78431509 ], [ -81.12853085, 75.71398347 ], [ -80.05751095, 75.33684886 ], [ -79.83393287, 74.92312735 ], [ -80.45777076, 74.65730378 ], [ -81.94884254, 74.44245901 ], [ -83.2288936, 74.56402782 ], [ -86.09745236, 74.41003205 ], [ -88.15035031, 74.39230703 ], [ -89.76472205, 74.51555533 ], [ -92.42244097, 74.83775788 ], [ -92.76828549, 75.38681997 ], [ -92.88990597, 75.88265534 ], [ -93.89382402, 76.31924368 ], [ -95.96245745, 76.44138093 ], [ -97.12137895, 76.75107779 ], [ -96.74512285, 77.16138866 ], [ -94.68408586, 77.09787832 ] ] ], [ [ [ -116.1985866, 77.64528677 ], [ -116.33581336, 76.87696158 ], [ -117.10605058, 76.53003185 ], [ -118.04041216, 76.48117178 ], [ -119.89931759, 76.05321341 ], [ -121.49999508, 75.90001862 ], [ -122.85492449, 76.11654287 ], [ -122.85492529, 76.11654287 ], [ -121.15753536, 76.86450755 ], [ -119.10393897, 77.51221996 ], [ -117.57013078, 77.498319 ], [ -116.1985866, 77.64528677 ] ] ], [ [ [ -93.84000302, 77.51999726 ], [ -94.29560828, 77.49134268 ], [ -96.1696541, 77.5551114 ], [ -96.43630449, 77.83462922 ], [ -94.42257728, 77.82000479 ], [ -93.7206563, 77.63433137 ], [ -93.84000302, 77.51999726 ] ] ], [ [ [ -110.18693804, 77.69701488 ], [ -112.05119117, 77.40922883 ], [ -113.53427894, 77.73220653 ], [ -112.72458676, 78.05105012 ], [ -111.26444333, 78.15295604 ], [ -109.85445187, 77.99632477 ], [ -110.18693804, 77.69701488 ] ] ], [ [ [ -109.66314572, 78.60197256 ], [ -110.88131426, 78.40691987 ], [ -112.54209144, 78.40790172 ], [ -112.52589088, 78.55055451 ], [ -111.50001034, 78.8499936 ], [ -110.96366065, 78.80444082 ], [ -109.66314572, 78.60197256 ] ] ], [ [ [ -95.83029497, 78.05694123 ], [ -97.3098429, 77.85059724 ], [ -98.12428931, 78.08285696 ], [ -98.5528678, 78.45810537 ], [ -98.63198442, 78.87193024 ], [ -97.33723141, 78.83198436 ], [ -96.75439877, 78.76581269 ], [ -95.55927792, 78.41831452 ], [ -95.83029497, 78.05694123 ] ] ], [ [ [ -100.06019182, 78.32475434 ], [ -99.67093909, 77.90754466 ], [ -101.30394019, 78.01898489 ], [ -102.94980872, 78.34322866 ], [ -105.17613278, 78.38033234 ], [ -104.21042945, 78.67742015 ], [ -105.41958045, 78.91833568 ], [ -105.49228919, 79.30159394 ], [ -103.5292824, 79.16534903 ], [ -100.82515805, 78.80046174 ], [ -100.06019182, 78.32475434 ] ] ], [ [ [ -87.02, 79.66 ], [ -85.81435, 79.3369 ], [ -87.18756, 79.0393 ], [ -89.03535, 78.28723 ], [ -90.80436, 78.21533 ], [ -92.87669, 78.34333 ], [ -93.95116, 78.75099 ], [ -93.93574, 79.11373 ], [ -93.14524, 79.3801 ], [ -94.974, 79.37248 ], [ -96.07614, 79.70502 ], [ -96.70972, 80.15777 ], [ -96.01644, 80.60233 ], [ -95.32345, 80.90729 ], [ -94.29843, 80.97727 ], [ -94.73542, 81.20646 ], [ -92.40984, 81.25739 ], [ -91.13289, 80.72345 ], [ -89.45, 80.50932203 ], [ -87.81, 80.32 ], [ -87.02, 79.66 ] ] ], [ [ [ -68.5, 83.10632152 ], [ -65.82735, 83.02801 ], [ -63.68, 82.9 ], [ -61.85, 82.6286 ], [ -61.89388, 82.36165 ], [ -64.334, 81.92775 ], [ -66.75342, 81.72527 ], [ -67.65755, 81.50141 ], [ -65.48031, 81.50657 ], [ -67.84, 80.9 ], [ -69.4697, 80.61683 ], [ -71.18, 79.8 ], [ -73.2428, 79.63415 ], [ -73.88, 79.4301622 ], [ -76.90773, 79.32309 ], [ -75.52924, 79.19766 ], [ -76.22046, 79.01907 ], [ -75.39345, 78.52581 ], [ -76.34354, 78.18296 ], [ -77.88851, 77.89991 ], [ -78.36269, 77.50859 ], [ -79.75951, 77.20968 ], [ -79.61965, 76.98336 ], [ -77.91089, 77.022045 ], [ -77.88911, 76.777955 ], [ -80.56125, 76.17812 ], [ -83.17439, 76.45403 ], [ -86.11184, 76.29901 ], [ -87.6, 76.42 ], [ -89.49068, 76.47239 ], [ -89.6161, 76.95213 ], [ -87.76739, 77.17833 ], [ -88.26, 77.9 ], [ -87.65, 77.97022222 ], [ -84.97634, 77.53873 ], [ -86.34, 78.18 ], [ -87.96192, 78.37181 ], [ -87.15198, 78.75867 ], [ -85.37868, 78.9969 ], [ -85.09495, 79.34543 ], [ -86.50734, 79.73624 ], [ -86.93179, 80.25145 ], [ -84.19844, 80.20836 ], [ -83.40869565, 80.1 ], [ -81.84823, 80.46442 ], [ -84.1, 80.58 ], [ -87.59895, 80.51627 ], [ -89.36663, 80.85569 ], [ -90.2, 81.26 ], [ -91.36786, 81.5531 ], [ -91.58702, 81.89429 ], [ -90.1, 82.085 ], [ -88.93227, 82.11751 ], [ -86.97024, 82.27961 ], [ -85.5, 82.65227346 ], [ -84.260005, 82.6 ], [ -83.18, 82.32 ], [ -82.42, 82.86 ], [ -81.1, 83.02 ], [ -79.30664, 83.13056 ], [ -76.25, 83.17205882 ], [ -75.71878, 83.06404 ], [ -72.83153, 83.23324 ], [ -70.665765, 83.16978076 ], [ -68.5, 83.10632152 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Switzerland", "sov_a3": "CHE", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Switzerland", "adm0_a3": "CHE", "geou_dif": 0.000000, "geounit": "Switzerland", "gu_a3": "CHE", "su_dif": 0.000000, "subunit": "Switzerland", "su_a3": "CHE", "brk_diff": 0.000000, "name": "Switzerland", "name_long": "Switzerland", "brk_a3": "CHE", "brk_name": "Switzerland", "brk_group": null, "abbrev": "Switz.", "postal": "CH", "formal_en": "Swiss Confederation", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Switzerland", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 2.000000, "mapcolor9": 7.000000, "mapcolor13": 3.000000, "pop_est": 7604467.000000, "gdp_md_est": 316700.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "CH", "iso_a3": "CHE", "iso_n3": "756", "un_a3": "756", "wb_a2": "CH", "wb_a3": "CHE", "woe_id": -99.000000, "adm0_a3_is": "CHE", "adm0_a3_us": "CHE", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Western Europe", "region_wb": "Europe & Central Asia", "name_len": 11.000000, "long_len": 11.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 9.59422611, 47.52505809 ], [ 9.63293176, 47.34760122 ], [ 9.47996952, 47.10280996 ], [ 9.93244836, 46.92072805 ], [ 10.44270145, 46.89354625 ], [ 10.36337813, 46.48357128 ], [ 9.92283654, 46.3148994 ], [ 9.18288171, 46.44021475 ], [ 8.96630578, 46.03693187 ], [ 8.48995243, 46.00515087 ], [ 8.31662967, 46.16364248 ], [ 7.75599206, 45.82449006 ], [ 7.27385095, 45.77694774 ], [ 6.84359297, 45.99114655 ], [ 6.50009972, 46.42967276 ], [ 6.02260949, 46.27298981 ], [ 6.03738895, 46.72577871 ], [ 6.76871382, 47.28770824 ], [ 6.73657108, 47.54180126 ], [ 7.19220218, 47.44976553 ], [ 7.46675907, 47.62058198 ], [ 8.31730147, 47.61357982 ], [ 8.52261193, 47.83082754 ], [ 9.59422611, 47.52505809 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Chile", "sov_a3": "CHL", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Chile", "adm0_a3": "CHL", "geou_dif": 0.000000, "geounit": "Chile", "gu_a3": "CHL", "su_dif": 0.000000, "subunit": "Chile", "su_a3": "CHL", "brk_diff": 0.000000, "name": "Chile", "name_long": "Chile", "brk_a3": "CHL", "brk_name": "Chile", "brk_group": null, "abbrev": "Chile", "postal": "CL", "formal_en": "Republic of Chile", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Chile", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 1.000000, "mapcolor9": 5.000000, "mapcolor13": 9.000000, "pop_est": 16601707.000000, "gdp_md_est": 244500.000000, "pop_year": -99.000000, "lastcensus": 2002.000000, "gdp_year": -99.000000, "economy": "5. Emerging region: G20", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "CL", "iso_a3": "CHL", "iso_n3": "152", "un_a3": "152", "wb_a2": "CL", "wb_a3": "CHL", "woe_id": -99.000000, "adm0_a3_is": "CHL", "adm0_a3_us": "CHL", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "South America", "region_un": "Americas", "subregion": "South America", "region_wb": "Latin America & Caribbean", "name_len": 5.000000, "long_len": 5.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -68.63401023, -52.63637046 ], [ -68.63335, -54.8695 ], [ -67.56244, -54.87001 ], [ -66.95992, -54.89681 ], [ -67.29103, -55.30124 ], [ -68.14863, -55.61183 ], [ -68.63999081, -55.580018 ], [ -69.2321, -55.49906 ], [ -69.95809, -55.19843 ], [ -71.00568, -55.05383 ], [ -72.2639, -54.49514 ], [ -73.2852, -53.95752 ], [ -74.66253, -52.83749 ], [ -73.8381, -53.04743 ], [ -72.43418, -53.7154 ], [ -71.10773, -54.07433 ], [ -70.59178, -53.61583 ], [ -70.26748, -52.93123 ], [ -69.34565, -52.5183 ], [ -68.63401023, -52.63637046 ] ] ], [ [ [ -68.21991309, -21.49434661 ], [ -67.8281799, -22.8729188 ], [ -67.10667355, -22.73592457 ], [ -66.98523393, -22.98634857 ], [ -67.32844296, -24.02530324 ], [ -68.41765296, -24.51855478 ], [ -68.38600115, -26.18501637 ], [ -68.59479977, -26.50690887 ], [ -68.29554155, -26.89933969 ], [ -69.00123491, -27.52121388 ], [ -69.65613034, -28.45914113 ], [ -70.01355038, -29.36792287 ], [ -69.91900835, -30.33633921 ], [ -70.53506894, -31.36501027 ], [ -70.07439938, -33.09120981 ], [ -69.81477698, -33.273886 ], [ -69.81730913, -34.19357147 ], [ -70.38804949, -35.1696876 ], [ -70.36476925, -36.0050888 ], [ -71.12188066, -36.65812387 ], [ -71.11862505, -37.57682749 ], [ -70.81466427, -38.55299529 ], [ -71.41351661, -38.91602223 ], [ -71.68076128, -39.80816416 ], [ -71.91573402, -40.83233937 ], [ -71.74680376, -42.05138641 ], [ -72.14889808, -42.2548882 ], [ -71.91542396, -43.40856455 ], [ -71.46405616, -43.78761118 ], [ -71.79362261, -44.20717213 ], [ -71.32980079, -44.40752166 ], [ -71.2227789, -44.78424285 ], [ -71.65931556, -44.97368865 ], [ -71.55200945, -45.56073292 ], [ -71.91725847, -46.88483815 ], [ -72.44735531, -47.73853281 ], [ -72.33116085, -48.24423838 ], [ -72.64824744, -48.87861826 ], [ -73.41543576, -49.31843637 ], [ -73.32805091, -50.37878509 ], [ -72.97574683, -50.74145029 ], [ -72.30997352, -50.67700978 ], [ -72.32940386, -51.42595631 ], [ -71.91480384, -52.00902231 ], [ -69.49836219, -52.14276091 ], [ -68.57154538, -52.29944386 ], [ -69.46128435, -52.29195077 ], [ -69.94277951, -52.53793059 ], [ -70.84510169, -52.89920053 ], [ -71.00633216, -53.83325204 ], [ -71.42979468, -53.85645476 ], [ -72.55794288, -53.53141 ], [ -73.70275672, -52.83506927 ], [ -73.70275672, -52.83507008 ], [ -74.94676348, -52.26275359 ], [ -75.26002601, -51.62935475 ], [ -74.97663245, -51.04339568 ], [ -75.4797542, -50.37837168 ], [ -75.6080151, -48.67377288 ], [ -75.18276974, -47.71191945 ], [ -74.12658098, -46.93925343 ], [ -75.64439531, -46.64764332 ], [ -74.69215369, -45.76397633 ], [ -74.35170936, -44.10304412 ], [ -73.240356, -44.45496063 ], [ -72.71780392, -42.38335581 ], [ -73.38889991, -42.11753224 ], [ -73.70133562, -43.36577646 ], [ -74.33194312, -43.22495818 ], [ -74.01795712, -41.79481292 ], [ -73.67709937, -39.94221282 ], [ -73.21759254, -39.25868865 ], [ -73.50555946, -38.28288258 ], [ -73.58806088, -37.15628468 ], [ -73.16671709, -37.12378021 ], [ -72.55313697, -35.50884002 ], [ -71.86173214, -33.90909271 ], [ -71.43845049, -32.41889943 ], [ -71.66872067, -30.92064463 ], [ -71.37008257, -30.09568206 ], [ -71.48989438, -28.86144215 ], [ -70.90512387, -27.64037973 ], [ -70.72495399, -25.70592417 ], [ -70.40396583, -23.62899668 ], [ -70.0912459, -21.39331919 ], [ -70.16441973, -19.75646819 ], [ -70.37257239, -18.34797536 ], [ -69.85844357, -18.09269378 ], [ -69.59042375, -17.5800119 ], [ -69.10024696, -18.26012542 ], [ -68.96681841, -18.98168344 ], [ -68.4422251, -19.40506845 ], [ -68.75716712, -20.37265797 ], [ -68.21991309, -21.49434661 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "China", "sov_a3": "CH1", "adm0_dif": 1.000000, "level": 2.000000, "type": "Country", "admin": "China", "adm0_a3": "CHN", "geou_dif": 0.000000, "geounit": "China", "gu_a3": "CHN", "su_dif": 0.000000, "subunit": "China", "su_a3": "CHN", "brk_diff": 0.000000, "name": "China", "name_long": "China", "brk_a3": "CHN", "brk_name": "China", "brk_group": null, "abbrev": "China", "postal": "CN", "formal_en": "People's Republic of China", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "China", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 4.000000, "mapcolor9": 4.000000, "mapcolor13": 3.000000, "pop_est": 1338612970.000000, "gdp_md_est": 7973000.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "3. Emerging region: BRIC", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "CN", "iso_a3": "CHN", "iso_n3": "156", "un_a3": "156", "wb_a2": "CN", "wb_a3": "CHN", "woe_id": -99.000000, "adm0_a3_is": "CHN", "adm0_a3_us": "CHN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Eastern Asia", "region_wb": "East Asia & Pacific", "name_len": 5.000000, "long_len": 5.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 110.33918786, 18.67839509 ], [ 109.47520959, 18.19770091 ], [ 108.65520796, 18.50768199 ], [ 108.62621748, 19.36788789 ], [ 109.11905562, 19.82103852 ], [ 110.21159875, 20.10125397 ], [ 110.78655073, 20.07753449 ], [ 111.0100513, 19.69592988 ], [ 110.5706466, 19.25587922 ], [ 110.33918786, 18.67839509 ] ] ], [ [ [ 127.65740726, 49.76027049 ], [ 129.39781782, 49.44060008 ], [ 130.58229333, 48.7296874 ], [ 130.98728153, 47.79013235 ], [ 132.50667199, 47.78896963 ], [ 133.37359582, 48.18344168 ], [ 135.02631148, 48.47822989 ], [ 134.50081384, 47.57843985 ], [ 134.1123621, 47.21246735 ], [ 133.769644, 46.11692699 ], [ 133.09712691, 45.14406647 ], [ 131.88345422, 45.32116161 ], [ 131.02521203, 44.96795319 ], [ 131.28855513, 44.11151968 ], [ 131.14468794, 42.92998973 ], [ 130.63386641, 42.90301463 ], [ 130.6400159, 42.39500947 ], [ 130.63999971, 42.39502428 ], [ 129.99426721, 42.98538687 ], [ 129.59666874, 42.4249818 ], [ 128.0522152, 41.99428457 ], [ 128.20843306, 41.46677155 ], [ 127.34378299, 41.50315176 ], [ 126.86908329, 41.81656932 ], [ 126.18204512, 41.10733613 ], [ 125.07994185, 40.56982372 ], [ 124.26562463, 39.92849335 ], [ 122.86757043, 39.63778758 ], [ 122.13138797, 39.17045177 ], [ 121.05455448, 38.89747101 ], [ 121.58599491, 39.36085358 ], [ 121.37675703, 39.75026134 ], [ 122.16859501, 40.42244253 ], [ 121.64035851, 40.94638988 ], [ 120.76862878, 40.59338817 ], [ 119.63960209, 39.89805594 ], [ 119.02346398, 39.25233308 ], [ 118.04274865, 39.20427399 ], [ 117.53270226, 38.73763581 ], [ 118.05969852, 38.06147553 ], [ 118.87814986, 37.89732534 ], [ 118.91163618, 37.44846385 ], [ 119.70280236, 37.15638866 ], [ 120.82345747, 37.87042776 ], [ 121.71125858, 37.48112336 ], [ 122.35793745, 37.45448416 ], [ 122.51999474, 36.93061433 ], [ 121.10416385, 36.65132905 ], [ 120.63700891, 36.11143952 ], [ 119.6645618, 35.60979055 ], [ 119.15120812, 34.90985912 ], [ 120.22752486, 34.36033194 ], [ 120.62036909, 33.37672272 ], [ 121.22901411, 32.46031871 ], [ 121.90814579, 31.69217438 ], [ 121.89191939, 30.94935151 ], [ 121.26425744, 30.6762674 ], [ 121.50351932, 30.14291494 ], [ 122.09211389, 29.83252045 ], [ 121.93842818, 29.01802237 ], [ 121.68443851, 28.2255126 ], [ 121.12566125, 28.13567312 ], [ 120.39547326, 27.0532069 ], [ 119.58549686, 25.74078054 ], [ 118.65687137, 24.54739086 ], [ 117.28160648, 23.62450145 ], [ 115.8907353, 22.78287324 ], [ 114.76382735, 22.66807404 ], [ 114.15254683, 22.22376008 ], [ 113.80677982, 22.54833975 ], [ 113.24107792, 22.0513675 ], [ 111.84359216, 21.55049368 ], [ 110.78546553, 21.39714387 ], [ 110.44403934, 20.34103262 ], [ 109.88986128, 20.28245738 ], [ 109.62765506, 21.00822704 ], [ 109.86448815, 21.39505097 ], [ 108.52281294, 21.71521231 ], [ 108.05018029, 21.55237987 ], [ 107.04342004, 21.81189891 ], [ 106.56727339, 22.21820486 ], [ 106.72540327, 22.79426789 ], [ 105.81124719, 22.9768924 ], [ 105.32920943, 23.3520633 ], [ 104.47685835, 22.81915009 ], [ 103.5045146, 22.70375662 ], [ 102.70699222, 22.70879507 ], [ 102.17043583, 22.46475312 ], [ 101.65201786, 22.31819876 ], [ 101.80311974, 21.17436677 ], [ 101.27002567, 21.20165192 ], [ 101.18000532, 21.43657298 ], [ 101.15003299, 21.84998444 ], [ 100.41653771, 21.55883942 ], [ 99.98348921, 21.74293671 ], [ 99.24089888, 22.11831432 ], [ 99.53199222, 22.9490388 ], [ 98.89874922, 23.14272207 ], [ 98.66026249, 24.06328604 ], [ 97.60471968, 23.89740469 ], [ 97.724609, 25.08363719 ], [ 98.67183801, 25.9187025 ], [ 98.71209395, 26.74353587 ], [ 98.68269006, 27.50881216 ], [ 98.24623091, 27.74722138 ], [ 97.91198775, 28.33594514 ], [ 97.32711389, 28.26158275 ], [ 96.24883345, 28.41103099 ], [ 96.58659061, 28.83097952 ], [ 96.11767866, 29.45280203 ], [ 95.40480228, 29.03171662 ], [ 94.56599043, 29.27743806 ], [ 93.41334761, 28.64062938 ], [ 92.50311893, 27.89687633 ], [ 91.69665653, 27.77174185 ], [ 91.25885379, 28.04061433 ], [ 90.73051395, 28.06495393 ], [ 90.01582889, 28.2964385 ], [ 89.47581017, 28.0427589 ], [ 88.81424849, 27.2993159 ], [ 88.73032596, 28.08686473 ], [ 88.12044071, 27.87654165 ], [ 86.95451704, 27.97426179 ], [ 85.82331994, 28.20357595 ], [ 85.01163822, 28.64277395 ], [ 84.23457971, 28.8398937 ], [ 83.89899295, 29.32022614 ], [ 83.33711511, 29.46373159 ], [ 82.32751265, 30.11526805 ], [ 81.52580448, 30.42271699 ], [ 81.11125614, 30.18348094 ], [ 79.72136682, 30.88271475 ], [ 78.73889448, 31.51590607 ], [ 78.45844649, 32.61816437 ], [ 79.17612878, 32.48377981 ], [ 79.20889164, 32.99439464 ], [ 78.81108646, 33.50619803 ], [ 78.91226891, 34.32193635 ], [ 77.8374508, 35.49400951 ], [ 76.19284834, 35.89840343 ], [ 75.89689741, 36.66680614 ], [ 75.15802779, 37.13303091 ], [ 74.98000248, 37.41999014 ], [ 74.82998579, 37.99000703 ], [ 74.86481571, 38.37884634 ], [ 74.25751428, 38.60650686 ], [ 73.92885217, 38.50581533 ], [ 73.67537927, 39.43123688 ], [ 73.96001306, 39.66000845 ], [ 73.82224369, 39.8939735 ], [ 74.77686242, 40.36642528 ], [ 75.467828, 40.56207225 ], [ 76.52636804, 40.42794607 ], [ 76.90448449, 41.06648591 ], [ 78.18719689, 41.18531586 ], [ 78.54366092, 41.58224254 ], [ 80.11943037, 42.12394074 ], [ 80.25999027, 42.34999929 ], [ 80.18015018, 42.92006786 ], [ 80.8662065, 43.18036205 ], [ 79.9661064, 44.91751699 ], [ 81.94707075, 45.31702749 ], [ 82.45892582, 45.53964956 ], [ 83.18048384, 47.33003124 ], [ 85.1642904, 47.00095572 ], [ 85.72048384, 47.45296947 ], [ 85.76823286, 48.45575064 ], [ 86.59877648, 48.54918163 ], [ 87.35997033, 49.21498078 ], [ 87.75126428, 49.29719798 ], [ 88.01383223, 48.5994628 ], [ 88.85429772, 48.06908173 ], [ 90.28082564, 47.6935491 ], [ 90.97080936, 46.88814606 ], [ 90.58576826, 45.71971609 ], [ 90.94553959, 45.28607331 ], [ 92.13389082, 45.115076 ], [ 93.48073368, 44.97547211 ], [ 94.68892866, 44.35233185 ], [ 95.30687544, 44.24133088 ], [ 95.76245487, 43.31944916 ], [ 96.34939579, 42.72563528 ], [ 97.45175744, 42.74888968 ], [ 99.5158175, 42.52469147 ], [ 100.84586551, 42.66380443 ], [ 101.8330404, 42.51487295 ], [ 103.31227827, 41.90746817 ], [ 104.52228194, 41.90834667 ], [ 104.96499393, 41.59740957 ], [ 106.12931563, 42.1343277 ], [ 107.74477258, 42.48151581 ], [ 109.24359582, 42.51944632 ], [ 110.41210331, 42.87123363 ], [ 111.12968224, 43.40683401 ], [ 111.82958784, 43.74311839 ], [ 111.66773726, 44.07317577 ], [ 111.34837691, 44.45744172 ], [ 111.87330611, 45.10207937 ], [ 112.43606245, 45.01164562 ], [ 113.46390669, 44.80889313 ], [ 114.46033166, 45.3398168 ], [ 115.98509647, 45.72723501 ], [ 116.71786828, 46.38820242 ], [ 117.42170129, 46.67273286 ], [ 118.8743258, 46.8054121 ], [ 119.66326989, 46.69267996 ], [ 119.77282393, 47.04805878 ], [ 118.86657433, 47.74706004 ], [ 118.06414269, 48.06673046 ], [ 117.29550744, 47.69770905 ], [ 116.30895267, 47.85341014 ], [ 115.74283736, 47.7265445 ], [ 115.48528202, 48.1353826 ], [ 116.1918022, 49.13459809 ], [ 116.6788009, 49.8885314 ], [ 117.87924442, 49.51098338 ], [ 119.28846073, 50.1428828 ], [ 119.27936568, 50.58290762 ], [ 120.1820496, 51.64356639 ], [ 120.73819136, 51.9641153 ], [ 120.72578902, 52.5162263 ], [ 120.17708866, 52.75388622 ], [ 121.00308475, 53.25140107 ], [ 122.24574792, 53.43172598 ], [ 123.57150679, 53.45880443 ], [ 125.0682113, 53.16104483 ], [ 125.94634891, 52.79279857 ], [ 126.56439904, 51.78425548 ], [ 126.93915653, 51.35389415 ], [ 127.28745568, 50.73979727 ], [ 127.65740726, 49.76027049 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Ivory Coast", "sov_a3": "CIV", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Ivory Coast", "adm0_a3": "CIV", "geou_dif": 0.000000, "geounit": "Ivory Coast", "gu_a3": "CIV", "su_dif": 0.000000, "subunit": "Ivory Coast", "su_a3": "CIV", "brk_diff": 0.000000, "name": "Ce d'Ivoire", "name_long": "Ce d'Ivoire", "brk_a3": "CIV", "brk_name": "Ce d'Ivoire", "brk_group": null, "abbrev": "I.C.", "postal": "CI", "formal_en": "Republic of Ivory Coast", "formal_fr": "Republic of Cote D'Ivoire", "note_adm0": null, "note_brk": null, "name_sort": "Ce d'Ivoire", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 6.000000, "mapcolor9": 3.000000, "mapcolor13": 3.000000, "pop_est": 20617068.000000, "gdp_md_est": 33850.000000, "pop_year": -99.000000, "lastcensus": 1998.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "CI", "iso_a3": "CIV", "iso_n3": "384", "un_a3": "384", "wb_a2": "CI", "wb_a3": "CIV", "woe_id": -99.000000, "adm0_a3_is": "CIV", "adm0_a3_us": "CIV", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Western Africa", "region_wb": "Sub-Saharan Africa", "name_len": 13.000000, "long_len": 13.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -5.4043416, 10.3707368 ], [ -4.95465329, 10.15271393 ], [ -4.77988359, 9.82198477 ], [ -4.33024695, 9.61083487 ], [ -3.98044918, 9.86234406 ], [ -3.51189897, 9.90032624 ], [ -2.8274963, 9.64246084 ], [ -2.5621895, 8.21962779 ], [ -2.98358497, 7.3797049 ], [ -3.24437008, 6.2504715 ], [ -2.81070146, 5.38905122 ], [ -2.85612505, 4.99447582 ], [ -3.31108436, 4.98429556 ], [ -4.00881955, 5.17981334 ], [ -4.64991736, 5.16826366 ], [ -5.83449622, 4.99370067 ], [ -6.52876909, 4.7050878 ], [ -7.51894121, 4.33828848 ], [ -7.71215939, 4.36456594 ], [ -7.63536821, 5.18815908 ], [ -7.53971514, 5.31334524 ], [ -7.57015255, 5.7073522 ], [ -7.99369259, 6.12618968 ], [ -8.31134762, 6.19303315 ], [ -8.60288021, 6.4675642 ], [ -8.38545163, 6.91180065 ], [ -8.48544552, 7.39520783 ], [ -8.43929847, 7.68604279 ], [ -8.2807035, 7.68717967 ], [ -8.22179236, 8.12332876 ], [ -8.29904863, 8.31644359 ], [ -8.20349891, 8.45545319 ], [ -7.83210039, 8.57570425 ], [ -8.07911374, 9.37622386 ], [ -8.30961646, 9.78953197 ], [ -8.22933712, 10.12902029 ], [ -8.02994361, 10.20653494 ], [ -7.89958981, 10.29738211 ], [ -7.62275916, 10.14723623 ], [ -6.85050656, 10.13899384 ], [ -6.66646094, 10.43081066 ], [ -6.49396501, 10.4113028 ], [ -6.20522295, 10.52406078 ], [ -6.05045203, 10.09636079 ], [ -5.81692624, 10.22255463 ], [ -5.4043416, 10.3707368 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Cameroon", "sov_a3": "CMR", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Cameroon", "adm0_a3": "CMR", "geou_dif": 0.000000, "geounit": "Cameroon", "gu_a3": "CMR", "su_dif": 0.000000, "subunit": "Cameroon", "su_a3": "CMR", "brk_diff": 0.000000, "name": "Cameroon", "name_long": "Cameroon", "brk_a3": "CMR", "brk_name": "Cameroon", "brk_group": null, "abbrev": "Cam.", "postal": "CM", "formal_en": "Republic of Cameroon", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Cameroon", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 4.000000, "mapcolor9": 1.000000, "mapcolor13": 3.000000, "pop_est": 18879301.000000, "gdp_md_est": 42750.000000, "pop_year": -99.000000, "lastcensus": 2005.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "CM", "iso_a3": "CMR", "iso_n3": "120", "un_a3": "120", "wb_a2": "CM", "wb_a3": "CMR", "woe_id": -99.000000, "adm0_a3_is": "CMR", "adm0_a3_us": "CMR", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Middle Africa", "region_wb": "Sub-Saharan Africa", "name_len": 8.000000, "long_len": 8.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 14.92356489, 10.89132518 ], [ 15.46787276, 9.98233674 ], [ 14.90935388, 9.99212942 ], [ 14.62720056, 9.9209193 ], [ 14.1714661, 10.02137828 ], [ 13.95421838, 9.54949494 ], [ 14.54446659, 8.96586131 ], [ 14.97999556, 8.79610423 ], [ 15.12086551, 8.38215017 ], [ 15.43609175, 7.6928124 ], [ 15.27946048, 7.42192455 ], [ 14.77654544, 6.40849803 ], [ 14.53656009, 6.22695873 ], [ 14.45940718, 5.45176057 ], [ 14.55893599, 5.03059764 ], [ 14.47837243, 4.7326055 ], [ 14.9509534, 4.21038931 ], [ 15.03621952, 3.8513673 ], [ 15.40539595, 3.3353006 ], [ 15.86273237, 3.0135373 ], [ 15.90738081, 2.55738943 ], [ 16.01285241, 2.26763968 ], [ 15.94091882, 1.72767263 ], [ 15.14634199, 1.9640148 ], [ 14.33781253, 2.22787466 ], [ 13.07582238, 2.26709707 ], [ 12.95133386, 2.32161571 ], [ 12.35938032, 2.1928122 ], [ 11.75166548, 2.32675751 ], [ 11.27644901, 2.26105093 ], [ 9.64915816, 2.28386608 ], [ 9.79519575, 3.07340445 ], [ 9.4043669, 3.73452688 ], [ 8.94811568, 3.90412893 ], [ 8.74492394, 4.35221528 ], [ 8.48881555, 4.49561738 ], [ 8.50028771, 4.77198294 ], [ 8.75753299, 5.47966584 ], [ 9.23316288, 6.44449067 ], [ 9.52270593, 6.45348237 ], [ 10.11827681, 7.03876964 ], [ 10.49737512, 7.05535777 ], [ 11.05878788, 6.64442678 ], [ 11.74577437, 6.98138296 ], [ 11.83930871, 7.39704234 ], [ 12.06394616, 7.79980846 ], [ 12.2188721, 8.30582408 ], [ 12.7536715, 8.71776276 ], [ 12.95546797, 9.41777171 ], [ 13.16759972, 9.64062633 ], [ 13.30867639, 10.16036205 ], [ 13.57294966, 10.79856599 ], [ 14.41537886, 11.57236888 ], [ 14.46819217, 11.9047517 ], [ 14.57717777, 12.08536083 ], [ 14.1813363, 12.48365693 ], [ 14.21353071, 12.80203543 ], [ 14.49578739, 12.85939627 ], [ 14.89338586, 12.21904776 ], [ 14.96015181, 11.55557404 ], [ 14.92356489, 10.89132518 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Democratic Republic of the Congo", "sov_a3": "COD", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Democratic Republic of the Congo", "adm0_a3": "COD", "geou_dif": 0.000000, "geounit": "Democratic Republic of the Congo", "gu_a3": "COD", "su_dif": 0.000000, "subunit": "Democratic Republic of the Congo", "su_a3": "COD", "brk_diff": 0.000000, "name": "Dem. Rep. Congo", "name_long": "Democratic Republic of the Congo", "brk_a3": "COD", "brk_name": "Democratic Republic of the Congo", "brk_group": null, "abbrev": "D.R.C.", "postal": "DRC", "formal_en": "Democratic Republic of the Congo", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Congo, Dem. Rep.", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 4.000000, "mapcolor9": 4.000000, "mapcolor13": 7.000000, "pop_est": 68692542.000000, "gdp_md_est": 20640.000000, "pop_year": -99.000000, "lastcensus": 1984.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "CD", "iso_a3": "COD", "iso_n3": "180", "un_a3": "180", "wb_a2": "ZR", "wb_a3": "ZAR", "woe_id": -99.000000, "adm0_a3_is": "COD", "adm0_a3_us": "COD", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Middle Africa", "region_wb": "Sub-Saharan Africa", "name_len": 15.000000, "long_len": 32.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 26.40276086, 5.15087454 ], [ 27.04406538, 5.12785269 ], [ 27.37422611, 5.2339444 ], [ 27.97997725, 4.4084134 ], [ 28.42899377, 4.28715465 ], [ 28.69667769, 4.45507722 ], [ 29.1590784, 4.38926728 ], [ 29.71599531, 4.60080476 ], [ 29.9535002, 4.17369904 ], [ 30.83385242, 3.5091716 ], [ 30.8338599, 3.50916596 ], [ 30.7733468, 2.33988333 ], [ 31.1741492, 2.20446524 ], [ 30.85267012, 1.84939647 ], [ 30.46850752, 1.58380545 ], [ 30.0861536, 1.06231273 ], [ 29.87577884, 0.59737987 ], [ 29.81950321, -0.20531015 ], [ 29.58783776, -0.58740569 ], [ 29.57946618, -1.34131316 ], [ 29.29188683, -1.62005584 ], [ 29.25483483, -2.21510996 ], [ 29.11747888, -2.2922112 ], [ 29.02492639, -2.83925791 ], [ 29.2763839, -3.29390716 ], [ 29.28552136, -3.4671476 ], [ 29.28103478, -3.45549936 ], [ 29.10171756, -5.05400644 ], [ 29.3719853, -5.61645273 ], [ 29.19318485, -6.03802907 ], [ 29.53652306, -6.75416107 ], [ 30.14702844, -7.29924407 ], [ 30.2773564, -7.84835784 ], [ 30.56684777, -8.11500823 ], [ 30.52177417, -8.28363628 ], [ 30.34608605, -8.23825652 ], [ 29.00291223, -8.40703175 ], [ 28.73486657, -8.52655934 ], [ 28.44987105, -9.16491831 ], [ 28.67368167, -9.60592498 ], [ 28.49606978, -10.78988372 ], [ 28.37225305, -11.79364674 ], [ 28.64241743, -11.9715687 ], [ 29.34154789, -12.36074391 ], [ 29.61600142, -12.17889455 ], [ 29.69961389, -13.25722666 ], [ 28.93428592, -13.24895843 ], [ 28.52356164, -12.69860442 ], [ 28.15510868, -12.27248056 ], [ 27.38879886, -12.13274749 ], [ 27.16441979, -11.60874847 ], [ 26.5530876, -11.92443979 ], [ 25.7523096, -11.7849651 ], [ 25.41811812, -11.33093597 ], [ 24.78316979, -11.23869354 ], [ 24.31451623, -11.26282643 ], [ 24.25715539, -10.95199269 ], [ 23.9122152, -10.92682627 ], [ 23.45679081, -10.86786346 ], [ 22.83734541, -11.01762176 ], [ 22.40279829, -10.99307545 ], [ 22.15526818, -11.08480112 ], [ 22.20875329, -9.89479624 ], [ 21.87518192, -9.52370778 ], [ 21.80180139, -8.90870656 ], [ 21.94913089, -8.30590097 ], [ 21.74645593, -7.92008473 ], [ 21.72811079, -7.29087249 ], [ 20.51474816, -7.29960581 ], [ 20.60182295, -6.93931772 ], [ 20.09162153, -6.9430901 ], [ 20.03772302, -7.11636118 ], [ 19.41750248, -7.15542856 ], [ 19.1666134, -7.73818369 ], [ 19.01675174, -7.98824594 ], [ 18.46417565, -7.84701426 ], [ 18.13422163, -7.9876775 ], [ 17.47297, -8.06855112 ], [ 17.08999597, -7.54568898 ], [ 16.86019087, -7.22229787 ], [ 16.57317997, -6.62264455 ], [ 16.32652835, -5.87747039 ], [ 13.37559736, -5.86424122 ], [ 13.02486942, -5.98438893 ], [ 12.73517134, -5.96568206 ], [ 12.32243167, -6.10009246 ], [ 12.18233687, -5.78993052 ], [ 12.43668827, -5.68430389 ], [ 12.46800418, -5.2483615 ], [ 12.63161177, -4.99127125 ], [ 12.99551721, -4.7811032 ], [ 13.25824019, -4.88295745 ], [ 13.60023482, -4.50013844 ], [ 14.14495609, -4.51000864 ], [ 14.20903486, -4.79309214 ], [ 14.58260379, -4.97023895 ], [ 15.17099165, -4.34350718 ], [ 15.75354007, -3.85516489 ], [ 16.0062895, -3.53513274 ], [ 15.97280318, -2.71239227 ], [ 16.40709191, -1.74092702 ], [ 16.86530684, -1.22581634 ], [ 17.52371626, -0.74383025 ], [ 17.63864465, -0.42483164 ], [ 17.66355269, -0.058084 ], [ 17.82654015, 0.28892324 ], [ 17.77419193, 0.85565868 ], [ 17.89883548, 1.74183198 ], [ 18.09427575, 2.36572154 ], [ 18.39379235, 2.90044343 ], [ 18.45306522, 3.50438589 ], [ 18.54298221, 4.20178518 ], [ 18.93231245, 4.70950613 ], [ 19.46778364, 5.03152782 ], [ 20.29067915, 4.69167776 ], [ 20.92759118, 4.32278555 ], [ 21.65912276, 4.22434195 ], [ 22.40512373, 4.02916006 ], [ 22.70412357, 4.63305085 ], [ 22.84147953, 4.71012625 ], [ 23.29721398, 4.6096931 ], [ 24.41053104, 5.10878408 ], [ 24.80502892, 4.89724661 ], [ 25.12883345, 4.92724478 ], [ 25.27879846, 5.17040823 ], [ 25.65045536, 5.25608775 ], [ 26.40276086, 5.15087454 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Republic of Congo", "sov_a3": "COG", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Republic of Congo", "adm0_a3": "COG", "geou_dif": 0.000000, "geounit": "Republic of Congo", "gu_a3": "COG", "su_dif": 0.000000, "subunit": "Republic of Congo", "su_a3": "COG", "brk_diff": 0.000000, "name": "Congo", "name_long": "Republic of Congo", "brk_a3": "COG", "brk_name": "Republic of Congo", "brk_group": null, "abbrev": "Rep. Congo", "postal": "CG", "formal_en": "Republic of Congo", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Congo, Rep.", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 1.000000, "mapcolor9": 3.000000, "mapcolor13": 10.000000, "pop_est": 4012809.000000, "gdp_md_est": 15350.000000, "pop_year": -99.000000, "lastcensus": 2007.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "CG", "iso_a3": "COG", "iso_n3": "178", "un_a3": "178", "wb_a2": "CG", "wb_a3": "COG", "woe_id": -99.000000, "adm0_a3_is": "COG", "adm0_a3_us": "COG", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Middle Africa", "region_wb": "Sub-Saharan Africa", "name_len": 5.000000, "long_len": 17.000000, "abbrev_len": 10.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 18.45306522, 3.50438589 ], [ 18.39379235, 2.90044343 ], [ 18.09427575, 2.36572154 ], [ 17.89883548, 1.74183198 ], [ 17.77419193, 0.85565868 ], [ 17.82654015, 0.28892324 ], [ 17.66355269, -0.058084 ], [ 17.63864465, -0.42483164 ], [ 17.52371626, -0.74383025 ], [ 16.86530684, -1.22581634 ], [ 16.40709191, -1.74092702 ], [ 15.97280318, -2.71239227 ], [ 16.0062895, -3.53513274 ], [ 15.75354007, -3.85516489 ], [ 15.17099165, -4.34350718 ], [ 14.58260379, -4.97023895 ], [ 14.20903486, -4.79309214 ], [ 14.14495609, -4.51000864 ], [ 13.60023482, -4.50013844 ], [ 13.25824019, -4.88295745 ], [ 12.99551721, -4.7811032 ], [ 12.62075972, -4.43802337 ], [ 12.31860762, -4.60623016 ], [ 11.91496301, -5.03798675 ], [ 11.09377282, -3.97882659 ], [ 11.8551217, -3.42687062 ], [ 11.47803877, -2.76561899 ], [ 11.82096358, -2.51416147 ], [ 12.49570275, -2.39168833 ], [ 12.57528446, -1.94851124 ], [ 13.10961877, -2.42874033 ], [ 13.99240726, -2.47080495 ], [ 14.29921024, -1.99827565 ], [ 14.42545576, -1.33340667 ], [ 14.31641849, -0.55262746 ], [ 13.84332075, 0.03875764 ], [ 14.2762659, 1.19692984 ], [ 14.02666874, 1.3956774 ], [ 13.28263146, 1.31418366 ], [ 13.00311364, 1.83089631 ], [ 13.07582238, 2.26709707 ], [ 14.33781253, 2.22787466 ], [ 15.14634199, 1.9640148 ], [ 15.94091882, 1.72767263 ], [ 16.01285241, 2.26763968 ], [ 16.53705814, 3.19825471 ], [ 17.13304243, 3.72819652 ], [ 17.80990034, 3.56019644 ], [ 18.45306522, 3.50438589 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Colombia", "sov_a3": "COL", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Colombia", "adm0_a3": "COL", "geou_dif": 0.000000, "geounit": "Colombia", "gu_a3": "COL", "su_dif": 0.000000, "subunit": "Colombia", "su_a3": "COL", "brk_diff": 0.000000, "name": "Colombia", "name_long": "Colombia", "brk_a3": "COL", "brk_name": "Colombia", "brk_group": null, "abbrev": "Col.", "postal": "CO", "formal_en": "Republic of Colombia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Colombia", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 1.000000, "mapcolor9": 3.000000, "mapcolor13": 1.000000, "pop_est": 45644023.000000, "gdp_md_est": 395400.000000, "pop_year": -99.000000, "lastcensus": 2006.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "CO", "iso_a3": "COL", "iso_n3": "170", "un_a3": "170", "wb_a2": "CO", "wb_a3": "COL", "woe_id": -99.000000, "adm0_a3_is": "COL", "adm0_a3_us": "COL", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "South America", "region_un": "Americas", "subregion": "South America", "region_wb": "Latin America & Caribbean", "name_len": 8.000000, "long_len": 8.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -71.33158362, 11.77628408 ], [ -71.97392168, 11.60867158 ], [ -72.22757545, 11.10870209 ], [ -72.61465776, 10.82197541 ], [ -72.90528602, 10.45034435 ], [ -73.02760413, 9.73677033 ], [ -73.30495154, 9.15199982 ], [ -72.78872982, 9.08502717 ], [ -72.66049476, 8.62528779 ], [ -72.43986223, 8.40527538 ], [ -72.36090064, 8.00263845 ], [ -72.47967892, 7.63250601 ], [ -72.44448727, 7.4237849 ], [ -72.19835242, 7.34043081 ], [ -71.96017575, 6.9916149 ], [ -70.67423357, 7.08778474 ], [ -70.09331295, 6.96037649 ], [ -69.38947995, 6.09986054 ], [ -68.98531857, 6.20680492 ], [ -68.26505246, 6.15326813 ], [ -67.69508725, 6.26731802 ], [ -67.34143958, 6.09546804 ], [ -67.52153195, 5.55687043 ], [ -67.74469662, 5.22112865 ], [ -67.82301225, 4.50393728 ], [ -67.6218359, 3.83948172 ], [ -67.33756385, 3.54234223 ], [ -67.30317318, 3.31845409 ], [ -67.80993812, 2.82065502 ], [ -67.44709205, 2.60028087 ], [ -67.18129432, 2.25063813 ], [ -66.87632585, 1.2533605 ], [ -67.06504818, 1.13011221 ], [ -67.25999752, 1.71999868 ], [ -67.53781002, 2.03716279 ], [ -67.86856503, 1.69245515 ], [ -69.81697323, 1.7148052 ], [ -69.80459673, 1.08908112 ], [ -69.21863766, 0.98567658 ], [ -69.25243405, 0.60265087 ], [ -69.452396, 0.70615876 ], [ -70.01556576, 0.54141429 ], [ -70.02065589, -0.18515635 ], [ -69.5770654, -0.54999196 ], [ -69.42048581, -1.1226185 ], [ -69.44410194, -1.55628712 ], [ -69.89363522, -4.29818694 ], [ -70.39404395, -3.76659149 ], [ -70.69268205, -3.742872 ], [ -70.0477085, -2.72515635 ], [ -70.81347571, -2.25686452 ], [ -71.4136458, -2.34280242 ], [ -71.77476071, -2.16978973 ], [ -72.32578651, -2.43421803 ], [ -73.07039222, -2.30895436 ], [ -73.65950355, -1.26049122 ], [ -74.12239519, -1.00283253 ], [ -74.44160051, -0.53082 ], [ -75.10662452, -0.0572055 ], [ -75.37322323, -0.15203175 ], [ -75.80146583, 0.08480134 ], [ -76.29231442, 0.41604727 ], [ -76.57637977, 0.25693553 ], [ -77.4249843, 0.39568675 ], [ -77.66861284, 0.82589305 ], [ -77.85506141, 0.80992503 ], [ -78.85525876, 1.38092377 ], [ -78.99093523, 1.69136994 ], [ -78.61783139, 1.76640412 ], [ -78.66211809, 2.26735545 ], [ -78.42761044, 2.62955557 ], [ -77.93154253, 2.69660574 ], [ -77.51043128, 3.32501699 ], [ -77.12768979, 3.84963614 ], [ -77.49627194, 4.08760611 ], [ -77.30760128, 4.66798412 ], [ -77.53322059, 5.582812 ], [ -77.31881507, 5.84535411 ], [ -77.47666073, 6.69111644 ], [ -77.88157142, 7.22377127 ], [ -77.75341387, 7.70983979 ], [ -77.43110796, 7.63806122 ], [ -77.24256649, 7.93527823 ], [ -77.47472287, 8.5242862 ], [ -77.35336077, 8.67050467 ], [ -76.83667396, 8.6387495 ], [ -76.08638384, 9.33682058 ], [ -75.67460019, 9.4432482 ], [ -75.66470415, 9.7740032 ], [ -75.48042599, 10.61899038 ], [ -74.90689511, 11.08304475 ], [ -74.27675269, 11.10203583 ], [ -74.19722266, 11.31047272 ], [ -73.41476396, 11.22701529 ], [ -72.62783525, 11.73197154 ], [ -72.23819495, 11.95554963 ], [ -71.75409014, 12.43730317 ], [ -71.39982235, 12.37604076 ], [ -71.13746111, 12.11298188 ], [ -71.33158362, 11.77628408 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Costa Rica", "sov_a3": "CRI", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Costa Rica", "adm0_a3": "CRI", "geou_dif": 0.000000, "geounit": "Costa Rica", "gu_a3": "CRI", "su_dif": 0.000000, "subunit": "Costa Rica", "su_a3": "CRI", "brk_diff": 0.000000, "name": "Costa Rica", "name_long": "Costa Rica", "brk_a3": "CRI", "brk_name": "Costa Rica", "brk_group": null, "abbrev": "C.R.", "postal": "CR", "formal_en": "Republic of Costa Rica", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Costa Rica", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 2.000000, "mapcolor9": 4.000000, "mapcolor13": 2.000000, "pop_est": 4253877.000000, "gdp_md_est": 48320.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "5. Emerging region: G20", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "CR", "iso_a3": "CRI", "iso_n3": "188", "un_a3": "188", "wb_a2": "CR", "wb_a3": "CRI", "woe_id": -99.000000, "adm0_a3_is": "CRI", "adm0_a3_us": "CRI", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "North America", "region_un": "Americas", "subregion": "Central America", "region_wb": "Latin America & Caribbean", "name_len": 10.000000, "long_len": 10.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -83.65561174, 10.93876415 ], [ -83.40231971, 10.39543814 ], [ -83.01567664, 9.99298208 ], [ -82.54619626, 9.56613475 ], [ -82.932891, 9.47681204 ], [ -82.92715491, 9.07433015 ], [ -82.71918311, 8.92570873 ], [ -82.86865719, 8.80726634 ], [ -82.82977068, 8.62629548 ], [ -82.91317644, 8.42351716 ], [ -82.96578305, 8.22502798 ], [ -83.50843726, 8.44692658 ], [ -83.71147397, 8.65683625 ], [ -83.59631304, 8.83044322 ], [ -83.63264157, 9.05138581 ], [ -83.90988563, 9.29080272 ], [ -84.30340166, 9.48735403 ], [ -84.64764421, 9.61553742 ], [ -84.7133508, 9.90805187 ], [ -84.97566037, 10.08672313 ], [ -84.91137488, 9.79599152 ], [ -85.11092343, 9.5570397 ], [ -85.33948829, 9.83454214 ], [ -85.66078651, 9.93334748 ], [ -85.79744483, 10.13488557 ], [ -85.79170875, 10.43933727 ], [ -85.65931373, 10.75433096 ], [ -85.94172543, 10.89527843 ], [ -85.71254045, 11.08844493 ], [ -85.56185198, 11.21711925 ], [ -84.9030033, 10.95230337 ], [ -84.67306902, 11.08265717 ], [ -84.35593075, 10.99922557 ], [ -84.1901786, 10.79345002 ], [ -83.89505449, 10.7268391 ], [ -83.65561174, 10.93876415 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Cuba", "sov_a3": "CUB", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Cuba", "adm0_a3": "CUB", "geou_dif": 0.000000, "geounit": "Cuba", "gu_a3": "CUB", "su_dif": 0.000000, "subunit": "Cuba", "su_a3": "CUB", "brk_diff": 0.000000, "name": "Cuba", "name_long": "Cuba", "brk_a3": "CUB", "brk_name": "Cuba", "brk_group": null, "abbrev": "Cuba", "postal": "CU", "formal_en": "Republic of Cuba", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Cuba", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 5.000000, "mapcolor9": 3.000000, "mapcolor13": 4.000000, "pop_est": 11451652.000000, "gdp_md_est": 108200.000000, "pop_year": -99.000000, "lastcensus": 2002.000000, "gdp_year": -99.000000, "economy": "5. Emerging region: G20", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "CU", "iso_a3": "CUB", "iso_n3": "192", "un_a3": "192", "wb_a2": "CU", "wb_a3": "CUB", "woe_id": -99.000000, "adm0_a3_is": "CUB", "adm0_a3_us": "CUB", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "North America", "region_un": "Americas", "subregion": "Caribbean", "region_wb": "Latin America & Caribbean", "name_len": 4.000000, "long_len": 4.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -79.67952369, 22.76530325 ], [ -79.28148597, 22.39920157 ], [ -78.34743446, 22.51216625 ], [ -77.99329586, 22.27719351 ], [ -77.14642249, 21.65785147 ], [ -76.52382484, 21.20681957 ], [ -76.19462012, 21.2205655 ], [ -75.59822242, 21.01662446 ], [ -75.67106035, 20.73509125 ], [ -74.93389604, 20.69390514 ], [ -74.17802487, 20.28462779 ], [ -74.29664812, 20.05037853 ], [ -74.96159461, 19.92343537 ], [ -75.63468014, 19.87377432 ], [ -76.32365618, 19.95289094 ], [ -77.75548092, 19.85548086 ], [ -77.08510841, 20.41335379 ], [ -77.49265459, 20.67310537 ], [ -78.13729224, 20.73994884 ], [ -78.48282671, 21.02861339 ], [ -78.7198665, 21.59811351 ], [ -79.28499997, 21.55917532 ], [ -80.21747535, 21.82732433 ], [ -80.51753455, 22.03707897 ], [ -81.82094337, 22.19205659 ], [ -82.16999183, 22.38710928 ], [ -81.7950018, 22.63696483 ], [ -82.775898, 22.68815034 ], [ -83.49445879, 22.16851797 ], [ -83.90880042, 22.15456533 ], [ -84.05215085, 21.91057506 ], [ -84.5470302, 21.80122773 ], [ -84.97491106, 21.89602814 ], [ -84.44706214, 22.20494986 ], [ -84.23035702, 22.56575471 ], [ -83.77823992, 22.78811839 ], [ -83.26754757, 22.9830419 ], [ -82.51043616, 23.07874665 ], [ -82.26815121, 23.18861074 ], [ -81.40445716, 23.11727143 ], [ -80.61876868, 23.10598013 ], [ -79.67952369, 22.76530325 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Northern Cyprus", "sov_a3": "CYN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Northern Cyprus", "adm0_a3": "CYN", "geou_dif": 0.000000, "geounit": "Northern Cyprus", "gu_a3": "CYN", "su_dif": 0.000000, "subunit": "Northern Cyprus", "su_a3": "CYN", "brk_diff": 1.000000, "name": "N. Cyprus", "name_long": "Northern Cyprus", "brk_a3": "B20", "brk_name": "N. Cyprus", "brk_group": null, "abbrev": "N. Cy.", "postal": "CN", "formal_en": "Turkish Republic of Northern Cyprus", "formal_fr": null, "note_adm0": "Self admin.", "note_brk": "Self admin.; Claimed by Cyprus", "name_sort": "Cyprus, Northern", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 1.000000, "mapcolor9": 4.000000, "mapcolor13": 8.000000, "pop_est": 265100.000000, "gdp_md_est": 3600.000000, "pop_year": -99.000000, "lastcensus": -99.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "-99", "iso_a3": "-99", "iso_n3": "-99", "un_a3": "-099", "wb_a2": "-99", "wb_a3": "-99", "woe_id": -99.000000, "adm0_a3_is": "CYP", "adm0_a3_us": "CYP", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Western Asia", "region_wb": "Europe & Central Asia", "name_len": 9.000000, "long_len": 15.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 33.97361657, 35.05850637 ], [ 33.86643965, 35.09359467 ], [ 33.67539188, 35.01786286 ], [ 33.52568526, 35.03868846 ], [ 33.4758175, 35.00034455 ], [ 33.45592207, 35.10142365 ], [ 33.38383345, 35.1627119 ], [ 33.190977, 35.1731247 ], [ 32.91957238, 35.08783275 ], [ 32.73178023, 35.14002595 ], [ 32.80247359, 35.14550365 ], [ 32.94696089, 35.3867034 ], [ 33.667227, 35.37321585 ], [ 34.57647383, 35.67159557 ], [ 33.90080448, 35.24575593 ], [ 33.97361657, 35.05850637 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Cyprus", "sov_a3": "CYP", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Cyprus", "adm0_a3": "CYP", "geou_dif": 0.000000, "geounit": "Cyprus", "gu_a3": "CYP", "su_dif": 0.000000, "subunit": "Cyprus", "su_a3": "CYP", "brk_diff": 0.000000, "name": "Cyprus", "name_long": "Cyprus", "brk_a3": "CYP", "brk_name": "Cyprus", "brk_group": null, "abbrev": "Cyp.", "postal": "CY", "formal_en": "Republic of Cyprus", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Cyprus", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 2.000000, "mapcolor9": 3.000000, "mapcolor13": 7.000000, "pop_est": 531640.000000, "gdp_md_est": 22700.000000, "pop_year": -99.000000, "lastcensus": 2001.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "2. High income: nonOECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "CY", "iso_a3": "CYP", "iso_n3": "196", "un_a3": "196", "wb_a2": "CY", "wb_a3": "CYP", "woe_id": -99.000000, "adm0_a3_is": "CYP", "adm0_a3_us": "CYP", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Western Asia", "region_wb": "Europe & Central Asia", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 33.97361657, 35.05850637 ], [ 34.00488081, 34.97809785 ], [ 32.9798271, 34.57186941 ], [ 32.49029626, 34.70165477 ], [ 32.25666711, 35.10323233 ], [ 32.73178023, 35.14002595 ], [ 32.91957238, 35.08783275 ], [ 33.190977, 35.1731247 ], [ 33.38383345, 35.1627119 ], [ 33.45592207, 35.10142365 ], [ 33.4758175, 35.00034455 ], [ 33.52568526, 35.03868846 ], [ 33.67539188, 35.01786286 ], [ 33.86643965, 35.09359467 ], [ 33.97361657, 35.05850637 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Czech Republic", "sov_a3": "CZE", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Czech Republic", "adm0_a3": "CZE", "geou_dif": 0.000000, "geounit": "Czech Republic", "gu_a3": "CZE", "su_dif": 0.000000, "subunit": "Czech Republic", "su_a3": "CZE", "brk_diff": 0.000000, "name": "Czech Rep.", "name_long": "Czech Republic", "brk_a3": "CZE", "brk_name": "Czech Rep.", "brk_group": null, "abbrev": "Cz. Rep.", "postal": "CZ", "formal_en": "Czech Republic", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Czech Republic", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 1.000000, "mapcolor9": 2.000000, "mapcolor13": 6.000000, "pop_est": 10211904.000000, "gdp_md_est": 265200.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "CZ", "iso_a3": "CZE", "iso_n3": "203", "un_a3": "203", "wb_a2": "CZ", "wb_a3": "CZE", "woe_id": -99.000000, "adm0_a3_is": "CZE", "adm0_a3_us": "CZE", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Eastern Europe", "region_wb": "Europe & Central Asia", "name_len": 10.000000, "long_len": 14.000000, "abbrev_len": 8.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 15.01699588, 51.1066741 ], [ 15.49097212, 50.78472993 ], [ 16.23862674, 50.69773265 ], [ 16.17625329, 50.42260733 ], [ 16.71947595, 50.21574657 ], [ 16.86876916, 50.4739737 ], [ 17.55456709, 50.3621459 ], [ 17.64944502, 50.0490384 ], [ 18.39291385, 49.98862865 ], [ 18.85314416, 49.49622976 ], [ 18.55497114, 49.49501537 ], [ 18.39999352, 49.31500052 ], [ 18.17049849, 49.2715148 ], [ 18.10497277, 49.04398347 ], [ 17.91351159, 48.99649282 ], [ 17.88648482, 48.90347525 ], [ 17.54500695, 48.80001903 ], [ 17.1019849, 48.8169689 ], [ 16.96028812, 48.59698233 ], [ 16.49928267, 48.78580801 ], [ 16.02964725, 48.73389903 ], [ 15.25341556, 49.03907421 ], [ 14.90144738, 48.96440176 ], [ 14.33889774, 48.55530528 ], [ 13.59594567, 48.87717194 ], [ 13.03132897, 49.30706818 ], [ 12.5210242, 49.54741527 ], [ 12.41519087, 49.9691208 ], [ 12.24011112, 50.2663378 ], [ 12.96683679, 50.48407644 ], [ 13.33813195, 50.73323436 ], [ 14.05622765, 50.92691763 ], [ 14.30701338, 51.11726777 ], [ 14.57071821, 51.00233938 ], [ 15.01699588, 51.1066741 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Germany", "sov_a3": "DEU", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Germany", "adm0_a3": "DEU", "geou_dif": 0.000000, "geounit": "Germany", "gu_a3": "DEU", "su_dif": 0.000000, "subunit": "Germany", "su_a3": "DEU", "brk_diff": 0.000000, "name": "Germany", "name_long": "Germany", "brk_a3": "DEU", "brk_name": "Germany", "brk_group": null, "abbrev": "Ger.", "postal": "D", "formal_en": "Federal Republic of Germany", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Germany", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 5.000000, "mapcolor9": 5.000000, "mapcolor13": 1.000000, "pop_est": 82329758.000000, "gdp_md_est": 2918000.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "1. Developed region: G7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "DE", "iso_a3": "DEU", "iso_n3": "276", "un_a3": "276", "wb_a2": "DE", "wb_a3": "DEU", "woe_id": -99.000000, "adm0_a3_is": "DEU", "adm0_a3_us": "DEU", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Western Europe", "region_wb": "Europe & Central Asia", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 14.11968631, 53.75702912 ], [ 14.35331546, 53.24817129 ], [ 14.07452111, 52.98126252 ], [ 14.43759973, 52.62485017 ], [ 14.68502648, 52.08994741 ], [ 14.60709842, 51.7451881 ], [ 15.01699588, 51.1066741 ], [ 14.57071821, 51.00233938 ], [ 14.30701338, 51.11726777 ], [ 14.05622765, 50.92691763 ], [ 13.33813195, 50.73323436 ], [ 12.96683679, 50.48407644 ], [ 12.24011112, 50.2663378 ], [ 12.41519087, 49.9691208 ], [ 12.5210242, 49.54741527 ], [ 13.03132897, 49.30706818 ], [ 13.59594567, 48.87717194 ], [ 13.24335737, 48.41611481 ], [ 12.88410282, 48.28914582 ], [ 13.02585127, 47.63758352 ], [ 12.93262699, 47.46764558 ], [ 12.62075972, 47.6723876 ], [ 12.14135746, 47.7030834 ], [ 11.42641402, 47.52376618 ], [ 10.54450402, 47.56639924 ], [ 10.40208377, 47.3024877 ], [ 9.89606815, 47.58019685 ], [ 9.59422611, 47.52505809 ], [ 8.52261193, 47.83082754 ], [ 8.31730147, 47.61357982 ], [ 7.46675907, 47.62058198 ], [ 7.59367639, 48.33301911 ], [ 8.0992786, 49.01778352 ], [ 6.65822961, 49.20195832 ], [ 6.18632043, 49.4638028 ], [ 6.24275109, 49.90222565 ], [ 6.04307336, 50.12805166 ], [ 6.15665816, 50.80372102 ], [ 5.98865807, 51.85161571 ], [ 6.5893966, 51.85202912 ], [ 6.8428695, 52.22844025 ], [ 7.09205326, 53.14404328 ], [ 6.9051396, 53.48216218 ], [ 7.10042484, 53.6939322 ], [ 7.93623945, 53.7482958 ], [ 8.12170617, 53.52779247 ], [ 8.80073449, 54.02078563 ], [ 8.57211795, 54.39564647 ], [ 8.52622928, 54.96274364 ], [ 9.28204878, 54.83086538 ], [ 9.92190637, 54.98310415 ], [ 9.93957971, 54.59664195 ], [ 10.95011234, 54.36360708 ], [ 10.93946699, 54.00869335 ], [ 11.95625248, 54.1964855 ], [ 12.51844038, 54.47037059 ], [ 13.64746708, 54.07551097 ], [ 14.11968631, 53.75702912 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Djibouti", "sov_a3": "DJI", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Djibouti", "adm0_a3": "DJI", "geou_dif": 0.000000, "geounit": "Djibouti", "gu_a3": "DJI", "su_dif": 0.000000, "subunit": "Djibouti", "su_a3": "DJI", "brk_diff": 0.000000, "name": "Djibouti", "name_long": "Djibouti", "brk_a3": "DJI", "brk_name": "Djibouti", "brk_group": null, "abbrev": "Dji.", "postal": "DJ", "formal_en": "Republic of Djibouti", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Djibouti", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 2.000000, "mapcolor9": 4.000000, "mapcolor13": 8.000000, "pop_est": 516055.000000, "gdp_md_est": 1885.000000, "pop_year": -99.000000, "lastcensus": 2009.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "DJ", "iso_a3": "DJI", "iso_n3": "262", "un_a3": "262", "wb_a2": "DJ", "wb_a3": "DJI", "woe_id": -99.000000, "adm0_a3_is": "DJI", "adm0_a3_us": "DJI", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Eastern Africa", "region_wb": "Middle East & North Africa", "name_len": 8.000000, "long_len": 8.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 43.1453048, 11.4620397 ], [ 42.77685184, 10.92687857 ], [ 42.55493, 11.10511 ], [ 42.31414, 11.0342 ], [ 41.75557, 11.05091 ], [ 41.73959, 11.35511 ], [ 41.66176, 11.6312 ], [ 42.0, 12.1 ], [ 42.35156, 12.54223 ], [ 42.77964237, 12.45541576 ], [ 43.08122603, 12.69963858 ], [ 43.31785241, 12.39014842 ], [ 43.28638146, 11.97492829 ], [ 42.71587365, 11.73564057 ], [ 43.1453048, 11.4620397 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Denmark", "sov_a3": "DN1", "adm0_dif": 1.000000, "level": 2.000000, "type": "Country", "admin": "Denmark", "adm0_a3": "DNK", "geou_dif": 0.000000, "geounit": "Denmark", "gu_a3": "DNK", "su_dif": 0.000000, "subunit": "Denmark", "su_a3": "DNK", "brk_diff": 0.000000, "name": "Denmark", "name_long": "Denmark", "brk_a3": "DNK", "brk_name": "Denmark", "brk_group": null, "abbrev": "Den.", "postal": "DK", "formal_en": "Kingdom of Denmark", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Denmark", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 1.000000, "mapcolor9": 3.000000, "mapcolor13": 12.000000, "pop_est": 5500510.000000, "gdp_md_est": 203600.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "DK", "iso_a3": "DNK", "iso_n3": "208", "un_a3": "208", "wb_a2": "DK", "wb_a3": "DNK", "woe_id": -99.000000, "adm0_a3_is": "DNK", "adm0_a3_us": "DNK", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Northern Europe", "region_wb": "Europe & Central Asia", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 12.69000614, 55.60999095 ], [ 12.08999108, 54.80001455 ], [ 11.04354333, 55.3648638 ], [ 10.90391361, 55.77995474 ], [ 12.37090417, 56.11140738 ], [ 12.69000614, 55.60999095 ] ] ], [ [ [ 10.91218184, 56.45862132 ], [ 10.66780399, 56.08138337 ], [ 10.36999271, 56.19000723 ], [ 9.64998498, 55.4699995 ], [ 9.92190637, 54.98310415 ], [ 9.28204878, 54.83086538 ], [ 8.52622928, 54.96274364 ], [ 8.12031091, 55.51772268 ], [ 8.08997684, 56.54001171 ], [ 8.25658166, 56.80996939 ], [ 8.54343753, 57.11000275 ], [ 9.42446903, 57.17206615 ], [ 9.77555871, 57.44794078 ], [ 10.58000573, 57.73001659 ], [ 10.54610599, 57.21573273 ], [ 10.25, 56.89001618 ], [ 10.36999271, 56.60998159 ], [ 10.91218184, 56.45862132 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Dominican Republic", "sov_a3": "DOM", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Dominican Republic", "adm0_a3": "DOM", "geou_dif": 0.000000, "geounit": "Dominican Republic", "gu_a3": "DOM", "su_dif": 0.000000, "subunit": "Dominican Republic", "su_a3": "DOM", "brk_diff": 0.000000, "name": "Dominican Rep.", "name_long": "Dominican Republic", "brk_a3": "DOM", "brk_name": "Dominican Rep.", "brk_group": null, "abbrev": "Dom. Rep.", "postal": "DO", "formal_en": "Dominican Republic", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Dominican Republic", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 2.000000, "mapcolor9": 5.000000, "mapcolor13": 7.000000, "pop_est": 9650054.000000, "gdp_md_est": 78000.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "DO", "iso_a3": "DOM", "iso_n3": "214", "un_a3": "214", "wb_a2": "DO", "wb_a3": "DOM", "woe_id": -99.000000, "adm0_a3_is": "DOM", "adm0_a3_us": "DOM", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "North America", "region_un": "Americas", "subregion": "Caribbean", "region_wb": "Latin America & Caribbean", "name_len": 14.000000, "long_len": 18.000000, "abbrev_len": 9.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -71.70830482, 18.04499706 ], [ -71.6877376, 18.31666006 ], [ -71.94511207, 18.61690013 ], [ -71.70130266, 18.78541698 ], [ -71.62487322, 19.16983796 ], [ -71.71236142, 19.71445588 ], [ -71.58730445, 19.88491059 ], [ -70.8067061, 19.88028555 ], [ -70.214365, 19.62288524 ], [ -69.95081519, 19.64799999 ], [ -69.76925005, 19.29326712 ], [ -69.22212582, 19.31321422 ], [ -69.25434608, 19.01519623 ], [ -68.80941199, 18.97907441 ], [ -68.31794328, 18.61219758 ], [ -68.68931597, 18.20514232 ], [ -69.16494585, 18.42264842 ], [ -69.6239876, 18.380713 ], [ -69.95293393, 18.42830699 ], [ -70.133233, 18.24591503 ], [ -70.51713721, 18.18429088 ], [ -70.66929847, 18.42688589 ], [ -70.99995012, 18.28332876 ], [ -71.40020993, 17.59856436 ], [ -71.65766191, 17.75757274 ], [ -71.70830482, 18.04499706 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Algeria", "sov_a3": "DZA", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Algeria", "adm0_a3": "DZA", "geou_dif": 0.000000, "geounit": "Algeria", "gu_a3": "DZA", "su_dif": 0.000000, "subunit": "Algeria", "su_a3": "DZA", "brk_diff": 0.000000, "name": "Algeria", "name_long": "Algeria", "brk_a3": "DZA", "brk_name": "Algeria", "brk_group": null, "abbrev": "Alg.", "postal": "DZ", "formal_en": "People's Democratic Republic of Algeria", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Algeria", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 1.000000, "mapcolor9": 6.000000, "mapcolor13": 3.000000, "pop_est": 34178188.000000, "gdp_md_est": 232900.000000, "pop_year": -99.000000, "lastcensus": 2008.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "DZ", "iso_a3": "DZA", "iso_n3": "012", "un_a3": "012", "wb_a2": "DZ", "wb_a3": "DZA", "woe_id": -99.000000, "adm0_a3_is": "DZA", "adm0_a3_us": "DZA", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Northern Africa", "region_wb": "Middle East & North Africa", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 8.42096439, 36.94642731 ], [ 8.21782433, 36.43317699 ], [ 8.37636763, 35.479876 ], [ 8.14098148, 34.65514598 ], [ 7.52448164, 34.09737641 ], [ 7.61264164, 33.3441149 ], [ 8.43047285, 32.74833731 ], [ 8.43910282, 32.5062849 ], [ 9.05560265, 32.10269196 ], [ 9.48213993, 30.30755606 ], [ 9.80563439, 29.42463837 ], [ 9.859998, 28.95998973 ], [ 9.68388472, 28.1441739 ], [ 9.75612837, 27.68825857 ], [ 9.62905602, 27.14095348 ], [ 9.71628584, 26.51220633 ], [ 9.31941084, 26.09432486 ], [ 9.91069258, 25.36545462 ], [ 9.94826135, 24.93695364 ], [ 10.30384688, 24.37931326 ], [ 10.77136356, 24.56253205 ], [ 11.56066939, 24.09790925 ], [ 11.99950565, 23.4716684 ], [ 8.5728931, 21.56566071 ], [ 5.67756595, 19.60120698 ], [ 4.26741947, 19.1552652 ], [ 3.15813317, 19.0573642 ], [ 3.146661, 19.6935786 ], [ 2.68358849, 19.85623017 ], [ 2.06099084, 20.14223338 ], [ 1.82322757, 20.61080943 ], [ -1.5500549, 22.79266592 ], [ -4.92333737, 24.97457408 ], [ -8.68439979, 27.39574413 ], [ -8.66512448, 27.58947907 ], [ -8.66558957, 27.65642589 ], [ -8.67411618, 28.84128897 ], [ -7.05922767, 29.57922842 ], [ -6.06063229, 29.73169973 ], [ -5.24212928, 30.00044302 ], [ -4.85964617, 30.50118765 ], [ -3.69044105, 30.89695161 ], [ -3.64749793, 31.63729401 ], [ -3.06898027, 31.72449799 ], [ -2.61660478, 32.09434622 ], [ -1.30789914, 32.2628889 ], [ -1.12455115, 32.65152151 ], [ -1.38804928, 32.864015 ], [ -1.73345456, 33.91971284 ], [ -1.79298581, 34.52791861 ], [ -2.1699137, 35.16839631 ], [ -1.20860287, 35.71484874 ], [ -0.12745439, 35.88866242 ], [ 0.50387658, 36.30127289 ], [ 1.46691857, 36.60564708 ], [ 3.16169885, 36.78390493 ], [ 4.81575809, 36.86503693 ], [ 5.32012007, 36.71651887 ], [ 6.2618197, 37.11065502 ], [ 7.33038496, 37.11838064 ], [ 7.73707848, 36.88570751 ], [ 8.42096439, 36.94642731 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Ecuador", "sov_a3": "ECU", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Ecuador", "adm0_a3": "ECU", "geou_dif": 0.000000, "geounit": "Ecuador", "gu_a3": "ECU", "su_dif": 0.000000, "subunit": "Ecuador", "su_a3": "ECU", "brk_diff": 0.000000, "name": "Ecuador", "name_long": "Ecuador", "brk_a3": "ECU", "brk_name": "Ecuador", "brk_group": null, "abbrev": "Ecu.", "postal": "EC", "formal_en": "Republic of Ecuador", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Ecuador", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 5.000000, "mapcolor9": 2.000000, "mapcolor13": 12.000000, "pop_est": 14573101.000000, "gdp_md_est": 107700.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "EC", "iso_a3": "ECU", "iso_n3": "218", "un_a3": "218", "wb_a2": "EC", "wb_a3": "ECU", "woe_id": -99.000000, "adm0_a3_is": "ECU", "adm0_a3_us": "ECU", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "South America", "region_un": "Americas", "subregion": "South America", "region_wb": "Latin America & Caribbean", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -75.37322323, -0.15203175 ], [ -75.2337227, -0.91141692 ], [ -75.54499569, -1.5616098 ], [ -76.63539425, -2.60867767 ], [ -77.83790483, -3.00302052 ], [ -78.45068397, -3.87309661 ], [ -78.63989722, -4.54778411 ], [ -79.20528907, -4.95912851 ], [ -79.62497921, -4.45419809 ], [ -80.02890805, -4.346091 ], [ -80.44224199, -4.42572438 ], [ -80.4692946, -4.0592868 ], [ -80.18401486, -3.8211618 ], [ -80.30256059, -3.40485646 ], [ -79.77029334, -2.6575119 ], [ -79.98655921, -2.22079437 ], [ -80.36878394, -2.68515879 ], [ -80.96776547, -2.24694264 ], [ -80.76480628, -1.9650477 ], [ -80.93365902, -1.05745452 ], [ -80.58337033, -0.90666269 ], [ -80.39932471, -0.2837033 ], [ -80.0208982, 0.36034007 ], [ -80.09060971, 0.76842886 ], [ -79.54276201, 0.98293773 ], [ -78.85525876, 1.38092377 ], [ -77.85506141, 0.80992503 ], [ -77.66861284, 0.82589305 ], [ -77.4249843, 0.39568675 ], [ -76.57637977, 0.25693553 ], [ -76.29231442, 0.41604727 ], [ -75.80146583, 0.08480134 ], [ -75.37322323, -0.15203175 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Egypt", "sov_a3": "EGY", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Egypt", "adm0_a3": "EGY", "geou_dif": 0.000000, "geounit": "Egypt", "gu_a3": "EGY", "su_dif": 0.000000, "subunit": "Egypt", "su_a3": "EGY", "brk_diff": 0.000000, "name": "Egypt", "name_long": "Egypt", "brk_a3": "EGY", "brk_name": "Egypt", "brk_group": null, "abbrev": "Egypt", "postal": "EG", "formal_en": "Arab Republic of Egypt", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Egypt, Arab Rep.", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 6.000000, "mapcolor9": 7.000000, "mapcolor13": 2.000000, "pop_est": 83082869.000000, "gdp_md_est": 443700.000000, "pop_year": -99.000000, "lastcensus": 2006.000000, "gdp_year": -99.000000, "economy": "5. Emerging region: G20", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "EG", "iso_a3": "EGY", "iso_n3": "818", "un_a3": "818", "wb_a2": "EG", "wb_a3": "EGY", "woe_id": -99.000000, "adm0_a3_is": "EGY", "adm0_a3_us": "EGY", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Northern Africa", "region_wb": "Middle East & North Africa", "name_len": 5.000000, "long_len": 5.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 28.45048, 31.02577 ], [ 28.91353, 30.87005 ], [ 29.68342, 31.18686 ], [ 30.09503, 31.4734 ], [ 30.97693, 31.55586 ], [ 31.68796, 31.4296 ], [ 31.96041, 30.9336 ], [ 32.19247, 31.26034 ], [ 32.99392, 31.02407 ], [ 33.7734, 30.96746 ], [ 34.26543474, 31.21935731 ], [ 34.26544, 31.21936 ], [ 34.82324329, 29.76108077 ], [ 34.9226, 29.50133 ], [ 34.64174, 29.09942 ], [ 34.42655, 28.34399 ], [ 34.15451, 27.8233 ], [ 33.92136, 27.6487 ], [ 33.58811, 27.97136 ], [ 33.13676, 28.41765 ], [ 32.42323, 29.85108 ], [ 32.32046, 29.76043 ], [ 32.73482, 28.70523 ], [ 33.34876, 27.69989 ], [ 34.10455, 26.14227 ], [ 34.47387, 25.59856 ], [ 34.79507, 25.03375 ], [ 35.69241, 23.92671 ], [ 35.49372, 23.75237 ], [ 35.52598, 23.10244 ], [ 36.69069, 22.20485 ], [ 36.86623, 22.0 ], [ 32.9, 22.0 ], [ 29.02, 22.0 ], [ 25.0, 22.0 ], [ 25.0, 25.6825 ], [ 25.0, 29.23865453 ], [ 24.70007, 30.04419 ], [ 24.95762, 30.6616 ], [ 24.80287, 31.08929 ], [ 25.16482, 31.56915 ], [ 26.49533, 31.58568 ], [ 27.45762, 31.32126 ], [ 28.45048, 31.02577 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Eritrea", "sov_a3": "ERI", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Eritrea", "adm0_a3": "ERI", "geou_dif": 0.000000, "geounit": "Eritrea", "gu_a3": "ERI", "su_dif": 0.000000, "subunit": "Eritrea", "su_a3": "ERI", "brk_diff": 0.000000, "name": "Eritrea", "name_long": "Eritrea", "brk_a3": "ERI", "brk_name": "Eritrea", "brk_group": null, "abbrev": "Erit.", "postal": "ER", "formal_en": "State of Eritrea", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Eritrea", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 1.000000, "mapcolor9": 2.000000, "mapcolor13": 12.000000, "pop_est": 5647168.000000, "gdp_md_est": 3945.000000, "pop_year": -99.000000, "lastcensus": 1984.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "ER", "iso_a3": "ERI", "iso_n3": "232", "un_a3": "232", "wb_a2": "ER", "wb_a3": "ERI", "woe_id": -99.000000, "adm0_a3_is": "ERI", "adm0_a3_us": "ERI", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Eastern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 39.81429365, 15.43564728 ], [ 41.17927494, 14.49107962 ], [ 41.73495161, 13.92103689 ], [ 42.27683068, 13.34399201 ], [ 42.58957645, 13.00042125 ], [ 43.08122603, 12.69963858 ], [ 42.77964237, 12.45541576 ], [ 42.35156, 12.54223 ], [ 42.00975, 12.86582 ], [ 41.59856, 13.45209 ], [ 41.15519372, 13.77331981 ], [ 40.8966, 14.11864 ], [ 40.0262187, 14.51957917 ], [ 39.34061, 14.53155 ], [ 39.0994, 14.74064 ], [ 38.51295, 14.50547 ], [ 37.90607, 14.95943 ], [ 37.59377, 14.2131 ], [ 36.42951, 14.42211 ], [ 36.32318892, 14.82248058 ], [ 36.7538603, 16.29187409 ], [ 36.85253, 16.95655 ], [ 37.16747, 17.26314 ], [ 37.904, 17.42754 ], [ 38.41008996, 17.9983074 ], [ 38.990623, 16.84062613 ], [ 39.26611006, 15.9227235 ], [ 39.81429365, 15.43564728 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Spain", "sov_a3": "ESP", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Spain", "adm0_a3": "ESP", "geou_dif": 0.000000, "geounit": "Spain", "gu_a3": "ESP", "su_dif": 0.000000, "subunit": "Spain", "su_a3": "ESP", "brk_diff": 0.000000, "name": "Spain", "name_long": "Spain", "brk_a3": "ESP", "brk_name": "Spain", "brk_group": null, "abbrev": "Sp.", "postal": "E", "formal_en": "Kingdom of Spain", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Spain", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 5.000000, "mapcolor9": 5.000000, "mapcolor13": 5.000000, "pop_est": 40525002.000000, "gdp_md_est": 1403000.000000, "pop_year": -99.000000, "lastcensus": 2001.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "ES", "iso_a3": "ESP", "iso_n3": "724", "un_a3": "724", "wb_a2": "ES", "wb_a3": "ESP", "woe_id": -99.000000, "adm0_a3_is": "ESP", "adm0_a3_us": "ESP", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Southern Europe", "region_wb": "Europe & Central Asia", "name_len": 5.000000, "long_len": 5.000000, "abbrev_len": 3.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -1.90135128, 43.42280203 ], [ -1.50277096, 43.03401439 ], [ 0.33804691, 42.57954601 ], [ 0.70159061, 42.79573436 ], [ 1.82679325, 42.34338471 ], [ 2.98599898, 42.47301504 ], [ 3.03948408, 41.89212027 ], [ 2.09184167, 41.22608857 ], [ 0.81052453, 41.01473196 ], [ 0.72133101, 40.67831839 ], [ 0.10669152, 40.12393362 ], [ -0.27871131, 39.30997814 ], [ 0.11129072, 38.73851431 ], [ -0.46712358, 38.29236583 ], [ -0.68338945, 37.64235383 ], [ -1.43838213, 37.44306367 ], [ -2.1464526, 36.67414419 ], [ -3.41578081, 36.65889964 ], [ -4.36890093, 36.67783906 ], [ -4.99521929, 36.32470816 ], [ -5.3771598, 35.94685008 ], [ -5.86643226, 36.0298166 ], [ -6.23669389, 36.36767711 ], [ -6.5201908, 36.94291332 ], [ -7.45372555, 37.09778758 ], [ -7.53710548, 37.42890432 ], [ -7.16650794, 37.80389435 ], [ -7.02928118, 38.07576407 ], [ -7.37409217, 38.37305858 ], [ -7.09803667, 39.03007274 ], [ -7.49863237, 39.62957103 ], [ -7.06659156, 39.71189159 ], [ -7.02641313, 40.18452424 ], [ -6.86401994, 40.33087189 ], [ -6.85112667, 41.11108267 ], [ -6.38908769, 41.3818155 ], [ -6.66860552, 41.88338695 ], [ -7.25130897, 41.91834606 ], [ -7.42251299, 41.79207469 ], [ -8.01317461, 41.79088614 ], [ -8.26385698, 42.28046865 ], [ -8.67194577, 42.13468944 ], [ -9.03481767, 41.88057058 ], [ -8.98443315, 42.59277517 ], [ -9.39288367, 43.02662466 ], [ -7.97818966, 43.74833771 ], [ -6.75449175, 43.56790945 ], [ -5.41188636, 43.57423981 ], [ -4.34784278, 43.40344921 ], [ -3.5175317, 43.45590078 ], [ -1.90135128, 43.42280203 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Estonia", "sov_a3": "EST", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Estonia", "adm0_a3": "EST", "geou_dif": 0.000000, "geounit": "Estonia", "gu_a3": "EST", "su_dif": 0.000000, "subunit": "Estonia", "su_a3": "EST", "brk_diff": 0.000000, "name": "Estonia", "name_long": "Estonia", "brk_a3": "EST", "brk_name": "Estonia", "brk_group": null, "abbrev": "Est.", "postal": "EST", "formal_en": "Republic of Estonia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Estonia", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 2.000000, "mapcolor9": 1.000000, "mapcolor13": 10.000000, "pop_est": 1299371.000000, "gdp_md_est": 27410.000000, "pop_year": -99.000000, "lastcensus": 2000.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "EE", "iso_a3": "EST", "iso_n3": "233", "un_a3": "233", "wb_a2": "EE", "wb_a3": "EST", "woe_id": -99.000000, "adm0_a3_is": "EST", "adm0_a3_us": "EST", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Northern Europe", "region_wb": "Europe & Central Asia", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 25.86418908, 59.6110904 ], [ 26.94913578, 59.44580333 ], [ 27.98111413, 59.47538809 ], [ 27.98112686, 59.47537333 ], [ 28.13169925, 59.3008251 ], [ 27.42016646, 58.7245812 ], [ 27.71668583, 57.79189912 ], [ 27.28818485, 57.47452831 ], [ 26.46353234, 57.47638866 ], [ 25.60280969, 57.84752879 ], [ 25.16459354, 57.97015697 ], [ 24.31286258, 57.79342357 ], [ 24.42892785, 58.3834134 ], [ 24.06119836, 58.25737458 ], [ 23.42656009, 58.6127534 ], [ 23.33979536, 59.1872403 ], [ 24.60421431, 59.46585379 ], [ 25.86418908, 59.6110904 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Ethiopia", "sov_a3": "ETH", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Ethiopia", "adm0_a3": "ETH", "geou_dif": 0.000000, "geounit": "Ethiopia", "gu_a3": "ETH", "su_dif": 0.000000, "subunit": "Ethiopia", "su_a3": "ETH", "brk_diff": 0.000000, "name": "Ethiopia", "name_long": "Ethiopia", "brk_a3": "ETH", "brk_name": "Ethiopia", "brk_group": null, "abbrev": "Eth.", "postal": "ET", "formal_en": "Federal Democratic Republic of Ethiopia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Ethiopia", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 4.000000, "mapcolor9": 1.000000, "mapcolor13": 13.000000, "pop_est": 85237338.000000, "gdp_md_est": 68770.000000, "pop_year": -99.000000, "lastcensus": 2007.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "ET", "iso_a3": "ETH", "iso_n3": "231", "un_a3": "231", "wb_a2": "ET", "wb_a3": "ETH", "woe_id": -99.000000, "adm0_a3_is": "ETH", "adm0_a3_us": "ETH", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Eastern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 8.000000, "long_len": 8.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 37.90607, 14.95943 ], [ 38.51295, 14.50547 ], [ 39.0994, 14.74064 ], [ 39.34061, 14.53155 ], [ 40.02625, 14.51959 ], [ 40.8966, 14.11864 ], [ 41.1552, 13.77333 ], [ 41.59856, 13.45209 ], [ 42.00975, 12.86582 ], [ 42.35156, 12.54223 ], [ 42.0, 12.1 ], [ 41.66176, 11.6312 ], [ 41.73959, 11.35511 ], [ 41.75557, 11.05091 ], [ 42.31414, 11.0342 ], [ 42.55493, 11.10511 ], [ 42.77685184, 10.92687857 ], [ 42.55876, 10.57258 ], [ 42.92812, 10.02194 ], [ 43.29699, 9.54048 ], [ 43.67875, 9.18358 ], [ 46.94834, 7.99688 ], [ 47.78942, 8.003 ], [ 44.9636, 5.00162 ], [ 43.66087, 4.95755 ], [ 42.76967, 4.25259 ], [ 42.12861, 4.23413 ], [ 41.85508309, 3.91891192 ], [ 41.1718, 3.91909 ], [ 40.76848, 4.25702 ], [ 39.85494, 3.83879 ], [ 39.55938426, 3.42206 ], [ 38.89251, 3.50074 ], [ 38.67114, 3.61607 ], [ 38.43697, 3.58851 ], [ 38.120915, 3.598605 ], [ 36.85509324, 4.44786413 ], [ 36.15907863, 4.44786413 ], [ 35.81744766, 4.77696566 ], [ 35.81744766, 5.33823208 ], [ 35.29800712, 5.506 ], [ 34.70702, 6.59422 ], [ 34.25032, 6.82607 ], [ 34.0751, 7.22595 ], [ 33.56829, 7.71334 ], [ 32.95418, 7.78497 ], [ 33.2948, 8.35458 ], [ 33.8255, 8.37916 ], [ 33.97498, 8.68456 ], [ 33.96339279, 9.46428523 ], [ 33.96162, 9.58358 ], [ 34.25745, 10.63009 ], [ 34.73115, 10.91017 ], [ 34.83163, 11.31896 ], [ 35.26049, 12.08286 ], [ 35.86363, 12.57828 ], [ 36.27022, 13.56333 ], [ 36.42951, 14.42211 ], [ 37.59377, 14.2131 ], [ 37.90607, 14.95943 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Finland", "sov_a3": "FI1", "adm0_dif": 1.000000, "level": 2.000000, "type": "Country", "admin": "Finland", "adm0_a3": "FIN", "geou_dif": 0.000000, "geounit": "Finland", "gu_a3": "FIN", "su_dif": 0.000000, "subunit": "Finland", "su_a3": "FIN", "brk_diff": 0.000000, "name": "Finland", "name_long": "Finland", "brk_a3": "FIN", "brk_name": "Finland", "brk_group": null, "abbrev": "Fin.", "postal": "FIN", "formal_en": "Republic of Finland", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Finland", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 1.000000, "mapcolor9": 4.000000, "mapcolor13": 6.000000, "pop_est": 5250275.000000, "gdp_md_est": 193500.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "FI", "iso_a3": "FIN", "iso_n3": "246", "un_a3": "246", "wb_a2": "FI", "wb_a3": "FIN", "woe_id": -99.000000, "adm0_a3_is": "FIN", "adm0_a3_us": "FIN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Northern Europe", "region_wb": "Europe & Central Asia", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 28.59192956, 69.06477692 ], [ 28.44594364, 68.36461294 ], [ 29.97742639, 67.69829702 ], [ 29.05458866, 66.9442862 ], [ 30.21765, 65.80598 ], [ 29.54442956, 64.94867158 ], [ 30.44468469, 64.20445344 ], [ 30.03587243, 63.55281363 ], [ 31.51609216, 62.86768749 ], [ 31.13999108, 62.35769278 ], [ 30.21110721, 61.78002778 ], [ 28.07000192, 60.50351913 ], [ 28.06999759, 60.50351655 ], [ 26.25517297, 60.42396068 ], [ 24.49662398, 60.05731639 ], [ 22.86969486, 59.8463732 ], [ 22.29076379, 60.39192129 ], [ 21.32224409, 60.72016999 ], [ 21.54486616, 61.70532949 ], [ 21.05921105, 62.6073933 ], [ 21.53602949, 63.18973501 ], [ 22.44274417, 63.81781037 ], [ 24.73051151, 64.90234366 ], [ 25.39806766, 65.1114265 ], [ 25.294043, 65.53434642 ], [ 23.90337853, 66.0069274 ], [ 23.56587975, 66.39605093 ], [ 23.5394731, 67.93600861 ], [ 21.97853478, 68.61684561 ], [ 20.64559289, 69.10624726 ], [ 21.24493615, 69.37044302 ], [ 22.35623783, 68.84174144 ], [ 23.66204959, 68.89124746 ], [ 24.73567915, 68.64955679 ], [ 25.68921268, 69.09211376 ], [ 26.17962202, 69.82529898 ], [ 27.73229211, 70.16419302 ], [ 29.01557295, 69.7664912 ], [ 28.59192956, 69.06477692 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Fiji", "sov_a3": "FJI", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Fiji", "adm0_a3": "FJI", "geou_dif": 0.000000, "geounit": "Fiji", "gu_a3": "FJI", "su_dif": 0.000000, "subunit": "Fiji", "su_a3": "FJI", "brk_diff": 0.000000, "name": "Fiji", "name_long": "Fiji", "brk_a3": "FJI", "brk_name": "Fiji", "brk_group": null, "abbrev": "Fiji", "postal": "FJ", "formal_en": "Republic of Fiji", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Fiji", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 1.000000, "mapcolor9": 2.000000, "mapcolor13": 2.000000, "pop_est": 944720.000000, "gdp_md_est": 3579.000000, "pop_year": -99.000000, "lastcensus": 2007.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "FJ", "iso_a3": "FJI", "iso_n3": "242", "un_a3": "242", "wb_a2": "FJ", "wb_a3": "FJI", "woe_id": -99.000000, "adm0_a3_is": "FJI", "adm0_a3_us": "FJI", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Oceania", "region_un": "Oceania", "subregion": "Melanesia", "region_wb": "East Asia & Pacific", "name_len": 4.000000, "long_len": 4.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 178.3736, -17.33992 ], [ 178.71806, -17.62846 ], [ 178.55271, -18.15059 ], [ 177.93266, -18.28799 ], [ 177.38146, -18.16432 ], [ 177.28504, -17.72465 ], [ 177.67087, -17.38114 ], [ 178.12557, -17.50481 ], [ 178.3736, -17.33992 ] ] ], [ [ [ 179.36414266, -16.80135408 ], [ 178.72505936, -17.01204167 ], [ 178.5968386, -16.63915 ], [ 179.09660936, -16.43398428 ], [ 179.41350936, -16.37905428 ], [ 180.0, -16.06713266 ], [ 180.0, -16.55521657 ], [ 179.36414266, -16.80135408 ] ] ], [ [ [ -179.91736938, -16.50178314 ], [ -180.0, -16.55521657 ], [ -180.0, -16.06713266 ], [ -179.79332011, -16.02088226 ], [ -179.91736938, -16.50178314 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "United Kingdom", "sov_a3": "GB1", "adm0_dif": 1.000000, "level": 2.000000, "type": "Dependency", "admin": "Falkland Islands", "adm0_a3": "FLK", "geou_dif": 0.000000, "geounit": "Falkland Islands", "gu_a3": "FLK", "su_dif": 0.000000, "subunit": "Falkland Islands", "su_a3": "FLK", "brk_diff": 1.000000, "name": "Falkland Is.", "name_long": "Falkland Islands", "brk_a3": "B12", "brk_name": "Falkland Is.", "brk_group": null, "abbrev": "Flk. Is.", "postal": "FK", "formal_en": "Falkland Islands", "formal_fr": null, "note_adm0": "U.K.", "note_brk": "Admin. by U.K.; Claimed by Argentina", "name_sort": "Falkland Islands", "name_alt": "Islas Malvinas", "mapcolor7": 6.000000, "mapcolor8": 6.000000, "mapcolor9": 6.000000, "mapcolor13": 3.000000, "pop_est": 3140.000000, "gdp_md_est": 105.100000, "pop_year": -99.000000, "lastcensus": -99.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "FK", "iso_a3": "FLK", "iso_n3": "238", "un_a3": "238", "wb_a2": "-99", "wb_a3": "-99", "woe_id": -99.000000, "adm0_a3_is": "FLK", "adm0_a3_us": "FLK", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "South America", "region_un": "Americas", "subregion": "South America", "region_wb": "Latin America & Caribbean", "name_len": 12.000000, "long_len": 16.000000, "abbrev_len": 8.000000, "tiny": -99.000000, "homepart": -99.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -58.55, -51.1 ], [ -57.75, -51.55 ], [ -58.05, -51.9 ], [ -59.4, -52.2 ], [ -59.85, -51.85 ], [ -60.7, -52.3 ], [ -61.2, -51.85 ], [ -60.0, -51.25 ], [ -59.15, -51.5 ], [ -58.55, -51.1 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "France", "sov_a3": "FR1", "adm0_dif": 1.000000, "level": 2.000000, "type": "Country", "admin": "France", "adm0_a3": "FRA", "geou_dif": 0.000000, "geounit": "France", "gu_a3": "FRA", "su_dif": 0.000000, "subunit": "France", "su_a3": "FRA", "brk_diff": 0.000000, "name": "France", "name_long": "France", "brk_a3": "FRA", "brk_name": "France", "brk_group": null, "abbrev": "Fr.", "postal": "F", "formal_en": "French Republic", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "France", "name_alt": null, "mapcolor7": 7.000000, "mapcolor8": 5.000000, "mapcolor9": 9.000000, "mapcolor13": 11.000000, "pop_est": 64057792.000000, "gdp_md_est": 2128000.000000, "pop_year": -99.000000, "lastcensus": -99.000000, "gdp_year": -99.000000, "economy": "1. Developed region: G7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "FR", "iso_a3": "FRA", "iso_n3": "250", "un_a3": "250", "wb_a2": "FR", "wb_a3": "FRA", "woe_id": -99.000000, "adm0_a3_is": "FRA", "adm0_a3_us": "FRA", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Western Europe", "region_wb": "Europe & Central Asia", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 3.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -52.55642473, 2.50470531 ], [ -52.93965715, 2.12485769 ], [ -53.41846514, 2.05338919 ], [ -53.55483924, 2.33489655 ], [ -53.77852068, 2.37670279 ], [ -54.08806251, 2.10555655 ], [ -54.5247542, 2.31184886 ], [ -54.27122962, 2.73874787 ], [ -54.18428402, 3.19417227 ], [ -54.01150387, 3.62256989 ], [ -54.3995422, 4.2126114 ], [ -54.47863298, 4.89675568 ], [ -53.9580446, 5.75654816 ], [ -53.61845293, 5.64652904 ], [ -52.88214128, 5.40985098 ], [ -51.82334286, 4.56576813 ], [ -51.65779741, 4.15623241 ], [ -52.24933753, 3.24109447 ], [ -52.55642473, 2.50470531 ] ] ], [ [ [ 9.56001631, 42.15249197 ], [ 9.22975223, 41.38000682 ], [ 8.7757231, 41.58361197 ], [ 8.54421268, 42.25651663 ], [ 8.74600915, 42.62812185 ], [ 9.39000085, 43.00998485 ], [ 9.56001631, 42.15249197 ] ] ], [ [ [ 3.58818444, 50.37899242 ], [ 4.28602298, 49.90749665 ], [ 4.79922163, 49.98537303 ], [ 5.67405195, 49.52948355 ], [ 5.89775923, 49.44266714 ], [ 6.18632043, 49.4638028 ], [ 6.65822961, 49.20195832 ], [ 8.0992786, 49.01778352 ], [ 7.59367639, 48.33301911 ], [ 7.46675907, 47.62058198 ], [ 7.19220218, 47.44976553 ], [ 6.73657108, 47.54180126 ], [ 6.76871382, 47.28770824 ], [ 6.03738895, 46.72577871 ], [ 6.02260949, 46.27298981 ], [ 6.50009972, 46.42967276 ], [ 6.84359297, 45.99114655 ], [ 6.80235518, 45.70857982 ], [ 7.09665246, 45.33309886 ], [ 6.74995528, 45.02851797 ], [ 7.00756229, 44.25476675 ], [ 7.54959639, 44.12790111 ], [ 7.43518477, 43.69384492 ], [ 6.52924523, 43.12889232 ], [ 4.55696252, 43.39965099 ], [ 3.1004106, 43.07520051 ], [ 2.98599898, 42.47301504 ], [ 1.82679325, 42.34338471 ], [ 0.70159061, 42.79573436 ], [ 0.33804691, 42.57954601 ], [ -1.50277096, 43.03401439 ], [ -1.90135128, 43.42280203 ], [ -1.38422523, 44.02261038 ], [ -1.19379757, 46.01491771 ], [ -2.22572425, 47.0643627 ], [ -2.96327613, 47.57032665 ], [ -4.49155494, 47.95495433 ], [ -4.59234982, 48.68416047 ], [ -3.29581397, 48.90169241 ], [ -1.61651079, 48.64442129 ], [ -1.93349403, 49.77634186 ], [ -0.98946896, 49.3473758 ], [ 1.33876102, 50.12717316 ], [ 1.63900109, 50.94660635 ], [ 2.51357303, 51.14850617 ], [ 2.65842207, 50.79684805 ], [ 3.12325158, 50.78036327 ], [ 3.58818444, 50.37899242 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Gabon", "sov_a3": "GAB", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Gabon", "adm0_a3": "GAB", "geou_dif": 0.000000, "geounit": "Gabon", "gu_a3": "GAB", "su_dif": 0.000000, "subunit": "Gabon", "su_a3": "GAB", "brk_diff": 0.000000, "name": "Gabon", "name_long": "Gabon", "brk_a3": "GAB", "brk_name": "Gabon", "brk_group": null, "abbrev": "Gabon", "postal": "GA", "formal_en": "Gabonese Republic", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Gabon", "name_alt": null, "mapcolor7": 6.000000, "mapcolor8": 2.000000, "mapcolor9": 5.000000, "mapcolor13": 5.000000, "pop_est": 1514993.000000, "gdp_md_est": 21110.000000, "pop_year": -99.000000, "lastcensus": 2003.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "GA", "iso_a3": "GAB", "iso_n3": "266", "un_a3": "266", "wb_a2": "GA", "wb_a3": "GAB", "woe_id": -99.000000, "adm0_a3_is": "GAB", "adm0_a3_us": "GAB", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Middle Africa", "region_wb": "Sub-Saharan Africa", "name_len": 5.000000, "long_len": 5.000000, "abbrev_len": 5.000000, "tiny": 3.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 13.07582238, 2.26709707 ], [ 13.00311364, 1.83089631 ], [ 13.28263146, 1.31418366 ], [ 14.02666874, 1.3956774 ], [ 14.2762659, 1.19692984 ], [ 13.84332075, 0.03875764 ], [ 14.31641849, -0.55262746 ], [ 14.42545576, -1.33340667 ], [ 14.29921024, -1.99827565 ], [ 13.99240726, -2.47080495 ], [ 13.10961877, -2.42874033 ], [ 12.57528446, -1.94851124 ], [ 12.49570275, -2.39168833 ], [ 11.82096358, -2.51416147 ], [ 11.47803877, -2.76561899 ], [ 11.8551217, -3.42687062 ], [ 11.09377282, -3.97882659 ], [ 10.06613529, -2.96948252 ], [ 9.4052454, -2.14431325 ], [ 8.79799564, -1.11130136 ], [ 8.8300867, -0.77907358 ], [ 9.04841963, -0.45935149 ], [ 9.29135054, 0.26866608 ], [ 9.49288862, 1.01011953 ], [ 9.83028405, 1.06789378 ], [ 11.28507897, 1.05766185 ], [ 11.27644901, 2.26105093 ], [ 11.75166548, 2.32675751 ], [ 12.35938032, 2.1928122 ], [ 12.95133386, 2.32161571 ], [ 13.07582238, 2.26709707 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "United Kingdom", "sov_a3": "GB1", "adm0_dif": 1.000000, "level": 2.000000, "type": "Country", "admin": "United Kingdom", "adm0_a3": "GBR", "geou_dif": 0.000000, "geounit": "United Kingdom", "gu_a3": "GBR", "su_dif": 0.000000, "subunit": "United Kingdom", "su_a3": "GBR", "brk_diff": 0.000000, "name": "United Kingdom", "name_long": "United Kingdom", "brk_a3": "GBR", "brk_name": "United Kingdom", "brk_group": null, "abbrev": "U.K.", "postal": "GB", "formal_en": "United Kingdom of Great Britain and Northern Ireland", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "United Kingdom", "name_alt": null, "mapcolor7": 6.000000, "mapcolor8": 6.000000, "mapcolor9": 6.000000, "mapcolor13": 3.000000, "pop_est": 62262000.000000, "gdp_md_est": 1977704.000000, "pop_year": 0.000000, "lastcensus": 2011.000000, "gdp_year": 2009.000000, "economy": "1. Developed region: G7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "GB", "iso_a3": "GBR", "iso_n3": "826", "un_a3": "826", "wb_a2": "GB", "wb_a3": "GBR", "woe_id": -99.000000, "adm0_a3_is": "GBR", "adm0_a3_us": "GBR", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Northern Europe", "region_wb": "Europe & Central Asia", "name_len": 14.000000, "long_len": 14.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -5.66194861, 54.55460318 ], [ -6.19788489, 53.86756501 ], [ -6.95373023, 54.0737023 ], [ -7.57216793, 54.05995637 ], [ -7.36603065, 54.59584097 ], [ -7.57216793, 55.13162222 ], [ -6.73384701, 55.17286001 ], [ -5.66194861, 54.55460318 ] ] ], [ [ [ -3.00500485, 58.63500011 ], [ -4.0738285, 57.55302481 ], [ -3.0550018, 57.69001903 ], [ -1.95928056, 57.68479971 ], [ -2.21998817, 56.8700174 ], [ -3.11900306, 55.97379304 ], [ -2.08500932, 55.90999848 ], [ -2.00567568, 55.80490285 ], [ -1.11499101, 54.62498648 ], [ -0.43048499, 54.46437613 ], [ 0.18498132, 53.32501415 ], [ 0.46997684, 52.9299995 ], [ 1.6815308, 52.73952017 ], [ 1.55998783, 52.09999848 ], [ 1.05056156, 51.80676057 ], [ 1.44986535, 51.2894278 ], [ 0.55033369, 50.76573884 ], [ -0.78751746, 50.77498892 ], [ -2.48999752, 50.50001862 ], [ -2.95627397, 50.69687999 ], [ -3.61744809, 50.22835562 ], [ -4.5425079, 50.34183706 ], [ -5.24502316, 49.9599999 ], [ -5.77656694, 50.15967764 ], [ -4.30998979, 51.21000113 ], [ -3.41485063, 51.42600861 ], [ -3.42271947, 51.42684817 ], [ -4.98436723, 51.59346609 ], [ -5.2672957, 51.99140046 ], [ -4.22234656, 52.3013557 ], [ -4.77001339, 52.84000499 ], [ -4.57999915, 53.49500377 ], [ -3.09383067, 53.4045474 ], [ -3.09207964, 53.40444082 ], [ -2.94500851, 53.9849997 ], [ -3.61470083, 54.60093677 ], [ -3.63000546, 54.61501293 ], [ -4.84416907, 54.79097118 ], [ -5.08252662, 55.06160065 ], [ -4.71911211, 55.5084726 ], [ -5.04798092, 55.7839855 ], [ -5.58639767, 55.31114615 ], [ -5.64499875, 56.27501496 ], [ -6.14998084, 56.78500967 ], [ -5.78682471, 57.81884838 ], [ -5.00999875, 58.63001333 ], [ -4.21149451, 58.55084504 ], [ -3.00500485, 58.63500011 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Georgia", "sov_a3": "GEO", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Georgia", "adm0_a3": "GEO", "geou_dif": 0.000000, "geounit": "Georgia", "gu_a3": "GEO", "su_dif": 0.000000, "subunit": "Georgia", "su_a3": "GEO", "brk_diff": 0.000000, "name": "Georgia", "name_long": "Georgia", "brk_a3": "GEO", "brk_name": "Georgia", "brk_group": null, "abbrev": "Geo.", "postal": "GE", "formal_en": "Georgia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Georgia", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 1.000000, "mapcolor9": 3.000000, "mapcolor13": 2.000000, "pop_est": 4615807.000000, "gdp_md_est": 21510.000000, "pop_year": -99.000000, "lastcensus": 2002.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "GE", "iso_a3": "GEO", "iso_n3": "268", "un_a3": "268", "wb_a2": "GE", "wb_a3": "GEO", "woe_id": -99.000000, "adm0_a3_is": "GEO", "adm0_a3_us": "GEO", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Western Asia", "region_wb": "Europe & Central Asia", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 43.75601688, 42.74082815 ], [ 43.93119999, 42.55497386 ], [ 44.53762292, 42.7119927 ], [ 45.47027917, 42.50278067 ], [ 45.77641035, 42.09244396 ], [ 46.4049508, 41.86067516 ], [ 46.14543176, 41.72280244 ], [ 46.63790816, 41.18167268 ], [ 46.5016374, 41.06444469 ], [ 45.96260054, 41.12387259 ], [ 45.21742639, 41.41145193 ], [ 44.9724801, 41.24812857 ], [ 43.5827458, 41.09214326 ], [ 42.61954878, 41.58317272 ], [ 41.5540841, 41.53565624 ], [ 41.70317061, 41.96294282 ], [ 41.45347009, 42.6451234 ], [ 40.87546919, 43.01362804 ], [ 40.32139448, 43.12863394 ], [ 39.95500858, 43.43499767 ], [ 40.07696496, 43.55310415 ], [ 40.92218469, 43.38215851 ], [ 42.39439457, 43.22030793 ], [ 43.75601688, 42.74082815 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Ghana", "sov_a3": "GHA", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Ghana", "adm0_a3": "GHA", "geou_dif": 0.000000, "geounit": "Ghana", "gu_a3": "GHA", "su_dif": 0.000000, "subunit": "Ghana", "su_a3": "GHA", "brk_diff": 0.000000, "name": "Ghana", "name_long": "Ghana", "brk_a3": "GHA", "brk_name": "Ghana", "brk_group": null, "abbrev": "Ghana", "postal": "GH", "formal_en": "Republic of Ghana", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Ghana", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 3.000000, "mapcolor9": 1.000000, "mapcolor13": 4.000000, "pop_est": 23832495.000000, "gdp_md_est": 34200.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "GH", "iso_a3": "GHA", "iso_n3": "288", "un_a3": "288", "wb_a2": "GH", "wb_a3": "GHA", "woe_id": -99.000000, "adm0_a3_is": "GHA", "adm0_a3_us": "GHA", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Western Africa", "region_wb": "Sub-Saharan Africa", "name_len": 5.000000, "long_len": 5.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 0.02380252, 11.01868175 ], [ -0.04978472, 10.70691783 ], [ 0.36757999, 10.19121288 ], [ 0.36590051, 9.46500397 ], [ 0.46119185, 8.6772226 ], [ 0.71202925, 8.3124645 ], [ 0.49095747, 7.41174429 ], [ 0.57038415, 6.91435863 ], [ 0.83693119, 6.27997875 ], [ 1.0601217, 5.92883739 ], [ -0.50763791, 5.3434726 ], [ -1.06362464, 5.0005478 ], [ -1.96470659, 4.71046214 ], [ -2.85612505, 4.99447582 ], [ -2.81070146, 5.38905122 ], [ -3.24437008, 6.2504715 ], [ -2.98358497, 7.3797049 ], [ -2.5621895, 8.21962779 ], [ -2.8274963, 9.64246084 ], [ -2.96389625, 10.39533478 ], [ -2.94040931, 10.96269033 ], [ -1.20335771, 11.00981924 ], [ -0.76157589, 10.93692963 ], [ -0.43870154, 11.09834097 ], [ 0.02380252, 11.01868175 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Guinea", "sov_a3": "GIN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Guinea", "adm0_a3": "GIN", "geou_dif": 0.000000, "geounit": "Guinea", "gu_a3": "GIN", "su_dif": 0.000000, "subunit": "Guinea", "su_a3": "GIN", "brk_diff": 0.000000, "name": "Guinea", "name_long": "Guinea", "brk_a3": "GIN", "brk_name": "Guinea", "brk_group": null, "abbrev": "Gin.", "postal": "GN", "formal_en": "Republic of Guinea", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Guinea", "name_alt": null, "mapcolor7": 6.000000, "mapcolor8": 3.000000, "mapcolor9": 7.000000, "mapcolor13": 2.000000, "pop_est": 10057975.000000, "gdp_md_est": 10600.000000, "pop_year": -99.000000, "lastcensus": 1996.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "GN", "iso_a3": "GIN", "iso_n3": "324", "un_a3": "324", "wb_a2": "GN", "wb_a3": "GIN", "woe_id": -99.000000, "adm0_a3_is": "GIN", "adm0_a3_us": "GIN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Western Africa", "region_wb": "Sub-Saharan Africa", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -11.51394284, 12.44298758 ], [ -11.45616859, 12.07683421 ], [ -11.29757361, 12.0779711 ], [ -11.03655596, 12.21124462 ], [ -10.87082964, 12.17788748 ], [ -10.59322384, 11.92397533 ], [ -10.16521379, 11.84408356 ], [ -9.8909928, 12.06047862 ], [ -9.56791175, 12.19424307 ], [ -9.32761634, 12.3342862 ], [ -9.12747352, 12.30806041 ], [ -8.90526486, 12.08835806 ], [ -8.78609901, 11.81256094 ], [ -8.3763049, 11.39364594 ], [ -8.5813053, 11.13624563 ], [ -8.62032101, 10.81089081 ], [ -8.40731076, 10.9092569 ], [ -8.28235714, 10.79259736 ], [ -8.33537716, 10.49481192 ], [ -8.02994361, 10.20653494 ], [ -8.22933712, 10.12902029 ], [ -8.30961646, 9.78953197 ], [ -8.07911374, 9.37622386 ], [ -7.83210039, 8.57570425 ], [ -8.20349891, 8.45545319 ], [ -8.29904863, 8.31644359 ], [ -8.22179236, 8.12332876 ], [ -8.2807035, 7.68717967 ], [ -8.43929847, 7.68604279 ], [ -8.72212358, 7.7116743 ], [ -8.92606462, 7.30903738 ], [ -9.20878638, 7.3139208 ], [ -9.40334815, 7.52690522 ], [ -9.33727983, 7.92853445 ], [ -9.75534217, 8.5410552 ], [ -10.01656653, 8.42850393 ], [ -10.23009355, 8.40620555 ], [ -10.50547726, 8.34889639 ], [ -10.49431515, 8.71554068 ], [ -10.65477047, 8.97717845 ], [ -10.62239519, 9.26791006 ], [ -10.83915198, 9.68824616 ], [ -11.11748125, 10.04587291 ], [ -11.91727739, 10.04698395 ], [ -12.1503381, 9.85857168 ], [ -12.42592851, 9.83583405 ], [ -12.59671912, 9.6201883 ], [ -12.71195757, 9.3427117 ], [ -13.24655026, 8.90304861 ], [ -13.68515398, 9.49474376 ], [ -14.07404497, 9.8861669 ], [ -14.33007585, 10.01571971 ], [ -14.57969886, 10.21446727 ], [ -14.69323198, 10.65630077 ], [ -14.8395538, 10.87657156 ], [ -15.13031125, 11.04041169 ], [ -14.68568722, 11.5278238 ], [ -14.38219153, 11.50927196 ], [ -14.12140642, 11.67711701 ], [ -13.90079973, 11.67871898 ], [ -13.74316077, 11.81126903 ], [ -13.82827186, 12.14264415 ], [ -13.71874366, 12.24718557 ], [ -13.70047604, 12.58618297 ], [ -13.21781816, 12.57587352 ], [ -12.49905067, 12.33208995 ], [ -12.27859901, 12.35444001 ], [ -12.20356483, 12.46564769 ], [ -11.65830095, 12.38658275 ], [ -11.51394284, 12.44298758 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Gambia", "sov_a3": "GMB", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Gambia", "adm0_a3": "GMB", "geou_dif": 0.000000, "geounit": "Gambia", "gu_a3": "GMB", "su_dif": 0.000000, "subunit": "Gambia", "su_a3": "GMB", "brk_diff": 0.000000, "name": "Gambia", "name_long": "The Gambia", "brk_a3": "GMB", "brk_name": "Gambia", "brk_group": null, "abbrev": "Gambia", "postal": "GM", "formal_en": "Republic of the Gambia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Gambia, The", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 4.000000, "mapcolor9": 1.000000, "mapcolor13": 8.000000, "pop_est": 1782893.000000, "gdp_md_est": 2272.000000, "pop_year": -99.000000, "lastcensus": 2003.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "GM", "iso_a3": "GMB", "iso_n3": "270", "un_a3": "270", "wb_a2": "GM", "wb_a3": "GMB", "woe_id": -99.000000, "adm0_a3_is": "GMB", "adm0_a3_us": "GMB", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Western Africa", "region_wb": "Sub-Saharan Africa", "name_len": 6.000000, "long_len": 10.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -16.84152462, 13.15139395 ], [ -16.71372881, 13.5949586 ], [ -15.62459632, 13.62358735 ], [ -15.39877031, 13.86036876 ], [ -15.0817354, 13.87649181 ], [ -14.68703081, 13.63035696 ], [ -14.37671383, 13.62568024 ], [ -14.04699236, 13.7940679 ], [ -13.84496334, 13.50504161 ], [ -14.27770179, 13.28058503 ], [ -14.71219723, 13.29820669 ], [ -15.1411633, 13.50951162 ], [ -15.51181251, 13.27856965 ], [ -15.69100054, 13.27035309 ], [ -15.93129595, 13.13028413 ], [ -16.84152462, 13.15139395 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Guinea Bissau", "sov_a3": "GNB", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Guinea Bissau", "adm0_a3": "GNB", "geou_dif": 0.000000, "geounit": "Guinea Bissau", "gu_a3": "GNB", "su_dif": 0.000000, "subunit": "Guinea Bissau", "su_a3": "GNB", "brk_diff": 0.000000, "name": "Guinea-Bissau", "name_long": "Guinea-Bissau", "brk_a3": "GNB", "brk_name": "Guinea-Bissau", "brk_group": null, "abbrev": "GnB.", "postal": "GW", "formal_en": "Republic of Guinea-Bissau", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Guinea-Bissau", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 5.000000, "mapcolor9": 3.000000, "mapcolor13": 4.000000, "pop_est": 1533964.000000, "gdp_md_est": 904.200000, "pop_year": -99.000000, "lastcensus": 2009.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "GW", "iso_a3": "GNB", "iso_n3": "624", "un_a3": "624", "wb_a2": "GW", "wb_a3": "GNB", "woe_id": -99.000000, "adm0_a3_is": "GNB", "adm0_a3_us": "GNB", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Western Africa", "region_wb": "Sub-Saharan Africa", "name_len": 13.000000, "long_len": 13.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -13.70047604, 12.58618297 ], [ -13.71874366, 12.24718557 ], [ -13.82827186, 12.14264415 ], [ -13.74316077, 11.81126903 ], [ -13.90079973, 11.67871898 ], [ -14.12140642, 11.67711701 ], [ -14.38219153, 11.50927196 ], [ -14.68568722, 11.5278238 ], [ -15.13031125, 11.04041169 ], [ -15.66418047, 11.45847403 ], [ -16.0852142, 11.52459402 ], [ -16.31478675, 11.8065148 ], [ -16.30894731, 11.95870189 ], [ -16.61383826, 12.17091116 ], [ -16.67745195, 12.38485159 ], [ -16.14771684, 12.54776154 ], [ -15.81657427, 12.51556712 ], [ -15.54847694, 12.62817007 ], [ -13.70047604, 12.58618297 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Equatorial Guinea", "sov_a3": "GNQ", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Equatorial Guinea", "adm0_a3": "GNQ", "geou_dif": 0.000000, "geounit": "Equatorial Guinea", "gu_a3": "GNQ", "su_dif": 0.000000, "subunit": "Equatorial Guinea", "su_a3": "GNQ", "brk_diff": 0.000000, "name": "Eq. Guinea", "name_long": "Equatorial Guinea", "brk_a3": "GNQ", "brk_name": "Eq. Guinea", "brk_group": null, "abbrev": "Eq. G.", "postal": "GQ", "formal_en": "Republic of Equatorial Guinea", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Equatorial Guinea", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 1.000000, "mapcolor9": 4.000000, "mapcolor13": 8.000000, "pop_est": 650702.000000, "gdp_md_est": 14060.000000, "pop_year": 0.000000, "lastcensus": 2002.000000, "gdp_year": 0.000000, "economy": "7. Least developed region", "income_grp": "2. High income: nonOECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "GQ", "iso_a3": "GNQ", "iso_n3": "226", "un_a3": "226", "wb_a2": "GQ", "wb_a3": "GNQ", "woe_id": -99.000000, "adm0_a3_is": "GNQ", "adm0_a3_us": "GNQ", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Middle Africa", "region_wb": "Sub-Saharan Africa", "name_len": 10.000000, "long_len": 17.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 11.27644901, 2.26105093 ], [ 11.28507897, 1.05766185 ], [ 9.83028405, 1.06789378 ], [ 9.49288862, 1.01011953 ], [ 9.30561323, 1.16091136 ], [ 9.64915816, 2.28386608 ], [ 11.27644901, 2.26105093 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Greece", "sov_a3": "GRC", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Greece", "adm0_a3": "GRC", "geou_dif": 0.000000, "geounit": "Greece", "gu_a3": "GRC", "su_dif": 0.000000, "subunit": "Greece", "su_a3": "GRC", "brk_diff": 0.000000, "name": "Greece", "name_long": "Greece", "brk_a3": "GRC", "brk_name": "Greece", "brk_group": null, "abbrev": "Greece", "postal": "GR", "formal_en": "Hellenic Republic", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Greece", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 2.000000, "mapcolor9": 2.000000, "mapcolor13": 9.000000, "pop_est": 10737428.000000, "gdp_md_est": 343000.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "GR", "iso_a3": "GRC", "iso_n3": "300", "un_a3": "300", "wb_a2": "GR", "wb_a3": "GRC", "woe_id": -99.000000, "adm0_a3_is": "GRC", "adm0_a3_us": "GRC", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Southern Europe", "region_wb": "Europe & Central Asia", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 23.6999801, 35.70500438 ], [ 24.24666507, 35.36802237 ], [ 25.0250155, 35.42499563 ], [ 25.7692078, 35.35401805 ], [ 25.74502323, 35.17999767 ], [ 26.29000288, 35.29999034 ], [ 26.16499759, 35.00499543 ], [ 24.72498213, 34.9199877 ], [ 24.73500736, 35.08499055 ], [ 23.51497847, 35.27999156 ], [ 23.6999801, 35.70500438 ] ] ], [ [ [ 26.60419559, 41.56211457 ], [ 26.29460209, 40.9362613 ], [ 26.05694217, 40.82412344 ], [ 25.44767704, 40.85254548 ], [ 24.92584842, 40.94706167 ], [ 23.71481123, 40.68712922 ], [ 24.40799889, 40.12499299 ], [ 23.89996789, 39.96200552 ], [ 23.3429993, 39.96099783 ], [ 22.81398766, 40.47600515 ], [ 22.62629886, 40.25656118 ], [ 22.84974776, 39.65931082 ], [ 23.3500273, 39.1900113 ], [ 22.9730994, 38.97090323 ], [ 23.53001631, 38.51000113 ], [ 24.02502486, 38.21999299 ], [ 24.04001102, 37.65501455 ], [ 23.11500288, 37.9200113 ], [ 23.40997196, 37.40999075 ], [ 22.77497196, 37.30501008 ], [ 23.15422529, 36.4225058 ], [ 22.49002811, 36.41000011 ], [ 21.67002648, 36.84498648 ], [ 21.29501061, 37.64498933 ], [ 21.12003421, 38.31032339 ], [ 20.73003218, 38.76998526 ], [ 20.21771203, 39.34023469 ], [ 20.1500159, 39.62499767 ], [ 20.61500044, 40.11000682 ], [ 20.67499678, 40.4349999 ], [ 20.99998986, 40.58000397 ], [ 21.02004032, 40.84272696 ], [ 21.6741606, 40.93127452 ], [ 22.05537764, 41.14986583 ], [ 22.59730838, 41.13048717 ], [ 22.76177, 41.3048 ], [ 22.95237715, 41.33799388 ], [ 23.6920736, 41.30908092 ], [ 24.49264489, 41.58389619 ], [ 25.19720137, 41.23448599 ], [ 26.10613814, 41.32889883 ], [ 26.11704186, 41.82690461 ], [ 26.60419559, 41.56211457 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Denmark", "sov_a3": "DN1", "adm0_dif": 1.000000, "level": 2.000000, "type": "Country", "admin": "Greenland", "adm0_a3": "GRL", "geou_dif": 0.000000, "geounit": "Greenland", "gu_a3": "GRL", "su_dif": 0.000000, "subunit": "Greenland", "su_a3": "GRL", "brk_diff": 0.000000, "name": "Greenland", "name_long": "Greenland", "brk_a3": "GRL", "brk_name": "Greenland", "brk_group": null, "abbrev": "Grlnd.", "postal": "GL", "formal_en": "Greenland", "formal_fr": null, "note_adm0": "Den.", "note_brk": null, "name_sort": "Greenland", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 1.000000, "mapcolor9": 3.000000, "mapcolor13": 12.000000, "pop_est": 57600.000000, "gdp_md_est": 1100.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "2. High income: nonOECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "GL", "iso_a3": "GRL", "iso_n3": "304", "un_a3": "304", "wb_a2": "GL", "wb_a3": "GRL", "woe_id": -99.000000, "adm0_a3_is": "GRL", "adm0_a3_us": "GRL", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "North America", "region_un": "Americas", "subregion": "Northern America", "region_wb": "Europe & Central Asia", "name_len": 9.000000, "long_len": 9.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": -99.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -27.10046, 83.51966 ], [ -20.84539, 82.72669 ], [ -22.69182, 82.34165 ], [ -26.51753, 82.29765 ], [ -31.9, 82.2 ], [ -31.39646, 82.02154 ], [ -27.85666, 82.13178 ], [ -24.84448, 81.78697 ], [ -22.90328, 82.09317 ], [ -22.07175, 81.73449 ], [ -23.16961, 81.15271 ], [ -20.62363, 81.52462 ], [ -15.76818, 81.91245 ], [ -12.77018, 81.71885 ], [ -12.20855, 81.29154 ], [ -16.28533, 80.58004 ], [ -16.85, 80.35 ], [ -20.04624, 80.17708 ], [ -17.73035, 80.12912 ], [ -18.9, 79.4 ], [ -19.70499, 78.75128 ], [ -19.67353, 77.63859 ], [ -18.47285, 76.98565 ], [ -20.03503, 76.94434 ], [ -21.67944, 76.62795 ], [ -19.83407, 76.09808 ], [ -19.59896, 75.24838 ], [ -20.66818, 75.15585 ], [ -19.37281, 74.29561 ], [ -21.59422, 74.22382 ], [ -20.43454, 73.81713 ], [ -20.76234, 73.46436 ], [ -22.17221, 73.30955 ], [ -23.56593, 73.30663 ], [ -22.31311, 72.62928 ], [ -22.29954, 72.18409 ], [ -24.27834, 72.59788 ], [ -24.79296, 72.3302 ], [ -23.44296, 72.08016 ], [ -22.13281, 71.46898 ], [ -21.75356, 70.66369 ], [ -23.53603, 70.471 ], [ -24.30702, 70.85649 ], [ -25.54341, 71.43094 ], [ -25.20135, 70.75226 ], [ -26.36276, 70.22646 ], [ -23.72742, 70.18401 ], [ -22.34902, 70.12946 ], [ -25.02927, 69.2588 ], [ -27.74737, 68.47046 ], [ -30.67371, 68.12503 ], [ -31.77665, 68.12078 ], [ -32.81105, 67.73547 ], [ -34.20196, 66.67974 ], [ -36.35284, 65.9789 ], [ -37.04378, 65.93768 ], [ -38.37505, 65.69213 ], [ -39.81222, 65.45848 ], [ -40.66899, 64.83997 ], [ -40.68281, 64.13902 ], [ -41.1887, 63.48246 ], [ -42.81938, 62.68233 ], [ -42.41666, 61.90093 ], [ -42.86619, 61.07404 ], [ -43.3784, 60.09772 ], [ -44.7875, 60.03676 ], [ -46.26364, 60.85328 ], [ -48.26294, 60.85843 ], [ -49.23308, 61.40681 ], [ -49.90039, 62.38336 ], [ -51.63325, 63.62691 ], [ -52.14014, 64.27842 ], [ -52.27659, 65.1767 ], [ -53.66166, 66.09957 ], [ -53.30161, 66.8365 ], [ -53.96911, 67.18899 ], [ -52.9804, 68.35759 ], [ -51.47536, 68.72958 ], [ -51.08041, 69.14781 ], [ -50.87122, 69.9291 ], [ -52.013585, 69.574925 ], [ -52.55792, 69.42616 ], [ -53.45629, 69.283625 ], [ -54.68336, 69.61003 ], [ -54.75001, 70.28932 ], [ -54.35884, 70.821315 ], [ -53.431315, 70.835755 ], [ -51.39014, 70.56978 ], [ -53.10937, 71.20485 ], [ -54.00422, 71.54719 ], [ -55.0, 71.40653697 ], [ -55.83468, 71.65444 ], [ -54.71819, 72.58625 ], [ -55.32634, 72.95861 ], [ -56.12003, 73.64977 ], [ -57.32363, 74.71026 ], [ -58.59679, 75.09861 ], [ -58.58516, 75.51727 ], [ -61.26861, 76.10238 ], [ -63.39165, 76.1752 ], [ -66.06427, 76.13486 ], [ -68.50438, 76.06141 ], [ -69.66485, 76.37975 ], [ -71.40257, 77.00857 ], [ -68.77671, 77.32312 ], [ -66.76397, 77.37595 ], [ -71.04293, 77.63595 ], [ -73.297, 78.04419 ], [ -73.15938, 78.43271 ], [ -69.37345, 78.91388 ], [ -65.7107, 79.39436 ], [ -65.3239, 79.75814 ], [ -68.02298, 80.11721 ], [ -67.15129, 80.51582 ], [ -63.68925, 81.21396 ], [ -62.23444, 81.3211 ], [ -62.65116, 81.77042 ], [ -60.28249, 82.03363 ], [ -57.20744, 82.19074 ], [ -54.13442, 82.19962 ], [ -53.04328, 81.88833 ], [ -50.39061, 82.43883 ], [ -48.00386, 82.06481 ], [ -46.59984, 81.985945 ], [ -44.523, 81.6607 ], [ -46.9007, 82.19979 ], [ -46.76379, 82.62796 ], [ -43.40644, 83.22516 ], [ -39.89753, 83.18018 ], [ -38.62214, 83.54905 ], [ -35.08787, 83.64513 ], [ -27.10046, 83.51966 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Guatemala", "sov_a3": "GTM", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Guatemala", "adm0_a3": "GTM", "geou_dif": 0.000000, "geounit": "Guatemala", "gu_a3": "GTM", "su_dif": 0.000000, "subunit": "Guatemala", "su_a3": "GTM", "brk_diff": 0.000000, "name": "Guatemala", "name_long": "Guatemala", "brk_a3": "GTM", "brk_name": "Guatemala", "brk_group": null, "abbrev": "Guat.", "postal": "GT", "formal_en": "Republic of Guatemala", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Guatemala", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 3.000000, "mapcolor9": 3.000000, "mapcolor13": 6.000000, "pop_est": 13276517.000000, "gdp_md_est": 68580.000000, "pop_year": -99.000000, "lastcensus": 2002.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "GT", "iso_a3": "GTM", "iso_n3": "320", "un_a3": "320", "wb_a2": "GT", "wb_a3": "GTM", "woe_id": -99.000000, "adm0_a3_is": "GTM", "adm0_a3_us": "GTM", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "North America", "region_un": "Americas", "subregion": "Central America", "region_wb": "Latin America & Caribbean", "name_len": 9.000000, "long_len": 9.000000, "abbrev_len": 5.000000, "tiny": 4.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -89.14308041, 17.808319 ], [ -89.15080604, 17.01557669 ], [ -89.22912167, 15.88693757 ], [ -88.93061276, 15.88727346 ], [ -88.60458615, 15.70638011 ], [ -88.51836402, 15.85538911 ], [ -88.22502275, 15.72772248 ], [ -88.68067969, 15.34624706 ], [ -89.15481096, 15.06641918 ], [ -89.2252201, 14.8742862 ], [ -89.14553504, 14.67801911 ], [ -89.35332598, 14.4241328 ], [ -89.5873427, 14.36258617 ], [ -89.53421933, 14.24481558 ], [ -89.72193397, 14.13422801 ], [ -90.0646779, 13.88196951 ], [ -90.09555457, 13.73533763 ], [ -90.60862403, 13.90977143 ], [ -91.23241024, 13.92783234 ], [ -91.68974667, 14.12621817 ], [ -92.22775001, 14.53882864 ], [ -92.20322954, 14.83010285 ], [ -92.08721595, 15.06458466 ], [ -92.22924862, 15.25144664 ], [ -91.74796017, 16.06656485 ], [ -90.46447262, 16.06956208 ], [ -90.43886695, 16.41010977 ], [ -90.60084673, 16.4707779 ], [ -90.71182187, 16.68748302 ], [ -91.08167009, 16.91847667 ], [ -91.45392127, 17.25217723 ], [ -91.00226925, 17.2546577 ], [ -91.00151995, 17.81759492 ], [ -90.06793352, 17.81932608 ], [ -89.14308041, 17.808319 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Guyana", "sov_a3": "GUY", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Guyana", "adm0_a3": "GUY", "geou_dif": 0.000000, "geounit": "Guyana", "gu_a3": "GUY", "su_dif": 0.000000, "subunit": "Guyana", "su_a3": "GUY", "brk_diff": 0.000000, "name": "Guyana", "name_long": "Guyana", "brk_a3": "GUY", "brk_name": "Guyana", "brk_group": null, "abbrev": "Guy.", "postal": "GY", "formal_en": "Co-operative Republic of Guyana", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Guyana", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 1.000000, "mapcolor9": 4.000000, "mapcolor13": 8.000000, "pop_est": 772298.000000, "gdp_md_est": 2966.000000, "pop_year": -99.000000, "lastcensus": 2002.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "GY", "iso_a3": "GUY", "iso_n3": "328", "un_a3": "328", "wb_a2": "GY", "wb_a3": "GUY", "woe_id": -99.000000, "adm0_a3_is": "GUY", "adm0_a3_us": "GUY", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "South America", "region_un": "Americas", "subregion": "South America", "region_wb": "Latin America & Caribbean", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -57.14743649, 5.97314993 ], [ -57.30724586, 5.0735666 ], [ -57.91428891, 4.81262645 ], [ -57.86020952, 4.57680105 ], [ -58.04469438, 4.06086355 ], [ -57.60156898, 3.33465465 ], [ -57.28143348, 3.33349193 ], [ -57.15009783, 2.76892691 ], [ -56.53938575, 1.89952261 ], [ -56.78270423, 1.86371084 ], [ -57.33582292, 1.94853771 ], [ -57.66097104, 1.68258495 ], [ -58.11344988, 1.50719514 ], [ -58.4294771, 1.46394196 ], [ -58.54001299, 1.26808828 ], [ -59.03086158, 1.31769766 ], [ -59.64604367, 1.78689383 ], [ -59.7185457, 2.24963044 ], [ -59.97452491, 2.75523265 ], [ -59.81541317, 3.60649852 ], [ -59.53803992, 3.9588026 ], [ -59.76740577, 4.42350292 ], [ -60.11100237, 4.57496654 ], [ -59.98095862, 5.01406118 ], [ -60.21368344, 5.2444864 ], [ -60.73357418, 5.20027721 ], [ -61.4103029, 5.9590681 ], [ -61.13941505, 6.23429678 ], [ -61.15933631, 6.69607738 ], [ -60.54399919, 6.85658438 ], [ -60.2956681, 7.04391144 ], [ -60.63797279, 7.4149999 ], [ -60.55058794, 7.77960297 ], [ -59.75828488, 8.36703482 ], [ -59.10168413, 7.99920197 ], [ -58.48296221, 7.34769135 ], [ -58.45487606, 6.83278738 ], [ -58.0781032, 6.80909374 ], [ -57.54221859, 6.32126822 ], [ -57.14743649, 5.97314993 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Honduras", "sov_a3": "HND", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Honduras", "adm0_a3": "HND", "geou_dif": 0.000000, "geounit": "Honduras", "gu_a3": "HND", "su_dif": 0.000000, "subunit": "Honduras", "su_a3": "HND", "brk_diff": 0.000000, "name": "Honduras", "name_long": "Honduras", "brk_a3": "HND", "brk_name": "Honduras", "brk_group": null, "abbrev": "Hond.", "postal": "HN", "formal_en": "Republic of Honduras", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Honduras", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 5.000000, "mapcolor9": 2.000000, "mapcolor13": 5.000000, "pop_est": 7792854.000000, "gdp_md_est": 33720.000000, "pop_year": -99.000000, "lastcensus": 2001.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "HN", "iso_a3": "HND", "iso_n3": "340", "un_a3": "340", "wb_a2": "HN", "wb_a3": "HND", "woe_id": -99.000000, "adm0_a3_is": "HND", "adm0_a3_us": "HND", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "North America", "region_un": "Americas", "subregion": "Central America", "region_wb": "Latin America & Caribbean", "name_len": 8.000000, "long_len": 8.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -83.147219, 14.99582917 ], [ -83.48998878, 15.0162672 ], [ -83.62858497, 14.88007396 ], [ -83.9757214, 14.74943594 ], [ -84.22834164, 14.74876415 ], [ -84.4493359, 14.62161428 ], [ -84.64958208, 14.66680532 ], [ -84.82003679, 14.8195867 ], [ -84.9245007, 14.79049287 ], [ -85.05278744, 14.55154104 ], [ -85.14875058, 14.56019684 ], [ -85.16536455, 14.35436962 ], [ -85.51441301, 14.07901175 ], [ -85.69866533, 13.96007844 ], [ -85.80129473, 13.836055 ], [ -86.0962638, 14.03818736 ], [ -86.3121421, 13.77135611 ], [ -86.52070818, 13.77848745 ], [ -86.75508664, 13.75484549 ], [ -86.73382178, 13.26309256 ], [ -86.88055701, 13.25420421 ], [ -87.00576901, 13.02579438 ], [ -87.31665443, 12.98468578 ], [ -87.48940874, 13.2975349 ], [ -87.79311113, 13.3844805 ], [ -87.72350298, 13.78505036 ], [ -87.85951535, 13.89331249 ], [ -88.06534258, 13.96462596 ], [ -88.50399797, 13.84548595 ], [ -88.54123084, 13.98015473 ], [ -88.84307288, 14.1405067 ], [ -89.05851193, 14.34002941 ], [ -89.35332598, 14.4241328 ], [ -89.14553504, 14.67801911 ], [ -89.2252201, 14.8742862 ], [ -89.15481096, 15.06641918 ], [ -88.68067969, 15.34624706 ], [ -88.22502275, 15.72772248 ], [ -88.12115312, 15.6886551 ], [ -87.90181251, 15.86445832 ], [ -87.6156801, 15.87879853 ], [ -87.52292091, 15.79727896 ], [ -87.36776242, 15.84694001 ], [ -86.90319129, 15.75671296 ], [ -86.4409456, 15.78283539 ], [ -86.11923397, 15.8934488 ], [ -86.00195431, 16.00540579 ], [ -85.68331743, 15.95365184 ], [ -85.44400387, 15.88574901 ], [ -85.18244361, 15.90915843 ], [ -84.98372189, 15.99592316 ], [ -84.52697974, 15.85722362 ], [ -84.36825558, 15.83515778 ], [ -84.06305457, 15.64824413 ], [ -83.77397661, 15.42407176 ], [ -83.41038123, 15.27090282 ], [ -83.147219, 14.99582917 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Croatia", "sov_a3": "HRV", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Croatia", "adm0_a3": "HRV", "geou_dif": 0.000000, "geounit": "Croatia", "gu_a3": "HRV", "su_dif": 0.000000, "subunit": "Croatia", "su_a3": "HRV", "brk_diff": 0.000000, "name": "Croatia", "name_long": "Croatia", "brk_a3": "HRV", "brk_name": "Croatia", "brk_group": null, "abbrev": "Cro.", "postal": "HR", "formal_en": "Republic of Croatia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Croatia", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 4.000000, "mapcolor9": 5.000000, "mapcolor13": 1.000000, "pop_est": 4489409.000000, "gdp_md_est": 82390.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "2. High income: nonOECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "HR", "iso_a3": "HRV", "iso_n3": "191", "un_a3": "191", "wb_a2": "HR", "wb_a3": "HRV", "woe_id": -99.000000, "adm0_a3_is": "HRV", "adm0_a3_us": "HRV", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Southern Europe", "region_wb": "Europe & Central Asia", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 17.63006636, 45.95176911 ], [ 18.45606245, 45.75948111 ], [ 18.82982479, 45.90887236 ], [ 18.82983809, 45.90887767 ], [ 19.072769, 45.52151114 ], [ 19.3904757, 45.23651561 ], [ 19.00548628, 44.86023367 ], [ 19.0054846, 44.86023449 ], [ 18.55321415, 45.08158967 ], [ 17.86178348, 45.06774038 ], [ 17.00214603, 45.23377676 ], [ 16.53493941, 45.21160757 ], [ 16.31815677, 45.0041267 ], [ 15.9593673, 45.23377676 ], [ 15.75002608, 44.81871166 ], [ 16.23966027, 44.3511433 ], [ 16.45644291, 44.04123973 ], [ 16.91615645, 43.66772248 ], [ 17.29737349, 43.44634064 ], [ 17.6749215, 43.02856253 ], [ 18.56, 42.65 ], [ 18.45001688, 42.47999225 ], [ 18.45001631, 42.47999136 ], [ 17.50997033, 42.84999462 ], [ 16.93000573, 43.20999848 ], [ 16.01538456, 43.50721548 ], [ 15.17445397, 44.24319123 ], [ 15.37625044, 44.31791535 ], [ 14.92030928, 44.738484 ], [ 14.90160241, 45.07606029 ], [ 14.25874759, 45.23377676 ], [ 13.95225467, 44.80212352 ], [ 13.65697554, 45.13693513 ], [ 13.67940311, 45.48414907 ], [ 13.71505985, 45.5003238 ], [ 14.41196821, 45.46616568 ], [ 14.59510949, 45.6349409 ], [ 14.93524377, 45.47169505 ], [ 15.32767459, 45.45231639 ], [ 15.32395389, 45.73178254 ], [ 15.67152958, 45.83415355 ], [ 15.76873294, 46.23810822 ], [ 16.56480838, 46.50375092 ], [ 16.88251509, 46.38063182 ], [ 17.63006636, 45.95176911 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Haiti", "sov_a3": "HTI", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Haiti", "adm0_a3": "HTI", "geou_dif": 0.000000, "geounit": "Haiti", "gu_a3": "HTI", "su_dif": 0.000000, "subunit": "Haiti", "su_a3": "HTI", "brk_diff": 0.000000, "name": "Haiti", "name_long": "Haiti", "brk_a3": "HTI", "brk_name": "Haiti", "brk_group": null, "abbrev": "Haiti", "postal": "HT", "formal_en": "Republic of Haiti", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Haiti", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 1.000000, "mapcolor9": 7.000000, "mapcolor13": 2.000000, "pop_est": 9035536.000000, "gdp_md_est": 11500.000000, "pop_year": -99.000000, "lastcensus": 2003.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "HT", "iso_a3": "HTI", "iso_n3": "332", "un_a3": "332", "wb_a2": "HT", "wb_a3": "HTI", "woe_id": -99.000000, "adm0_a3_is": "HTI", "adm0_a3_us": "HTI", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "North America", "region_un": "Americas", "subregion": "Caribbean", "region_wb": "Latin America & Caribbean", "name_len": 5.000000, "long_len": 5.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -71.71236142, 19.71445588 ], [ -71.62487322, 19.16983796 ], [ -71.70130266, 18.78541698 ], [ -71.94511207, 18.61690013 ], [ -71.6877376, 18.31666006 ], [ -71.70830482, 18.04499706 ], [ -72.37247616, 18.21496084 ], [ -72.84441118, 18.14561107 ], [ -73.45455482, 18.2179064 ], [ -73.92243323, 18.03099274 ], [ -74.45803362, 18.34254995 ], [ -74.3699253, 18.66490754 ], [ -73.4495422, 18.52605296 ], [ -72.6949371, 18.44579947 ], [ -72.33488156, 18.66842154 ], [ -72.79164954, 19.10162507 ], [ -72.78410478, 19.48359142 ], [ -73.41502235, 19.63955089 ], [ -73.18979062, 19.91568391 ], [ -72.57967282, 19.87150056 ], [ -71.71236142, 19.71445588 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Hungary", "sov_a3": "HUN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Hungary", "adm0_a3": "HUN", "geou_dif": 0.000000, "geounit": "Hungary", "gu_a3": "HUN", "su_dif": 0.000000, "subunit": "Hungary", "su_a3": "HUN", "brk_diff": 0.000000, "name": "Hungary", "name_long": "Hungary", "brk_a3": "HUN", "brk_name": "Hungary", "brk_group": null, "abbrev": "Hun.", "postal": "HU", "formal_en": "Republic of Hungary", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Hungary", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 6.000000, "mapcolor9": 1.000000, "mapcolor13": 5.000000, "pop_est": 9905596.000000, "gdp_md_est": 196600.000000, "pop_year": -99.000000, "lastcensus": 2001.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "HU", "iso_a3": "HUN", "iso_n3": "348", "un_a3": "348", "wb_a2": "HU", "wb_a3": "HUN", "woe_id": -99.000000, "adm0_a3_is": "HUN", "adm0_a3_us": "HUN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Eastern Europe", "region_wb": "Europe & Central Asia", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 20.80129398, 48.62385407 ], [ 21.87223636, 48.31997081 ], [ 22.08560835, 48.42226431 ], [ 22.64081994, 48.15023957 ], [ 22.71053145, 47.88219392 ], [ 22.09976769, 47.67243928 ], [ 21.62651493, 46.99423778 ], [ 21.02195235, 46.31608796 ], [ 20.2201925, 46.12746898 ], [ 19.59604455, 46.17172984 ], [ 18.82983809, 45.90887767 ], [ 18.82982479, 45.90887236 ], [ 18.45606245, 45.75948111 ], [ 17.63006636, 45.95176911 ], [ 16.88251509, 46.38063182 ], [ 16.56480838, 46.50375092 ], [ 16.370505, 46.84132722 ], [ 16.20229821, 46.85238597 ], [ 16.53426761, 47.49617097 ], [ 16.34058434, 47.71290192 ], [ 16.9037541, 47.71486563 ], [ 16.97966678, 48.12349702 ], [ 17.48847293, 47.86746613 ], [ 17.8571326, 47.75842886 ], [ 18.69651289, 47.88095368 ], [ 18.77702477, 48.0817683 ], [ 19.17436486, 48.11137889 ], [ 19.66136356, 48.2666149 ], [ 19.76947066, 48.20269115 ], [ 20.2390544, 48.32756725 ], [ 20.47356205, 48.56285004 ], [ 20.80129398, 48.62385407 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Indonesia", "sov_a3": "IDN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Indonesia", "adm0_a3": "IDN", "geou_dif": 0.000000, "geounit": "Indonesia", "gu_a3": "IDN", "su_dif": 0.000000, "subunit": "Indonesia", "su_a3": "IDN", "brk_diff": 0.000000, "name": "Indonesia", "name_long": "Indonesia", "brk_a3": "IDN", "brk_name": "Indonesia", "brk_group": null, "abbrev": "Indo.", "postal": "INDO", "formal_en": "Republic of Indonesia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Indonesia", "name_alt": null, "mapcolor7": 6.000000, "mapcolor8": 6.000000, "mapcolor9": 6.000000, "mapcolor13": 11.000000, "pop_est": 240271522.000000, "gdp_md_est": 914600.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "4. Emerging region: MIKT", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "ID", "iso_a3": "IDN", "iso_n3": "360", "un_a3": "360", "wb_a2": "ID", "wb_a3": "IDN", "woe_id": -99.000000, "adm0_a3_is": "IDN", "adm0_a3_us": "IDN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "South-Eastern Asia", "region_wb": "East Asia & Pacific", "name_len": 9.000000, "long_len": 9.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 120.71560876, -10.23958139 ], [ 120.29501428, -10.25865 ], [ 118.96780847, -9.55796925 ], [ 119.90030969, -9.36134043 ], [ 120.42575565, -9.66592132 ], [ 120.77550174, -9.96967539 ], [ 120.71560876, -10.23958139 ] ] ], [ [ [ 124.43595015, -10.14000091 ], [ 123.57998172, -10.35998748 ], [ 123.45998905, -10.23999481 ], [ 123.55000939, -9.90001556 ], [ 123.98000899, -9.29002695 ], [ 124.96868249, -8.89279022 ], [ 125.07001997, -9.08998748 ], [ 125.08852014, -9.39317311 ], [ 124.43595015, -10.14000091 ] ] ], [ [ [ 117.90001835, -8.09568125 ], [ 118.26061649, -8.36238331 ], [ 118.87845991, -8.28068288 ], [ 119.12650679, -8.70582488 ], [ 117.97040165, -8.9066395 ], [ 117.27773075, -9.04089487 ], [ 116.74014082, -9.0329367 ], [ 117.08373742, -8.45715789 ], [ 117.63202437, -8.44930307 ], [ 117.90001835, -8.09568125 ] ] ], [ [ [ 122.90353723, -8.09423431 ], [ 122.75698286, -8.64980763 ], [ 121.25449059, -8.93366627 ], [ 119.9243909, -8.81041798 ], [ 119.92092858, -8.4448589 ], [ 120.71509199, -8.23696461 ], [ 121.34166874, -8.5367396 ], [ 122.00736454, -8.46062021 ], [ 122.90353723, -8.09423431 ] ] ], [ [ [ 108.62347863, -6.77767384 ], [ 110.53922733, -6.87735768 ], [ 110.75957564, -6.46518646 ], [ 112.61481123, -6.94603566 ], [ 112.97876835, -7.59421315 ], [ 114.47893517, -7.7765276 ], [ 115.70552697, -8.37080657 ], [ 114.56451135, -8.75181691 ], [ 113.46473351, -8.34894744 ], [ 112.55967248, -8.37618092 ], [ 111.5220614, -8.30212859 ], [ 110.58614953, -8.12260467 ], [ 109.42766727, -7.74066416 ], [ 108.69365523, -7.64160044 ], [ 108.2777633, -7.7666574 ], [ 106.454102, -7.35489959 ], [ 106.28062422, -6.9249 ], [ 105.36548628, -6.85141611 ], [ 106.05164595, -5.89591888 ], [ 107.26500858, -5.95498504 ], [ 108.0720911, -6.34576222 ], [ 108.48684614, -6.42198496 ], [ 108.62347863, -6.77767384 ] ] ], [ [ [ 134.72462447, -6.21440073 ], [ 134.21013391, -6.89523773 ], [ 134.11277551, -6.14246714 ], [ 134.29033573, -5.78305755 ], [ 134.49962528, -5.44504201 ], [ 134.72700158, -5.73758229 ], [ 134.72462447, -6.21440073 ] ] ], [ [ [ 127.24921512, -3.45906504 ], [ 126.87492272, -3.79098276 ], [ 126.18380212, -3.6073764 ], [ 125.98903364, -3.17727345 ], [ 127.00065148, -3.12931772 ], [ 127.24921512, -3.45906504 ] ] ], [ [ [ 130.47134403, -3.09376434 ], [ 130.83483605, -3.85847218 ], [ 129.9905465, -3.44630096 ], [ 129.15524865, -3.36263681 ], [ 128.59068363, -3.42867929 ], [ 127.89889123, -3.39343597 ], [ 128.13587935, -2.8436504 ], [ 129.37099776, -2.80215423 ], [ 130.47134403, -3.09376434 ] ] ], [ [ [ 134.14336795, -1.15186736 ], [ 134.42262739, -2.76918467 ], [ 135.45760298, -3.36775278 ], [ 136.29331424, -2.30704233 ], [ 137.44073775, -1.70351328 ], [ 138.32972741, -1.70268646 ], [ 139.18492069, -2.05129567 ], [ 139.9266842, -2.40905161 ], [ 141.0002104, -2.60015106 ], [ 141.01705692, -5.85902191 ], [ 141.03385176, -9.11789275 ], [ 140.14341516, -8.29716766 ], [ 139.12776655, -8.09604298 ], [ 138.88147668, -8.38093515 ], [ 137.61447391, -8.41168263 ], [ 138.03909916, -7.59788218 ], [ 138.66862145, -7.3202247 ], [ 138.40791385, -6.23284922 ], [ 137.9278398, -5.39336557 ], [ 135.98925012, -4.54654388 ], [ 135.16459761, -4.46293141 ], [ 133.66288049, -3.53885345 ], [ 133.36770471, -4.02481862 ], [ 132.98395552, -4.11297861 ], [ 132.75694095, -3.74628265 ], [ 132.75378869, -3.3117872 ], [ 131.98980432, -2.82055104 ], [ 133.06684452, -2.46041798 ], [ 133.78003096, -2.47984832 ], [ 133.69621179, -2.21454152 ], [ 132.23237349, -2.21252614 ], [ 131.83622196, -1.61716196 ], [ 130.9428398, -1.43252207 ], [ 130.51955814, -0.93772023 ], [ 131.86753788, -0.69546111 ], [ 132.38011641, -0.36953786 ], [ 133.98554813, -0.78021046 ], [ 134.14336795, -1.15186736 ] ] ], [ [ [ 125.24050052, 1.41983613 ], [ 124.43703535, 0.42788117 ], [ 123.685505, 0.23559317 ], [ 122.72308312, 0.43113679 ], [ 121.05672489, 0.38121735 ], [ 120.18308312, 0.23724681 ], [ 120.04086958, -0.51965789 ], [ 120.93590539, -1.40890594 ], [ 121.47582075, -0.95596201 ], [ 123.34056481, -0.6156727 ], [ 123.25839929, -1.07621307 ], [ 122.82271529, -0.93095062 ], [ 122.3885299, -1.51685801 ], [ 121.50827355, -1.90448292 ], [ 122.45457238, -3.18605844 ], [ 122.27189619, -3.52950001 ], [ 123.17096276, -4.68369313 ], [ 123.1623328, -5.34060394 ], [ 122.62851525, -5.63459116 ], [ 122.23639448, -5.28293304 ], [ 122.71956913, -4.46417164 ], [ 121.73823368, -4.85133148 ], [ 121.48946333, -4.5745525 ], [ 121.61917118, -4.18847788 ], [ 120.89818159, -3.6021054 ], [ 120.97238895, -2.62764292 ], [ 120.30545292, -2.93160369 ], [ 120.39004724, -4.09757903 ], [ 120.43071659, -5.52824106 ], [ 119.79654341, -5.67340016 ], [ 119.36690555, -5.37987802 ], [ 119.6536064, -4.45941741 ], [ 119.49883548, -3.49441172 ], [ 119.07834435, -3.48702199 ], [ 118.767769, -2.8019992 ], [ 119.18097375, -2.14710377 ], [ 119.323394, -1.35314707 ], [ 119.82599898, 0.15425446 ], [ 120.03570194, 0.56647736 ], [ 120.88577925, 1.30922272 ], [ 121.66681685, 1.01394359 ], [ 122.92756677, 0.87519237 ], [ 124.07752241, 0.91710196 ], [ 125.06598921, 1.64325918 ], [ 125.24050052, 1.41983613 ] ] ], [ [ [ 128.68824873, 1.13238597 ], [ 128.63595218, 0.25848583 ], [ 128.12016971, 0.35641267 ], [ 127.9680343, -0.25207733 ], [ 128.37999881, -0.78000376 ], [ 128.1000159, -0.89999643 ], [ 127.69647464, -0.2665984 ], [ 127.39949019, 1.0117215 ], [ 127.60051151, 1.81069082 ], [ 127.93237756, 2.17459626 ], [ 128.00415612, 1.6285314 ], [ 128.59455936, 1.54081066 ], [ 128.68824873, 1.13238597 ] ] ], [ [ [ 117.87562707, 1.82764069 ], [ 118.99674727, 0.90221914 ], [ 117.81185835, 0.78424185 ], [ 117.47833866, 0.10247468 ], [ 117.52164351, -0.80372324 ], [ 116.56004846, -1.48766082 ], [ 116.53379683, -2.48351735 ], [ 116.14808394, -4.01272633 ], [ 116.00085778, -3.65703745 ], [ 114.86480309, -4.10698414 ], [ 114.46865156, -3.49570363 ], [ 113.75567183, -3.43916961 ], [ 113.25699426, -3.11877573 ], [ 112.06812626, -3.47839202 ], [ 111.70329064, -2.99444223 ], [ 111.04824019, -3.04942596 ], [ 110.22384606, -2.93403248 ], [ 110.0709355, -1.59287404 ], [ 109.57194787, -1.31490651 ], [ 109.09187381, -0.45950652 ], [ 108.95265751, 0.41537547 ], [ 109.06913618, 1.34193391 ], [ 109.66326013, 2.00646699 ], [ 109.83022668, 1.33813569 ], [ 110.51406091, 0.77313142 ], [ 111.15913781, 0.97647818 ], [ 111.79754846, 0.90444123 ], [ 112.38025191, 1.41012096 ], [ 112.8598092, 1.49779003 ], [ 113.80584964, 1.21754873 ], [ 114.62135542, 1.43068818 ], [ 115.13403731, 2.82148184 ], [ 115.5190784, 3.16923839 ], [ 115.86551721, 4.30655915 ], [ 117.01521447, 4.30609406 ], [ 117.88203495, 4.13755138 ], [ 117.31323246, 3.23442821 ], [ 118.04832971, 2.28769013 ], [ 117.87562707, 1.82764069 ] ] ], [ [ [ 105.81765506, -5.85235565 ], [ 104.71038415, -5.8732846 ], [ 103.86821333, -5.03731496 ], [ 102.5842607, -4.22025888 ], [ 102.15617313, -3.61414601 ], [ 101.3991134, -2.79977711 ], [ 100.90250288, -2.05026214 ], [ 100.14198083, -0.65034759 ], [ 99.26373986, 0.18314159 ], [ 98.97001102, 1.04288239 ], [ 98.60135135, 1.82350658 ], [ 97.69959761, 2.45318391 ], [ 97.17694217, 3.30879059 ], [ 96.42401655, 3.86885977 ], [ 95.38087609, 4.97078217 ], [ 95.29302616, 5.47982087 ], [ 95.93686283, 5.43951325 ], [ 97.48488203, 5.24632091 ], [ 98.36916914, 4.26837027 ], [ 99.14255863, 3.59034964 ], [ 99.69399784, 3.17432852 ], [ 100.64143355, 2.09938121 ], [ 101.65801232, 2.08369741 ], [ 102.49827111, 1.39870047 ], [ 103.07684045, 0.5613614 ], [ 103.83839603, 0.10454173 ], [ 103.4376453, -0.7119459 ], [ 104.01078861, -1.05921152 ], [ 104.36999149, -1.08484303 ], [ 104.53949019, -1.78237151 ], [ 104.88789269, -2.34042531 ], [ 105.62211144, -2.42884368 ], [ 106.10859338, -3.06177663 ], [ 105.85744592, -4.305525 ], [ 105.81765506, -5.85235565 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "India", "sov_a3": "IND", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "India", "adm0_a3": "IND", "geou_dif": 0.000000, "geounit": "India", "gu_a3": "IND", "su_dif": 0.000000, "subunit": "India", "su_a3": "IND", "brk_diff": 0.000000, "name": "India", "name_long": "India", "brk_a3": "IND", "brk_name": "India", "brk_group": null, "abbrev": "India", "postal": "IND", "formal_en": "Republic of India", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "India", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 3.000000, "mapcolor9": 2.000000, "mapcolor13": 2.000000, "pop_est": 1166079220.000000, "gdp_md_est": 3297000.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "3. Emerging region: BRIC", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "IN", "iso_a3": "IND", "iso_n3": "356", "un_a3": "356", "wb_a2": "IN", "wb_a3": "IND", "woe_id": -99.000000, "adm0_a3_is": "IND", "adm0_a3_us": "IND", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Southern Asia", "region_wb": "South Asia", "name_len": 5.000000, "long_len": 5.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 81.11125614, 30.18348094 ], [ 80.47672123, 29.72986522 ], [ 80.08842451, 28.79447012 ], [ 81.05720259, 28.41609528 ], [ 81.99998742, 27.92547923 ], [ 83.3042489, 27.36450572 ], [ 84.67501794, 27.23490123 ], [ 85.2517786, 26.72619843 ], [ 86.02439294, 26.63098461 ], [ 87.22747196, 26.39789806 ], [ 88.06023766, 26.41461538 ], [ 88.17480432, 26.81040518 ], [ 88.04313277, 27.44581859 ], [ 88.12044071, 27.87654165 ], [ 88.73032596, 28.08686473 ], [ 88.81424849, 27.2993159 ], [ 88.83564253, 27.09896638 ], [ 89.74452762, 26.71940298 ], [ 90.37327477, 26.87572419 ], [ 91.21751265, 26.80864818 ], [ 92.03348351, 26.83831045 ], [ 92.10371179, 27.45261404 ], [ 91.69665653, 27.77174185 ], [ 92.50311893, 27.89687633 ], [ 93.41334761, 28.64062938 ], [ 94.56599043, 29.27743806 ], [ 95.40480228, 29.03171662 ], [ 96.11767866, 29.45280203 ], [ 96.58659061, 28.83097952 ], [ 96.24883345, 28.41103099 ], [ 97.32711389, 28.26158275 ], [ 97.40256148, 27.88253612 ], [ 97.05198856, 27.69905895 ], [ 97.13399906, 27.08377351 ], [ 96.41936568, 27.26458934 ], [ 95.12476769, 26.57357209 ], [ 95.15515344, 26.00130728 ], [ 94.60324914, 25.16249543 ], [ 94.55265791, 24.67523835 ], [ 94.10674198, 23.85074087 ], [ 93.32518762, 24.07855642 ], [ 93.28632694, 23.04365835 ], [ 93.06029422, 22.70311066 ], [ 93.16612756, 22.27845958 ], [ 92.67272098, 22.04123892 ], [ 92.14603478, 23.62749868 ], [ 91.86992761, 23.62434642 ], [ 91.70647505, 22.98526398 ], [ 91.15896325, 23.50352692 ], [ 91.46772993, 24.07263947 ], [ 91.91509281, 24.13041372 ], [ 92.37620161, 24.97669282 ], [ 91.79959598, 25.14743175 ], [ 90.87221073, 25.13260061 ], [ 89.92069258, 25.26974986 ], [ 89.83248091, 25.9650821 ], [ 89.35509403, 26.01440725 ], [ 88.56304935, 26.44652558 ], [ 88.20978926, 25.7680657 ], [ 88.93155399, 25.23869233 ], [ 88.30637251, 24.86607941 ], [ 88.08442224, 24.50165721 ], [ 88.69994022, 24.23371491 ], [ 88.52976973, 23.63114187 ], [ 88.87631188, 22.87914643 ], [ 89.0319613, 22.05570832 ], [ 88.8887659, 21.69058849 ], [ 88.20849735, 21.7031717 ], [ 86.97570438, 21.49556163 ], [ 87.03316857, 20.74330781 ], [ 86.49935103, 20.1516385 ], [ 85.06026574, 19.4785788 ], [ 83.94100589, 18.30200979 ], [ 83.18921716, 17.67122142 ], [ 82.19279219, 17.01663605 ], [ 82.1912419, 16.55666413 ], [ 81.69271935, 16.31021922 ], [ 80.79199914, 15.95197236 ], [ 80.32489587, 15.89918488 ], [ 80.02506921, 15.1364149 ], [ 80.23327355, 13.83577078 ], [ 80.28629357, 13.00626069 ], [ 79.86254683, 12.05621532 ], [ 79.8579993, 10.35727509 ], [ 79.34051151, 10.30885427 ], [ 78.88534549, 9.54613597 ], [ 79.18971968, 9.21654369 ], [ 78.27794071, 8.93304678 ], [ 77.9411654, 8.25295909 ], [ 77.5398979, 7.96553478 ], [ 76.59297896, 8.89927623 ], [ 76.13006148, 10.29963003 ], [ 75.74646732, 11.30825064 ], [ 75.39610111, 11.78124502 ], [ 74.86481571, 12.74193574 ], [ 74.61671716, 13.99258291 ], [ 74.44385949, 14.61722179 ], [ 73.53419925, 15.99065217 ], [ 73.1199093, 17.92857005 ], [ 72.82090946, 19.20823355 ], [ 72.82447513, 20.41950328 ], [ 72.63053348, 21.35600943 ], [ 71.17527347, 20.75744131 ], [ 70.47045861, 20.87733063 ], [ 69.16413008, 22.089298 ], [ 69.64492761, 22.45077464 ], [ 69.3495968, 22.84317963 ], [ 68.17664514, 23.69196503 ], [ 68.84259932, 24.35913361 ], [ 71.04324019, 24.35652395 ], [ 70.84469933, 25.21510204 ], [ 70.28287316, 25.72222871 ], [ 70.16892663, 26.49187165 ], [ 69.51439294, 26.94096568 ], [ 70.61649621, 27.98919628 ], [ 71.77766564, 27.91318024 ], [ 72.82375166, 28.9615917 ], [ 73.45063846, 29.97641348 ], [ 74.42138024, 30.97981476 ], [ 74.40592899, 31.69263947 ], [ 75.2586418, 32.27110546 ], [ 74.45155928, 32.7648996 ], [ 74.10429365, 33.44147329 ], [ 73.74994836, 34.31769888 ], [ 74.24020267, 34.74888703 ], [ 75.75706099, 34.50492259 ], [ 76.87172163, 34.65354401 ], [ 77.8374508, 35.49400951 ], [ 78.91226891, 34.32193635 ], [ 78.81108646, 33.50619803 ], [ 79.20889164, 32.99439464 ], [ 79.17612878, 32.48377981 ], [ 78.45844649, 32.61816437 ], [ 78.73889448, 31.51590607 ], [ 79.72136682, 30.88271475 ], [ 81.11125614, 30.18348094 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Ireland", "sov_a3": "IRL", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Ireland", "adm0_a3": "IRL", "geou_dif": 0.000000, "geounit": "Ireland", "gu_a3": "IRL", "su_dif": 0.000000, "subunit": "Ireland", "su_a3": "IRL", "brk_diff": 0.000000, "name": "Ireland", "name_long": "Ireland", "brk_a3": "IRL", "brk_name": "Ireland", "brk_group": null, "abbrev": "Ire.", "postal": "IRL", "formal_en": "Ireland", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Ireland", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 3.000000, "mapcolor9": 2.000000, "mapcolor13": 2.000000, "pop_est": 4203200.000000, "gdp_md_est": 188400.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "IE", "iso_a3": "IRL", "iso_n3": "372", "un_a3": "372", "wb_a2": "IE", "wb_a3": "IRL", "woe_id": -99.000000, "adm0_a3_is": "IRL", "adm0_a3_us": "IRL", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Northern Europe", "region_wb": "Europe & Central Asia", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -6.19788489, 53.86756501 ], [ -6.0329854, 53.15316417 ], [ -6.78885657, 52.26011791 ], [ -8.56161658, 51.66930126 ], [ -9.97708574, 51.82045482 ], [ -9.16628252, 52.86462881 ], [ -9.68852454, 53.88136262 ], [ -8.32798743, 54.66451895 ], [ -7.57216793, 55.13162222 ], [ -7.36603065, 54.59584097 ], [ -7.57216793, 54.05995637 ], [ -6.95373023, 54.0737023 ], [ -6.19788489, 53.86756501 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Iran", "sov_a3": "IRN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Iran", "adm0_a3": "IRN", "geou_dif": 0.000000, "geounit": "Iran", "gu_a3": "IRN", "su_dif": 0.000000, "subunit": "Iran", "su_a3": "IRN", "brk_diff": 0.000000, "name": "Iran", "name_long": "Iran", "brk_a3": "IRN", "brk_name": "Iran", "brk_group": null, "abbrev": "Iran", "postal": "IRN", "formal_en": "Islamic Republic of Iran", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Iran, Islamic Rep.", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 3.000000, "mapcolor9": 4.000000, "mapcolor13": 13.000000, "pop_est": 66429284.000000, "gdp_md_est": 841700.000000, "pop_year": -99.000000, "lastcensus": 2006.000000, "gdp_year": -99.000000, "economy": "5. Emerging region: G20", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "IR", "iso_a3": "IRN", "iso_n3": "364", "un_a3": "364", "wb_a2": "IR", "wb_a3": "IRN", "woe_id": -99.000000, "adm0_a3_is": "IRN", "adm0_a3_us": "IRN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Southern Asia", "region_wb": "Middle East & North Africa", "name_len": 4.000000, "long_len": 4.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 45.4577218, 38.87413911 ], [ 46.14362308, 38.74120148 ], [ 46.50571984, 38.77060537 ], [ 47.68507938, 39.50836396 ], [ 48.06009525, 39.58223542 ], [ 48.35552941, 39.28876496 ], [ 48.01074426, 38.7940148 ], [ 48.63437544, 38.27037751 ], [ 48.88324914, 38.32024527 ], [ 49.19961226, 37.58287425 ], [ 50.14777144, 37.37456656 ], [ 50.84235436, 36.87281424 ], [ 52.26402469, 36.70042166 ], [ 53.82578983, 36.96503083 ], [ 53.92159793, 37.19891836 ], [ 54.80030399, 37.39242076 ], [ 55.5115784, 37.96411713 ], [ 56.18037479, 37.93512665 ], [ 56.61936608, 38.12139435 ], [ 57.33043379, 38.02922944 ], [ 58.43615441, 37.52230948 ], [ 59.234762, 37.41298798 ], [ 60.37763797, 36.52738312 ], [ 61.12307051, 36.49159719 ], [ 61.21081709, 35.65007233 ], [ 60.80319339, 34.40410187 ], [ 60.5284298, 33.67644603 ], [ 60.96370039, 33.5288323 ], [ 60.53607792, 32.98126883 ], [ 60.86365482, 32.18291962 ], [ 60.94194461, 31.54807465 ], [ 61.69931441, 31.37950613 ], [ 61.78122155, 30.73585033 ], [ 60.87424849, 29.829239 ], [ 61.36930871, 29.30327627 ], [ 61.77186812, 28.69933381 ], [ 62.72783044, 28.25964488 ], [ 62.75542565, 27.37892345 ], [ 63.23389774, 27.21704702 ], [ 63.31663171, 26.7565325 ], [ 61.87418745, 26.23997488 ], [ 61.49736291, 25.07823701 ], [ 59.61613407, 25.38015656 ], [ 58.52576135, 25.60996166 ], [ 57.39725142, 25.73990205 ], [ 56.97076582, 26.96610627 ], [ 56.49213871, 27.14330476 ], [ 55.72371016, 26.96463349 ], [ 54.71508955, 26.48065786 ], [ 53.49309696, 26.81236888 ], [ 52.48359785, 27.58084911 ], [ 51.52076257, 27.8656896 ], [ 50.85294803, 28.81452058 ], [ 50.11500858, 30.14777253 ], [ 49.57685021, 29.98571524 ], [ 48.94133345, 30.31709036 ], [ 48.56797123, 29.92677827 ], [ 48.01456831, 30.45245677 ], [ 48.00469811, 30.98513744 ], [ 47.68528609, 30.98485322 ], [ 47.84920373, 31.70917593 ], [ 47.33466149, 32.46915538 ], [ 46.10936161, 33.0172873 ], [ 45.41669071, 33.96779776 ], [ 45.64845951, 34.74813772 ], [ 46.15178796, 35.09325878 ], [ 46.07634037, 35.67738333 ], [ 45.42061812, 35.97754588 ], [ 44.7726771, 37.17043693 ], [ 44.77267, 37.17045 ], [ 44.22575565, 37.97158438 ], [ 44.42140262, 38.28128124 ], [ 44.10922529, 39.4281363 ], [ 44.7939897, 39.71300263 ], [ 44.95268802, 39.33576468 ], [ 45.4577218, 38.87413911 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Iraq", "sov_a3": "IRQ", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Iraq", "adm0_a3": "IRQ", "geou_dif": 0.000000, "geounit": "Iraq", "gu_a3": "IRQ", "su_dif": 0.000000, "subunit": "Iraq", "su_a3": "IRQ", "brk_diff": 0.000000, "name": "Iraq", "name_long": "Iraq", "brk_a3": "IRQ", "brk_name": "Iraq", "brk_group": null, "abbrev": "Iraq", "postal": "IRQ", "formal_en": "Republic of Iraq", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Iraq", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 4.000000, "mapcolor9": 3.000000, "mapcolor13": 1.000000, "pop_est": 31129225.000000, "gdp_md_est": 103900.000000, "pop_year": -99.000000, "lastcensus": 1997.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "IQ", "iso_a3": "IRQ", "iso_n3": "368", "un_a3": "368", "wb_a2": "IQ", "wb_a3": "IRQ", "woe_id": -99.000000, "adm0_a3_is": "IRQ", "adm0_a3_us": "IRQ", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Western Asia", "region_wb": "Middle East & North Africa", "name_len": 4.000000, "long_len": 4.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 43.94225874, 37.25622753 ], [ 44.29345178, 37.00151439 ], [ 44.7726771, 37.17043693 ], [ 44.77269901, 37.17044465 ], [ 45.42061812, 35.97754588 ], [ 46.07634037, 35.67738333 ], [ 46.15178796, 35.09325878 ], [ 45.64845951, 34.74813772 ], [ 45.41669071, 33.96779776 ], [ 46.10936161, 33.0172873 ], [ 47.33466149, 32.46915538 ], [ 47.84920373, 31.70917593 ], [ 47.68528609, 30.98485322 ], [ 48.00469811, 30.98513744 ], [ 48.01456831, 30.45245677 ], [ 48.56797123, 29.92677827 ], [ 47.97451908, 29.9758192 ], [ 47.3026221, 30.05906993 ], [ 46.56871341, 29.09902517 ], [ 44.70949873, 29.1788911 ], [ 41.88998091, 31.19000865 ], [ 40.39999434, 31.88999177 ], [ 39.19546838, 32.16100882 ], [ 38.79234053, 33.37868643 ], [ 41.00615889, 34.41937226 ], [ 41.38396529, 35.62831656 ], [ 41.28970747, 36.3588146 ], [ 41.83706424, 36.60585379 ], [ 42.3495911, 37.22987254 ], [ 42.7791256, 37.38526358 ], [ 43.94225874, 37.25622753 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Iceland", "sov_a3": "ISL", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Iceland", "adm0_a3": "ISL", "geou_dif": 0.000000, "geounit": "Iceland", "gu_a3": "ISL", "su_dif": 0.000000, "subunit": "Iceland", "su_a3": "ISL", "brk_diff": 0.000000, "name": "Iceland", "name_long": "Iceland", "brk_a3": "ISL", "brk_name": "Iceland", "brk_group": null, "abbrev": "Iceland", "postal": "IS", "formal_en": "Republic of Iceland", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Iceland", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 4.000000, "mapcolor9": 4.000000, "mapcolor13": 9.000000, "pop_est": 306694.000000, "gdp_md_est": 12710.000000, "pop_year": -99.000000, "lastcensus": -99.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "IS", "iso_a3": "ISL", "iso_n3": "352", "un_a3": "352", "wb_a2": "IS", "wb_a3": "ISL", "woe_id": -99.000000, "adm0_a3_is": "ISL", "adm0_a3_us": "ISL", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Northern Europe", "region_wb": "Europe & Central Asia", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 7.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -14.50869544, 66.45589224 ], [ -14.73963742, 65.80874828 ], [ -13.60973222, 65.12667105 ], [ -14.90983375, 64.36408194 ], [ -17.79443804, 63.67874909 ], [ -18.6562459, 63.49638296 ], [ -19.97275469, 63.64363496 ], [ -22.76297197, 63.96017894 ], [ -21.77848426, 64.40211579 ], [ -23.95504391, 64.89112987 ], [ -22.18440264, 65.08496817 ], [ -22.22742327, 65.37859366 ], [ -24.32618405, 65.61118928 ], [ -23.6505147, 66.26251903 ], [ -22.13492245, 66.41046866 ], [ -20.57628374, 65.73211213 ], [ -19.0568416, 66.27660086 ], [ -17.79862383, 65.99385326 ], [ -16.16781898, 66.5267923 ], [ -14.50869544, 66.45589224 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Israel", "sov_a3": "ISR", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Israel", "adm0_a3": "ISR", "geou_dif": 0.000000, "geounit": "Israel", "gu_a3": "ISR", "su_dif": 0.000000, "subunit": "Israel", "su_a3": "ISR", "brk_diff": 0.000000, "name": "Israel", "name_long": "Israel", "brk_a3": "ISR", "brk_name": "Israel", "brk_group": null, "abbrev": "Isr.", "postal": "IS", "formal_en": "State of Israel", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Israel", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 2.000000, "mapcolor9": 5.000000, "mapcolor13": 9.000000, "pop_est": 7233701.000000, "gdp_md_est": 201400.000000, "pop_year": -99.000000, "lastcensus": 2009.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "IL", "iso_a3": "ISR", "iso_n3": "376", "un_a3": "376", "wb_a2": "IL", "wb_a3": "ISR", "woe_id": -99.000000, "adm0_a3_is": "ISR", "adm0_a3_us": "ISR", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Western Asia", "region_wb": "Middle East & North Africa", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 35.8211007, 33.27742646 ], [ 35.83639693, 32.86812328 ], [ 35.70079797, 32.7160137 ], [ 35.71991825, 32.70919241 ], [ 35.54566532, 32.39399201 ], [ 35.18393029, 32.53251069 ], [ 34.97464074, 31.86658234 ], [ 35.22589155, 31.75434113 ], [ 34.97050663, 31.61677847 ], [ 34.92740848, 31.35343537 ], [ 35.39756066, 31.48908601 ], [ 35.42091841, 31.10006582 ], [ 34.92260257, 29.5013262 ], [ 34.82324329, 29.76108077 ], [ 34.26543474, 31.21935731 ], [ 34.26543338, 31.21936087 ], [ 34.5563717, 31.54882396 ], [ 34.48810713, 31.60553885 ], [ 34.75258711, 32.07292634 ], [ 34.95541711, 32.82737641 ], [ 35.09845747, 33.08053925 ], [ 35.12605269, 33.09090038 ], [ 35.46070926, 33.08904003 ], [ 35.55279667, 33.26427481 ], [ 35.8211007, 33.27742646 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Italy", "sov_a3": "ITA", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Italy", "adm0_a3": "ITA", "geou_dif": 0.000000, "geounit": "Italy", "gu_a3": "ITA", "su_dif": 0.000000, "subunit": "Italy", "su_a3": "ITA", "brk_diff": 0.000000, "name": "Italy", "name_long": "Italy", "brk_a3": "ITA", "brk_name": "Italy", "brk_group": null, "abbrev": "Italy", "postal": "I", "formal_en": "Italian Republic", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Italy", "name_alt": null, "mapcolor7": 6.000000, "mapcolor8": 7.000000, "mapcolor9": 8.000000, "mapcolor13": 7.000000, "pop_est": 58126212.000000, "gdp_md_est": 1823000.000000, "pop_year": -99.000000, "lastcensus": 2012.000000, "gdp_year": -99.000000, "economy": "1. Developed region: G7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "IT", "iso_a3": "ITA", "iso_n3": "380", "un_a3": "380", "wb_a2": "IT", "wb_a3": "ITA", "woe_id": -99.000000, "adm0_a3_is": "ITA", "adm0_a3_us": "ITA", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Southern Europe", "region_wb": "Europe & Central Asia", "name_len": 5.000000, "long_len": 5.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 15.52037601, 38.2311551 ], [ 15.16024295, 37.44404552 ], [ 15.3098979, 37.13421947 ], [ 15.09998823, 36.61998729 ], [ 14.33522871, 36.99663097 ], [ 13.82673262, 37.10453136 ], [ 12.43100386, 37.61294994 ], [ 12.57094364, 38.12638113 ], [ 13.74115645, 38.03496552 ], [ 14.76124922, 38.1438736 ], [ 15.52037601, 38.2311551 ] ] ], [ [ [ 9.21001183, 41.20999136 ], [ 9.80997521, 40.50000886 ], [ 9.66951867, 39.17737641 ], [ 9.21481774, 39.24047333 ], [ 8.80693566, 38.90661774 ], [ 8.42830244, 39.17184703 ], [ 8.38825321, 40.37831086 ], [ 8.15999841, 40.95000723 ], [ 8.70999068, 40.89998444 ], [ 9.21001183, 41.20999136 ] ] ], [ [ [ 12.37648522, 46.76755911 ], [ 13.80647546, 46.50930614 ], [ 13.69810998, 46.01677806 ], [ 13.93763024, 45.59101594 ], [ 13.14160648, 45.7366918 ], [ 12.32858117, 45.38177806 ], [ 12.38387495, 44.88537425 ], [ 12.26145348, 44.60048208 ], [ 12.58923709, 44.09136587 ], [ 13.52690596, 43.58772736 ], [ 14.029821, 42.7610078 ], [ 15.14256961, 41.95513968 ], [ 15.92619103, 41.96131501 ], [ 16.16989709, 41.74029491 ], [ 15.88934574, 41.54108226 ], [ 16.78500166, 41.17960562 ], [ 17.51916874, 40.87714346 ], [ 18.37668745, 40.3556249 ], [ 18.48024702, 40.16886628 ], [ 18.29338504, 39.81077444 ], [ 17.73838016, 40.27767101 ], [ 16.86959598, 40.44223461 ], [ 16.44874312, 39.7954007 ], [ 17.1714897, 39.42469982 ], [ 17.05284061, 38.9028712 ], [ 16.63508833, 38.8435725 ], [ 16.10096073, 37.98589875 ], [ 15.68408695, 37.90884919 ], [ 15.68796268, 38.2145928 ], [ 15.89198124, 38.75094249 ], [ 16.10933231, 38.96454702 ], [ 15.71881351, 39.54407237 ], [ 15.4136125, 40.04835684 ], [ 14.99849572, 40.17294872 ], [ 14.70326826, 40.60455028 ], [ 14.06067183, 40.78634797 ], [ 13.62798506, 41.18828726 ], [ 12.8880819, 41.2530895 ], [ 12.10668257, 41.70453482 ], [ 11.19190637, 42.35542532 ], [ 10.51194787, 42.93146251 ], [ 10.20002892, 43.92000682 ], [ 9.70248823, 44.03627879 ], [ 8.88894616, 44.36633617 ], [ 8.42856083, 44.23122814 ], [ 7.85076664, 43.76714794 ], [ 7.43518477, 43.69384492 ], [ 7.54959639, 44.12790111 ], [ 7.00756229, 44.25476675 ], [ 6.74995528, 45.02851797 ], [ 7.09665246, 45.33309886 ], [ 6.80235518, 45.70857982 ], [ 6.84359297, 45.99114655 ], [ 7.27385095, 45.77694774 ], [ 7.75599206, 45.82449006 ], [ 8.31662967, 46.16364248 ], [ 8.48995243, 46.00515087 ], [ 8.96630578, 46.03693187 ], [ 9.18288171, 46.44021475 ], [ 9.92283654, 46.3148994 ], [ 10.36337813, 46.48357128 ], [ 10.44270145, 46.89354625 ], [ 11.04855594, 46.75135855 ], [ 11.16482792, 46.94157949 ], [ 12.15308801, 47.11539317 ], [ 12.37648522, 46.76755911 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Jamaica", "sov_a3": "JAM", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Jamaica", "adm0_a3": "JAM", "geou_dif": 0.000000, "geounit": "Jamaica", "gu_a3": "JAM", "su_dif": 0.000000, "subunit": "Jamaica", "su_a3": "JAM", "brk_diff": 0.000000, "name": "Jamaica", "name_long": "Jamaica", "brk_a3": "JAM", "brk_name": "Jamaica", "brk_group": null, "abbrev": "Jam.", "postal": "J", "formal_en": "Jamaica", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Jamaica", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 2.000000, "mapcolor9": 4.000000, "mapcolor13": 10.000000, "pop_est": 2825928.000000, "gdp_md_est": 20910.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "JM", "iso_a3": "JAM", "iso_n3": "388", "un_a3": "388", "wb_a2": "JM", "wb_a3": "JAM", "woe_id": -99.000000, "adm0_a3_is": "JAM", "adm0_a3_us": "JAM", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "North America", "region_un": "Americas", "subregion": "Caribbean", "region_wb": "Latin America & Caribbean", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -76.90256141, 17.86823782 ], [ -77.20634132, 17.70111624 ], [ -77.76602292, 17.8615974 ], [ -78.33771929, 18.22596792 ], [ -78.21772661, 18.45453278 ], [ -77.79736467, 18.52421845 ], [ -77.5696008, 18.49052542 ], [ -76.89661862, 18.40086681 ], [ -76.36535906, 18.16070059 ], [ -76.19965858, 17.88686717 ], [ -76.90256141, 17.86823782 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Jordan", "sov_a3": "JOR", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Jordan", "adm0_a3": "JOR", "geou_dif": 0.000000, "geounit": "Jordan", "gu_a3": "JOR", "su_dif": 0.000000, "subunit": "Jordan", "su_a3": "JOR", "brk_diff": 0.000000, "name": "Jordan", "name_long": "Jordan", "brk_a3": "JOR", "brk_name": "Jordan", "brk_group": null, "abbrev": "Jord.", "postal": "J", "formal_en": "Hashemite Kingdom of Jordan", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Jordan", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 3.000000, "mapcolor9": 4.000000, "mapcolor13": 4.000000, "pop_est": 6342948.000000, "gdp_md_est": 31610.000000, "pop_year": -99.000000, "lastcensus": 2004.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "JO", "iso_a3": "JOR", "iso_n3": "400", "un_a3": "400", "wb_a2": "JO", "wb_a3": "JOR", "woe_id": -99.000000, "adm0_a3_is": "JOR", "adm0_a3_us": "JOR", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Western Asia", "region_wb": "Middle East & North Africa", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 39.19546838, 32.16100882 ], [ 39.0048857, 32.01021699 ], [ 37.00216556, 31.50841299 ], [ 37.99884891, 30.50849986 ], [ 37.66811974, 30.33866527 ], [ 37.50358198, 30.00377615 ], [ 36.74052778, 29.86528331 ], [ 36.50121423, 29.50525361 ], [ 36.06894087, 29.19749462 ], [ 34.95603723, 29.35655467 ], [ 34.92260257, 29.5013262 ], [ 35.42091841, 31.10006582 ], [ 35.39756066, 31.48908601 ], [ 35.54525191, 31.78250479 ], [ 35.54566532, 32.39399201 ], [ 35.71991825, 32.70919241 ], [ 36.83406213, 32.31293753 ], [ 38.79234053, 33.37868643 ], [ 39.19546838, 32.16100882 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Japan", "sov_a3": "JPN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Japan", "adm0_a3": "JPN", "geou_dif": 0.000000, "geounit": "Japan", "gu_a3": "JPN", "su_dif": 0.000000, "subunit": "Japan", "su_a3": "JPN", "brk_diff": 0.000000, "name": "Japan", "name_long": "Japan", "brk_a3": "JPN", "brk_name": "Japan", "brk_group": null, "abbrev": "Japan", "postal": "J", "formal_en": "Japan", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Japan", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 3.000000, "mapcolor9": 5.000000, "mapcolor13": 4.000000, "pop_est": 127078679.000000, "gdp_md_est": 4329000.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "1. Developed region: G7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "JP", "iso_a3": "JPN", "iso_n3": "392", "un_a3": "392", "wb_a2": "JP", "wb_a3": "JPN", "woe_id": -99.000000, "adm0_a3_is": "JPN", "adm0_a3_us": "JPN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Eastern Asia", "region_wb": "East Asia & Pacific", "name_len": 5.000000, "long_len": 5.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 134.63842818, 34.14923371 ], [ 134.76637902, 33.80633474 ], [ 134.20341597, 33.20117788 ], [ 133.79295007, 33.52198518 ], [ 133.28026818, 33.28957042 ], [ 133.01485803, 32.70456737 ], [ 132.36311486, 32.98938203 ], [ 132.37117639, 33.46364248 ], [ 132.92437259, 34.06029857 ], [ 133.49296838, 33.94462088 ], [ 133.90410607, 34.36493114 ], [ 134.63842818, 34.14923371 ] ] ], [ [ [ 140.97638757, 37.14207429 ], [ 140.59976973, 36.34398347 ], [ 140.77407433, 35.8428771 ], [ 140.25327925, 35.13811392 ], [ 138.97552779, 34.6676 ], [ 137.21759891, 34.60628592 ], [ 135.79298303, 33.4648052 ], [ 135.1209827, 33.84907115 ], [ 135.07943485, 34.59654491 ], [ 133.3403162, 34.37593822 ], [ 132.15677087, 33.90493338 ], [ 130.98614465, 33.88576142 ], [ 132.00003625, 33.14999238 ], [ 131.33279016, 31.45035452 ], [ 130.68631799, 31.02957917 ], [ 130.20241988, 31.41823762 ], [ 130.44767622, 32.3194746 ], [ 129.8146916, 32.61030956 ], [ 129.40846317, 33.29605581 ], [ 130.35393517, 33.6041507 ], [ 130.87845096, 34.23274282 ], [ 131.88422936, 34.74971385 ], [ 132.61767297, 35.43339305 ], [ 134.60830082, 35.73161774 ], [ 135.67753788, 35.5271341 ], [ 136.7238306, 37.30498424 ], [ 137.39061161, 36.82739065 ], [ 138.85760217, 37.82748465 ], [ 139.42640466, 38.21596223 ], [ 140.05479007, 39.43880748 ], [ 139.88337935, 40.56331249 ], [ 140.30578251, 41.19500519 ], [ 141.36897342, 41.37855988 ], [ 141.91426314, 39.99161612 ], [ 141.88460086, 39.18086457 ], [ 140.95948937, 38.17400096 ], [ 140.97638757, 37.14207429 ] ] ], [ [ [ 143.91016198, 44.17409984 ], [ 144.61342655, 43.96088288 ], [ 145.32082523, 44.38473298 ], [ 145.54313724, 43.26208832 ], [ 144.0596619, 42.98835826 ], [ 143.18384973, 41.99521475 ], [ 141.61149092, 42.6787906 ], [ 141.06728641, 41.58459382 ], [ 139.95510624, 41.56955598 ], [ 139.81754357, 42.56375886 ], [ 140.31208703, 43.33327261 ], [ 141.38054894, 43.38882477 ], [ 141.67195235, 44.77212535 ], [ 141.96764489, 45.55148347 ], [ 143.14287031, 44.51035838 ], [ 143.91016198, 44.17409984 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Kazakhstan", "sov_a3": "KAZ", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Kazakhstan", "adm0_a3": "KAZ", "geou_dif": 0.000000, "geounit": "Kazakhstan", "gu_a3": "KAZ", "su_dif": 0.000000, "subunit": "Kazakhstan", "su_a3": "KAZ", "brk_diff": 0.000000, "name": "Kazakhstan", "name_long": "Kazakhstan", "brk_a3": "KAZ", "brk_name": "Kazakhstan", "brk_group": null, "abbrev": "Kaz.", "postal": "KZ", "formal_en": "Republic of Kazakhstan", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Kazakhstan", "name_alt": null, "mapcolor7": 6.000000, "mapcolor8": 1.000000, "mapcolor9": 6.000000, "mapcolor13": 1.000000, "pop_est": 15399437.000000, "gdp_md_est": 175800.000000, "pop_year": -99.000000, "lastcensus": 2009.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "KZ", "iso_a3": "KAZ", "iso_n3": "398", "un_a3": "398", "wb_a2": "KZ", "wb_a3": "KAZ", "woe_id": -99.000000, "adm0_a3_is": "KAZ", "adm0_a3_us": "KAZ", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Central Asia", "region_wb": "Europe & Central Asia", "name_len": 10.000000, "long_len": 10.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 70.86526655, 55.16973359 ], [ 71.18013106, 54.13328522 ], [ 72.22415002, 54.37665538 ], [ 73.50851607, 54.03561677 ], [ 73.42567875, 53.48981029 ], [ 74.38484501, 53.54686107 ], [ 76.89110029, 54.4905244 ], [ 76.52517948, 54.17700349 ], [ 77.80091556, 53.40441498 ], [ 80.03555952, 50.86475088 ], [ 80.56844689, 51.38833649 ], [ 81.94598555, 50.81219595 ], [ 83.38300378, 51.06918285 ], [ 83.93511478, 50.88924551 ], [ 84.41637739, 50.31139964 ], [ 85.11555952, 50.11730296 ], [ 85.54126997, 49.69285859 ], [ 86.82935672, 49.82667471 ], [ 87.35997033, 49.21498078 ], [ 86.59877648, 48.54918163 ], [ 85.76823286, 48.45575064 ], [ 85.72048384, 47.45296947 ], [ 85.1642904, 47.00095572 ], [ 83.18048384, 47.33003124 ], [ 82.45892582, 45.53964956 ], [ 81.94707075, 45.31702749 ], [ 79.9661064, 44.91751699 ], [ 80.8662065, 43.18036205 ], [ 80.18015018, 42.92006786 ], [ 80.25999027, 42.34999929 ], [ 79.64364546, 42.49668285 ], [ 79.14217736, 42.85609243 ], [ 77.65839196, 42.96068553 ], [ 76.00035363, 42.98802237 ], [ 75.63696496, 42.87789989 ], [ 74.21286584, 43.29833934 ], [ 73.64530358, 43.09127188 ], [ 73.48975752, 42.50089448 ], [ 71.8446383, 42.84539541 ], [ 71.18628055, 42.70429291 ], [ 70.96231489, 42.26615428 ], [ 70.38896488, 42.08130768 ], [ 69.0700273, 41.38424429 ], [ 68.63248294, 40.66868073 ], [ 68.25989587, 40.66232453 ], [ 67.98585575, 41.13599071 ], [ 66.71404707, 41.16844351 ], [ 66.51064863, 41.98764415 ], [ 66.02339155, 41.99464631 ], [ 66.09801232, 42.99766002 ], [ 64.90082442, 43.72808055 ], [ 63.18578698, 43.65007498 ], [ 62.01330041, 43.50447663 ], [ 61.05831994, 44.40581696 ], [ 60.23997196, 44.78403677 ], [ 58.68998905, 45.50001374 ], [ 58.50312707, 45.58680431 ], [ 55.92891727, 44.99585847 ], [ 55.96819136, 41.30864167 ], [ 55.45525109, 41.25985912 ], [ 54.75534549, 42.04397146 ], [ 54.07941776, 42.3241094 ], [ 52.94429325, 42.11603425 ], [ 52.50245975, 41.78331554 ], [ 52.44633915, 42.02715078 ], [ 52.69211226, 42.44389537 ], [ 52.50142622, 42.79229788 ], [ 51.3424272, 43.13297476 ], [ 50.89129195, 44.03103364 ], [ 50.33912927, 44.28401561 ], [ 50.30564294, 44.60983552 ], [ 51.27850345, 44.51485423 ], [ 51.31689904, 45.24599824 ], [ 52.16738976, 45.40839143 ], [ 53.0408765, 45.25904654 ], [ 53.22086551, 46.2346459 ], [ 53.04273685, 46.85300609 ], [ 52.04202274, 46.80463695 ], [ 51.19194543, 47.04870474 ], [ 50.03408329, 46.60898998 ], [ 49.10116, 46.39933 ], [ 48.593241, 46.56103425 ], [ 48.69473351, 47.07562816 ], [ 48.05725305, 47.74375275 ], [ 47.31523115, 47.71584748 ], [ 46.46644575, 48.39415233 ], [ 47.0436715, 49.15203889 ], [ 46.75159631, 49.35600576 ], [ 47.54948042, 50.45469839 ], [ 48.57784142, 49.87475963 ], [ 48.70238163, 50.60512849 ], [ 50.76664839, 51.69276236 ], [ 52.32872359, 51.71865225 ], [ 54.53287845, 51.02623973 ], [ 55.71694055, 50.62171662 ], [ 56.77796105, 51.04355134 ], [ 58.36329064, 51.06365347 ], [ 59.64228234, 50.54544221 ], [ 59.93280724, 50.84219412 ], [ 61.33742435, 50.79907014 ], [ 61.58800337, 51.2726588 ], [ 59.96753381, 51.96042044 ], [ 60.92726851, 52.44754833 ], [ 60.73999312, 52.71998648 ], [ 61.6999862, 52.97999645 ], [ 60.97806644, 53.66499339 ], [ 61.43659142, 54.00626455 ], [ 65.17853356, 54.35422781 ], [ 65.66687585, 54.60126699 ], [ 68.16910038, 54.97039175 ], [ 69.06816695, 55.38525015 ], [ 70.86526655, 55.16973359 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Kenya", "sov_a3": "KEN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Kenya", "adm0_a3": "KEN", "geou_dif": 0.000000, "geounit": "Kenya", "gu_a3": "KEN", "su_dif": 0.000000, "subunit": "Kenya", "su_a3": "KEN", "brk_diff": 0.000000, "name": "Kenya", "name_long": "Kenya", "brk_a3": "KEN", "brk_name": "Kenya", "brk_group": null, "abbrev": "Ken.", "postal": "KE", "formal_en": "Republic of Kenya", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Kenya", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 2.000000, "mapcolor9": 7.000000, "mapcolor13": 3.000000, "pop_est": 39002772.000000, "gdp_md_est": 61510.000000, "pop_year": -99.000000, "lastcensus": 2009.000000, "gdp_year": -99.000000, "economy": "5. Emerging region: G20", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "KE", "iso_a3": "KEN", "iso_n3": "404", "un_a3": "404", "wb_a2": "KE", "wb_a3": "KEN", "woe_id": -99.000000, "adm0_a3_is": "KEN", "adm0_a3_us": "KEN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Eastern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 5.000000, "long_len": 5.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 41.85508309, 3.91891192 ], [ 40.98105, 2.78452 ], [ 40.993, -0.85829 ], [ 41.58513, -1.68325 ], [ 40.88477, -2.08255 ], [ 40.63785, -2.49979 ], [ 40.26304, -2.57309 ], [ 40.12119, -3.27768 ], [ 39.80006, -3.68116 ], [ 39.60489, -4.34653 ], [ 39.20222, -4.67677 ], [ 37.7669, -3.67712 ], [ 37.69869, -3.09699 ], [ 34.07262917, -1.05982515 ], [ 34.1362423, -0.31930836 ], [ 33.8940477, 0.05978836 ], [ 33.89356897, 0.10981354 ], [ 34.18, 0.515 ], [ 34.6721, 1.17694 ], [ 35.03599, 1.90584 ], [ 34.59607, 3.05374 ], [ 34.47913, 3.5556 ], [ 34.005, 4.24988495 ], [ 34.62019627, 4.84712274 ], [ 35.29800712, 5.506 ], [ 35.81744766, 5.33823208 ], [ 35.81744766, 4.77696566 ], [ 36.15907863, 4.44786413 ], [ 36.85509324, 4.44786413 ], [ 38.120915, 3.598605 ], [ 38.43697, 3.58851 ], [ 38.67114, 3.61607 ], [ 38.89251, 3.50074 ], [ 39.55938426, 3.42206 ], [ 39.85494, 3.83879 ], [ 40.76848, 4.25702 ], [ 41.1718, 3.91909 ], [ 41.85508309, 3.91891192 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Kyrgyzstan", "sov_a3": "KGZ", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Kyrgyzstan", "adm0_a3": "KGZ", "geou_dif": 0.000000, "geounit": "Kyrgyzstan", "gu_a3": "KGZ", "su_dif": 0.000000, "subunit": "Kyrgyzstan", "su_a3": "KGZ", "brk_diff": 0.000000, "name": "Kyrgyzstan", "name_long": "Kyrgyzstan", "brk_a3": "KGZ", "brk_name": "Kyrgyzstan", "brk_group": null, "abbrev": "Kgz.", "postal": "KG", "formal_en": "Kyrgyz Republic", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Kyrgyz Republic", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 7.000000, "mapcolor9": 7.000000, "mapcolor13": 6.000000, "pop_est": 5431747.000000, "gdp_md_est": 11610.000000, "pop_year": -99.000000, "lastcensus": 2009.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "KG", "iso_a3": "KGZ", "iso_n3": "417", "un_a3": "417", "wb_a2": "KG", "wb_a3": "KGZ", "woe_id": -99.000000, "adm0_a3_is": "KGZ", "adm0_a3_us": "KGZ", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Central Asia", "region_wb": "Europe & Central Asia", "name_len": 10.000000, "long_len": 10.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 80.25999027, 42.34999929 ], [ 80.11943037, 42.12394074 ], [ 78.54366092, 41.58224254 ], [ 78.18719689, 41.18531586 ], [ 76.90448449, 41.06648591 ], [ 76.52636804, 40.42794607 ], [ 75.467828, 40.56207225 ], [ 74.77686242, 40.36642528 ], [ 73.82224369, 39.8939735 ], [ 73.96001306, 39.66000845 ], [ 73.67537927, 39.43123688 ], [ 71.78469364, 39.2794632 ], [ 70.54916182, 39.6041979 ], [ 69.46488692, 39.52668325 ], [ 69.55960982, 40.10321137 ], [ 70.64801883, 39.93575389 ], [ 71.01419803, 40.24436555 ], [ 71.77487512, 40.14584443 ], [ 73.05541711, 40.86603303 ], [ 71.87011478, 41.39290009 ], [ 71.15785851, 41.14358714 ], [ 70.42002241, 41.51999828 ], [ 71.25924767, 42.16771068 ], [ 70.96231489, 42.26615428 ], [ 71.18628055, 42.70429291 ], [ 71.8446383, 42.84539541 ], [ 73.48975752, 42.50089448 ], [ 73.64530358, 43.09127188 ], [ 74.21286584, 43.29833934 ], [ 75.63696496, 42.87789989 ], [ 76.00035363, 42.98802237 ], [ 77.65839196, 42.96068553 ], [ 79.14217736, 42.85609243 ], [ 79.64364546, 42.49668285 ], [ 80.25999027, 42.34999929 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Cambodia", "sov_a3": "KHM", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Cambodia", "adm0_a3": "KHM", "geou_dif": 0.000000, "geounit": "Cambodia", "gu_a3": "KHM", "su_dif": 0.000000, "subunit": "Cambodia", "su_a3": "KHM", "brk_diff": 0.000000, "name": "Cambodia", "name_long": "Cambodia", "brk_a3": "KHM", "brk_name": "Cambodia", "brk_group": null, "abbrev": "Camb.", "postal": "KH", "formal_en": "Kingdom of Cambodia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Cambodia", "name_alt": null, "mapcolor7": 6.000000, "mapcolor8": 3.000000, "mapcolor9": 6.000000, "mapcolor13": 5.000000, "pop_est": 14494293.000000, "gdp_md_est": 27940.000000, "pop_year": -99.000000, "lastcensus": 2008.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "KH", "iso_a3": "KHM", "iso_n3": "116", "un_a3": "116", "wb_a2": "KH", "wb_a3": "KHM", "woe_id": -99.000000, "adm0_a3_is": "KHM", "adm0_a3_us": "KHM", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "South-Eastern Asia", "region_wb": "East Asia & Pacific", "name_len": 8.000000, "long_len": 8.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 107.38272749, 14.2024409 ], [ 107.61454797, 13.53553071 ], [ 107.49140303, 12.33720592 ], [ 105.81052372, 11.56761465 ], [ 106.24967004, 10.96181184 ], [ 105.19991499, 10.8893098 ], [ 104.33433475, 10.48654369 ], [ 103.4972799, 10.63255545 ], [ 103.09068973, 11.15366059 ], [ 102.58493249, 12.18659496 ], [ 102.3480994, 13.39424734 ], [ 102.98842207, 14.22572114 ], [ 104.28141808, 14.41674307 ], [ 105.21877689, 14.27321178 ], [ 106.04394616, 13.88109101 ], [ 106.49637333, 14.57058381 ], [ 107.38272749, 14.2024409 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "South Korea", "sov_a3": "KOR", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "South Korea", "adm0_a3": "KOR", "geou_dif": 0.000000, "geounit": "South Korea", "gu_a3": "KOR", "su_dif": 0.000000, "subunit": "South Korea", "su_a3": "KOR", "brk_diff": 0.000000, "name": "Korea", "name_long": "Republic of Korea", "brk_a3": "KOR", "brk_name": "Republic of Korea", "brk_group": null, "abbrev": "S.K.", "postal": "KR", "formal_en": "Republic of Korea", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Korea, Rep.", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 1.000000, "mapcolor9": 1.000000, "mapcolor13": 5.000000, "pop_est": 48508972.000000, "gdp_md_est": 1335000.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "4. Emerging region: MIKT", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "KR", "iso_a3": "KOR", "iso_n3": "410", "un_a3": "410", "wb_a2": "KR", "wb_a3": "KOR", "woe_id": -99.000000, "adm0_a3_is": "KOR", "adm0_a3_us": "KOR", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Eastern Asia", "region_wb": "East Asia & Pacific", "name_len": 5.000000, "long_len": 17.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 126.17475874, 37.74968578 ], [ 126.2373389, 37.84037792 ], [ 126.68371992, 37.80477285 ], [ 127.07330855, 38.25611481 ], [ 127.78003544, 38.30453563 ], [ 128.20574588, 38.37039724 ], [ 128.34971642, 38.61224295 ], [ 129.21291955, 37.43239248 ], [ 129.46044966, 36.78418915 ], [ 129.46830448, 35.63214061 ], [ 129.09137658, 35.08248424 ], [ 128.18585046, 34.8903771 ], [ 127.3865194, 34.47567373 ], [ 126.48574751, 34.39004588 ], [ 126.37391971, 34.93456045 ], [ 126.5592314, 35.68454051 ], [ 126.1173979, 36.72548473 ], [ 126.86014326, 36.89392406 ], [ 126.17475874, 37.74968578 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Kosovo", "sov_a3": "KOS", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Kosovo", "adm0_a3": "KOS", "geou_dif": 0.000000, "geounit": "Kosovo", "gu_a3": "KOS", "su_dif": 0.000000, "subunit": "Kosovo", "su_a3": "KOS", "brk_diff": 1.000000, "name": "Kosovo", "name_long": "Kosovo", "brk_a3": "B57", "brk_name": "Kosovo", "brk_group": null, "abbrev": "Kos.", "postal": "KO", "formal_en": "Republic of Kosovo", "formal_fr": null, "note_adm0": null, "note_brk": "Self admin.; Claimed by Serbia", "name_sort": "Kosovo", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 2.000000, "mapcolor9": 3.000000, "mapcolor13": 11.000000, "pop_est": 1804838.000000, "gdp_md_est": 5352.000000, "pop_year": -99.000000, "lastcensus": 1981.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "-99", "iso_a3": "-99", "iso_n3": "-99", "un_a3": "-099", "wb_a2": "KV", "wb_a3": "KSV", "woe_id": -99.000000, "adm0_a3_is": "SRB", "adm0_a3_us": "KOS", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Southern Europe", "region_wb": "Europe & Central Asia", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 21.43866, 42.86255 ], [ 21.63302, 42.67717 ], [ 21.77505, 42.6827 ], [ 21.66292, 42.43922 ], [ 21.54332, 42.32025 ], [ 21.57663599, 42.2452244 ], [ 21.3527, 42.2068 ], [ 20.76216, 42.05186 ], [ 20.71731, 41.84711 ], [ 20.59024655, 41.85540892 ], [ 20.59023, 41.85541 ], [ 20.52295, 42.21787 ], [ 20.28374, 42.32025 ], [ 20.0707, 42.58863 ], [ 20.25758, 42.81275 ], [ 20.49679, 42.88469 ], [ 20.63508, 43.21671 ], [ 20.81448, 43.27205 ], [ 20.95651, 43.13094 ], [ 21.143395, 43.068685 ], [ 21.27421, 42.90959 ], [ 21.43866, 42.86255 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Kuwait", "sov_a3": "KWT", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Kuwait", "adm0_a3": "KWT", "geou_dif": 0.000000, "geounit": "Kuwait", "gu_a3": "KWT", "su_dif": 0.000000, "subunit": "Kuwait", "su_a3": "KWT", "brk_diff": 0.000000, "name": "Kuwait", "name_long": "Kuwait", "brk_a3": "KWT", "brk_name": "Kuwait", "brk_group": null, "abbrev": "Kwt.", "postal": "KW", "formal_en": "State of Kuwait", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Kuwait", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 2.000000, "mapcolor9": 2.000000, "mapcolor13": 2.000000, "pop_est": 2691158.000000, "gdp_md_est": 149100.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "2. High income: nonOECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "KW", "iso_a3": "KWT", "iso_n3": "414", "un_a3": "414", "wb_a2": "KW", "wb_a3": "KWT", "woe_id": -99.000000, "adm0_a3_is": "KWT", "adm0_a3_us": "KWT", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Western Asia", "region_wb": "Middle East & North Africa", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 47.97451908, 29.9758192 ], [ 48.18318851, 29.53447663 ], [ 48.09394331, 29.30629934 ], [ 48.41609419, 28.5520043 ], [ 47.70885054, 28.52606273 ], [ 47.45982181, 29.00251944 ], [ 46.56871341, 29.09902517 ], [ 47.3026221, 30.05906993 ], [ 47.97451908, 29.9758192 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Laos", "sov_a3": "LAO", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Laos", "adm0_a3": "LAO", "geou_dif": 0.000000, "geounit": "Laos", "gu_a3": "LAO", "su_dif": 0.000000, "subunit": "Laos", "su_a3": "LAO", "brk_diff": 0.000000, "name": "Lao PDR", "name_long": "Lao PDR", "brk_a3": "LAO", "brk_name": "Laos", "brk_group": null, "abbrev": "Laos", "postal": "LA", "formal_en": "Lao People's Democratic Republic", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Lao PDR", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 1.000000, "mapcolor9": 1.000000, "mapcolor13": 9.000000, "pop_est": 6834942.000000, "gdp_md_est": 13980.000000, "pop_year": -99.000000, "lastcensus": 2005.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "LA", "iso_a3": "LAO", "iso_n3": "418", "un_a3": "418", "wb_a2": "LA", "wb_a3": "LAO", "woe_id": -99.000000, "adm0_a3_is": "LAO", "adm0_a3_us": "LAO", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "South-Eastern Asia", "region_wb": "East Asia & Pacific", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 107.38272749, 14.2024409 ], [ 106.49637333, 14.57058381 ], [ 106.04394616, 13.88109101 ], [ 105.21877689, 14.27321178 ], [ 105.54433841, 14.72393362 ], [ 105.58903853, 15.57031607 ], [ 104.77932051, 16.44186494 ], [ 104.71694706, 17.42885895 ], [ 103.95647668, 18.24095409 ], [ 103.20019209, 18.30963207 ], [ 102.99870568, 17.96169465 ], [ 102.413005, 17.93278168 ], [ 102.11359175, 18.10910167 ], [ 101.05954756, 17.51249726 ], [ 101.03593143, 18.40892833 ], [ 101.2820146, 19.46258495 ], [ 100.60629357, 19.50834443 ], [ 100.54888106, 20.10923798 ], [ 100.11598758, 20.41784964 ], [ 100.32910119, 20.78612173 ], [ 101.18000532, 21.43657298 ], [ 101.27002567, 21.20165192 ], [ 101.80311974, 21.17436677 ], [ 101.65201786, 22.31819876 ], [ 102.17043583, 22.46475312 ], [ 102.75489627, 21.67513723 ], [ 103.20386112, 20.7665622 ], [ 104.43500044, 20.75873322 ], [ 104.82257368, 19.88664175 ], [ 104.18338789, 19.62466808 ], [ 103.89653202, 19.26518098 ], [ 105.09459842, 18.6669746 ], [ 105.92576216, 17.48531546 ], [ 106.55600793, 16.60428396 ], [ 107.31270593, 15.90853832 ], [ 107.56452518, 15.20217316 ], [ 107.38272749, 14.2024409 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Lebanon", "sov_a3": "LBN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Lebanon", "adm0_a3": "LBN", "geou_dif": 0.000000, "geounit": "Lebanon", "gu_a3": "LBN", "su_dif": 0.000000, "subunit": "Lebanon", "su_a3": "LBN", "brk_diff": 0.000000, "name": "Lebanon", "name_long": "Lebanon", "brk_a3": "LBN", "brk_name": "Lebanon", "brk_group": null, "abbrev": "Leb.", "postal": "LB", "formal_en": "Lebanese Republic", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Lebanon", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 4.000000, "mapcolor9": 4.000000, "mapcolor13": 12.000000, "pop_est": 4017095.000000, "gdp_md_est": 44060.000000, "pop_year": -99.000000, "lastcensus": 1970.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "LB", "iso_a3": "LBN", "iso_n3": "422", "un_a3": "422", "wb_a2": "LB", "wb_a3": "LBN", "woe_id": -99.000000, "adm0_a3_is": "LBN", "adm0_a3_us": "LBN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Western Asia", "region_wb": "Middle East & North Africa", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": 4.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 35.8211007, 33.27742646 ], [ 35.55279667, 33.26427481 ], [ 35.46070926, 33.08904003 ], [ 35.12605269, 33.09090038 ], [ 35.48220666, 33.90545014 ], [ 35.97959232, 34.6100583 ], [ 35.99840254, 34.64491405 ], [ 36.44819421, 34.59393525 ], [ 36.61175012, 34.20178864 ], [ 36.0664604, 33.82491242 ], [ 35.8211007, 33.27742646 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Liberia", "sov_a3": "LBR", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Liberia", "adm0_a3": "LBR", "geou_dif": 0.000000, "geounit": "Liberia", "gu_a3": "LBR", "su_dif": 0.000000, "subunit": "Liberia", "su_a3": "LBR", "brk_diff": 0.000000, "name": "Liberia", "name_long": "Liberia", "brk_a3": "LBR", "brk_name": "Liberia", "brk_group": null, "abbrev": "Liberia", "postal": "LR", "formal_en": "Republic of Liberia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Liberia", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 3.000000, "mapcolor9": 4.000000, "mapcolor13": 9.000000, "pop_est": 3441790.000000, "gdp_md_est": 1526.000000, "pop_year": -99.000000, "lastcensus": 2008.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "LR", "iso_a3": "LBR", "iso_n3": "430", "un_a3": "430", "wb_a2": "LR", "wb_a3": "LBR", "woe_id": -99.000000, "adm0_a3_is": "LBR", "adm0_a3_us": "LBR", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Western Africa", "region_wb": "Sub-Saharan Africa", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 7.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -8.43929847, 7.68604279 ], [ -8.48544552, 7.39520783 ], [ -8.38545163, 6.91180065 ], [ -8.60288021, 6.4675642 ], [ -8.31134762, 6.19303315 ], [ -7.99369259, 6.12618968 ], [ -7.57015255, 5.7073522 ], [ -7.53971514, 5.31334524 ], [ -7.63536821, 5.18815908 ], [ -7.71215939, 4.36456594 ], [ -7.97410722, 4.35575511 ], [ -9.00479367, 4.83241852 ], [ -9.91342038, 5.5935607 ], [ -10.76538388, 6.14071076 ], [ -11.43877947, 6.78591686 ], [ -11.19980181, 7.10584565 ], [ -11.14670427, 7.39670645 ], [ -10.69559486, 7.93946402 ], [ -10.23009355, 8.40620555 ], [ -10.01656653, 8.42850393 ], [ -9.75534217, 8.5410552 ], [ -9.33727983, 7.92853445 ], [ -9.40334815, 7.52690522 ], [ -9.20878638, 7.3139208 ], [ -8.92606462, 7.30903738 ], [ -8.72212358, 7.7116743 ], [ -8.43929847, 7.68604279 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Libya", "sov_a3": "LBY", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Libya", "adm0_a3": "LBY", "geou_dif": 0.000000, "geounit": "Libya", "gu_a3": "LBY", "su_dif": 0.000000, "subunit": "Libya", "su_a3": "LBY", "brk_diff": 0.000000, "name": "Libya", "name_long": "Libya", "brk_a3": "LBY", "brk_name": "Libya", "brk_group": null, "abbrev": "Libya", "postal": "LY", "formal_en": "Libya", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Libya", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 2.000000, "mapcolor9": 2.000000, "mapcolor13": 11.000000, "pop_est": 6310434.000000, "gdp_md_est": 88830.000000, "pop_year": -99.000000, "lastcensus": 2006.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "LY", "iso_a3": "LBY", "iso_n3": "434", "un_a3": "434", "wb_a2": "LY", "wb_a3": "LBY", "woe_id": -99.000000, "adm0_a3_is": "LBY", "adm0_a3_us": "LBY", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Northern Africa", "region_wb": "Middle East & North Africa", "name_len": 5.000000, "long_len": 5.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 25.16482, 31.56915 ], [ 24.80287, 31.08929 ], [ 24.95762, 30.6616 ], [ 24.70007, 30.04419 ], [ 25.0, 29.23865453 ], [ 25.0, 25.6825 ], [ 25.0, 22.0 ], [ 25.0, 20.00304 ], [ 23.85, 20.0 ], [ 23.83766, 19.58047 ], [ 19.84926, 21.49509 ], [ 15.86085, 23.40972 ], [ 14.8513, 22.86295 ], [ 14.14387088, 22.49128897 ], [ 13.58142459, 23.04050609 ], [ 11.99950565, 23.4716684 ], [ 11.56066939, 24.09790925 ], [ 10.77136356, 24.56253205 ], [ 10.30384688, 24.37931326 ], [ 9.94826135, 24.93695364 ], [ 9.91069258, 25.36545462 ], [ 9.31941084, 26.09432486 ], [ 9.71628584, 26.51220633 ], [ 9.62905602, 27.14095348 ], [ 9.75612837, 27.68825857 ], [ 9.68388472, 28.1441739 ], [ 9.859998, 28.95998973 ], [ 9.80563439, 29.42463837 ], [ 9.48213993, 30.30755606 ], [ 9.97001712, 30.53932486 ], [ 10.05657515, 30.96183137 ], [ 9.95022505, 31.37606965 ], [ 10.63690148, 31.7614208 ], [ 10.94478967, 32.08181468 ], [ 11.43225345, 32.3689031 ], [ 11.48878747, 33.13699575 ], [ 12.66331, 32.79278 ], [ 13.08326, 32.87882 ], [ 13.91868, 32.71196 ], [ 15.24563, 32.26508 ], [ 15.71394, 31.37626 ], [ 16.61162, 31.18218 ], [ 18.02109, 30.76357 ], [ 19.08641, 30.26639 ], [ 19.57404, 30.52582 ], [ 20.05335, 30.98576 ], [ 19.82033, 31.75179 ], [ 20.13397, 32.2382 ], [ 20.85452, 32.7068 ], [ 21.54298, 32.8432 ], [ 22.89576, 32.63858 ], [ 23.2368, 32.19149 ], [ 23.60913, 32.18726 ], [ 23.9275, 32.01667 ], [ 24.92114, 31.89936 ], [ 25.16482, 31.56915 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Sri Lanka", "sov_a3": "LKA", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Sri Lanka", "adm0_a3": "LKA", "geou_dif": 0.000000, "geounit": "Sri Lanka", "gu_a3": "LKA", "su_dif": 0.000000, "subunit": "Sri Lanka", "su_a3": "LKA", "brk_diff": 0.000000, "name": "Sri Lanka", "name_long": "Sri Lanka", "brk_a3": "LKA", "brk_name": "Sri Lanka", "brk_group": null, "abbrev": "Sri L.", "postal": "LK", "formal_en": "Democratic Socialist Republic of Sri Lanka", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Sri Lanka", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 5.000000, "mapcolor9": 4.000000, "mapcolor13": 9.000000, "pop_est": 21324791.000000, "gdp_md_est": 91870.000000, "pop_year": -99.000000, "lastcensus": 2001.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "LK", "iso_a3": "LKA", "iso_n3": "144", "un_a3": "144", "wb_a2": "LK", "wb_a3": "LKA", "woe_id": -99.000000, "adm0_a3_is": "LKA", "adm0_a3_us": "LKA", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Southern Asia", "region_wb": "South Asia", "name_len": 9.000000, "long_len": 9.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 81.21801965, 6.19714142 ], [ 80.34835697, 5.96836986 ], [ 79.8724687, 6.76346345 ], [ 79.69516686, 8.20084341 ], [ 80.14780073, 9.82407766 ], [ 80.83881799, 9.26842683 ], [ 81.30431929, 8.56420624 ], [ 81.78795902, 7.52305532 ], [ 81.63732222, 6.48177521 ], [ 81.21801965, 6.19714142 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Lesotho", "sov_a3": "LSO", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Lesotho", "adm0_a3": "LSO", "geou_dif": 0.000000, "geounit": "Lesotho", "gu_a3": "LSO", "su_dif": 0.000000, "subunit": "Lesotho", "su_a3": "LSO", "brk_diff": 0.000000, "name": "Lesotho", "name_long": "Lesotho", "brk_a3": "LSO", "brk_name": "Lesotho", "brk_group": null, "abbrev": "Les.", "postal": "LS", "formal_en": "Kingdom of Lesotho", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Lesotho", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 5.000000, "mapcolor9": 2.000000, "mapcolor13": 8.000000, "pop_est": 2130819.000000, "gdp_md_est": 3293.000000, "pop_year": -99.000000, "lastcensus": 2006.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "LS", "iso_a3": "LSO", "iso_n3": "426", "un_a3": "426", "wb_a2": "LS", "wb_a3": "LSO", "woe_id": -99.000000, "adm0_a3_is": "LSO", "adm0_a3_us": "LSO", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Southern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 28.10720462, -30.54573211 ], [ 27.74939701, -30.64510589 ], [ 26.99926192, -29.87595387 ], [ 27.53251102, -29.24271087 ], [ 28.07433841, -28.8514686 ], [ 28.54170007, -28.64750172 ], [ 28.97826257, -28.95559661 ], [ 29.32516646, -29.25738698 ], [ 29.01841515, -29.74376556 ], [ 28.84839969, -30.07005055 ], [ 28.29106937, -30.22621673 ], [ 28.10720462, -30.54573211 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Lithuania", "sov_a3": "LTU", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Lithuania", "adm0_a3": "LTU", "geou_dif": 0.000000, "geounit": "Lithuania", "gu_a3": "LTU", "su_dif": 0.000000, "subunit": "Lithuania", "su_a3": "LTU", "brk_diff": 0.000000, "name": "Lithuania", "name_long": "Lithuania", "brk_a3": "LTU", "brk_name": "Lithuania", "brk_group": null, "abbrev": "Lith.", "postal": "LT", "formal_en": "Republic of Lithuania", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Lithuania", "name_alt": null, "mapcolor7": 6.000000, "mapcolor8": 3.000000, "mapcolor9": 3.000000, "mapcolor13": 9.000000, "pop_est": 3555179.000000, "gdp_md_est": 63330.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "LT", "iso_a3": "LTU", "iso_n3": "440", "un_a3": "440", "wb_a2": "LT", "wb_a3": "LTU", "woe_id": -99.000000, "adm0_a3_is": "LTU", "adm0_a3_us": "LTU", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Northern Europe", "region_wb": "Europe & Central Asia", "name_len": 9.000000, "long_len": 9.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 26.4943315, 55.61510692 ], [ 26.58827925, 55.1671756 ], [ 25.76843265, 54.84696259 ], [ 25.53635379, 54.28242341 ], [ 24.45068363, 53.90570222 ], [ 23.48412764, 53.91249767 ], [ 23.24398726, 54.22056672 ], [ 22.73109867, 54.32753693 ], [ 22.65105187, 54.58274099 ], [ 22.75776371, 54.85657441 ], [ 22.3157235, 55.01529857 ], [ 21.26844893, 55.19048168 ], [ 21.05580041, 56.03107636 ], [ 22.20115685, 56.33780183 ], [ 23.87826379, 56.27367137 ], [ 24.86068444, 56.37252839 ], [ 25.00093428, 56.16453075 ], [ 25.5330465, 56.10029694 ], [ 26.4943315, 55.61510692 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Luxembourg", "sov_a3": "LUX", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Luxembourg", "adm0_a3": "LUX", "geou_dif": 0.000000, "geounit": "Luxembourg", "gu_a3": "LUX", "su_dif": 0.000000, "subunit": "Luxembourg", "su_a3": "LUX", "brk_diff": 0.000000, "name": "Luxembourg", "name_long": "Luxembourg", "brk_a3": "LUX", "brk_name": "Luxembourg", "brk_group": null, "abbrev": "Lux.", "postal": "L", "formal_en": "Grand Duchy of Luxembourg", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Luxembourg", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 7.000000, "mapcolor9": 3.000000, "mapcolor13": 7.000000, "pop_est": 491775.000000, "gdp_md_est": 39370.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "LU", "iso_a3": "LUX", "iso_n3": "442", "un_a3": "442", "wb_a2": "LU", "wb_a3": "LUX", "woe_id": -99.000000, "adm0_a3_is": "LUX", "adm0_a3_us": "LUX", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Western Europe", "region_wb": "Europe & Central Asia", "name_len": 10.000000, "long_len": 10.000000, "abbrev_len": 4.000000, "tiny": 5.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 6.18632043, 49.4638028 ], [ 5.89775923, 49.44266714 ], [ 5.67405195, 49.52948355 ], [ 5.78241743, 50.09032787 ], [ 6.04307336, 50.12805166 ], [ 6.24275109, 49.90222565 ], [ 6.18632043, 49.4638028 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Latvia", "sov_a3": "LVA", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Latvia", "adm0_a3": "LVA", "geou_dif": 0.000000, "geounit": "Latvia", "gu_a3": "LVA", "su_dif": 0.000000, "subunit": "Latvia", "su_a3": "LVA", "brk_diff": 0.000000, "name": "Latvia", "name_long": "Latvia", "brk_a3": "LVA", "brk_name": "Latvia", "brk_group": null, "abbrev": "Lat.", "postal": "LV", "formal_en": "Republic of Latvia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Latvia", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 7.000000, "mapcolor9": 6.000000, "mapcolor13": 13.000000, "pop_est": 2231503.000000, "gdp_md_est": 38860.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "LV", "iso_a3": "LVA", "iso_n3": "428", "un_a3": "428", "wb_a2": "LV", "wb_a3": "LVA", "woe_id": -99.000000, "adm0_a3_is": "LVA", "adm0_a3_us": "LVA", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Northern Europe", "region_wb": "Europe & Central Asia", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 27.28818485, 57.47452831 ], [ 27.7700159, 57.24425812 ], [ 27.85528202, 56.75932648 ], [ 28.17670943, 56.16912995 ], [ 27.10245975, 55.78331371 ], [ 26.4943315, 55.61510692 ], [ 25.5330465, 56.10029694 ], [ 25.00093428, 56.16453075 ], [ 24.86068444, 56.37252839 ], [ 23.87826379, 56.27367137 ], [ 22.20115685, 56.33780183 ], [ 21.05580041, 56.03107636 ], [ 21.09042362, 56.78387279 ], [ 21.58186649, 57.41187063 ], [ 22.52434126, 57.75337434 ], [ 23.318453, 57.00623648 ], [ 24.12072961, 57.02569265 ], [ 24.31286258, 57.79342357 ], [ 25.16459354, 57.97015697 ], [ 25.60280969, 57.84752879 ], [ 26.46353234, 57.47638866 ], [ 27.28818485, 57.47452831 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Morocco", "sov_a3": "MAR", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Morocco", "adm0_a3": "MAR", "geou_dif": 0.000000, "geounit": "Morocco", "gu_a3": "MAR", "su_dif": 0.000000, "subunit": "Morocco", "su_a3": "MAR", "brk_diff": 0.000000, "name": "Morocco", "name_long": "Morocco", "brk_a3": "MAR", "brk_name": "Morocco", "brk_group": null, "abbrev": "Mor.", "postal": "MA", "formal_en": "Kingdom of Morocco", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Morocco", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 2.000000, "mapcolor9": 3.000000, "mapcolor13": 9.000000, "pop_est": 34859364.000000, "gdp_md_est": 136600.000000, "pop_year": -99.000000, "lastcensus": 2004.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "MA", "iso_a3": "MAR", "iso_n3": "504", "un_a3": "504", "wb_a2": "MA", "wb_a3": "MAR", "woe_id": -99.000000, "adm0_a3_is": "MAR", "adm0_a3_us": "MAR", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Northern Africa", "region_wb": "Middle East & North Africa", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -2.1699137, 35.16839631 ], [ -1.79298581, 34.52791861 ], [ -1.73345456, 33.91971284 ], [ -1.38804928, 32.864015 ], [ -1.12455115, 32.65152151 ], [ -1.30789914, 32.2628889 ], [ -2.61660478, 32.09434622 ], [ -3.06898027, 31.72449799 ], [ -3.64749793, 31.63729401 ], [ -3.69044105, 30.89695161 ], [ -4.85964617, 30.50118765 ], [ -5.24212928, 30.00044302 ], [ -6.06063229, 29.73169973 ], [ -7.05922767, 29.57922842 ], [ -8.67411618, 28.84128897 ], [ -8.66558957, 27.65642589 ], [ -8.81780901, 27.65642589 ], [ -8.81782833, 27.65642589 ], [ -8.794884, 27.12069632 ], [ -9.41303748, 27.08847606 ], [ -9.73534339, 26.86094473 ], [ -10.1894242, 26.86094473 ], [ -10.55126258, 26.9908076 ], [ -11.3925549, 26.88342398 ], [ -11.71821977, 26.1040917 ], [ -12.03075884, 26.0308662 ], [ -12.50096269, 24.77011628 ], [ -13.8911104, 23.69100902 ], [ -14.22116777, 22.31016307 ], [ -14.63083269, 21.86093985 ], [ -14.75095456, 21.50060008 ], [ -17.0029618, 21.42073416 ], [ -17.02042843, 21.42231029 ], [ -16.97324785, 21.88574453 ], [ -16.58913693, 22.15823436 ], [ -16.26192176, 22.6793395 ], [ -16.32641395, 23.01776846 ], [ -15.98261064, 23.72335847 ], [ -15.42600379, 24.35913361 ], [ -15.08933183, 24.52026073 ], [ -14.82464515, 25.10353262 ], [ -14.80092567, 25.63626496 ], [ -14.43993995, 26.25441844 ], [ -13.7738049, 26.61889232 ], [ -13.13994178, 27.64014781 ], [ -13.12161337, 27.65414767 ], [ -12.61883664, 28.03818553 ], [ -11.68891924, 28.14864391 ], [ -10.900957, 28.83214224 ], [ -10.39959225, 29.09858592 ], [ -9.56481116, 29.93357372 ], [ -9.81471839, 31.1777355 ], [ -9.43479326, 32.03809642 ], [ -9.30069292, 32.56467927 ], [ -8.65747637, 33.24024527 ], [ -7.65417843, 33.69706493 ], [ -6.91254411, 34.11047639 ], [ -6.24434201, 35.14586538 ], [ -5.92999427, 35.7599881 ], [ -5.19386349, 35.7551822 ], [ -4.59100623, 35.33071198 ], [ -3.64005653, 35.39985505 ], [ -2.60430579, 35.17909333 ], [ -2.1699137, 35.16839631 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Moldova", "sov_a3": "MDA", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Moldova", "adm0_a3": "MDA", "geou_dif": 0.000000, "geounit": "Moldova", "gu_a3": "MDA", "su_dif": 0.000000, "subunit": "Moldova", "su_a3": "MDA", "brk_diff": 0.000000, "name": "Moldova", "name_long": "Moldova", "brk_a3": "MDA", "brk_name": "Moldova", "brk_group": null, "abbrev": "Mda.", "postal": "MD", "formal_en": "Republic of Moldova", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Moldova", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 5.000000, "mapcolor9": 4.000000, "mapcolor13": 12.000000, "pop_est": 4320748.000000, "gdp_md_est": 10670.000000, "pop_year": -99.000000, "lastcensus": 2004.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "MD", "iso_a3": "MDA", "iso_n3": "498", "un_a3": "498", "wb_a2": "MD", "wb_a3": "MDA", "woe_id": -99.000000, "adm0_a3_is": "MDA", "adm0_a3_us": "MDA", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Eastern Europe", "region_wb": "Europe & Central Asia", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 28.2335535, 45.48828319 ], [ 28.05444299, 45.94458609 ], [ 28.16001794, 46.37156261 ], [ 28.12803023, 46.81047639 ], [ 27.55116621, 47.40511709 ], [ 27.23387292, 47.82677094 ], [ 26.92417606, 48.12326447 ], [ 26.61933679, 48.22072622 ], [ 26.85782352, 48.36821076 ], [ 27.52253747, 48.46711945 ], [ 28.25954675, 48.15556224 ], [ 28.67089115, 48.11814851 ], [ 29.1226982, 47.84909516 ], [ 29.05086795, 47.51022696 ], [ 29.41513513, 47.34664521 ], [ 29.55967411, 46.92858287 ], [ 29.90885176, 46.67436066 ], [ 29.83821008, 46.52532583 ], [ 30.02465864, 46.42393667 ], [ 29.75997196, 46.3499877 ], [ 29.17065392, 46.3792624 ], [ 29.07210697, 46.51767772 ], [ 28.86297245, 46.43788931 ], [ 28.93371748, 46.25883047 ], [ 28.65998742, 45.93998688 ], [ 28.4852694, 45.59690705 ], [ 28.2335535, 45.48828319 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Madagascar", "sov_a3": "MDG", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Madagascar", "adm0_a3": "MDG", "geou_dif": 0.000000, "geounit": "Madagascar", "gu_a3": "MDG", "su_dif": 0.000000, "subunit": "Madagascar", "su_a3": "MDG", "brk_diff": 0.000000, "name": "Madagascar", "name_long": "Madagascar", "brk_a3": "MDG", "brk_name": "Madagascar", "brk_group": null, "abbrev": "Mad.", "postal": "MG", "formal_en": "Republic of Madagascar", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Madagascar", "name_alt": null, "mapcolor7": 6.000000, "mapcolor8": 5.000000, "mapcolor9": 2.000000, "mapcolor13": 3.000000, "pop_est": 20653556.000000, "gdp_md_est": 20130.000000, "pop_year": -99.000000, "lastcensus": 1993.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "MG", "iso_a3": "MDG", "iso_n3": "450", "un_a3": "450", "wb_a2": "MG", "wb_a3": "MDG", "woe_id": -99.000000, "adm0_a3_is": "MDG", "adm0_a3_us": "MDG", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Eastern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 10.000000, "long_len": 10.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 50.05651086, -13.55576141 ], [ 50.21743127, -14.75878875 ], [ 50.4765369, -15.22651214 ], [ 50.37711144, -15.70606943 ], [ 50.20027469, -16.00026336 ], [ 49.8606055, -15.41425262 ], [ 49.67260664, -15.71020355 ], [ 49.86334435, -16.45103688 ], [ 49.77456424, -16.87504201 ], [ 49.49861209, -17.10603566 ], [ 49.43561852, -17.95306406 ], [ 49.04179243, -19.11878102 ], [ 48.54854089, -20.49688812 ], [ 47.93074914, -22.39150115 ], [ 47.54772342, -23.78195892 ], [ 47.09576135, -24.94162973 ], [ 46.28247765, -25.17846282 ], [ 45.40950768, -25.60143442 ], [ 44.83357385, -25.34610117 ], [ 44.03972049, -24.98834523 ], [ 43.76376834, -24.46067718 ], [ 43.69777754, -23.57411631 ], [ 43.34565433, -22.77690399 ], [ 43.25418705, -22.05741302 ], [ 43.43329756, -21.33647511 ], [ 43.8936829, -21.16330739 ], [ 43.89637007, -20.83045949 ], [ 44.37432539, -20.07236622 ], [ 44.46439741, -19.4354542 ], [ 44.23242191, -18.96199472 ], [ 44.04297611, -18.33138722 ], [ 43.96308434, -17.40994476 ], [ 44.3124687, -16.8504957 ], [ 44.44651737, -16.21621917 ], [ 44.94493656, -16.17937387 ], [ 45.50273197, -15.97437347 ], [ 45.87299361, -15.79345428 ], [ 46.31224328, -15.78001841 ], [ 46.88218265, -15.21018239 ], [ 47.70512984, -14.59430267 ], [ 48.00521488, -14.0912326 ], [ 47.86904748, -13.6638685 ], [ 48.29382775, -13.78406788 ], [ 48.84506026, -13.0891749 ], [ 48.86350874, -12.48786793 ], [ 49.19465132, -12.04055674 ], [ 49.54351891, -12.46983286 ], [ 49.80898075, -12.89528493 ], [ 50.05651086, -13.55576141 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Mexico", "sov_a3": "MEX", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Mexico", "adm0_a3": "MEX", "geou_dif": 0.000000, "geounit": "Mexico", "gu_a3": "MEX", "su_dif": 0.000000, "subunit": "Mexico", "su_a3": "MEX", "brk_diff": 0.000000, "name": "Mexico", "name_long": "Mexico", "brk_a3": "MEX", "brk_name": "Mexico", "brk_group": null, "abbrev": "Mex.", "postal": "MX", "formal_en": "United Mexican States", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Mexico", "name_alt": null, "mapcolor7": 6.000000, "mapcolor8": 1.000000, "mapcolor9": 7.000000, "mapcolor13": 3.000000, "pop_est": 111211789.000000, "gdp_md_est": 1563000.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "4. Emerging region: MIKT", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "MX", "iso_a3": "MEX", "iso_n3": "484", "un_a3": "484", "wb_a2": "MX", "wb_a3": "MEX", "woe_id": -99.000000, "adm0_a3_is": "MEX", "adm0_a3_us": "MEX", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "North America", "region_un": "Americas", "subregion": "Central America", "region_wb": "Latin America & Caribbean", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -97.53, 25.84 ], [ -97.14000831, 25.86999746 ], [ -97.52807248, 24.99214407 ], [ -97.70294552, 24.27234304 ], [ -97.77604184, 22.93257986 ], [ -97.87236671, 22.44421174 ], [ -97.69904395, 21.89868948 ], [ -97.38895952, 21.41101899 ], [ -97.18933346, 20.63543325 ], [ -96.52557553, 19.89093089 ], [ -96.29212724, 19.32037141 ], [ -95.90088498, 18.8280242 ], [ -94.83906348, 18.56271739 ], [ -94.42572954, 18.14437084 ], [ -93.54865129, 18.42383698 ], [ -92.78611386, 18.52483857 ], [ -92.03734819, 18.7045692 ], [ -91.40790341, 18.87608328 ], [ -90.77186988, 19.28412039 ], [ -90.53358985, 19.86741812 ], [ -90.451476, 20.70752188 ], [ -90.27861833, 20.99985545 ], [ -89.60132117, 21.26172578 ], [ -88.54386634, 21.49367544 ], [ -87.65841651, 21.45884553 ], [ -87.05189022, 21.5435432 ], [ -86.81198239, 21.3315148 ], [ -86.84590797, 20.84986461 ], [ -87.38329119, 20.25540477 ], [ -87.62105445, 19.64655305 ], [ -87.43675045, 19.47240347 ], [ -87.58656043, 19.04013011 ], [ -87.83719113, 18.25981599 ], [ -88.09066403, 18.51664785 ], [ -88.30003109, 18.4999822 ], [ -88.49012285, 18.48683055 ], [ -88.84834388, 17.88319815 ], [ -89.02985735, 18.00151134 ], [ -89.15090939, 17.95546764 ], [ -89.14308041, 17.808319 ], [ -90.06793352, 17.81932608 ], [ -91.00151995, 17.81759492 ], [ -91.00226925, 17.2546577 ], [ -91.45392127, 17.25217723 ], [ -91.08167009, 16.91847667 ], [ -90.71182187, 16.68748302 ], [ -90.60084673, 16.4707779 ], [ -90.43886695, 16.41010977 ], [ -90.46447262, 16.06956208 ], [ -91.74796017, 16.06656485 ], [ -92.22924862, 15.25144664 ], [ -92.08721595, 15.06458466 ], [ -92.20322954, 14.83010285 ], [ -92.22775001, 14.53882864 ], [ -93.35946387, 15.61542959 ], [ -93.87516883, 15.94016429 ], [ -94.69165646, 16.20097525 ], [ -95.25022702, 16.12831818 ], [ -96.05338213, 15.75208792 ], [ -96.55743405, 15.65351512 ], [ -97.2635925, 15.91706493 ], [ -98.01302995, 16.10731171 ], [ -98.94767575, 16.5660434 ], [ -99.69739743, 16.70616405 ], [ -100.82949887, 17.17107107 ], [ -101.66608863, 17.64902639 ], [ -101.918528, 17.9160902 ], [ -102.47813209, 17.97575064 ], [ -103.50098955, 18.29229462 ], [ -103.91752743, 18.74857168 ], [ -104.99200965, 19.31613394 ], [ -105.4930385, 19.94676728 ], [ -105.73139604, 20.43410187 ], [ -105.397773, 20.53171865 ], [ -105.50066077, 20.81689505 ], [ -105.27075233, 21.0762849 ], [ -105.26581723, 21.42210358 ], [ -105.60316098, 21.87114594 ], [ -105.69341387, 22.26908031 ], [ -106.0287164, 22.77375235 ], [ -106.90998043, 23.76777436 ], [ -107.91544878, 24.54891531 ], [ -108.40190487, 25.17231395 ], [ -109.26019874, 25.58060944 ], [ -109.44408932, 25.82488394 ], [ -109.29164385, 26.44293407 ], [ -109.80145769, 26.67617565 ], [ -110.39173174, 27.16211498 ], [ -110.64101885, 27.859876 ], [ -111.17891883, 27.94124055 ], [ -111.7596069, 28.46795258 ], [ -112.22823463, 28.95440868 ], [ -112.2718237, 29.26684439 ], [ -112.80959449, 30.02111359 ], [ -113.16381059, 30.7868808 ], [ -113.1486694, 31.17096589 ], [ -113.87188107, 31.56760834 ], [ -114.20573666, 31.52404511 ], [ -114.77645118, 31.79953217 ], [ -114.9366998, 31.39348461 ], [ -114.77123186, 30.91361726 ], [ -114.6738993, 30.16268118 ], [ -114.33097449, 29.75043244 ], [ -113.58887509, 29.06161144 ], [ -113.42405311, 28.82617361 ], [ -113.27196937, 28.75478262 ], [ -113.14003944, 28.41128937 ], [ -112.96229835, 28.42519033 ], [ -112.76158708, 27.78021678 ], [ -112.45791053, 27.52581371 ], [ -112.24495195, 27.17172679 ], [ -111.61648902, 26.66281729 ], [ -111.28467465, 25.73258983 ], [ -110.98781938, 25.29460623 ], [ -110.71000688, 24.82600434 ], [ -110.655049, 24.29859467 ], [ -110.17285621, 24.26554759 ], [ -109.77184709, 23.81118256 ], [ -109.40910438, 23.36467235 ], [ -109.4333923, 23.18558767 ], [ -109.85421933, 22.81827159 ], [ -110.03139197, 22.8230775 ], [ -110.29507097, 23.43097321 ], [ -110.94950131, 24.00096426 ], [ -111.67056841, 24.48442312 ], [ -112.1820359, 24.73841279 ], [ -112.14898882, 25.47012523 ], [ -112.30071082, 26.0120043 ], [ -112.77729672, 26.32195954 ], [ -113.46467078, 26.76818553 ], [ -113.59672991, 26.63945954 ], [ -113.84893673, 26.90006379 ], [ -114.46574663, 27.14209036 ], [ -115.05514218, 27.72272675 ], [ -114.98225257, 27.79820018 ], [ -114.57036557, 27.7414853 ], [ -114.19932878, 28.11500255 ], [ -114.1620184, 28.56611197 ], [ -114.93184221, 29.27947928 ], [ -115.51865394, 29.5563616 ], [ -115.88736528, 30.18079377 ], [ -116.25835039, 30.83646434 ], [ -116.72152625, 31.63574372 ], [ -117.12776, 32.53534 ], [ -115.99135, 32.61239 ], [ -114.72139, 32.72083 ], [ -114.815, 32.52528 ], [ -113.30498, 32.03914 ], [ -111.02361, 31.33472 ], [ -109.035, 31.34194 ], [ -108.24194, 31.34222 ], [ -108.24, 31.75485372 ], [ -106.50759, 31.75452 ], [ -106.1429, 31.39995 ], [ -105.63159, 31.08383 ], [ -105.03737, 30.64402 ], [ -104.70575, 30.12173 ], [ -104.45697, 29.57196 ], [ -103.94, 29.27 ], [ -103.11, 28.97 ], [ -102.48, 29.76 ], [ -101.6624, 29.7793 ], [ -100.9576, 29.38071 ], [ -100.45584, 28.69612 ], [ -100.11, 28.11 ], [ -99.52, 27.54 ], [ -99.3, 26.84 ], [ -99.02, 26.37 ], [ -98.24, 26.06 ], [ -97.53, 25.84 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Macedonia", "sov_a3": "MKD", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Macedonia", "adm0_a3": "MKD", "geou_dif": 0.000000, "geounit": "Macedonia", "gu_a3": "MKD", "su_dif": 0.000000, "subunit": "Macedonia", "su_a3": "MKD", "brk_diff": 0.000000, "name": "Macedonia", "name_long": "Macedonia", "brk_a3": "MKD", "brk_name": "Macedonia", "brk_group": null, "abbrev": "Mkd.", "postal": "MK", "formal_en": "Former Yugoslav Republic of Macedonia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Macedonia, FYR", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 3.000000, "mapcolor9": 7.000000, "mapcolor13": 3.000000, "pop_est": 2066718.000000, "gdp_md_est": 18780.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "MK", "iso_a3": "MKD", "iso_n3": "807", "un_a3": "807", "wb_a2": "MK", "wb_a3": "MKD", "woe_id": -99.000000, "adm0_a3_is": "MKD", "adm0_a3_us": "MKD", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Southern Europe", "region_wb": "Europe & Central Asia", "name_len": 9.000000, "long_len": 9.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 22.88137373, 41.99929719 ], [ 22.95237715, 41.33799388 ], [ 22.76177, 41.3048 ], [ 22.59730838, 41.13048717 ], [ 22.05537764, 41.14986583 ], [ 21.6741606, 40.93127452 ], [ 21.02004032, 40.84272696 ], [ 20.60518, 41.08622 ], [ 20.46315, 41.51509 ], [ 20.59023, 41.85541 ], [ 20.59024655, 41.85540892 ], [ 20.71731, 41.84711 ], [ 20.76216, 42.05186 ], [ 21.3527, 42.2068 ], [ 21.57663599, 42.2452244 ], [ 21.91708, 42.30364 ], [ 22.38052575, 42.32025951 ], [ 22.88137373, 41.99929719 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Mali", "sov_a3": "MLI", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Mali", "adm0_a3": "MLI", "geou_dif": 0.000000, "geounit": "Mali", "gu_a3": "MLI", "su_dif": 0.000000, "subunit": "Mali", "su_a3": "MLI", "brk_diff": 0.000000, "name": "Mali", "name_long": "Mali", "brk_a3": "MLI", "brk_name": "Mali", "brk_group": null, "abbrev": "Mali", "postal": "ML", "formal_en": "Republic of Mali", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Mali", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 4.000000, "mapcolor9": 1.000000, "mapcolor13": 7.000000, "pop_est": 12666987.000000, "gdp_md_est": 14590.000000, "pop_year": -99.000000, "lastcensus": 2009.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "ML", "iso_a3": "MLI", "iso_n3": "466", "un_a3": "466", "wb_a2": "ML", "wb_a3": "MLI", "woe_id": -99.000000, "adm0_a3_is": "MLI", "adm0_a3_us": "MLI", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Western Africa", "region_wb": "Sub-Saharan Africa", "name_len": 4.000000, "long_len": 4.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 4.26741947, 19.1552652 ], [ 4.27021, 16.85222748 ], [ 3.72342167, 16.18428376 ], [ 3.6382589, 15.56811982 ], [ 2.74999271, 15.40952485 ], [ 1.38552819, 15.3235611 ], [ 1.01578332, 14.96818228 ], [ 0.37489221, 14.92890819 ], [ -0.26625729, 14.92430899 ], [ -0.51585446, 15.11615774 ], [ -1.06636349, 14.97381501 ], [ -2.00103512, 14.55900829 ], [ -2.19182451, 14.24641755 ], [ -2.96769446, 13.79815034 ], [ -3.10370683, 13.54126679 ], [ -3.5228027, 13.33766165 ], [ -4.00639075, 13.47248546 ], [ -4.28040504, 13.22844351 ], [ -4.4271661, 12.54264558 ], [ -5.22094194, 11.71385895 ], [ -5.19784258, 11.37514578 ], [ -5.47056495, 10.95126984 ], [ -5.4043416, 10.3707368 ], [ -5.81692624, 10.22255463 ], [ -6.05045203, 10.09636079 ], [ -6.20522295, 10.52406078 ], [ -6.49396501, 10.4113028 ], [ -6.66646094, 10.43081066 ], [ -6.85050656, 10.13899384 ], [ -7.62275916, 10.14723623 ], [ -7.89958981, 10.29738211 ], [ -8.02994361, 10.20653494 ], [ -8.33537716, 10.49481192 ], [ -8.28235714, 10.79259736 ], [ -8.40731076, 10.9092569 ], [ -8.62032101, 10.81089081 ], [ -8.5813053, 11.13624563 ], [ -8.3763049, 11.39364594 ], [ -8.78609901, 11.81256094 ], [ -8.90526486, 12.08835806 ], [ -9.12747352, 12.30806041 ], [ -9.32761634, 12.3342862 ], [ -9.56791175, 12.19424307 ], [ -9.8909928, 12.06047862 ], [ -10.16521379, 11.84408356 ], [ -10.59322384, 11.92397533 ], [ -10.87082964, 12.17788748 ], [ -11.03655596, 12.21124462 ], [ -11.29757361, 12.0779711 ], [ -11.45616859, 12.07683421 ], [ -11.51394284, 12.44298758 ], [ -11.46789914, 12.75451895 ], [ -11.55339779, 13.14121369 ], [ -11.92771603, 13.4220751 ], [ -12.12488746, 13.99472748 ], [ -12.17075029, 14.61683421 ], [ -11.83420753, 14.79909699 ], [ -11.66607825, 15.38820832 ], [ -11.34909502, 15.41125601 ], [ -10.65079139, 15.13274588 ], [ -10.08684648, 15.33048574 ], [ -9.70025509, 15.26410737 ], [ -9.55023841, 15.48649689 ], [ -5.53774431, 15.50168976 ], [ -5.31527727, 16.20185375 ], [ -5.48852251, 16.32510204 ], [ -5.97112871, 20.64083344 ], [ -6.45378659, 24.95659068 ], [ -4.92333737, 24.97457408 ], [ -1.5500549, 22.79266592 ], [ 1.82322757, 20.61080943 ], [ 2.06099084, 20.14223338 ], [ 2.68358849, 19.85623017 ], [ 3.146661, 19.6935786 ], [ 3.15813317, 19.0573642 ], [ 4.26741947, 19.1552652 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Myanmar", "sov_a3": "MMR", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Myanmar", "adm0_a3": "MMR", "geou_dif": 0.000000, "geounit": "Myanmar", "gu_a3": "MMR", "su_dif": 0.000000, "subunit": "Myanmar", "su_a3": "MMR", "brk_diff": 0.000000, "name": "Myanmar", "name_long": "Myanmar", "brk_a3": "MMR", "brk_name": "Myanmar", "brk_group": null, "abbrev": "Myan.", "postal": "MM", "formal_en": "Republic of the Union of Myanmar", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Myanmar", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 2.000000, "mapcolor9": 5.000000, "mapcolor13": 13.000000, "pop_est": 48137741.000000, "gdp_md_est": 55130.000000, "pop_year": -99.000000, "lastcensus": 1983.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "MM", "iso_a3": "MMR", "iso_n3": "104", "un_a3": "104", "wb_a2": "MM", "wb_a3": "MMR", "woe_id": -99.000000, "adm0_a3_is": "MMR", "adm0_a3_us": "MMR", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "South-Eastern Asia", "region_wb": "East Asia & Pacific", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 101.18000532, 21.43657298 ], [ 100.32910119, 20.78612173 ], [ 100.11598758, 20.41784964 ], [ 99.54330936, 20.1865976 ], [ 98.95967573, 19.75298066 ], [ 98.25372399, 19.70820303 ], [ 97.79778283, 18.62708039 ], [ 97.37589644, 18.44543773 ], [ 97.85912276, 17.56794607 ], [ 98.49376102, 16.8378356 ], [ 98.90334842, 16.1778242 ], [ 98.53737593, 15.30849742 ], [ 98.19207401, 15.1237025 ], [ 98.43081913, 14.6220277 ], [ 99.09775516, 13.82750255 ], [ 99.21201175, 13.26929373 ], [ 99.19635379, 12.80474844 ], [ 99.587286, 11.89276276 ], [ 99.03812056, 10.96054576 ], [ 98.55355065, 9.93295991 ], [ 98.45717411, 10.67526602 ], [ 98.76454553, 11.44129161 ], [ 98.42833866, 12.03298676 ], [ 98.50957401, 13.12237763 ], [ 98.10360396, 13.6404597 ], [ 97.77773238, 14.83728587 ], [ 97.59707157, 16.10056794 ], [ 97.16453983, 16.92873444 ], [ 96.50576867, 16.42724051 ], [ 95.36935225, 15.71438996 ], [ 94.80840458, 15.80345429 ], [ 94.18880415, 16.0379361 ], [ 94.53348596, 17.2772403 ], [ 94.32481652, 18.2135139 ], [ 93.5409884, 19.36649262 ], [ 93.66325484, 19.72696157 ], [ 93.07827762, 19.85514497 ], [ 92.3685535, 20.67088329 ], [ 92.30323449, 21.47548534 ], [ 92.65225711, 21.32404755 ], [ 92.67272098, 22.04123892 ], [ 93.16612756, 22.27845958 ], [ 93.06029422, 22.70311066 ], [ 93.28632694, 23.04365835 ], [ 93.32518762, 24.07855642 ], [ 94.10674198, 23.85074087 ], [ 94.55265791, 24.67523835 ], [ 94.60324914, 25.16249543 ], [ 95.15515344, 26.00130728 ], [ 95.12476769, 26.57357209 ], [ 96.41936568, 27.26458934 ], [ 97.13399906, 27.08377351 ], [ 97.05198856, 27.69905895 ], [ 97.40256148, 27.88253612 ], [ 97.32711389, 28.26158275 ], [ 97.91198775, 28.33594514 ], [ 98.24623091, 27.74722138 ], [ 98.68269006, 27.50881216 ], [ 98.71209395, 26.74353587 ], [ 98.67183801, 25.9187025 ], [ 97.724609, 25.08363719 ], [ 97.60471968, 23.89740469 ], [ 98.66026249, 24.06328604 ], [ 98.89874922, 23.14272207 ], [ 99.53199222, 22.9490388 ], [ 99.24089888, 22.11831432 ], [ 99.98348921, 21.74293671 ], [ 100.41653771, 21.55883942 ], [ 101.15003299, 21.84998444 ], [ 101.18000532, 21.43657298 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Montenegro", "sov_a3": "MNE", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Montenegro", "adm0_a3": "MNE", "geou_dif": 0.000000, "geounit": "Montenegro", "gu_a3": "MNE", "su_dif": 0.000000, "subunit": "Montenegro", "su_a3": "MNE", "brk_diff": 0.000000, "name": "Montenegro", "name_long": "Montenegro", "brk_a3": "MNE", "brk_name": "Montenegro", "brk_group": null, "abbrev": "Mont.", "postal": "ME", "formal_en": "Montenegro", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Montenegro", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 1.000000, "mapcolor9": 4.000000, "mapcolor13": 5.000000, "pop_est": 672180.000000, "gdp_md_est": 6816.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "ME", "iso_a3": "MNE", "iso_n3": "499", "un_a3": "499", "wb_a2": "ME", "wb_a3": "MNE", "woe_id": -99.000000, "adm0_a3_is": "MNE", "adm0_a3_us": "MNE", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Southern Europe", "region_wb": "Europe & Central Asia", "name_len": 10.000000, "long_len": 10.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 20.25758, 42.81275 ], [ 20.0707, 42.58863 ], [ 19.8016134, 42.50009349 ], [ 19.73805139, 42.68824738 ], [ 19.30449, 42.19574 ], [ 19.37177, 41.87755 ], [ 19.37176816, 41.87755068 ], [ 19.16246, 41.95502 ], [ 18.88214, 42.28151 ], [ 18.45001688, 42.47999225 ], [ 18.45, 42.48 ], [ 18.56, 42.65 ], [ 18.70648, 43.20011 ], [ 19.03165, 43.43253 ], [ 19.21852, 43.52384 ], [ 19.48389, 43.35229 ], [ 19.63, 43.21377997 ], [ 19.95857, 43.10604 ], [ 20.3398, 42.89852 ], [ 20.25758, 42.81275 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Mongolia", "sov_a3": "MNG", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Mongolia", "adm0_a3": "MNG", "geou_dif": 0.000000, "geounit": "Mongolia", "gu_a3": "MNG", "su_dif": 0.000000, "subunit": "Mongolia", "su_a3": "MNG", "brk_diff": 0.000000, "name": "Mongolia", "name_long": "Mongolia", "brk_a3": "MNG", "brk_name": "Mongolia", "brk_group": null, "abbrev": "Mong.", "postal": "MN", "formal_en": "Mongolia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Mongolia", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 5.000000, "mapcolor9": 5.000000, "mapcolor13": 6.000000, "pop_est": 3041142.000000, "gdp_md_est": 9476.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "MN", "iso_a3": "MNG", "iso_n3": "496", "un_a3": "496", "wb_a2": "MN", "wb_a3": "MNG", "woe_id": -99.000000, "adm0_a3_is": "MNG", "adm0_a3_us": "MNG", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Eastern Asia", "region_wb": "East Asia & Pacific", "name_len": 8.000000, "long_len": 8.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 102.25590864, 50.51056061 ], [ 103.67654544, 50.08996613 ], [ 104.62155236, 50.27532949 ], [ 105.88659142, 50.40601919 ], [ 106.88880415, 50.27429597 ], [ 107.8681759, 49.79370515 ], [ 108.47516727, 49.28254772 ], [ 109.40244917, 49.29296052 ], [ 110.66201053, 49.13012808 ], [ 111.58123091, 49.37796825 ], [ 112.8977397, 49.54356538 ], [ 114.3624565, 50.24830272 ], [ 114.96210982, 50.1402473 ], [ 115.48569543, 49.80517731 ], [ 116.6788009, 49.8885314 ], [ 116.1918022, 49.13459809 ], [ 115.48528202, 48.1353826 ], [ 115.74283736, 47.7265445 ], [ 116.30895267, 47.85341014 ], [ 117.29550744, 47.69770905 ], [ 118.06414269, 48.06673046 ], [ 118.86657433, 47.74706004 ], [ 119.77282393, 47.04805878 ], [ 119.66326989, 46.69267996 ], [ 118.8743258, 46.8054121 ], [ 117.42170129, 46.67273286 ], [ 116.71786828, 46.38820242 ], [ 115.98509647, 45.72723501 ], [ 114.46033166, 45.3398168 ], [ 113.46390669, 44.80889313 ], [ 112.43606245, 45.01164562 ], [ 111.87330611, 45.10207937 ], [ 111.34837691, 44.45744172 ], [ 111.66773726, 44.07317577 ], [ 111.82958784, 43.74311839 ], [ 111.12968224, 43.40683401 ], [ 110.41210331, 42.87123363 ], [ 109.24359582, 42.51944632 ], [ 107.74477258, 42.48151581 ], [ 106.12931563, 42.1343277 ], [ 104.96499393, 41.59740957 ], [ 104.52228194, 41.90834667 ], [ 103.31227827, 41.90746817 ], [ 101.8330404, 42.51487295 ], [ 100.84586551, 42.66380443 ], [ 99.5158175, 42.52469147 ], [ 97.45175744, 42.74888968 ], [ 96.34939579, 42.72563528 ], [ 95.76245487, 43.31944916 ], [ 95.30687544, 44.24133088 ], [ 94.68892866, 44.35233185 ], [ 93.48073368, 44.97547211 ], [ 92.13389082, 45.115076 ], [ 90.94553959, 45.28607331 ], [ 90.58576826, 45.71971609 ], [ 90.97080936, 46.88814606 ], [ 90.28082564, 47.6935491 ], [ 88.85429772, 48.06908173 ], [ 88.01383223, 48.5994628 ], [ 87.75126428, 49.29719798 ], [ 88.80556685, 49.47052074 ], [ 90.71366743, 50.33181184 ], [ 92.23471154, 50.80217072 ], [ 93.10421919, 50.49529023 ], [ 94.14756636, 50.48053661 ], [ 94.81594933, 50.01343334 ], [ 95.81402795, 49.97746654 ], [ 97.25972782, 49.7260607 ], [ 98.23176151, 50.42240062 ], [ 97.82573978, 51.01099518 ], [ 98.86149051, 52.04736603 ], [ 99.98173221, 51.63400625 ], [ 100.88948042, 51.51685578 ], [ 102.06522261, 51.25992056 ], [ 102.25590864, 50.51056061 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Mozambique", "sov_a3": "MOZ", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Mozambique", "adm0_a3": "MOZ", "geou_dif": 0.000000, "geounit": "Mozambique", "gu_a3": "MOZ", "su_dif": 0.000000, "subunit": "Mozambique", "su_a3": "MOZ", "brk_diff": 0.000000, "name": "Mozambique", "name_long": "Mozambique", "brk_a3": "MOZ", "brk_name": "Mozambique", "brk_group": null, "abbrev": "Moz.", "postal": "MZ", "formal_en": "Republic of Mozambique", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Mozambique", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 2.000000, "mapcolor9": 1.000000, "mapcolor13": 4.000000, "pop_est": 21669278.000000, "gdp_md_est": 18940.000000, "pop_year": -99.000000, "lastcensus": 2007.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "MZ", "iso_a3": "MOZ", "iso_n3": "508", "un_a3": "508", "wb_a2": "MZ", "wb_a3": "MOZ", "woe_id": -99.000000, "adm0_a3_is": "MOZ", "adm0_a3_us": "MOZ", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Eastern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 10.000000, "long_len": 10.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 40.47838749, -10.76544077 ], [ 40.43725305, -11.76171071 ], [ 40.5608114, -12.63917653 ], [ 40.5996204, -14.20197519 ], [ 40.77547529, -14.69176442 ], [ 40.4772506, -15.40629445 ], [ 40.08926395, -16.10077402 ], [ 39.45255863, -16.72089121 ], [ 38.53835086, -17.10102304 ], [ 37.41113285, -17.5863681 ], [ 36.28127933, -18.6596876 ], [ 35.89649662, -18.84226043 ], [ 35.19839969, -19.55281137 ], [ 34.7863835, -19.78401173 ], [ 34.70189253, -20.49704315 ], [ 35.17612715, -21.25436126 ], [ 35.37342777, -21.84083709 ], [ 35.38584825, -22.14 ], [ 35.56254554, -22.09 ], [ 35.53393477, -23.07078786 ], [ 35.37177412, -23.53535898 ], [ 35.60747033, -23.706563 ], [ 35.45874556, -24.12260996 ], [ 35.0407349, -24.47835052 ], [ 34.21582401, -24.81631439 ], [ 33.01321008, -25.35757334 ], [ 32.5746322, -25.72731821 ], [ 32.6603634, -26.14858449 ], [ 32.91595503, -26.2158672 ], [ 32.83012048, -26.74219166 ], [ 32.07166548, -26.73382008 ], [ 31.98577925, -26.29177988 ], [ 31.83777795, -25.8433318 ], [ 31.75240848, -25.48428395 ], [ 31.93058882, -24.3694166 ], [ 31.67039798, -23.65896901 ], [ 31.19140913, -22.2515097 ], [ 32.24498823, -21.11648854 ], [ 32.50869307, -20.39529225 ], [ 32.65974328, -20.30429005 ], [ 32.77270796, -19.71559214 ], [ 32.61199426, -19.41938283 ], [ 32.6548857, -18.67208994 ], [ 32.84986087, -17.97905731 ], [ 32.84763879, -16.71339813 ], [ 32.32823897, -16.39207407 ], [ 31.85204064, -16.31941701 ], [ 31.63649824, -16.07199025 ], [ 31.173064, -15.8609437 ], [ 30.33895471, -15.88083913 ], [ 30.27425581, -15.50778696 ], [ 30.17948124, -14.79609913 ], [ 33.21402469, -13.97186004 ], [ 33.78970015, -14.45183074 ], [ 34.06482547, -14.35995005 ], [ 34.45963342, -14.61300954 ], [ 34.51766605, -15.01370859 ], [ 34.30729129, -15.47864145 ], [ 34.38129195, -16.18355967 ], [ 35.03381026, -16.80129974 ], [ 35.33906294, -16.10744028 ], [ 35.77190474, -15.89685882 ], [ 35.68684533, -14.61104583 ], [ 35.26795617, -13.88783416 ], [ 34.90715132, -13.5654249 ], [ 34.84946425, -13.56784642 ], [ 34.69388268, -12.42239389 ], [ 34.93283431, -11.47994429 ], [ 35.3123979, -11.43914642 ], [ 36.51408166, -11.720938 ], [ 36.77515099, -11.59453745 ], [ 37.47128421, -11.56875091 ], [ 37.82764489, -11.26876922 ], [ 38.42755659, -11.28520233 ], [ 39.5210299, -10.89685394 ], [ 40.31658623, -10.31709775 ], [ 40.31658858, -10.31709604 ], [ 40.31659, -10.3171 ], [ 40.47838749, -10.76544077 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Mauritania", "sov_a3": "MRT", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Mauritania", "adm0_a3": "MRT", "geou_dif": 0.000000, "geounit": "Mauritania", "gu_a3": "MRT", "su_dif": 0.000000, "subunit": "Mauritania", "su_a3": "MRT", "brk_diff": 0.000000, "name": "Mauritania", "name_long": "Mauritania", "brk_a3": "MRT", "brk_name": "Mauritania", "brk_group": null, "abbrev": "Mrt.", "postal": "MR", "formal_en": "Islamic Republic of Mauritania", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Mauritania", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 3.000000, "mapcolor9": 2.000000, "mapcolor13": 1.000000, "pop_est": 3129486.000000, "gdp_md_est": 6308.000000, "pop_year": -99.000000, "lastcensus": 2000.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "MR", "iso_a3": "MRT", "iso_n3": "478", "un_a3": "478", "wb_a2": "MR", "wb_a3": "MRT", "woe_id": -99.000000, "adm0_a3_is": "MRT", "adm0_a3_us": "MRT", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Western Africa", "region_wb": "Sub-Saharan Africa", "name_len": 10.000000, "long_len": 10.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -4.92333737, 24.97457408 ], [ -6.45378659, 24.95659068 ], [ -5.97112871, 20.64083344 ], [ -5.48852251, 16.32510204 ], [ -5.31527727, 16.20185375 ], [ -5.53774431, 15.50168976 ], [ -9.55023841, 15.48649689 ], [ -9.70025509, 15.26410737 ], [ -10.08684648, 15.33048574 ], [ -10.65079139, 15.13274588 ], [ -11.34909502, 15.41125601 ], [ -11.66607825, 15.38820832 ], [ -11.83420753, 14.79909699 ], [ -12.17075029, 14.61683421 ], [ -12.83065833, 15.30369151 ], [ -13.43573768, 16.03938304 ], [ -14.09952145, 16.30430227 ], [ -14.57734758, 16.59826366 ], [ -15.13573727, 16.58728242 ], [ -15.62366614, 16.36933706 ], [ -16.12069007, 16.45566254 ], [ -16.46309811, 16.13503612 ], [ -16.54970781, 16.67389212 ], [ -16.27055172, 17.1669628 ], [ -16.14634742, 18.10848155 ], [ -16.25688331, 19.09671581 ], [ -16.37765113, 19.59381725 ], [ -16.2778381, 20.09252066 ], [ -16.53632361, 20.56786632 ], [ -17.06342322, 20.9997521 ], [ -16.84519365, 21.33332347 ], [ -12.92910194, 21.32707062 ], [ -13.11875444, 22.7712202 ], [ -12.87422156, 23.28483226 ], [ -11.93722449, 23.37459422 ], [ -11.96941891, 25.93335277 ], [ -8.68729367, 25.88105622 ], [ -8.68439979, 27.39574413 ], [ -4.92333737, 24.97457408 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Malawi", "sov_a3": "MWI", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Malawi", "adm0_a3": "MWI", "geou_dif": 0.000000, "geounit": "Malawi", "gu_a3": "MWI", "su_dif": 0.000000, "subunit": "Malawi", "su_a3": "MWI", "brk_diff": 0.000000, "name": "Malawi", "name_long": "Malawi", "brk_a3": "MWI", "brk_name": "Malawi", "brk_group": null, "abbrev": "Mal.", "postal": "MW", "formal_en": "Republic of Malawi", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Malawi", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 3.000000, "mapcolor9": 4.000000, "mapcolor13": 5.000000, "pop_est": 14268711.000000, "gdp_md_est": 11810.000000, "pop_year": -99.000000, "lastcensus": 2008.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "MW", "iso_a3": "MWI", "iso_n3": "454", "un_a3": "454", "wb_a2": "MW", "wb_a3": "MWI", "woe_id": -99.000000, "adm0_a3_is": "MWI", "adm0_a3_us": "MWI", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Eastern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 34.54675988, -14.04766937 ], [ 34.70654341, -14.26202321 ], [ 34.88120975, -14.01201263 ], [ 35.23622684, -14.40129119 ], [ 35.26020471, -14.27747446 ], [ 35.05597945, -13.74293344 ], [ 34.86756717, -13.70112721 ], [ 34.84946425, -13.56784642 ], [ 34.90715132, -13.5654249 ], [ 35.26795617, -13.88783416 ], [ 35.68684533, -14.61104583 ], [ 35.77190474, -15.89685882 ], [ 35.33906294, -16.10744028 ], [ 35.03381026, -16.80129974 ], [ 34.38129195, -16.18355967 ], [ 34.30729129, -15.47864145 ], [ 34.51766605, -15.01370859 ], [ 34.45963342, -14.61300954 ], [ 34.06482547, -14.35995005 ], [ 33.78970015, -14.45183074 ], [ 33.21402469, -13.97186004 ], [ 32.68816532, -13.71285776 ], [ 32.99176436, -12.78387054 ], [ 33.30642215, -12.43577809 ], [ 33.11428918, -11.60719817 ], [ 33.3153105, -10.79654998 ], [ 33.4856877, -10.52555877 ], [ 33.23138797, -9.67672169 ], [ 32.75937544, -9.23059905 ], [ 33.73972904, -9.41715097 ], [ 33.93879963, -9.69087147 ], [ 33.9387996, -9.69087156 ], [ 33.90659224, -9.80172698 ], [ 34.25990401, -10.44757903 ], [ 34.32269087, -11.65298349 ], [ 34.0325277, -12.20855682 ], [ 34.32997725, -12.94458424 ], [ 34.32093387, -13.37938974 ], [ 34.5511007, -13.67208506 ], [ 34.54675988, -14.04766937 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Malaysia", "sov_a3": "MYS", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Malaysia", "adm0_a3": "MYS", "geou_dif": 0.000000, "geounit": "Malaysia", "gu_a3": "MYS", "su_dif": 0.000000, "subunit": "Malaysia", "su_a3": "MYS", "brk_diff": 0.000000, "name": "Malaysia", "name_long": "Malaysia", "brk_a3": "MYS", "brk_name": "Malaysia", "brk_group": null, "abbrev": "Malay.", "postal": "MY", "formal_en": "Malaysia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Malaysia", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 4.000000, "mapcolor9": 3.000000, "mapcolor13": 6.000000, "pop_est": 25715819.000000, "gdp_md_est": 384300.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "MY", "iso_a3": "MYS", "iso_n3": "458", "un_a3": "458", "wb_a2": "MY", "wb_a3": "MYS", "woe_id": -99.000000, "adm0_a3_is": "MYS", "adm0_a3_us": "MYS", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "South-Eastern Asia", "region_wb": "East Asia & Pacific", "name_len": 8.000000, "long_len": 8.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 101.07551558, 6.20486705 ], [ 101.15421878, 5.69138418 ], [ 101.81428185, 5.81080842 ], [ 102.14118696, 6.22163605 ], [ 102.37114709, 6.12820506 ], [ 102.96170536, 5.52449514 ], [ 103.38121463, 4.85500113 ], [ 103.43857547, 4.18160554 ], [ 103.33212202, 3.7266979 ], [ 103.42942875, 3.38286876 ], [ 103.50244754, 2.79101858 ], [ 103.85467411, 2.51545401 ], [ 104.24793176, 1.63114106 ], [ 104.22881148, 1.293048 ], [ 103.51970747, 1.22633373 ], [ 102.57361535, 1.96711538 ], [ 101.39063846, 2.76081371 ], [ 101.27353967, 3.27029165 ], [ 100.69543542, 3.93913972 ], [ 100.55740767, 4.76728038 ], [ 100.19670617, 5.31249258 ], [ 100.30626021, 6.04056184 ], [ 100.08575687, 6.46448945 ], [ 100.25959639, 6.64282482 ], [ 101.07551558, 6.20486705 ] ] ], [ [ [ 118.61832075, 4.47820242 ], [ 117.88203495, 4.13755138 ], [ 117.01521447, 4.30609406 ], [ 115.86551721, 4.30655915 ], [ 115.5190784, 3.16923839 ], [ 115.13403731, 2.82148184 ], [ 114.62135542, 1.43068818 ], [ 113.80584964, 1.21754873 ], [ 112.8598092, 1.49779003 ], [ 112.38025191, 1.41012096 ], [ 111.79754846, 0.90444123 ], [ 111.15913781, 0.97647818 ], [ 110.51406091, 0.77313142 ], [ 109.83022668, 1.33813569 ], [ 109.66326013, 2.00646699 ], [ 110.39613529, 1.66377473 ], [ 111.16885298, 1.8506367 ], [ 111.37008101, 2.69730337 ], [ 111.79692834, 2.88589651 ], [ 112.99561486, 3.10239492 ], [ 113.71293542, 3.89350943 ], [ 114.20401655, 4.52587393 ], [ 114.65959598, 4.00763683 ], [ 114.86955733, 4.34831371 ], [ 115.34746097, 4.31663605 ], [ 115.40570031, 4.95522757 ], [ 115.45071048, 5.4477298 ], [ 116.220741, 6.14319123 ], [ 116.72510298, 6.92477143 ], [ 117.12962609, 6.92805288 ], [ 117.64339318, 6.42216645 ], [ 117.68907515, 5.98749014 ], [ 118.34769128, 5.70869579 ], [ 119.18190392, 5.4078356 ], [ 119.1106938, 5.01612824 ], [ 118.439727, 4.96651887 ], [ 118.61832075, 4.47820242 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Namibia", "sov_a3": "NAM", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Namibia", "adm0_a3": "NAM", "geou_dif": 0.000000, "geounit": "Namibia", "gu_a3": "NAM", "su_dif": 0.000000, "subunit": "Namibia", "su_a3": "NAM", "brk_diff": 0.000000, "name": "Namibia", "name_long": "Namibia", "brk_a3": "NAM", "brk_name": "Namibia", "brk_group": null, "abbrev": "Nam.", "postal": "NA", "formal_en": "Republic of Namibia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Namibia", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 1.000000, "mapcolor9": 1.000000, "mapcolor13": 7.000000, "pop_est": 2108665.000000, "gdp_md_est": 13250.000000, "pop_year": -99.000000, "lastcensus": 2001.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "NA", "iso_a3": "NAM", "iso_n3": "516", "un_a3": "516", "wb_a2": "NA", "wb_a3": "NAM", "woe_id": -99.000000, "adm0_a3_is": "NAM", "adm0_a3_us": "NAM", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Southern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 23.21504846, -17.52311614 ], [ 24.03386153, -17.29584319 ], [ 24.68234907, -17.35341074 ], [ 25.07695031, -17.57882334 ], [ 25.08444339, -17.66181569 ], [ 24.52070519, -17.88712493 ], [ 24.21736454, -17.88934702 ], [ 23.57900557, -18.28126108 ], [ 23.19685835, -17.86903818 ], [ 21.65504032, -18.21914601 ], [ 20.91064131, -18.25221893 ], [ 20.88113407, -21.81432708 ], [ 19.8954578, -21.849157 ], [ 19.89576786, -24.76779022 ], [ 19.89473433, -28.46110483 ], [ 19.00212731, -28.97244313 ], [ 18.46489912, -29.04546193 ], [ 17.83615197, -28.85637786 ], [ 17.38749719, -28.78351409 ], [ 17.21892866, -28.35594329 ], [ 16.82401737, -28.08216155 ], [ 16.34497684, -28.57670501 ], [ 15.60181807, -27.82124725 ], [ 15.21047245, -27.09095591 ], [ 14.98971073, -26.11737192 ], [ 14.74321415, -25.39292002 ], [ 14.40814416, -23.85301401 ], [ 14.38571659, -22.65665293 ], [ 14.25771406, -22.11120818 ], [ 13.86864221, -21.69903696 ], [ 13.352498, -20.87283416 ], [ 12.82684533, -19.67316579 ], [ 12.60856408, -19.04534881 ], [ 11.79491865, -18.06912933 ], [ 11.73419885, -17.30188934 ], [ 12.21546146, -17.11166839 ], [ 12.81408125, -16.94134287 ], [ 13.46236209, -16.97121185 ], [ 14.05850142, -17.42338063 ], [ 14.20970666, -17.35310068 ], [ 18.26330936, -17.30995086 ], [ 18.95618696, -17.78909474 ], [ 21.37717614, -17.93063649 ], [ 23.21504846, -17.52311614 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "France", "sov_a3": "FR1", "adm0_dif": 1.000000, "level": 2.000000, "type": "Dependency", "admin": "New Caledonia", "adm0_a3": "NCL", "geou_dif": 0.000000, "geounit": "New Caledonia", "gu_a3": "NCL", "su_dif": 0.000000, "subunit": "New Caledonia", "su_a3": "NCL", "brk_diff": 0.000000, "name": "New Caledonia", "name_long": "New Caledonia", "brk_a3": "NCL", "brk_name": "New Caledonia", "brk_group": null, "abbrev": "New C.", "postal": "NC", "formal_en": "New Caledonia", "formal_fr": "Nouvelle-Calonie", "note_adm0": "Fr.", "note_brk": null, "name_sort": "New Caledonia", "name_alt": null, "mapcolor7": 7.000000, "mapcolor8": 5.000000, "mapcolor9": 9.000000, "mapcolor13": 11.000000, "pop_est": 227436.000000, "gdp_md_est": 3158.000000, "pop_year": -99.000000, "lastcensus": 2009.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "2. High income: nonOECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "NC", "iso_a3": "NCL", "iso_n3": "540", "un_a3": "540", "wb_a2": "NC", "wb_a3": "NCL", "woe_id": -99.000000, "adm0_a3_is": "NCL", "adm0_a3_us": "NCL", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Oceania", "region_un": "Oceania", "subregion": "Melanesia", "region_wb": "East Asia & Pacific", "name_len": 13.000000, "long_len": 13.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": -99.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 167.12001143, -22.15999074 ], [ 166.74003462, -22.39997609 ], [ 166.18973229, -22.12970835 ], [ 165.47437544, -21.67960662 ], [ 164.8298153, -21.14981984 ], [ 164.16799523, -20.4447466 ], [ 164.02960575, -20.10564585 ], [ 164.45996708, -20.1200119 ], [ 165.02003625, -20.45999114 ], [ 165.46000939, -20.80002207 ], [ 165.77998986, -21.08000498 ], [ 166.59999149, -21.70001881 ], [ 167.12001143, -22.15999074 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Niger", "sov_a3": "NER", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Niger", "adm0_a3": "NER", "geou_dif": 0.000000, "geounit": "Niger", "gu_a3": "NER", "su_dif": 0.000000, "subunit": "Niger", "su_a3": "NER", "brk_diff": 0.000000, "name": "Niger", "name_long": "Niger", "brk_a3": "NER", "brk_name": "Niger", "brk_group": null, "abbrev": "Niger", "postal": "NE", "formal_en": "Republic of Niger", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Niger", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 5.000000, "mapcolor9": 3.000000, "mapcolor13": 13.000000, "pop_est": 15306252.000000, "gdp_md_est": 10040.000000, "pop_year": -99.000000, "lastcensus": 2001.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "NE", "iso_a3": "NER", "iso_n3": "562", "un_a3": "562", "wb_a2": "NE", "wb_a3": "NER", "woe_id": -99.000000, "adm0_a3_is": "NER", "adm0_a3_us": "NER", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Western Africa", "region_wb": "Sub-Saharan Africa", "name_len": 5.000000, "long_len": 5.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 13.58142459, 23.04050609 ], [ 14.14387088, 22.49128897 ], [ 14.8513, 22.86295 ], [ 15.09688765, 21.30851879 ], [ 15.47107669, 21.04845714 ], [ 15.48714806, 20.73041454 ], [ 15.9032467, 20.38761892 ], [ 15.68574059, 19.95718008 ], [ 15.30044111, 17.92794994 ], [ 15.24773115, 16.62730581 ], [ 13.97220178, 15.68436595 ], [ 13.54039351, 14.36713369 ], [ 13.95669885, 13.99669119 ], [ 13.95447676, 13.3534488 ], [ 14.59578128, 13.33042695 ], [ 14.49578739, 12.85939627 ], [ 14.21353071, 12.80203543 ], [ 14.1813363, 12.48365693 ], [ 13.99535282, 12.46156525 ], [ 13.31870161, 13.55635631 ], [ 13.08398726, 13.59614716 ], [ 12.30207116, 13.03718903 ], [ 11.52780318, 13.32898001 ], [ 10.98959313, 13.3873227 ], [ 10.70103194, 13.24691783 ], [ 10.11481449, 13.2772519 ], [ 9.52492801, 12.8511022 ], [ 9.0149333, 12.82665925 ], [ 7.80467126, 13.34352692 ], [ 7.3307467, 13.09803803 ], [ 6.82044193, 13.11509125 ], [ 6.44542606, 13.49276846 ], [ 5.4430583, 13.86592398 ], [ 4.36834354, 13.74748159 ], [ 4.107946, 13.53121573 ], [ 3.96728275, 12.95610871 ], [ 3.68063358, 12.55290335 ], [ 3.61118045, 11.66016714 ], [ 2.84864302, 12.23563589 ], [ 2.49016361, 12.23305207 ], [ 2.1544735, 11.94015005 ], [ 2.17710778, 12.62501781 ], [ 1.02410322, 12.85182567 ], [ 0.99304569, 13.33574962 ], [ 0.42992761, 13.98873302 ], [ 0.2956464, 14.44423493 ], [ 0.37489221, 14.92890819 ], [ 1.01578332, 14.96818228 ], [ 1.38552819, 15.3235611 ], [ 2.74999271, 15.40952485 ], [ 3.6382589, 15.56811982 ], [ 3.72342167, 16.18428376 ], [ 4.27021, 16.85222748 ], [ 4.26741947, 19.1552652 ], [ 5.67756595, 19.60120698 ], [ 8.5728931, 21.56566071 ], [ 11.99950565, 23.4716684 ], [ 13.58142459, 23.04050609 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Nigeria", "sov_a3": "NGA", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Nigeria", "adm0_a3": "NGA", "geou_dif": 0.000000, "geounit": "Nigeria", "gu_a3": "NGA", "su_dif": 0.000000, "subunit": "Nigeria", "su_a3": "NGA", "brk_diff": 0.000000, "name": "Nigeria", "name_long": "Nigeria", "brk_a3": "NGA", "brk_name": "Nigeria", "brk_group": null, "abbrev": "Nigeria", "postal": "NG", "formal_en": "Federal Republic of Nigeria", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Nigeria", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 2.000000, "mapcolor9": 5.000000, "mapcolor13": 2.000000, "pop_est": 149229090.000000, "gdp_md_est": 335400.000000, "pop_year": -99.000000, "lastcensus": 2006.000000, "gdp_year": -99.000000, "economy": "5. Emerging region: G20", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "NG", "iso_a3": "NGA", "iso_n3": "566", "un_a3": "566", "wb_a2": "NG", "wb_a3": "NGA", "woe_id": -99.000000, "adm0_a3_is": "NGA", "adm0_a3_us": "NGA", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Western Africa", "region_wb": "Sub-Saharan Africa", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 7.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 14.1813363, 12.48365693 ], [ 14.57717777, 12.08536083 ], [ 14.46819217, 11.9047517 ], [ 14.41537886, 11.57236888 ], [ 13.57294966, 10.79856599 ], [ 13.30867639, 10.16036205 ], [ 13.16759972, 9.64062633 ], [ 12.95546797, 9.41777171 ], [ 12.7536715, 8.71776276 ], [ 12.2188721, 8.30582408 ], [ 12.06394616, 7.79980846 ], [ 11.83930871, 7.39704234 ], [ 11.74577437, 6.98138296 ], [ 11.05878788, 6.64442678 ], [ 10.49737512, 7.05535777 ], [ 10.11827681, 7.03876964 ], [ 9.52270593, 6.45348237 ], [ 9.23316288, 6.44449067 ], [ 8.75753299, 5.47966584 ], [ 8.50028771, 4.77198294 ], [ 7.46210819, 4.41210826 ], [ 7.08259647, 4.46468903 ], [ 6.69807214, 4.24059418 ], [ 5.89817264, 4.26245331 ], [ 5.3628048, 4.88797069 ], [ 5.03357425, 5.61180248 ], [ 4.32560713, 6.27065115 ], [ 3.57418013, 6.25830048 ], [ 2.69170169, 6.25881725 ], [ 2.74906253, 7.87073436 ], [ 2.72379276, 8.5068454 ], [ 2.91230838, 9.13760794 ], [ 3.2203516, 9.44415253 ], [ 3.70543827, 10.06321035 ], [ 3.60007002, 10.33218618 ], [ 3.79711226, 10.73474559 ], [ 3.57221642, 11.32793936 ], [ 3.61118045, 11.66016714 ], [ 3.68063358, 12.55290335 ], [ 3.96728275, 12.95610871 ], [ 4.107946, 13.53121573 ], [ 4.36834354, 13.74748159 ], [ 5.4430583, 13.86592398 ], [ 6.44542606, 13.49276846 ], [ 6.82044193, 13.11509125 ], [ 7.3307467, 13.09803803 ], [ 7.80467126, 13.34352692 ], [ 9.0149333, 12.82665925 ], [ 9.52492801, 12.8511022 ], [ 10.11481449, 13.2772519 ], [ 10.70103194, 13.24691783 ], [ 10.98959313, 13.3873227 ], [ 11.52780318, 13.32898001 ], [ 12.30207116, 13.03718903 ], [ 13.08398726, 13.59614716 ], [ 13.31870161, 13.55635631 ], [ 13.99535282, 12.46156525 ], [ 14.1813363, 12.48365693 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Nicaragua", "sov_a3": "NIC", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Nicaragua", "adm0_a3": "NIC", "geou_dif": 0.000000, "geounit": "Nicaragua", "gu_a3": "NIC", "su_dif": 0.000000, "subunit": "Nicaragua", "su_a3": "NIC", "brk_diff": 0.000000, "name": "Nicaragua", "name_long": "Nicaragua", "brk_a3": "NIC", "brk_name": "Nicaragua", "brk_group": null, "abbrev": "Nic.", "postal": "NI", "formal_en": "Republic of Nicaragua", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Nicaragua", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 4.000000, "mapcolor9": 1.000000, "mapcolor13": 9.000000, "pop_est": 5891199.000000, "gdp_md_est": 16790.000000, "pop_year": -99.000000, "lastcensus": 2005.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "NI", "iso_a3": "NIC", "iso_n3": "558", "un_a3": "558", "wb_a2": "NI", "wb_a3": "NIC", "woe_id": -99.000000, "adm0_a3_is": "NIC", "adm0_a3_us": "NIC", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "North America", "region_un": "Americas", "subregion": "Central America", "region_wb": "Latin America & Caribbean", "name_len": 9.000000, "long_len": 9.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -83.147219, 14.99582917 ], [ -83.23323442, 14.89986603 ], [ -83.28416155, 14.67662385 ], [ -83.18212643, 14.31070303 ], [ -83.41249997, 13.97007783 ], [ -83.51983192, 13.56769929 ], [ -83.5522072, 13.12705435 ], [ -83.49851539, 12.8692923 ], [ -83.47332313, 12.41908723 ], [ -83.6261045, 12.32085033 ], [ -83.719613, 11.8931245 ], [ -83.65085751, 11.62903209 ], [ -83.85547034, 11.37331127 ], [ -83.80893572, 11.10304352 ], [ -83.65561174, 10.93876415 ], [ -83.89505449, 10.7268391 ], [ -84.1901786, 10.79345002 ], [ -84.35593075, 10.99922557 ], [ -84.67306902, 11.08265717 ], [ -84.9030033, 10.95230337 ], [ -85.56185198, 11.21711925 ], [ -85.71254045, 11.08844493 ], [ -86.05848833, 11.40343863 ], [ -86.52584998, 11.80687653 ], [ -86.74599158, 12.1439619 ], [ -87.16751624, 12.45825796 ], [ -87.66849342, 12.90990998 ], [ -87.5574666, 13.0645517 ], [ -87.39238624, 12.91401826 ], [ -87.31665443, 12.98468578 ], [ -87.00576901, 13.02579438 ], [ -86.88055701, 13.25420421 ], [ -86.73382178, 13.26309256 ], [ -86.75508664, 13.75484549 ], [ -86.52070818, 13.77848745 ], [ -86.3121421, 13.77135611 ], [ -86.0962638, 14.03818736 ], [ -85.80129473, 13.836055 ], [ -85.69866533, 13.96007844 ], [ -85.51441301, 14.07901175 ], [ -85.16536455, 14.35436962 ], [ -85.14875058, 14.56019684 ], [ -85.05278744, 14.55154104 ], [ -84.9245007, 14.79049287 ], [ -84.82003679, 14.8195867 ], [ -84.64958208, 14.66680532 ], [ -84.4493359, 14.62161428 ], [ -84.22834164, 14.74876415 ], [ -83.9757214, 14.74943594 ], [ -83.62858497, 14.88007396 ], [ -83.48998878, 15.0162672 ], [ -83.147219, 14.99582917 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Netherlands", "sov_a3": "NL1", "adm0_dif": 1.000000, "level": 2.000000, "type": "Country", "admin": "Netherlands", "adm0_a3": "NLD", "geou_dif": 0.000000, "geounit": "Netherlands", "gu_a3": "NLD", "su_dif": 0.000000, "subunit": "Netherlands", "su_a3": "NLD", "brk_diff": 0.000000, "name": "Netherlands", "name_long": "Netherlands", "brk_a3": "NLD", "brk_name": "Netherlands", "brk_group": null, "abbrev": "Neth.", "postal": "NL", "formal_en": "Kingdom of the Netherlands", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Netherlands", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 2.000000, "mapcolor9": 2.000000, "mapcolor13": 9.000000, "pop_est": 16715999.000000, "gdp_md_est": 672000.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "NL", "iso_a3": "NLD", "iso_n3": "528", "un_a3": "528", "wb_a2": "NL", "wb_a3": "NLD", "woe_id": -99.000000, "adm0_a3_is": "NLD", "adm0_a3_us": "NLD", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Western Europe", "region_wb": "Europe & Central Asia", "name_len": 11.000000, "long_len": 11.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 5.98865807, 51.85161571 ], [ 6.15665816, 50.80372102 ], [ 5.60697595, 51.03729849 ], [ 4.97399133, 51.47502371 ], [ 4.04707116, 51.26725861 ], [ 3.31497114, 51.34575511 ], [ 3.31501148, 51.34577662 ], [ 3.83028853, 51.62054454 ], [ 4.70599735, 53.09179841 ], [ 6.07418257, 53.51040335 ], [ 6.9051396, 53.48216218 ], [ 7.09205326, 53.14404328 ], [ 6.8428695, 52.22844025 ], [ 6.5893966, 51.85202912 ], [ 5.98865807, 51.85161571 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Norway", "sov_a3": "NOR", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Norway", "adm0_a3": "NOR", "geou_dif": 0.000000, "geounit": "Norway", "gu_a3": "NOR", "su_dif": 0.000000, "subunit": "Norway", "su_a3": "NOR", "brk_diff": 0.000000, "name": "Norway", "name_long": "Norway", "brk_a3": "NOR", "brk_name": "Norway", "brk_group": null, "abbrev": "Nor.", "postal": "N", "formal_en": "Kingdom of Norway", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Norway", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 3.000000, "mapcolor9": 8.000000, "mapcolor13": 12.000000, "pop_est": 4676305.000000, "gdp_md_est": 276400.000000, "pop_year": -99.000000, "lastcensus": 2001.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "NO", "iso_a3": "NOR", "iso_n3": "578", "un_a3": "578", "wb_a2": "NO", "wb_a3": "NOR", "woe_id": -99.000000, "adm0_a3_is": "NOR", "adm0_a3_us": "NOR", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Northern Europe", "region_wb": "Europe & Central Asia", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 28.16554732, 71.18547435 ], [ 31.29341841, 70.45378775 ], [ 30.00543501, 70.18625886 ], [ 31.1010422, 69.55810109 ], [ 31.10107873, 69.55808015 ], [ 29.39958052, 69.156916 ], [ 28.59192956, 69.06477692 ], [ 29.01557295, 69.7664912 ], [ 27.73229211, 70.16419302 ], [ 26.17962202, 69.82529898 ], [ 25.68921268, 69.09211376 ], [ 24.73567915, 68.64955679 ], [ 23.66204959, 68.89124746 ], [ 22.35623783, 68.84174144 ], [ 21.24493615, 69.37044302 ], [ 20.64559289, 69.10624726 ], [ 20.025269, 69.06513866 ], [ 19.8785596, 68.40719432 ], [ 17.99386844, 68.56739126 ], [ 17.72918176, 68.01055187 ], [ 16.76887861, 68.01393667 ], [ 16.10871219, 67.30245555 ], [ 15.10841149, 66.19386689 ], [ 13.55568973, 64.7870277 ], [ 13.91990523, 64.44542064 ], [ 13.57191613, 64.04911408 ], [ 12.57993534, 64.06621898 ], [ 11.93056929, 63.12831757 ], [ 11.99206424, 61.80036245 ], [ 12.63114668, 61.29357168 ], [ 12.30036584, 60.11793285 ], [ 11.46827193, 59.4323933 ], [ 11.02736861, 58.8561494 ], [ 10.35655684, 59.46980703 ], [ 8.38200036, 58.31328848 ], [ 7.04874841, 58.07888418 ], [ 5.6658354, 58.58815542 ], [ 5.30823449, 59.66323192 ], [ 4.99207808, 61.97099803 ], [ 5.91290042, 62.61447297 ], [ 8.55341109, 63.45400829 ], [ 10.52770918, 64.48603832 ], [ 12.3583468, 65.87972586 ], [ 14.76114587, 67.81064159 ], [ 16.43592736, 68.56320547 ], [ 19.18402835, 69.81744416 ], [ 21.37841638, 70.25516938 ], [ 23.0237423, 70.20207185 ], [ 24.54654341, 71.03049673 ], [ 26.37004968, 70.98626171 ], [ 28.16554732, 71.18547435 ] ] ], [ [ [ 24.72412, 77.85385 ], [ 22.49032, 77.44493 ], [ 20.72601, 77.67704 ], [ 21.41611, 77.93504 ], [ 20.8119, 78.25463 ], [ 22.88426, 78.45494 ], [ 23.28134, 78.07954 ], [ 24.72412, 77.85385 ] ] ], [ [ [ 18.25183, 79.70175 ], [ 21.54383, 78.95611 ], [ 19.02737, 78.5626 ], [ 18.47172, 77.82669 ], [ 17.59441, 77.63796 ], [ 17.1182, 76.80941 ], [ 15.91315, 76.77045 ], [ 13.76259, 77.38035 ], [ 14.66956, 77.73565 ], [ 13.1706, 78.02493 ], [ 11.22231, 78.8693 ], [ 10.44453, 79.65239 ], [ 13.17077, 80.01046 ], [ 13.71852, 79.66039 ], [ 15.14282, 79.67431 ], [ 15.52255, 80.01608 ], [ 16.99085, 80.05086 ], [ 18.25183, 79.70175 ] ] ], [ [ [ 25.44762536, 80.4073404 ], [ 27.40750573, 80.05640575 ], [ 25.92465051, 79.51783397 ], [ 23.02446577, 79.40001171 ], [ 20.07518843, 79.56682323 ], [ 19.89726647, 79.84236197 ], [ 18.46226362, 79.85988028 ], [ 17.36801517, 80.31889619 ], [ 20.45599206, 80.59815563 ], [ 21.90794478, 80.35767935 ], [ 22.91925256, 80.65714427 ], [ 25.44762536, 80.4073404 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Nepal", "sov_a3": "NPL", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Nepal", "adm0_a3": "NPL", "geou_dif": 0.000000, "geounit": "Nepal", "gu_a3": "NPL", "su_dif": 0.000000, "subunit": "Nepal", "su_a3": "NPL", "brk_diff": 0.000000, "name": "Nepal", "name_long": "Nepal", "brk_a3": "NPL", "brk_name": "Nepal", "brk_group": null, "abbrev": "Nepal", "postal": "NP", "formal_en": "Nepal", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Nepal", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 2.000000, "mapcolor9": 3.000000, "mapcolor13": 12.000000, "pop_est": 28563377.000000, "gdp_md_est": 31080.000000, "pop_year": -99.000000, "lastcensus": 2001.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "NP", "iso_a3": "NPL", "iso_n3": "524", "un_a3": "524", "wb_a2": "NP", "wb_a3": "NPL", "woe_id": -99.000000, "adm0_a3_is": "NPL", "adm0_a3_us": "NPL", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Southern Asia", "region_wb": "South Asia", "name_len": 5.000000, "long_len": 5.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 88.12044071, 27.87654165 ], [ 88.04313277, 27.44581859 ], [ 88.17480432, 26.81040518 ], [ 88.06023766, 26.41461538 ], [ 87.22747196, 26.39789806 ], [ 86.02439294, 26.63098461 ], [ 85.2517786, 26.72619843 ], [ 84.67501794, 27.23490123 ], [ 83.3042489, 27.36450572 ], [ 81.99998742, 27.92547923 ], [ 81.05720259, 28.41609528 ], [ 80.08842451, 28.79447012 ], [ 80.47672123, 29.72986522 ], [ 81.11125614, 30.18348094 ], [ 81.52580448, 30.42271699 ], [ 82.32751265, 30.11526805 ], [ 83.33711511, 29.46373159 ], [ 83.89899295, 29.32022614 ], [ 84.23457971, 28.8398937 ], [ 85.01163822, 28.64277395 ], [ 85.82331994, 28.20357595 ], [ 86.95451704, 27.97426179 ], [ 88.12044071, 27.87654165 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "New Zealand", "sov_a3": "NZ1", "adm0_dif": 1.000000, "level": 2.000000, "type": "Country", "admin": "New Zealand", "adm0_a3": "NZL", "geou_dif": 0.000000, "geounit": "New Zealand", "gu_a3": "NZL", "su_dif": 0.000000, "subunit": "New Zealand", "su_a3": "NZL", "brk_diff": 0.000000, "name": "New Zealand", "name_long": "New Zealand", "brk_a3": "NZL", "brk_name": "New Zealand", "brk_group": null, "abbrev": "N.Z.", "postal": "NZ", "formal_en": "New Zealand", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "New Zealand", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 3.000000, "mapcolor9": 4.000000, "mapcolor13": 4.000000, "pop_est": 4213418.000000, "gdp_md_est": 116700.000000, "pop_year": -99.000000, "lastcensus": 2006.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "NZ", "iso_a3": "NZL", "iso_n3": "554", "un_a3": "554", "wb_a2": "NZ", "wb_a3": "NZL", "woe_id": -99.000000, "adm0_a3_is": "NZL", "adm0_a3_us": "NZL", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Oceania", "region_un": "Oceania", "subregion": "Australia and New Zealand", "region_wb": "East Asia & Pacific", "name_len": 11.000000, "long_len": 11.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 173.02037479, -40.91905242 ], [ 173.24723433, -41.33199879 ], [ 173.95840539, -40.92670053 ], [ 174.2475867, -41.34915537 ], [ 174.24851688, -41.77000823 ], [ 173.87644657, -42.2331841 ], [ 173.2227397, -42.97003834 ], [ 172.71124637, -43.37228769 ], [ 173.08011275, -43.8533436 ], [ 172.30858361, -43.86569427 ], [ 171.45292525, -44.24251881 ], [ 171.18513797, -44.89710418 ], [ 170.61669722, -45.90892872 ], [ 169.83142215, -46.35577483 ], [ 169.33233117, -46.64123545 ], [ 168.41135379, -46.61994476 ], [ 167.76374475, -46.29019744 ], [ 166.67688602, -46.21991749 ], [ 166.50914432, -45.85270477 ], [ 167.04642419, -45.11094126 ], [ 168.30376346, -44.12397308 ], [ 168.94940881, -43.93581919 ], [ 169.66781457, -43.55532562 ], [ 170.52491988, -43.03168833 ], [ 171.12508996, -42.51275359 ], [ 171.56971398, -41.76742441 ], [ 171.94870894, -41.5144166 ], [ 172.097227, -40.95610442 ], [ 172.79857954, -40.49396209 ], [ 173.02037479, -40.91905242 ] ] ], [ [ [ 174.61200891, -36.15639739 ], [ 175.33661584, -37.209098 ], [ 175.35759647, -36.52619394 ], [ 175.80888675, -36.79894215 ], [ 175.95849003, -37.55538177 ], [ 176.76319543, -37.88125335 ], [ 177.4388131, -37.96124847 ], [ 178.01035445, -37.57982472 ], [ 178.51709354, -37.69537322 ], [ 178.27473107, -38.5828126 ], [ 177.97046024, -39.16634287 ], [ 177.20699263, -39.14577565 ], [ 176.9399805, -39.44973642 ], [ 177.03294641, -39.87994272 ], [ 176.8858236, -40.06597788 ], [ 176.50801721, -40.60480804 ], [ 176.01244022, -41.28962412 ], [ 175.2395675, -41.68830779 ], [ 175.06789839, -41.42589487 ], [ 174.65097294, -41.28182098 ], [ 175.22763024, -40.45923553 ], [ 174.90015669, -39.9089332 ], [ 173.82404667, -39.50885426 ], [ 173.852262, -39.14660247 ], [ 174.57480187, -38.7976832 ], [ 174.74347375, -38.02780771 ], [ 174.69701664, -37.38112884 ], [ 174.29202844, -36.71109222 ], [ 174.31900353, -36.53482391 ], [ 173.84099654, -36.12198089 ], [ 173.05417118, -35.23712534 ], [ 172.63600549, -34.52910654 ], [ 173.00704227, -34.45066172 ], [ 173.55129846, -35.00618336 ], [ 174.3293905, -35.2654957 ], [ 174.61200891, -36.15639739 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Oman", "sov_a3": "OMN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Oman", "adm0_a3": "OMN", "geou_dif": 0.000000, "geounit": "Oman", "gu_a3": "OMN", "su_dif": 0.000000, "subunit": "Oman", "su_a3": "OMN", "brk_diff": 0.000000, "name": "Oman", "name_long": "Oman", "brk_a3": "OMN", "brk_name": "Oman", "brk_group": null, "abbrev": "Oman", "postal": "OM", "formal_en": "Sultanate of Oman", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Oman", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 4.000000, "mapcolor9": 1.000000, "mapcolor13": 6.000000, "pop_est": 3418085.000000, "gdp_md_est": 66980.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "2. High income: nonOECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "OM", "iso_a3": "OMN", "iso_n3": "512", "un_a3": "512", "wb_a2": "OM", "wb_a3": "OMN", "woe_id": -99.000000, "adm0_a3_is": "OMN", "adm0_a3_us": "OMN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Western Asia", "region_wb": "Middle East & North Africa", "name_len": 4.000000, "long_len": 4.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 58.86114139, 21.11403453 ], [ 58.48798587, 20.42898591 ], [ 58.03431848, 20.48143749 ], [ 57.82637251, 20.24300243 ], [ 57.66576216, 19.73600495 ], [ 57.78870039, 19.0675703 ], [ 57.6943909, 18.94470958 ], [ 57.23426395, 18.94799103 ], [ 56.60965091, 18.57426708 ], [ 56.51218916, 18.08711335 ], [ 56.28352095, 17.8760668 ], [ 55.66149173, 17.88412832 ], [ 55.26993941, 17.63230907 ], [ 55.27490034, 17.2283544 ], [ 54.79100223, 16.95069693 ], [ 54.23925296, 17.04498058 ], [ 53.57050825, 16.70766267 ], [ 53.10857263, 16.65105113 ], [ 52.78218428, 17.34974234 ], [ 52.0000098, 19.00000336 ], [ 54.99998172, 19.999994 ], [ 55.66665938, 22.00000113 ], [ 55.2083411, 22.70832998 ], [ 55.23448937, 23.11099274 ], [ 55.5258411, 23.52486929 ], [ 55.52863163, 23.93360403 ], [ 55.98121382, 24.13054291 ], [ 55.80411869, 24.26960419 ], [ 55.88623254, 24.92083059 ], [ 56.39684737, 24.92473216 ], [ 56.84514042, 24.24167308 ], [ 57.40345259, 23.87859447 ], [ 58.13694787, 23.74793061 ], [ 58.72921146, 23.56566783 ], [ 59.18050174, 22.99239533 ], [ 59.45009769, 22.6602709 ], [ 59.80806034, 22.53361197 ], [ 59.80614831, 22.31052481 ], [ 59.4421912, 21.71454051 ], [ 59.28240767, 21.43388581 ], [ 58.86114139, 21.11403453 ] ] ], [ [ [ 56.39142134, 25.89599071 ], [ 56.2610417, 25.71460643 ], [ 56.07082075, 26.05546418 ], [ 56.36201745, 26.39593435 ], [ 56.48567915, 26.30911795 ], [ 56.39142134, 25.89599071 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Pakistan", "sov_a3": "PAK", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Pakistan", "adm0_a3": "PAK", "geou_dif": 0.000000, "geounit": "Pakistan", "gu_a3": "PAK", "su_dif": 0.000000, "subunit": "Pakistan", "su_a3": "PAK", "brk_diff": 0.000000, "name": "Pakistan", "name_long": "Pakistan", "brk_a3": "PAK", "brk_name": "Pakistan", "brk_group": null, "abbrev": "Pak.", "postal": "PK", "formal_en": "Islamic Republic of Pakistan", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Pakistan", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 2.000000, "mapcolor9": 3.000000, "mapcolor13": 11.000000, "pop_est": 176242949.000000, "gdp_md_est": 427300.000000, "pop_year": -99.000000, "lastcensus": 1998.000000, "gdp_year": -99.000000, "economy": "5. Emerging region: G20", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "PK", "iso_a3": "PAK", "iso_n3": "586", "un_a3": "586", "wb_a2": "PK", "wb_a3": "PAK", "woe_id": -99.000000, "adm0_a3_is": "PAK", "adm0_a3_us": "PAK", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Southern Asia", "region_wb": "South Asia", "name_len": 8.000000, "long_len": 8.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 77.8374508, 35.49400951 ], [ 76.87172163, 34.65354401 ], [ 75.75706099, 34.50492259 ], [ 74.24020267, 34.74888703 ], [ 73.74994836, 34.31769888 ], [ 74.10429365, 33.44147329 ], [ 74.45155928, 32.7648996 ], [ 75.2586418, 32.27110546 ], [ 74.40592899, 31.69263947 ], [ 74.42138024, 30.97981476 ], [ 73.45063846, 29.97641348 ], [ 72.82375166, 28.9615917 ], [ 71.77766564, 27.91318024 ], [ 70.61649621, 27.98919628 ], [ 69.51439294, 26.94096568 ], [ 70.16892663, 26.49187165 ], [ 70.28287316, 25.72222871 ], [ 70.84469933, 25.21510204 ], [ 71.04324019, 24.35652395 ], [ 68.84259932, 24.35913361 ], [ 68.17664514, 23.69196503 ], [ 67.44366662, 23.94484365 ], [ 67.14544193, 24.66361115 ], [ 66.37282759, 25.4251409 ], [ 64.53040775, 25.23703868 ], [ 62.90570072, 25.21840933 ], [ 61.49736291, 25.07823701 ], [ 61.87418745, 26.23997488 ], [ 63.31663171, 26.7565325 ], [ 63.23389774, 27.21704702 ], [ 62.75542565, 27.37892345 ], [ 62.72783044, 28.25964488 ], [ 61.77186812, 28.69933381 ], [ 61.36930871, 29.30327627 ], [ 60.87424849, 29.829239 ], [ 62.54985681, 29.3185725 ], [ 63.55026086, 29.4683308 ], [ 64.14800215, 29.3408192 ], [ 64.35041874, 29.56003063 ], [ 65.04686201, 29.47218069 ], [ 66.34647261, 29.88794343 ], [ 66.38145755, 30.73889924 ], [ 66.93889123, 31.3049112 ], [ 67.68339359, 31.3031542 ], [ 67.79268924, 31.58293041 ], [ 68.556932, 31.71331004 ], [ 68.92667687, 31.62018911 ], [ 69.31776411, 31.90141226 ], [ 69.26252201, 32.50194408 ], [ 69.68714725, 33.10549897 ], [ 70.32359419, 33.35853262 ], [ 69.93054325, 34.02012014 ], [ 70.88180301, 33.9888559 ], [ 71.15677331, 34.34891144 ], [ 71.11501875, 34.73312572 ], [ 71.61307621, 35.15320344 ], [ 71.49876794, 35.65056326 ], [ 71.26234826, 36.07438752 ], [ 71.84629195, 36.50994233 ], [ 72.92002486, 36.72000703 ], [ 74.06755171, 36.83617565 ], [ 74.57589278, 37.02084138 ], [ 75.15802779, 37.13303091 ], [ 75.89689741, 36.66680614 ], [ 76.19284834, 35.89840343 ], [ 77.8374508, 35.49400951 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Panama", "sov_a3": "PAN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Panama", "adm0_a3": "PAN", "geou_dif": 0.000000, "geounit": "Panama", "gu_a3": "PAN", "su_dif": 0.000000, "subunit": "Panama", "su_a3": "PAN", "brk_diff": 0.000000, "name": "Panama", "name_long": "Panama", "brk_a3": "PAN", "brk_name": "Panama", "brk_group": null, "abbrev": "Pan.", "postal": "PA", "formal_en": "Republic of Panama", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Panama", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 4.000000, "mapcolor9": 6.000000, "mapcolor13": 3.000000, "pop_est": 3360474.000000, "gdp_md_est": 38830.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "PA", "iso_a3": "PAN", "iso_n3": "591", "un_a3": "591", "wb_a2": "PA", "wb_a3": "PAN", "woe_id": -99.000000, "adm0_a3_is": "PAN", "adm0_a3_us": "PAN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "North America", "region_un": "Americas", "subregion": "Central America", "region_wb": "Latin America & Caribbean", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -77.35336077, 8.67050467 ], [ -77.47472287, 8.5242862 ], [ -77.24256649, 7.93527823 ], [ -77.43110796, 7.63806122 ], [ -77.75341387, 7.70983979 ], [ -77.88157142, 7.22377127 ], [ -78.21493608, 7.51225495 ], [ -78.42916073, 8.05204112 ], [ -78.18209571, 8.31918244 ], [ -78.43546526, 8.38770539 ], [ -78.62212053, 8.7181245 ], [ -79.12030718, 8.99609203 ], [ -79.55787737, 8.93237499 ], [ -79.76057817, 8.58451508 ], [ -80.16448117, 8.33331594 ], [ -80.38265906, 8.29840851 ], [ -80.48068926, 8.09030752 ], [ -80.00368995, 7.54752412 ], [ -80.2766707, 7.41975414 ], [ -80.42115801, 7.27157197 ], [ -80.88640093, 7.22054149 ], [ -81.05954281, 7.81792105 ], [ -81.18971575, 7.64790559 ], [ -81.51951474, 7.70661001 ], [ -81.7213112, 8.10896271 ], [ -82.13144121, 8.17539277 ], [ -82.39093441, 8.29236237 ], [ -82.82008135, 8.29086376 ], [ -82.85095801, 8.07382274 ], [ -82.96578305, 8.22502798 ], [ -82.91317644, 8.42351716 ], [ -82.82977068, 8.62629548 ], [ -82.86865719, 8.80726634 ], [ -82.71918311, 8.92570873 ], [ -82.92715491, 9.07433015 ], [ -82.932891, 9.47681204 ], [ -82.54619626, 9.56613475 ], [ -82.18712257, 9.20744864 ], [ -82.20758643, 8.99557526 ], [ -81.80856686, 8.95061677 ], [ -81.71415402, 9.03195547 ], [ -81.43928708, 8.78623404 ], [ -80.9473016, 8.85850353 ], [ -80.52190121, 9.11107209 ], [ -79.91459978, 9.3127652 ], [ -79.57330278, 9.61161001 ], [ -79.02119178, 9.55293142 ], [ -79.05845049, 9.45456533 ], [ -78.50088762, 9.42045889 ], [ -78.0559277, 9.24773041 ], [ -77.72951352, 8.94684439 ], [ -77.35336077, 8.67050467 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Peru", "sov_a3": "PER", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Peru", "adm0_a3": "PER", "geou_dif": 0.000000, "geounit": "Peru", "gu_a3": "PER", "su_dif": 0.000000, "subunit": "Peru", "su_a3": "PER", "brk_diff": 0.000000, "name": "Peru", "name_long": "Peru", "brk_a3": "PER", "brk_name": "Peru", "brk_group": null, "abbrev": "Peru", "postal": "PE", "formal_en": "Republic of Peru", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Peru", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 4.000000, "mapcolor9": 4.000000, "mapcolor13": 11.000000, "pop_est": 29546963.000000, "gdp_md_est": 247300.000000, "pop_year": -99.000000, "lastcensus": 2007.000000, "gdp_year": -99.000000, "economy": "5. Emerging region: G20", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "PE", "iso_a3": "PER", "iso_n3": "604", "un_a3": "604", "wb_a2": "PE", "wb_a3": "PER", "woe_id": -99.000000, "adm0_a3_is": "PER", "adm0_a3_us": "PER", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "South America", "region_un": "Americas", "subregion": "South America", "region_wb": "Latin America & Caribbean", "name_len": 4.000000, "long_len": 4.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -69.89363522, -4.29818694 ], [ -70.79476885, -4.25126474 ], [ -70.92884335, -4.40159149 ], [ -71.74840573, -4.59398284 ], [ -72.89192766, -5.27456146 ], [ -72.96450721, -5.74125132 ], [ -73.21971127, -6.08918873 ], [ -73.12002743, -6.62993092 ], [ -73.72448666, -6.91859547 ], [ -73.72340146, -7.34099863 ], [ -73.98723548, -7.52382985 ], [ -73.57105933, -8.42444671 ], [ -73.01538266, -9.03283335 ], [ -73.22671343, -9.46221282 ], [ -72.56303301, -9.52019378 ], [ -72.18489071, -10.05359791 ], [ -71.30241228, -10.07943613 ], [ -70.48189389, -9.4901181 ], [ -70.54868568, -11.00914682 ], [ -70.0937522, -11.12397186 ], [ -69.52967811, -10.95173431 ], [ -68.66507972, -12.56130014 ], [ -68.88007952, -12.8997291 ], [ -68.9292238, -13.60268361 ], [ -68.94888668, -14.45363942 ], [ -69.33953467, -14.95319549 ], [ -69.16034665, -15.32397389 ], [ -69.38976417, -15.66012908 ], [ -68.95963538, -16.50069793 ], [ -69.59042375, -17.5800119 ], [ -69.85844357, -18.09269378 ], [ -70.37257239, -18.34797536 ], [ -71.37525021, -17.77379852 ], [ -71.46204078, -17.36348764 ], [ -73.44452959, -16.35936289 ], [ -75.23788266, -15.26568288 ], [ -76.00920508, -14.64928639 ], [ -76.4234692, -13.82318694 ], [ -76.2592415, -13.53503916 ], [ -77.10619239, -12.22271616 ], [ -78.09215288, -10.3777125 ], [ -79.03695309, -8.38656788 ], [ -79.44592038, -7.93083343 ], [ -79.76057817, -7.19434092 ], [ -80.53748166, -6.54166758 ], [ -81.2499963, -6.13683441 ], [ -80.92634681, -5.69055674 ], [ -81.41094255, -4.73676483 ], [ -81.09966956, -4.03639414 ], [ -80.30256059, -3.40485646 ], [ -80.18401486, -3.8211618 ], [ -80.4692946, -4.0592868 ], [ -80.44224199, -4.42572438 ], [ -80.02890805, -4.346091 ], [ -79.62497921, -4.45419809 ], [ -79.20528907, -4.95912851 ], [ -78.63989722, -4.54778411 ], [ -78.45068397, -3.87309661 ], [ -77.83790483, -3.00302052 ], [ -76.63539425, -2.60867767 ], [ -75.54499569, -1.5616098 ], [ -75.2337227, -0.91141692 ], [ -75.37322323, -0.15203175 ], [ -75.10662452, -0.0572055 ], [ -74.44160051, -0.53082 ], [ -74.12239519, -1.00283253 ], [ -73.65950355, -1.26049122 ], [ -73.07039222, -2.30895436 ], [ -72.32578651, -2.43421803 ], [ -71.77476071, -2.16978973 ], [ -71.4136458, -2.34280242 ], [ -70.81347571, -2.25686452 ], [ -70.0477085, -2.72515635 ], [ -70.69268205, -3.742872 ], [ -70.39404395, -3.76659149 ], [ -69.89363522, -4.29818694 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Philippines", "sov_a3": "PHL", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Philippines", "adm0_a3": "PHL", "geou_dif": 0.000000, "geounit": "Philippines", "gu_a3": "PHL", "su_dif": 0.000000, "subunit": "Philippines", "su_a3": "PHL", "brk_diff": 0.000000, "name": "Philippines", "name_long": "Philippines", "brk_a3": "PHL", "brk_name": "Philippines", "brk_group": null, "abbrev": "Phil.", "postal": "PH", "formal_en": "Republic of the Philippines", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Philippines", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 2.000000, "mapcolor9": 2.000000, "mapcolor13": 8.000000, "pop_est": 97976603.000000, "gdp_md_est": 317500.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "5. Emerging region: G20", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "PH", "iso_a3": "PHL", "iso_n3": "608", "un_a3": "608", "wb_a2": "PH", "wb_a3": "PHL", "woe_id": -99.000000, "adm0_a3_is": "PHL", "adm0_a3_us": "PHL", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "South-Eastern Asia", "region_wb": "East Asia & Pacific", "name_len": 11.000000, "long_len": 11.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 126.37681359, 8.41470633 ], [ 126.47851281, 7.75035411 ], [ 126.53742394, 7.1893806 ], [ 126.1967729, 6.27429434 ], [ 125.83142053, 7.29371532 ], [ 125.36385217, 6.7864853 ], [ 125.68316084, 6.04965689 ], [ 125.39651167, 5.58100332 ], [ 124.21978763, 6.1613555 ], [ 123.93871952, 6.88513561 ], [ 124.24366214, 7.36061046 ], [ 123.61021244, 7.83352733 ], [ 123.29607141, 7.41887564 ], [ 122.82550581, 7.45737458 ], [ 122.0854993, 6.89942414 ], [ 121.91992801, 7.19211945 ], [ 122.31235884, 8.03496206 ], [ 122.9423979, 8.31623688 ], [ 123.48768762, 8.69300975 ], [ 123.84115441, 8.2403242 ], [ 124.60146976, 8.51415762 ], [ 124.76461226, 8.96040945 ], [ 125.47139082, 8.98699698 ], [ 125.41211795, 9.76033478 ], [ 126.22271447, 9.28607433 ], [ 126.306637, 8.78248749 ], [ 126.37681359, 8.41470633 ] ] ], [ [ [ 123.98243778, 10.27877859 ], [ 123.62318322, 9.95009064 ], [ 123.30992069, 9.31826874 ], [ 122.99588301, 9.02218863 ], [ 122.38005497, 9.71336091 ], [ 122.5860889, 9.98104483 ], [ 122.83708133, 10.26115693 ], [ 122.94741052, 10.88186839 ], [ 123.49884973, 10.9406245 ], [ 123.33777429, 10.26738394 ], [ 124.07793583, 11.23272553 ], [ 123.98243778, 10.27877859 ] ] ], [ [ [ 118.50458093, 9.31638255 ], [ 117.17427453, 8.3674999 ], [ 117.66447717, 9.06688874 ], [ 118.38691369, 9.68449962 ], [ 118.98734216, 10.37629202 ], [ 119.51149621, 11.36966808 ], [ 119.68967655, 10.55429149 ], [ 119.02945845, 10.00365327 ], [ 118.50458093, 9.31638255 ] ] ], [ [ [ 121.8835478, 11.89175507 ], [ 122.48382124, 11.5821874 ], [ 123.12021651, 11.58366018 ], [ 123.10083784, 11.16593374 ], [ 122.63771366, 10.7413085 ], [ 122.0026103, 10.44101675 ], [ 121.96736698, 10.90569123 ], [ 122.0383704, 11.41584097 ], [ 121.8835478, 11.89175507 ] ] ], [ [ [ 125.50255171, 12.16269461 ], [ 125.7834648, 11.04612193 ], [ 125.01188399, 11.31145458 ], [ 125.03276127, 10.97581615 ], [ 125.27744917, 10.35872203 ], [ 124.80181929, 10.13467886 ], [ 124.76016808, 10.8379951 ], [ 124.45910119, 10.88992992 ], [ 124.3025216, 11.495371 ], [ 124.89101281, 11.41558259 ], [ 124.87799035, 11.79418997 ], [ 124.26676151, 12.55776093 ], [ 125.22711633, 12.53572093 ], [ 125.50255171, 12.16269461 ] ] ], [ [ [ 121.52739383, 13.06959016 ], [ 121.26219038, 12.20556021 ], [ 120.83389611, 12.70449616 ], [ 120.32343631, 13.46641348 ], [ 121.18012821, 13.42969737 ], [ 121.52739383, 13.06959016 ] ] ], [ [ [ 121.32130822, 18.50406464 ], [ 121.93760135, 18.21855235 ], [ 122.2460063, 18.4789499 ], [ 122.33695682, 18.22488272 ], [ 122.17427941, 17.8102827 ], [ 122.51565392, 17.09350475 ], [ 122.25231083, 16.26244436 ], [ 121.66278609, 15.93101756 ], [ 121.50506961, 15.12481354 ], [ 121.72882857, 14.32837637 ], [ 122.25892541, 14.21820222 ], [ 122.70127567, 14.33654125 ], [ 123.95029504, 13.78213064 ], [ 123.85510705, 13.2377711 ], [ 124.18128869, 12.99752737 ], [ 124.07741906, 12.53667695 ], [ 123.29803511, 13.02752554 ], [ 122.92865197, 13.55291983 ], [ 122.67135502, 13.18583629 ], [ 122.03464969, 13.78448192 ], [ 121.12638472, 13.63668732 ], [ 120.62863732, 13.85765575 ], [ 120.67938358, 14.27101553 ], [ 120.99181929, 14.52539277 ], [ 120.69333622, 14.75667064 ], [ 120.56414514, 14.3962792 ], [ 120.0704285, 14.97086945 ], [ 119.92092858, 15.40634675 ], [ 119.88377323, 16.36370433 ], [ 120.28648766, 16.03462881 ], [ 120.39004724, 17.59908112 ], [ 120.71586714, 18.50522736 ], [ 121.32130822, 18.50406464 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Papua New Guinea", "sov_a3": "PNG", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Papua New Guinea", "adm0_a3": "PNG", "geou_dif": 0.000000, "geounit": "Papua New Guinea", "gu_a3": "PNG", "su_dif": 1.000000, "subunit": "Papua New Guinea", "su_a3": "PN1", "brk_diff": 0.000000, "name": "Papua New Guinea", "name_long": "Papua New Guinea", "brk_a3": "PN1", "brk_name": "Papua New Guinea", "brk_group": null, "abbrev": "P.N.G.", "postal": "PG", "formal_en": "Independent State of Papua New Guinea", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Papua New Guinea", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 2.000000, "mapcolor9": 3.000000, "mapcolor13": 1.000000, "pop_est": 6057263.000000, "gdp_md_est": 13210.000000, "pop_year": -99.000000, "lastcensus": 2000.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "PG", "iso_a3": "PNG", "iso_n3": "598", "un_a3": "598", "wb_a2": "PG", "wb_a3": "PNG", "woe_id": -99.000000, "adm0_a3_is": "PNG", "adm0_a3_us": "PNG", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Oceania", "region_un": "Oceania", "subregion": "Melanesia", "region_wb": "East Asia & Pacific", "name_len": 16.000000, "long_len": 16.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 155.88002567, -6.81999684 ], [ 155.59999108, -6.91999074 ], [ 155.16699426, -6.53593149 ], [ 154.72919152, -5.90082814 ], [ 154.51411421, -5.13911753 ], [ 154.6525037, -5.04243092 ], [ 154.75999068, -5.33998382 ], [ 155.06291792, -5.56679168 ], [ 155.54774621, -6.2006548 ], [ 156.01996545, -6.54001393 ], [ 155.88002567, -6.81999684 ] ] ], [ [ [ 151.98279585, -5.47806325 ], [ 151.45910689, -5.56028045 ], [ 151.30139042, -5.84072845 ], [ 150.75444706, -6.08376271 ], [ 150.24119673, -6.31775359 ], [ 149.70996301, -6.31651336 ], [ 148.89006473, -6.02604013 ], [ 148.3189368, -5.74714243 ], [ 148.4018258, -5.43775563 ], [ 149.2984119, -5.58374155 ], [ 149.84556197, -5.50550343 ], [ 149.99625044, -5.02610117 ], [ 150.13975589, -5.00134816 ], [ 150.23690759, -5.53222015 ], [ 150.80746708, -5.45584238 ], [ 151.08967207, -5.11369272 ], [ 151.64788089, -4.75707366 ], [ 151.53786177, -4.16780731 ], [ 152.13679162, -4.14879038 ], [ 152.33874312, -4.3129664 ], [ 152.31869266, -4.86766123 ], [ 151.98279585, -5.47806325 ] ] ], [ [ [ 147.19187381, -7.38802418 ], [ 148.08463586, -8.04410817 ], [ 148.73410526, -9.10466359 ], [ 149.30683516, -9.07143564 ], [ 149.26663089, -9.51440602 ], [ 150.03872847, -9.68431813 ], [ 149.73879846, -9.87293711 ], [ 150.80162764, -10.29368662 ], [ 150.69057499, -10.5827129 ], [ 150.02839318, -10.65247609 ], [ 149.78231001, -10.3932671 ], [ 148.92313765, -10.28092254 ], [ 147.91301843, -10.13044077 ], [ 147.13544315, -9.49244354 ], [ 146.56788089, -8.94255462 ], [ 146.04848107, -8.06741424 ], [ 144.74416792, -7.63012827 ], [ 143.89708784, -7.9153305 ], [ 143.28637577, -8.24549122 ], [ 143.4139132, -8.98306894 ], [ 142.62843143, -9.32682057 ], [ 142.06825891, -9.15959564 ], [ 141.03385176, -9.11789275 ], [ 141.01705692, -5.85902191 ], [ 141.0002104, -2.60015106 ], [ 142.73524662, -3.28915293 ], [ 144.58397098, -3.86141774 ], [ 145.27317956, -4.37373789 ], [ 145.82978641, -4.8764979 ], [ 145.98192183, -5.46560923 ], [ 147.64807336, -6.08365936 ], [ 147.89110762, -6.61401458 ], [ 146.97090539, -6.72165659 ], [ 147.19187381, -7.38802418 ] ] ], [ [ [ 153.14003788, -4.49998341 ], [ 152.82729211, -4.7664271 ], [ 152.63867313, -4.17612721 ], [ 152.40602583, -3.78974253 ], [ 151.95323693, -3.46206227 ], [ 151.38427941, -3.03542164 ], [ 150.6620496, -2.7414861 ], [ 150.93996545, -2.50000213 ], [ 151.47998417, -2.77998504 ], [ 151.82001509, -2.99997161 ], [ 152.23998946, -3.24000864 ], [ 152.64001672, -3.65998301 ], [ 153.01999352, -3.98001515 ], [ 153.14003788, -4.49998341 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Poland", "sov_a3": "POL", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Poland", "adm0_a3": "POL", "geou_dif": 0.000000, "geounit": "Poland", "gu_a3": "POL", "su_dif": 0.000000, "subunit": "Poland", "su_a3": "POL", "brk_diff": 0.000000, "name": "Poland", "name_long": "Poland", "brk_a3": "POL", "brk_name": "Poland", "brk_group": null, "abbrev": "Pol.", "postal": "PL", "formal_en": "Republic of Poland", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Poland", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 7.000000, "mapcolor9": 1.000000, "mapcolor13": 2.000000, "pop_est": 38482919.000000, "gdp_md_est": 667900.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "PL", "iso_a3": "POL", "iso_n3": "616", "un_a3": "616", "wb_a2": "PL", "wb_a3": "POL", "woe_id": -99.000000, "adm0_a3_is": "POL", "adm0_a3_us": "POL", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Eastern Europe", "region_wb": "Europe & Central Asia", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 19.66064009, 54.42608389 ], [ 20.8922445, 54.31252493 ], [ 22.73109867, 54.32753693 ], [ 23.24398726, 54.22056672 ], [ 23.48412764, 53.91249767 ], [ 23.52753584, 53.47012157 ], [ 23.80493493, 53.08973135 ], [ 23.79919885, 52.69109935 ], [ 23.19949385, 52.48697744 ], [ 23.50800215, 52.02364655 ], [ 23.52707075, 51.57845409 ], [ 24.02998579, 50.7054066 ], [ 23.9227572, 50.42488109 ], [ 23.42650842, 50.30850576 ], [ 22.51845015, 49.47677359 ], [ 22.7764189, 49.02739533 ], [ 22.55813765, 49.08573802 ], [ 21.60780806, 49.47010733 ], [ 20.88795536, 49.32877228 ], [ 20.41583947, 49.43145336 ], [ 19.82502282, 49.21712535 ], [ 19.32071252, 49.571574 ], [ 18.90957482, 49.43584585 ], [ 18.85314416, 49.49622976 ], [ 18.39291385, 49.98862865 ], [ 17.64944502, 50.0490384 ], [ 17.55456709, 50.3621459 ], [ 16.86876916, 50.4739737 ], [ 16.71947595, 50.21574657 ], [ 16.17625329, 50.42260733 ], [ 16.23862674, 50.69773265 ], [ 15.49097212, 50.78472993 ], [ 15.01699588, 51.1066741 ], [ 14.60709842, 51.7451881 ], [ 14.68502648, 52.08994741 ], [ 14.43759973, 52.62485017 ], [ 14.07452111, 52.98126252 ], [ 14.35331546, 53.24817129 ], [ 14.11968631, 53.75702912 ], [ 14.80290042, 54.05070629 ], [ 16.363477, 54.51315868 ], [ 17.62283166, 54.85153596 ], [ 18.6208586, 54.6826057 ], [ 18.69625451, 54.43871878 ], [ 19.66064009, 54.42608389 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "United States of America", "sov_a3": "US1", "adm0_dif": 1.000000, "level": 2.000000, "type": "Dependency", "admin": "Puerto Rico", "adm0_a3": "PRI", "geou_dif": 0.000000, "geounit": "Puerto Rico", "gu_a3": "PRI", "su_dif": 0.000000, "subunit": "Puerto Rico", "su_a3": "PRI", "brk_diff": 0.000000, "name": "Puerto Rico", "name_long": "Puerto Rico", "brk_a3": "PRI", "brk_name": "Puerto Rico", "brk_group": null, "abbrev": "P.R.", "postal": "PR", "formal_en": "Commonwealth of Puerto Rico", "formal_fr": null, "note_adm0": "Commonwealth of U.S.A.", "note_brk": null, "name_sort": "Puerto Rico", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 5.000000, "mapcolor9": 1.000000, "mapcolor13": 1.000000, "pop_est": 3971020.000000, "gdp_md_est": 70230.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "2. High income: nonOECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "PR", "iso_a3": "PRI", "iso_n3": "630", "un_a3": "630", "wb_a2": "PR", "wb_a3": "PRI", "woe_id": -99.000000, "adm0_a3_is": "PRI", "adm0_a3_us": "PRI", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "North America", "region_un": "Americas", "subregion": "Caribbean", "region_wb": "Latin America & Caribbean", "name_len": 11.000000, "long_len": 11.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": -99.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -65.59100379, 18.22803498 ], [ -65.84716387, 17.97590567 ], [ -66.59993446, 17.98182262 ], [ -67.18416236, 17.94655345 ], [ -67.24242754, 18.37446015 ], [ -67.10067908, 18.5206011 ], [ -66.28243446, 18.51476166 ], [ -65.77130286, 18.42667919 ], [ -65.59100379, 18.22803498 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "North Korea", "sov_a3": "PRK", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "North Korea", "adm0_a3": "PRK", "geou_dif": 0.000000, "geounit": "North Korea", "gu_a3": "PRK", "su_dif": 0.000000, "subunit": "North Korea", "su_a3": "PRK", "brk_diff": 0.000000, "name": "Dem. Rep. Korea", "name_long": "Dem. Rep. Korea", "brk_a3": "PRK", "brk_name": "Dem. Rep. Korea", "brk_group": null, "abbrev": "N.K.", "postal": "KP", "formal_en": "Democratic People's Republic of Korea", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Korea, Dem. Rep.", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 5.000000, "mapcolor9": 3.000000, "mapcolor13": 9.000000, "pop_est": 22665345.000000, "gdp_md_est": 40000.000000, "pop_year": -99.000000, "lastcensus": 2009.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "KP", "iso_a3": "PRK", "iso_n3": "408", "un_a3": "408", "wb_a2": "KP", "wb_a3": "PRK", "woe_id": -99.000000, "adm0_a3_is": "PRK", "adm0_a3_us": "PRK", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Eastern Asia", "region_wb": "East Asia & Pacific", "name_len": 15.000000, "long_len": 15.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 130.6400159, 42.39500947 ], [ 130.78000485, 42.22001036 ], [ 130.78000736, 42.22000723 ], [ 130.78000366, 42.22000781 ], [ 130.77999232, 42.2200096 ], [ 130.40003055, 42.28000357 ], [ 129.96594852, 41.94136791 ], [ 129.6673621, 41.60110444 ], [ 129.70518924, 40.88282787 ], [ 129.18811486, 40.66180777 ], [ 129.01039961, 40.4854361 ], [ 128.63336836, 40.18984691 ], [ 127.96741418, 40.0254125 ], [ 127.5334355, 39.75685008 ], [ 127.50211958, 39.32393077 ], [ 127.3854342, 39.2134724 ], [ 127.78334273, 39.05089834 ], [ 128.34971642, 38.61224295 ], [ 128.20574588, 38.37039724 ], [ 127.78003544, 38.30453563 ], [ 127.07330855, 38.25611481 ], [ 126.68371992, 37.80477285 ], [ 126.2373389, 37.84037792 ], [ 126.17475874, 37.74968578 ], [ 125.68910363, 37.94001008 ], [ 125.56843916, 37.75208873 ], [ 125.27533044, 37.66907054 ], [ 125.24008711, 37.85722443 ], [ 124.98103316, 37.94882091 ], [ 124.71216068, 38.10834606 ], [ 124.98599409, 38.54847423 ], [ 125.22194868, 38.66585725 ], [ 125.13285851, 38.84855927 ], [ 125.3865898, 39.38795787 ], [ 125.32111576, 39.55138459 ], [ 124.73748213, 39.66034435 ], [ 124.26562463, 39.92849335 ], [ 125.07994185, 40.56982372 ], [ 126.18204512, 41.10733613 ], [ 126.86908329, 41.81656932 ], [ 127.34378299, 41.50315176 ], [ 128.20843306, 41.46677155 ], [ 128.0522152, 41.99428457 ], [ 129.59666874, 42.4249818 ], [ 129.99426721, 42.98538687 ], [ 130.63999971, 42.39502428 ], [ 130.6400159, 42.39500947 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Portugal", "sov_a3": "PRT", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Portugal", "adm0_a3": "PRT", "geou_dif": 0.000000, "geounit": "Portugal", "gu_a3": "PRT", "su_dif": 1.000000, "subunit": "Portugal", "su_a3": "PR1", "brk_diff": 0.000000, "name": "Portugal", "name_long": "Portugal", "brk_a3": "PR1", "brk_name": "Portugal", "brk_group": null, "abbrev": "Port.", "postal": "P", "formal_en": "Portuguese Republic", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Portugal", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 7.000000, "mapcolor9": 1.000000, "mapcolor13": 4.000000, "pop_est": 10707924.000000, "gdp_md_est": 208627.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": 0.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "PT", "iso_a3": "PRT", "iso_n3": "620", "un_a3": "620", "wb_a2": "PT", "wb_a3": "PRT", "woe_id": -99.000000, "adm0_a3_is": "PRT", "adm0_a3_us": "PRT", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Southern Europe", "region_wb": "Europe & Central Asia", "name_len": 8.000000, "long_len": 8.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -7.45372555, 37.09778758 ], [ -7.85561317, 36.83826854 ], [ -8.38281613, 36.97888011 ], [ -8.89885698, 36.86880931 ], [ -8.74610145, 37.65134553 ], [ -8.83999752, 38.26624339 ], [ -9.28746375, 38.35848583 ], [ -9.5265706, 38.7374291 ], [ -9.4469889, 39.39206615 ], [ -9.04830522, 39.75509309 ], [ -8.97735348, 40.15930614 ], [ -8.76868405, 40.76063894 ], [ -8.79085324, 41.18433401 ], [ -8.99078935, 41.54345938 ], [ -9.03481767, 41.88057058 ], [ -8.67194577, 42.13468944 ], [ -8.26385698, 42.28046865 ], [ -8.01317461, 41.79088614 ], [ -7.42251299, 41.79207469 ], [ -7.25130897, 41.91834606 ], [ -6.66860552, 41.88338695 ], [ -6.38908769, 41.3818155 ], [ -6.85112667, 41.11108267 ], [ -6.86401994, 40.33087189 ], [ -7.02641313, 40.18452424 ], [ -7.06659156, 39.71189159 ], [ -7.49863237, 39.62957103 ], [ -7.09803667, 39.03007274 ], [ -7.37409217, 38.37305858 ], [ -7.02928118, 38.07576407 ], [ -7.16650794, 37.80389435 ], [ -7.53710548, 37.42890432 ], [ -7.45372555, 37.09778758 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Paraguay", "sov_a3": "PRY", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Paraguay", "adm0_a3": "PRY", "geou_dif": 0.000000, "geounit": "Paraguay", "gu_a3": "PRY", "su_dif": 0.000000, "subunit": "Paraguay", "su_a3": "PRY", "brk_diff": 0.000000, "name": "Paraguay", "name_long": "Paraguay", "brk_a3": "PRY", "brk_name": "Paraguay", "brk_group": null, "abbrev": "Para.", "postal": "PY", "formal_en": "Republic of Paraguay", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Paraguay", "name_alt": null, "mapcolor7": 6.000000, "mapcolor8": 3.000000, "mapcolor9": 6.000000, "mapcolor13": 2.000000, "pop_est": 6995655.000000, "gdp_md_est": 28890.000000, "pop_year": -99.000000, "lastcensus": 2002.000000, "gdp_year": -99.000000, "economy": "5. Emerging region: G20", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "PY", "iso_a3": "PRY", "iso_n3": "600", "un_a3": "600", "wb_a2": "PY", "wb_a3": "PRY", "woe_id": -99.000000, "adm0_a3_is": "PRY", "adm0_a3_us": "PRY", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "South America", "region_un": "Americas", "subregion": "South America", "region_wb": "Latin America & Caribbean", "name_len": 8.000000, "long_len": 8.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -58.16639238, -20.17670094 ], [ -57.870674, -20.73268768 ], [ -57.93715573, -22.09017588 ], [ -56.88150957, -22.28215382 ], [ -56.47331743, -22.08630014 ], [ -55.79795814, -22.35692962 ], [ -55.61068275, -22.6556194 ], [ -55.51763933, -23.57199757 ], [ -55.40074724, -23.95693532 ], [ -55.02790178, -24.0012737 ], [ -54.65283424, -23.83957814 ], [ -54.29295956, -24.02101409 ], [ -54.29347633, -24.57079966 ], [ -54.42894609, -25.16218475 ], [ -54.6252907, -25.73925547 ], [ -54.78879493, -26.62178558 ], [ -55.69584551, -27.38783701 ], [ -56.48670163, -27.54849904 ], [ -57.60975969, -27.39589853 ], [ -58.61817359, -27.12371876 ], [ -57.63366004, -25.60365651 ], [ -57.77721717, -25.16233978 ], [ -58.80712847, -24.77145924 ], [ -60.02896603, -24.03279632 ], [ -60.8465647, -23.88071258 ], [ -62.68505714, -22.24902923 ], [ -62.29117937, -21.05163462 ], [ -62.26596127, -20.51373463 ], [ -61.78632646, -19.63373667 ], [ -60.04356462, -19.34274668 ], [ -59.11504249, -19.35690602 ], [ -58.18347144, -19.86839935 ], [ -58.16639238, -20.17670094 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Israel", "sov_a3": "ISR", "adm0_dif": 1.000000, "level": 2.000000, "type": "Disputed", "admin": "Palestine", "adm0_a3": "PSX", "geou_dif": 0.000000, "geounit": "Palestine", "gu_a3": "PSX", "su_dif": 0.000000, "subunit": "Palestine", "su_a3": "PSX", "brk_diff": 0.000000, "name": "Palestine", "name_long": "Palestine", "brk_a3": "PSX", "brk_name": "Palestine", "brk_group": null, "abbrev": "Pal.", "postal": "PAL", "formal_en": "West Bank and Gaza", "formal_fr": null, "note_adm0": "Partial self-admin.", "note_brk": "Partial self-admin.", "name_sort": "Palestine (West Bank and Gaza)", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 2.000000, "mapcolor9": 5.000000, "mapcolor13": 8.000000, "pop_est": 4119083.000000, "gdp_md_est": 11950.770000, "pop_year": -99.000000, "lastcensus": 2007.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "PS", "iso_a3": "PSE", "iso_n3": "275", "un_a3": "275", "wb_a2": "GZ", "wb_a3": "WBG", "woe_id": -99.000000, "adm0_a3_is": "PSE", "adm0_a3_us": "PSX", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Western Asia", "region_wb": "Middle East & North Africa", "name_len": 9.000000, "long_len": 9.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": -99.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 35.54566532, 32.39399201 ], [ 35.54525191, 31.78250479 ], [ 35.39756066, 31.48908601 ], [ 34.92740848, 31.35343537 ], [ 34.97050663, 31.61677847 ], [ 35.22589155, 31.75434113 ], [ 34.97464074, 31.86658234 ], [ 35.18393029, 32.53251069 ], [ 35.54566532, 32.39399201 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Qatar", "sov_a3": "QAT", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Qatar", "adm0_a3": "QAT", "geou_dif": 0.000000, "geounit": "Qatar", "gu_a3": "QAT", "su_dif": 0.000000, "subunit": "Qatar", "su_a3": "QAT", "brk_diff": 0.000000, "name": "Qatar", "name_long": "Qatar", "brk_a3": "QAT", "brk_name": "Qatar", "brk_group": null, "abbrev": "Qatar", "postal": "QA", "formal_en": "State of Qatar", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Qatar", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 6.000000, "mapcolor9": 2.000000, "mapcolor13": 4.000000, "pop_est": 833285.000000, "gdp_md_est": 91330.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "2. High income: nonOECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "QA", "iso_a3": "QAT", "iso_n3": "634", "un_a3": "634", "wb_a2": "QA", "wb_a3": "QAT", "woe_id": -99.000000, "adm0_a3_is": "QAT", "adm0_a3_us": "QAT", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Western Asia", "region_wb": "Middle East & North Africa", "name_len": 5.000000, "long_len": 5.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 51.38960778, 24.62738597 ], [ 51.1124154, 24.55633088 ], [ 50.81010827, 24.75474254 ], [ 50.74391076, 25.48242422 ], [ 51.01335168, 26.00699169 ], [ 51.28646162, 26.11458202 ], [ 51.58907881, 25.80111278 ], [ 51.60670047, 25.21567048 ], [ 51.38960778, 24.62738597 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Romania", "sov_a3": "ROU", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Romania", "adm0_a3": "ROU", "geou_dif": 0.000000, "geounit": "Romania", "gu_a3": "ROU", "su_dif": 0.000000, "subunit": "Romania", "su_a3": "ROU", "brk_diff": 0.000000, "name": "Romania", "name_long": "Romania", "brk_a3": "ROU", "brk_name": "Romania", "brk_group": null, "abbrev": "Rom.", "postal": "RO", "formal_en": "Romania", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Romania", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 4.000000, "mapcolor9": 3.000000, "mapcolor13": 13.000000, "pop_est": 22215421.000000, "gdp_md_est": 271400.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "RO", "iso_a3": "ROU", "iso_n3": "642", "un_a3": "642", "wb_a2": "RO", "wb_a3": "ROM", "woe_id": -99.000000, "adm0_a3_is": "ROU", "adm0_a3_us": "ROU", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Eastern Europe", "region_wb": "Europe & Central Asia", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 26.61933679, 48.22072622 ], [ 26.92417606, 48.12326447 ], [ 27.23387292, 47.82677094 ], [ 27.55116621, 47.40511709 ], [ 28.12803023, 46.81047639 ], [ 28.16001794, 46.37156261 ], [ 28.05444299, 45.94458609 ], [ 28.2335535, 45.48828319 ], [ 28.67977949, 45.30403087 ], [ 29.14972497, 45.46492544 ], [ 29.60328902, 45.29330801 ], [ 29.62654341, 45.03539094 ], [ 29.14161177, 44.82021027 ], [ 28.8378577, 44.91387381 ], [ 28.5580815, 43.70746166 ], [ 27.97010705, 43.81246817 ], [ 27.24239953, 44.17598603 ], [ 26.06515873, 43.94349376 ], [ 25.56927168, 43.68844473 ], [ 24.10067915, 43.74105134 ], [ 23.33230228, 43.89701081 ], [ 22.94483239, 43.82378531 ], [ 22.65714969, 44.234923 ], [ 22.47400842, 44.40922761 ], [ 22.70572554, 44.57800283 ], [ 22.45902225, 44.7025172 ], [ 22.14508792, 44.47842235 ], [ 21.56202274, 44.76894725 ], [ 21.48352624, 45.18117015 ], [ 20.87431278, 45.41637543 ], [ 20.76217492, 45.73457307 ], [ 20.2201925, 46.12746898 ], [ 21.02195235, 46.31608796 ], [ 21.62651493, 46.99423778 ], [ 22.09976769, 47.67243928 ], [ 22.71053145, 47.88219392 ], [ 23.14223636, 48.09634105 ], [ 23.76095829, 47.98559846 ], [ 24.40205611, 47.98187775 ], [ 24.86631717, 47.73752574 ], [ 25.20774336, 47.89105642 ], [ 25.9459412, 47.98714875 ], [ 26.19745039, 48.22088125 ], [ 26.61933679, 48.22072622 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Russia", "sov_a3": "RUS", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Russia", "adm0_a3": "RUS", "geou_dif": 0.000000, "geounit": "Russia", "gu_a3": "RUS", "su_dif": 0.000000, "subunit": "Russia", "su_a3": "RUS", "brk_diff": 0.000000, "name": "Russia", "name_long": "Russian Federation", "brk_a3": "RUS", "brk_name": "Russia", "brk_group": null, "abbrev": "Rus.", "postal": "RUS", "formal_en": "Russian Federation", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Russian Federation", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 5.000000, "mapcolor9": 7.000000, "mapcolor13": 7.000000, "pop_est": 140041247.000000, "gdp_md_est": 2266000.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "3. Emerging region: BRIC", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "RU", "iso_a3": "RUS", "iso_n3": "643", "un_a3": "643", "wb_a2": "RU", "wb_a3": "RUS", "woe_id": -99.000000, "adm0_a3_is": "RUS", "adm0_a3_us": "RUS", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Eastern Europe", "region_wb": "Europe & Central Asia", "name_len": 6.000000, "long_len": 18.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 143.64800744, 50.74760041 ], [ 144.65414758, 48.97639069 ], [ 143.17392785, 49.30655142 ], [ 142.55866825, 47.86157502 ], [ 143.53349247, 46.83672801 ], [ 143.50527713, 46.13790762 ], [ 142.74770064, 46.74076488 ], [ 142.09203006, 45.96675528 ], [ 141.90692508, 46.80592886 ], [ 142.01844282, 47.78013296 ], [ 141.90444461, 48.85918854 ], [ 142.1358, 49.61516307 ], [ 142.17998335, 50.95234243 ], [ 141.59407596, 51.93543488 ], [ 141.68254601, 53.30196646 ], [ 142.60693404, 53.76214509 ], [ 142.20974898, 54.22547598 ], [ 142.65478641, 54.36588085 ], [ 142.91461551, 53.70457754 ], [ 143.26084761, 52.7407604 ], [ 143.23526778, 51.75666026 ], [ 143.64800744, 50.74760041 ] ] ], [ [ [ 22.73109867, 54.32753693 ], [ 20.8922445, 54.31252493 ], [ 19.66064009, 54.42608389 ], [ 19.88848148, 54.86616039 ], [ 21.26844893, 55.19048168 ], [ 22.3157235, 55.01529857 ], [ 22.75776371, 54.85657441 ], [ 22.65105187, 54.58274099 ], [ 22.73109867, 54.32753693 ] ] ], [ [ [ -175.01425, 66.58435 ], [ -174.33983, 66.33556 ], [ -174.57182, 67.06219 ], [ -171.85731, 66.91308 ], [ -169.89958, 65.97724 ], [ -170.89107, 65.54139 ], [ -172.53025, 65.43791 ], [ -172.555, 64.46079 ], [ -172.95533, 64.25269 ], [ -173.89184, 64.2826 ], [ -174.65392, 64.63125 ], [ -175.98353, 64.92288 ], [ -176.20716, 65.35667 ], [ -177.22266, 65.52024 ], [ -178.35993, 65.39052 ], [ -178.90332, 65.74044 ], [ -178.68611, 66.11211 ], [ -179.88377, 65.87456 ], [ -179.43268, 65.40411 ], [ -180.0, 64.9797087 ], [ -180.0, 68.96363636 ], [ -177.55, 68.2 ], [ -174.92825, 67.20589 ], [ -175.01425, 66.58435 ] ] ], [ [ [ 180.0, 70.83219921 ], [ 178.903425, 70.78114 ], [ 178.7253, 71.0988 ], [ 180.0, 71.51571434 ], [ 180.0, 70.83219921 ] ] ], [ [ [ -178.69378, 70.89302 ], [ -180.0, 70.83219921 ], [ -180.0, 71.51571434 ], [ -179.871875, 71.55762 ], [ -179.02433, 71.55553 ], [ -177.577945, 71.26948 ], [ -177.663575, 71.13277 ], [ -178.69378, 70.89302 ] ] ], [ [ [ 143.60385, 73.21244 ], [ 142.08763, 73.20544 ], [ 140.038155, 73.31692 ], [ 139.86312, 73.36983 ], [ 140.81171, 73.76506 ], [ 142.06207, 73.85758 ], [ 143.48283, 73.47525 ], [ 143.60385, 73.21244 ] ] ], [ [ [ 150.73167, 75.08406 ], [ 149.575925, 74.68892 ], [ 147.977465, 74.778355 ], [ 146.11919, 75.17298 ], [ 146.358485, 75.49682 ], [ 148.22223, 75.345845 ], [ 150.73167, 75.08406 ] ] ], [ [ [ 145.086285, 75.562625 ], [ 144.3, 74.82 ], [ 140.61381, 74.84768 ], [ 138.95544, 74.61148 ], [ 136.97439, 75.26167 ], [ 137.51176, 75.94917 ], [ 138.831075, 76.13676 ], [ 141.471615, 76.09289 ], [ 145.086285, 75.562625 ] ] ], [ [ [ 57.53569258, 70.72046398 ], [ 56.94497928, 70.63274323 ], [ 53.67737512, 70.76265778 ], [ 53.41201664, 71.20666169 ], [ 51.60189457, 71.47475902 ], [ 51.45575362, 72.01488109 ], [ 52.47827518, 72.22944164 ], [ 52.44416874, 72.77473135 ], [ 54.42761356, 73.62754751 ], [ 53.50828983, 73.74981395 ], [ 55.90245894, 74.62748648 ], [ 55.63193281, 75.08141226 ], [ 57.86864383, 75.60939037 ], [ 61.17004439, 76.25188345 ], [ 64.49836836, 76.43905549 ], [ 66.210977, 76.80978221 ], [ 68.15705977, 76.93969676 ], [ 68.85221113, 76.54481131 ], [ 68.18057254, 76.23364167 ], [ 64.63732629, 75.73775463 ], [ 61.58350752, 75.26088451 ], [ 58.47708215, 74.3090563 ], [ 56.98678552, 73.33304352 ], [ 55.41933597, 72.37126761 ], [ 55.62283776, 71.54059479 ], [ 57.53569258, 70.72046398 ] ] ], [ [ [ 106.97013, 76.97419 ], [ 107.24, 76.48 ], [ 108.1538, 76.72335 ], [ 111.07726, 76.71 ], [ 113.33151, 76.22224 ], [ 114.13417, 75.84764 ], [ 113.88539, 75.32779 ], [ 112.77918, 75.03186 ], [ 110.15125, 74.47673 ], [ 109.4, 74.18 ], [ 110.64, 74.04 ], [ 112.11919, 73.78774 ], [ 113.01954, 73.97693 ], [ 113.52958, 73.33505 ], [ 113.96881, 73.59488 ], [ 115.56782, 73.75285 ], [ 118.77633, 73.58772 ], [ 119.02, 73.12 ], [ 123.20066, 72.97122 ], [ 123.25777, 73.73503 ], [ 125.38, 73.56 ], [ 126.97644, 73.56549 ], [ 128.59126, 73.03871 ], [ 129.05157, 72.39872 ], [ 128.46, 71.98 ], [ 129.71599, 71.19304 ], [ 131.28858, 70.78699 ], [ 132.2535, 71.8363 ], [ 133.85766, 71.38642 ], [ 135.56193, 71.65525 ], [ 137.49755, 71.34763 ], [ 138.23409, 71.62803 ], [ 139.86983, 71.48783 ], [ 139.14791, 72.41619 ], [ 140.46817, 72.84941 ], [ 149.5, 72.2 ], [ 150.35118, 71.60643 ], [ 152.9689, 70.84222 ], [ 157.00688, 71.03141 ], [ 158.99779, 70.86672 ], [ 159.83031, 70.45324 ], [ 159.70866, 69.72198 ], [ 160.94053, 69.43728 ], [ 162.27907, 69.64204 ], [ 164.05248, 69.66823 ], [ 165.94037, 69.47199 ], [ 167.83567, 69.58269 ], [ 169.57763, 68.6938 ], [ 170.81688, 69.01363 ], [ 170.0082, 69.65276 ], [ 170.45345, 70.09703 ], [ 173.64391, 69.81743 ], [ 175.72403, 69.87725 ], [ 178.6, 69.4 ], [ 180.0, 68.96363636 ], [ 180.0, 64.9797087 ], [ 179.99281, 64.97433 ], [ 178.7072, 64.53493 ], [ 177.41128, 64.60821 ], [ 178.313, 64.07593 ], [ 178.90825, 63.25197 ], [ 179.37034, 62.98262 ], [ 179.48636, 62.56894 ], [ 179.22825, 62.3041 ], [ 177.3643, 62.5219 ], [ 174.56929, 61.76915 ], [ 173.68013, 61.65261 ], [ 172.15, 60.95 ], [ 170.6985, 60.33618 ], [ 170.33085, 59.88177 ], [ 168.90046, 60.57355 ], [ 166.29498, 59.78855 ], [ 165.84, 60.16 ], [ 164.87674, 59.7316 ], [ 163.53929, 59.86871 ], [ 163.21711, 59.21101 ], [ 162.01733, 58.24328 ], [ 162.05297, 57.83912 ], [ 163.19191, 57.61503 ], [ 163.05794, 56.15924 ], [ 162.12958, 56.12219 ], [ 161.70146, 55.28568 ], [ 162.11749, 54.85514 ], [ 160.36877, 54.34433 ], [ 160.02173, 53.20257 ], [ 158.53094, 52.95868 ], [ 158.23118, 51.94269 ], [ 156.78979, 51.01105 ], [ 156.42, 51.7 ], [ 155.99182, 53.15895 ], [ 155.43366, 55.38103 ], [ 155.91442, 56.76792 ], [ 156.75815, 57.3647 ], [ 156.81035, 57.83204 ], [ 158.36433, 58.05575 ], [ 160.15064, 59.31477 ], [ 161.87204, 60.343 ], [ 163.66969, 61.1409 ], [ 164.47355, 62.55061 ], [ 163.25842, 62.46627 ], [ 162.65791, 61.6425 ], [ 160.12148, 60.54423 ], [ 159.30232, 61.77396 ], [ 156.72068, 61.43442 ], [ 154.21806, 59.75818 ], [ 155.04375, 59.14495 ], [ 152.81185, 58.88385 ], [ 151.26573, 58.78089 ], [ 151.33815, 59.50396 ], [ 149.78371, 59.65573 ], [ 148.54481, 59.16448 ], [ 145.48722, 59.33637 ], [ 142.19782, 59.03998 ], [ 138.95848, 57.08805 ], [ 135.12619, 54.72959 ], [ 136.70171, 54.60355 ], [ 137.19342, 53.97732 ], [ 138.1647, 53.75501 ], [ 138.80463, 54.25455 ], [ 139.90151, 54.18968 ], [ 141.34531, 53.08957 ], [ 141.37923, 52.23877 ], [ 140.59742, 51.23967 ], [ 140.51308, 50.04553 ], [ 140.06193, 48.44671 ], [ 138.55472, 46.99965 ], [ 138.21971, 46.30795 ], [ 136.86232, 45.1435 ], [ 135.51535, 43.989 ], [ 134.86939, 43.39821 ], [ 133.53687, 42.81147 ], [ 132.90627, 42.79849 ], [ 132.27807, 43.28456 ], [ 130.93587, 42.55274 ], [ 130.78000485, 42.22001036 ], [ 130.78000366, 42.22000781 ], [ 130.78, 42.22 ], [ 130.77999232, 42.2200096 ], [ 130.64, 42.395 ], [ 130.63999971, 42.39502428 ], [ 130.63386641, 42.90301463 ], [ 131.14468794, 42.92998973 ], [ 131.28855513, 44.11151968 ], [ 131.02519, 44.96796 ], [ 131.88345422, 45.32116161 ], [ 133.09712, 45.14409 ], [ 133.769644, 46.11692699 ], [ 134.11235, 47.21248 ], [ 134.50081, 47.57845 ], [ 135.02631148, 48.47822989 ], [ 133.37359582, 48.18344168 ], [ 132.50669, 47.78896 ], [ 130.98726, 47.79013 ], [ 130.58229333, 48.7296874 ], [ 129.39781782, 49.44060008 ], [ 127.6574, 49.76027 ], [ 127.28745568, 50.73979727 ], [ 126.93915653, 51.35389415 ], [ 126.56439904, 51.78425548 ], [ 125.94634891, 52.79279857 ], [ 125.0682113, 53.16104483 ], [ 123.57147, 53.4588 ], [ 122.24574792, 53.43172598 ], [ 121.00308475, 53.25140107 ], [ 120.17708866, 52.75388622 ], [ 120.72578902, 52.5162263 ], [ 120.7382, 51.96411 ], [ 120.18208, 51.64355 ], [ 119.27939, 50.58292 ], [ 119.28846073, 50.1428828 ], [ 117.87924442, 49.51098338 ], [ 116.6788009, 49.8885314 ], [ 115.48569543, 49.80517731 ], [ 114.96210982, 50.1402473 ], [ 114.3624565, 50.24830272 ], [ 112.8977397, 49.54356538 ], [ 111.58123091, 49.37796825 ], [ 110.66201053, 49.13012808 ], [ 109.40244917, 49.29296052 ], [ 108.47516727, 49.28254772 ], [ 107.8681759, 49.79370515 ], [ 106.88880415, 50.27429597 ], [ 106.97013, 76.97419 ] ] ], [ [ [ 106.97013, 76.97419 ], [ 106.88880415, 50.27429597 ], [ 105.88659142, 50.40601919 ], [ 104.62158, 50.27532 ], [ 103.67654544, 50.08996613 ], [ 102.25589, 50.51056 ], [ 102.06521, 51.25991 ], [ 100.88948042, 51.51685578 ], [ 99.98173221, 51.63400625 ], [ 98.86149051, 52.04736603 ], [ 97.82573978, 51.01099518 ], [ 98.23176151, 50.42240062 ], [ 97.25976, 49.72605 ], [ 95.81402, 49.97746 ], [ 94.81594933, 50.01343334 ], [ 94.14756636, 50.48053661 ], [ 93.10421, 50.49529 ], [ 92.23471154, 50.80217072 ], [ 90.71366743, 50.33181184 ], [ 88.80556685, 49.47052074 ], [ 87.75126428, 49.29719798 ], [ 87.35997033, 49.21498078 ], [ 86.82935672, 49.82667471 ], [ 85.54126997, 49.69285859 ], [ 85.11555952, 50.11730296 ], [ 84.41637739, 50.31139964 ], [ 83.93511478, 50.88924551 ], [ 83.38300378, 51.06918285 ], [ 81.94598555, 50.81219595 ], [ 80.56844689, 51.38833649 ], [ 80.03555952, 50.86475088 ], [ 77.80091556, 53.40441498 ], [ 76.52517948, 54.17700349 ], [ 76.89110029, 54.4905244 ], [ 74.38482, 53.54685 ], [ 73.42567875, 53.48981029 ], [ 73.50851607, 54.03561677 ], [ 72.22415002, 54.37665538 ], [ 71.18013106, 54.13328522 ], [ 70.86526655, 55.16973359 ], [ 69.06816695, 55.38525015 ], [ 68.16910038, 54.97039175 ], [ 65.66687, 54.60125 ], [ 65.17853356, 54.35422781 ], [ 61.4366, 54.00625 ], [ 60.97806644, 53.66499339 ], [ 61.6999862, 52.97999645 ], [ 60.73999312, 52.71998648 ], [ 60.92726851, 52.44754833 ], [ 59.96753381, 51.96042044 ], [ 61.58800337, 51.2726588 ], [ 61.33742435, 50.79907014 ], [ 59.93280724, 50.84219412 ], [ 59.64228234, 50.54544221 ], [ 58.36332, 51.06364 ], [ 56.77798, 51.04355 ], [ 55.71694, 50.62171 ], [ 54.53287845, 51.02623973 ], [ 52.32872359, 51.71865225 ], [ 50.76664839, 51.69276236 ], [ 48.70238163, 50.60512849 ], [ 48.57784142, 49.87475963 ], [ 47.54948042, 50.45469839 ], [ 46.75159631, 49.35600576 ], [ 47.0436715, 49.15203889 ], [ 46.46644575, 48.39415233 ], [ 47.31524, 47.71585 ], [ 48.05725, 47.74377 ], [ 48.69473351, 47.07562816 ], [ 48.59325, 46.56104 ], [ 49.10116, 46.39933 ], [ 48.64541, 45.80629 ], [ 47.67591, 45.64149 ], [ 46.68201, 44.6092 ], [ 47.59094, 43.66016 ], [ 47.49252, 42.98658 ], [ 48.58437, 41.80888 ], [ 48.5843534, 41.80886879 ], [ 47.98728316, 41.4058192 ], [ 47.81566572, 41.15141612 ], [ 47.37331546, 41.21973237 ], [ 46.68607059, 41.82713715 ], [ 46.4049508, 41.86067516 ], [ 45.7764, 42.09244 ], [ 45.47027917, 42.50278067 ], [ 44.53762292, 42.7119927 ], [ 43.93121, 42.55496 ], [ 43.75599, 42.74083 ], [ 42.3944, 43.2203 ], [ 40.92219, 43.38215 ], [ 40.07696496, 43.55310415 ], [ 39.95500858, 43.43499767 ], [ 38.68, 44.28 ], [ 37.53912, 44.65721 ], [ 36.67546, 45.24469 ], [ 37.40317, 45.40451 ], [ 38.23295, 46.24087 ], [ 37.67372, 46.63657 ], [ 39.14767, 47.04475 ], [ 39.1212, 47.26336 ], [ 38.22353804, 47.10218985 ], [ 38.25511234, 47.54640046 ], [ 38.77057, 47.82562 ], [ 39.73827762, 47.89893708 ], [ 39.89562, 48.23241 ], [ 39.67465, 48.78382 ], [ 40.08078902, 49.30742992 ], [ 40.06904, 49.60105 ], [ 38.59498823, 49.9264619 ], [ 38.01063114, 49.91566153 ], [ 37.39345951, 50.38395336 ], [ 36.62616784, 50.22559093 ], [ 35.35611616, 50.57719737 ], [ 35.37791, 50.77394 ], [ 35.02218306, 51.20757233 ], [ 34.22481571, 51.25599315 ], [ 34.14197839, 51.56641348 ], [ 34.39173058, 51.76888174 ], [ 33.75269982, 52.33507457 ], [ 32.71576053, 52.23846548 ], [ 32.41205814, 52.28869497 ], [ 32.15944, 52.06125 ], [ 31.78599245, 52.10167757 ], [ 31.78597, 52.10168 ], [ 31.54001834, 52.74205231 ], [ 31.30520064, 53.07399588 ], [ 31.49764, 53.16743 ], [ 32.30451948, 53.13272614 ], [ 32.69364302, 53.3514208 ], [ 32.40559859, 53.61804536 ], [ 31.73127282, 53.79402945 ], [ 31.79142419, 53.97463858 ], [ 31.38447228, 54.15705638 ], [ 30.75753381, 54.81177094 ], [ 30.97183597, 55.08154776 ], [ 30.87390913, 55.55097647 ], [ 29.89629439, 55.7894632 ], [ 29.37157189, 55.67009064 ], [ 29.22951338, 55.91834422 ], [ 28.17670943, 56.16912995 ], [ 27.85528202, 56.75932648 ], [ 27.7700159, 57.24425812 ], [ 27.28818485, 57.47452831 ], [ 27.71668583, 57.79189912 ], [ 27.42015, 58.72457 ], [ 28.13169925, 59.3008251 ], [ 27.98112, 59.47537 ], [ 27.98112686, 59.47537333 ], [ 29.1177, 60.02805 ], [ 28.07000192, 60.50351913 ], [ 28.07, 60.50352 ], [ 30.21110721, 61.78002778 ], [ 31.13999108, 62.35769278 ], [ 31.51609216, 62.86768749 ], [ 30.03587243, 63.55281363 ], [ 30.44468469, 64.20445344 ], [ 29.54442956, 64.94867158 ], [ 30.21765, 65.80598 ], [ 29.05458866, 66.9442862 ], [ 29.97742639, 67.69829702 ], [ 28.44594364, 68.36461294 ], [ 28.59192956, 69.06477692 ], [ 29.39955, 69.15692 ], [ 31.1010422, 69.55810109 ], [ 31.10108, 69.55811 ], [ 32.13272, 69.90595 ], [ 33.77547, 69.30142 ], [ 36.51396, 69.06342 ], [ 40.29234, 67.9324 ], [ 41.05987, 67.45713 ], [ 41.12595, 66.79158 ], [ 40.01583, 66.26618 ], [ 38.38295, 65.99953 ], [ 33.91871, 66.75961 ], [ 33.18444, 66.63253 ], [ 34.81477, 65.90015 ], [ 34.87857425, 65.43621288 ], [ 34.94391, 64.41437 ], [ 36.23129, 64.10945 ], [ 37.01273, 63.84983 ], [ 37.14197, 64.33471 ], [ 36.53957904, 64.76446 ], [ 37.17604, 65.14322 ], [ 39.59345, 64.52079 ], [ 40.4356, 64.76446 ], [ 39.7626, 65.49682 ], [ 42.09309, 66.47623 ], [ 43.01604, 66.41858 ], [ 43.94975, 66.06908 ], [ 44.53226, 66.75634 ], [ 43.69839, 67.35245 ], [ 44.18795, 67.95051 ], [ 43.45282, 68.57079 ], [ 46.25, 68.25 ], [ 46.82134, 67.68997 ], [ 45.55517, 67.56652 ], [ 45.56202, 67.01005 ], [ 46.34915, 66.66767 ], [ 47.89416, 66.88455 ], [ 48.13876, 67.52238 ], [ 50.22766, 67.99867 ], [ 53.71743, 68.85738 ], [ 54.47171, 68.80815 ], [ 53.48582, 68.20131 ], [ 54.72628, 68.09702 ], [ 55.44268, 68.43866 ], [ 57.31702, 68.46628 ], [ 58.802, 68.88082 ], [ 59.94142, 68.27844 ], [ 61.07784, 68.94069 ], [ 60.03, 69.52 ], [ 60.55, 69.85 ], [ 63.504, 69.54739 ], [ 64.888115, 69.234835 ], [ 68.51216, 68.09233 ], [ 69.18068, 68.61563 ], [ 68.16444, 69.14436 ], [ 68.13522, 69.35649 ], [ 66.93008, 69.45461 ], [ 67.25976, 69.92873 ], [ 66.72492, 70.70889 ], [ 66.69466, 71.02897 ], [ 68.54006, 71.9345 ], [ 69.19636, 72.84336 ], [ 69.94, 73.04 ], [ 72.58754, 72.77629 ], [ 72.79603, 72.22006 ], [ 71.84811, 71.40898 ], [ 72.47011, 71.09019 ], [ 72.79188, 70.39114 ], [ 72.5647, 69.02085 ], [ 73.66787, 68.4079 ], [ 73.2387, 67.7404 ], [ 71.28, 66.32 ], [ 72.42301, 66.17267 ], [ 72.82077, 66.53267 ], [ 73.92099, 66.78946 ], [ 74.18651, 67.28429 ], [ 75.052, 67.76047 ], [ 74.46926, 68.32899 ], [ 74.93584, 68.98918 ], [ 73.84236, 69.07146 ], [ 73.60187, 69.62763 ], [ 74.3998, 70.63175 ], [ 73.1011, 71.44717 ], [ 74.89082, 72.12119 ], [ 74.65926, 72.83227 ], [ 75.15801, 72.85497 ], [ 75.68351, 72.30056 ], [ 75.28898, 71.33556 ], [ 76.35911, 71.15287 ], [ 75.90313, 71.87401 ], [ 77.57665, 72.26717 ], [ 79.65202, 72.32011 ], [ 81.5, 71.75 ], [ 80.61071, 72.58285 ], [ 80.51109, 73.6482 ], [ 82.25, 73.85 ], [ 84.65526, 73.80591 ], [ 86.8223, 73.93688 ], [ 86.00956, 74.45967 ], [ 87.16682, 75.11643 ], [ 88.31571, 75.14393 ], [ 90.26, 75.64 ], [ 92.90058, 75.77333 ], [ 93.23421, 76.0472 ], [ 95.86, 76.14 ], [ 96.67821, 75.91548 ], [ 98.92254, 76.44689 ], [ 100.75967, 76.43028 ], [ 101.03532, 76.86189 ], [ 101.99084, 77.28754 ], [ 104.3516, 77.69792 ], [ 106.06664, 77.37389 ], [ 104.705, 77.1274 ], [ 106.97013, 76.97419 ] ] ], [ [ [ 105.07547, 78.30689 ], [ 99.43814, 77.921 ], [ 101.2649, 79.23399 ], [ 102.08635, 79.34641 ], [ 102.837815, 79.28129 ], [ 105.37243, 78.71334 ], [ 105.07547, 78.30689 ] ] ], [ [ [ 51.13618656, 80.54728018 ], [ 49.79368452, 80.41542776 ], [ 48.89441125, 80.33956676 ], [ 48.75493656, 80.17546825 ], [ 47.58611901, 80.01018118 ], [ 46.50282596, 80.24724681 ], [ 47.07245528, 80.55942414 ], [ 44.84695804, 80.58980988 ], [ 46.79913862, 80.77191763 ], [ 48.31847741, 80.78400991 ], [ 48.52280602, 80.514569 ], [ 49.09718957, 80.75398591 ], [ 50.03976769, 80.9188854 ], [ 51.52293298, 80.69972565 ], [ 51.13618656, 80.54728018 ] ] ], [ [ [ 99.93976, 78.88094 ], [ 97.75794, 78.7562 ], [ 94.97259, 79.044745 ], [ 93.31288, 79.4265 ], [ 92.5454, 80.14379 ], [ 91.18107, 80.34146 ], [ 93.77766, 81.0246 ], [ 95.940895, 81.2504 ], [ 97.88385, 80.746975 ], [ 100.186655, 79.780135 ], [ 99.93976, 78.88094 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Rwanda", "sov_a3": "RWA", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Rwanda", "adm0_a3": "RWA", "geou_dif": 0.000000, "geounit": "Rwanda", "gu_a3": "RWA", "su_dif": 0.000000, "subunit": "Rwanda", "su_a3": "RWA", "brk_diff": 0.000000, "name": "Rwanda", "name_long": "Rwanda", "brk_a3": "RWA", "brk_name": "Rwanda", "brk_group": null, "abbrev": "Rwa.", "postal": "RW", "formal_en": "Republic of Rwanda", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Rwanda", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 2.000000, "mapcolor9": 3.000000, "mapcolor13": 10.000000, "pop_est": 10473282.000000, "gdp_md_est": 9706.000000, "pop_year": -99.000000, "lastcensus": 2002.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "RW", "iso_a3": "RWA", "iso_n3": "646", "un_a3": "646", "wb_a2": "RW", "wb_a3": "RWA", "woe_id": -99.000000, "adm0_a3_is": "RWA", "adm0_a3_us": "RWA", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Eastern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 30.41910485, -1.13465911 ], [ 30.81613488, -1.69891408 ], [ 30.75830895, -2.28725026 ], [ 30.46969608, -2.41385752 ], [ 30.46967365, -2.41385476 ], [ 29.938359, -2.34848683 ], [ 29.63217614, -2.91785776 ], [ 29.02492639, -2.83925791 ], [ 29.11747888, -2.2922112 ], [ 29.25483483, -2.21510996 ], [ 29.29188683, -1.62005584 ], [ 29.57946618, -1.34131316 ], [ 29.82151859, -1.44332244 ], [ 30.41910485, -1.13465911 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 7.000000, "sovereignt": "Western Sahara", "sov_a3": "SAH", "adm0_dif": 0.000000, "level": 2.000000, "type": "Indeterminate", "admin": "Western Sahara", "adm0_a3": "SAH", "geou_dif": 0.000000, "geounit": "Western Sahara", "gu_a3": "SAH", "su_dif": 0.000000, "subunit": "Western Sahara", "su_a3": "SAH", "brk_diff": 1.000000, "name": "W. Sahara", "name_long": "Western Sahara", "brk_a3": "B28", "brk_name": "W. Sahara", "brk_group": null, "abbrev": "W. Sah.", "postal": "WS", "formal_en": "Sahrawi Arab Democratic Republic", "formal_fr": null, "note_adm0": "Self admin.", "note_brk": "Self admin.; Claimed by Morocco", "name_sort": "Western Sahara", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 7.000000, "mapcolor9": 4.000000, "mapcolor13": 4.000000, "pop_est": -99.000000, "gdp_md_est": -99.000000, "pop_year": -99.000000, "lastcensus": -99.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "EH", "iso_a3": "ESH", "iso_n3": "732", "un_a3": "732", "wb_a2": "-99", "wb_a3": "-99", "woe_id": -99.000000, "adm0_a3_is": "MAR", "adm0_a3_us": "SAH", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Northern Africa", "region_wb": "Middle East & North Africa", "name_len": 9.000000, "long_len": 14.000000, "abbrev_len": 7.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -8.66558957, 27.65642589 ], [ -8.66512448, 27.58947907 ], [ -8.68439979, 27.39574413 ], [ -8.68729367, 25.88105622 ], [ -11.96941891, 25.93335277 ], [ -11.93722449, 23.37459422 ], [ -12.87422156, 23.28483226 ], [ -13.11875444, 22.7712202 ], [ -12.92910194, 21.32707062 ], [ -16.84519365, 21.33332347 ], [ -17.06342322, 20.9997521 ], [ -17.02042843, 21.42231029 ], [ -17.0029618, 21.42073416 ], [ -14.75095456, 21.50060008 ], [ -14.63083269, 21.86093985 ], [ -14.22116777, 22.31016307 ], [ -13.8911104, 23.69100902 ], [ -12.50096269, 24.77011628 ], [ -12.03075884, 26.0308662 ], [ -11.71821977, 26.1040917 ], [ -11.3925549, 26.88342398 ], [ -10.55126258, 26.9908076 ], [ -10.1894242, 26.86094473 ], [ -9.73534339, 26.86094473 ], [ -9.41303748, 27.08847606 ], [ -8.794884, 27.12069632 ], [ -8.81782833, 27.65642589 ], [ -8.81780901, 27.65642589 ], [ -8.66558957, 27.65642589 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Saudi Arabia", "sov_a3": "SAU", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Saudi Arabia", "adm0_a3": "SAU", "geou_dif": 0.000000, "geounit": "Saudi Arabia", "gu_a3": "SAU", "su_dif": 0.000000, "subunit": "Saudi Arabia", "su_a3": "SAU", "brk_diff": 0.000000, "name": "Saudi Arabia", "name_long": "Saudi Arabia", "brk_a3": "SAU", "brk_name": "Saudi Arabia", "brk_group": null, "abbrev": "Saud.", "postal": "SA", "formal_en": "Kingdom of Saudi Arabia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Saudi Arabia", "name_alt": null, "mapcolor7": 6.000000, "mapcolor8": 1.000000, "mapcolor9": 6.000000, "mapcolor13": 7.000000, "pop_est": 28686633.000000, "gdp_md_est": 576500.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "2. High income: nonOECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "SA", "iso_a3": "SAU", "iso_n3": "682", "un_a3": "682", "wb_a2": "SA", "wb_a3": "SAU", "woe_id": -99.000000, "adm0_a3_is": "SAU", "adm0_a3_us": "SAU", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Western Asia", "region_wb": "Middle East & North Africa", "name_len": 12.000000, "long_len": 12.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 46.56871341, 29.09902517 ], [ 47.45982181, 29.00251944 ], [ 47.70885054, 28.52606273 ], [ 48.41609419, 28.5520043 ], [ 48.80759484, 27.689628 ], [ 49.29955448, 27.46121817 ], [ 49.47091353, 27.10999929 ], [ 50.15242232, 26.68966319 ], [ 50.21293542, 26.27702688 ], [ 50.11330326, 25.94397228 ], [ 50.23985884, 25.60804963 ], [ 50.52738651, 25.32780834 ], [ 50.66055668, 24.99989553 ], [ 50.81010827, 24.75474254 ], [ 51.1124154, 24.55633088 ], [ 51.38960778, 24.62738597 ], [ 51.57951867, 24.24549714 ], [ 51.61770755, 24.01421927 ], [ 52.00073327, 23.00115449 ], [ 55.00680301, 22.49694754 ], [ 55.2083411, 22.70832998 ], [ 55.66665938, 22.00000113 ], [ 54.99998172, 19.999994 ], [ 52.0000098, 19.00000336 ], [ 49.11667158, 18.61666759 ], [ 48.18334354, 18.16666922 ], [ 47.46669478, 17.11668163 ], [ 47.00000492, 16.94999929 ], [ 46.74999434, 17.28333812 ], [ 46.36665856, 17.23331533 ], [ 45.39999922, 17.33333507 ], [ 45.21665124, 17.43332897 ], [ 44.06261315, 17.41035879 ], [ 43.79151859, 17.31997671 ], [ 43.38079431, 17.57998668 ], [ 43.11579756, 17.08844046 ], [ 43.21837528, 16.66688996 ], [ 42.77933231, 16.34789134 ], [ 42.64957279, 16.77463532 ], [ 42.34798913, 17.07580557 ], [ 42.27088789, 17.47472179 ], [ 41.75438195, 17.83304617 ], [ 41.22139123, 18.67159964 ], [ 40.93934126, 19.4864853 ], [ 40.24765222, 20.17463451 ], [ 39.8016846, 20.33886221 ], [ 39.13939945, 21.29190481 ], [ 39.02369592, 21.98687531 ], [ 39.06632897, 22.57965567 ], [ 38.49277225, 23.68845104 ], [ 38.0238603, 24.07868561 ], [ 37.48363488, 24.2854947 ], [ 37.15481774, 24.85848298 ], [ 37.20949141, 25.08454153 ], [ 36.93162723, 25.6029595 ], [ 36.63960371, 25.82622753 ], [ 36.24913659, 26.57013561 ], [ 35.64018151, 27.37652049 ], [ 35.1301868, 28.06335196 ], [ 34.63233605, 28.05854605 ], [ 34.78777876, 28.60742727 ], [ 34.83222049, 28.95748343 ], [ 34.95603723, 29.35655467 ], [ 36.06894087, 29.19749462 ], [ 36.50121423, 29.50525361 ], [ 36.74052778, 29.86528331 ], [ 37.50358198, 30.00377615 ], [ 37.66811974, 30.33866527 ], [ 37.99884891, 30.50849986 ], [ 37.00216556, 31.50841299 ], [ 39.0048857, 32.01021699 ], [ 39.19546838, 32.16100882 ], [ 40.39999434, 31.88999177 ], [ 41.88998091, 31.19000865 ], [ 44.70949873, 29.1788911 ], [ 46.56871341, 29.09902517 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Sudan", "sov_a3": "SDN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Sudan", "adm0_a3": "SDN", "geou_dif": 0.000000, "geounit": "Sudan", "gu_a3": "SDN", "su_dif": 0.000000, "subunit": "Sudan", "su_a3": "SDN", "brk_diff": 0.000000, "name": "Sudan", "name_long": "Sudan", "brk_a3": "SDN", "brk_name": "Sudan", "brk_group": null, "abbrev": "Sudan", "postal": "SD", "formal_en": "Republic of the Sudan", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Sudan", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 6.000000, "mapcolor9": 4.000000, "mapcolor13": 1.000000, "pop_est": 25946220.000000, "gdp_md_est": 88080.000000, "pop_year": -99.000000, "lastcensus": 2008.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "SD", "iso_a3": "SDN", "iso_n3": "729", "un_a3": "729", "wb_a2": "SD", "wb_a3": "SDN", "woe_id": -99.000000, "adm0_a3_is": "SDN", "adm0_a3_us": "SDN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Northern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 5.000000, "long_len": 5.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 36.75389, 16.29186 ], [ 36.32322, 14.82249 ], [ 36.42951, 14.42211 ], [ 36.27022, 13.56333 ], [ 35.86363, 12.57828 ], [ 35.26049, 12.08286 ], [ 34.83163, 11.31896 ], [ 34.73115, 10.91017 ], [ 34.25745, 10.63009 ], [ 33.96162, 9.58358 ], [ 33.96339279, 9.46428523 ], [ 33.82496348, 9.48406085 ], [ 33.84213085, 9.98191464 ], [ 33.72195925, 10.32526208 ], [ 33.20693808, 10.72011164 ], [ 33.08676648, 11.44114127 ], [ 33.20693808, 12.17933827 ], [ 32.74341904, 12.24800776 ], [ 32.67474955, 12.02483192 ], [ 32.07389152, 11.9733298 ], [ 32.31423473, 11.68148448 ], [ 32.40007159, 11.08062645 ], [ 31.85071569, 10.53127055 ], [ 31.3528619, 9.81024092 ], [ 30.83784073, 9.70723668 ], [ 29.9966395, 10.29092734 ], [ 29.61895731, 10.08491887 ], [ 29.51595308, 9.79307354 ], [ 29.00093191, 9.60423245 ], [ 28.96659717, 9.39822399 ], [ 27.97088959, 9.39822399 ], [ 27.83355061, 9.60423245 ], [ 27.11252098, 9.63856719 ], [ 26.75200617, 9.46689347 ], [ 26.47732821, 9.55273033 ], [ 25.96230705, 10.13642099 ], [ 25.79063333, 10.41109894 ], [ 25.0696037, 10.27375996 ], [ 24.79492575, 9.81024092 ], [ 24.53741516, 8.91753757 ], [ 24.19406772, 8.72869647 ], [ 23.88697958, 8.61972971 ], [ 23.80581343, 8.66631887 ], [ 23.45901289, 8.95428579 ], [ 23.39477909, 9.26506786 ], [ 23.55724979, 9.68121817 ], [ 23.55430423, 10.08925528 ], [ 22.97754357, 10.71446259 ], [ 22.86416548, 11.14239513 ], [ 22.87622, 11.38461 ], [ 22.50869, 11.67936 ], [ 22.49762, 12.26024 ], [ 22.28801, 12.64605 ], [ 21.93681, 12.58818 ], [ 22.03759, 12.95546 ], [ 22.29658, 13.37232 ], [ 22.18329, 13.78648 ], [ 22.51202, 14.09318 ], [ 22.30351, 14.32682 ], [ 22.56795, 14.94429 ], [ 23.02459, 15.68072 ], [ 23.88689, 15.61084 ], [ 23.83766, 19.58047 ], [ 23.85, 20.0 ], [ 25.0, 20.00304 ], [ 25.0, 22.0 ], [ 29.02, 22.0 ], [ 32.9, 22.0 ], [ 36.86623, 22.0 ], [ 37.18872, 21.01885 ], [ 36.96941, 20.83744 ], [ 37.1147, 19.80796 ], [ 37.48179, 18.61409 ], [ 37.86276, 18.36786 ], [ 38.41008996, 17.9983074 ], [ 37.904, 17.42754 ], [ 37.16747, 17.26314 ], [ 36.85253, 16.95655 ], [ 36.75389, 16.29186 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "South Sudan", "sov_a3": "SDS", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "South Sudan", "adm0_a3": "SDS", "geou_dif": 0.000000, "geounit": "South Sudan", "gu_a3": "SDS", "su_dif": 0.000000, "subunit": "South Sudan", "su_a3": "SDS", "brk_diff": 0.000000, "name": "S. Sudan", "name_long": "South Sudan", "brk_a3": "SDS", "brk_name": "S. Sudan", "brk_group": null, "abbrev": "S. Sud.", "postal": "SS", "formal_en": "Republic of South Sudan", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "South Sudan", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 3.000000, "mapcolor9": 3.000000, "mapcolor13": 5.000000, "pop_est": 10625176.000000, "gdp_md_est": 13227.000000, "pop_year": -99.000000, "lastcensus": 2008.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "SS", "iso_a3": "SSD", "iso_n3": "728", "un_a3": "728", "wb_a2": "SS", "wb_a3": "SSD", "woe_id": -99.000000, "adm0_a3_is": "SSD", "adm0_a3_us": "SDS", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Eastern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 8.000000, "long_len": 11.000000, "abbrev_len": 7.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 33.84213085, 9.98191464 ], [ 33.82496348, 9.48406085 ], [ 33.96339279, 9.46428523 ], [ 33.97498, 8.68456 ], [ 33.8255, 8.37916 ], [ 33.2948, 8.35458 ], [ 32.95418, 7.78497 ], [ 33.56829, 7.71334 ], [ 34.0751, 7.22595 ], [ 34.25032, 6.82607 ], [ 34.70702, 6.59422 ], [ 35.29800712, 5.506 ], [ 34.62019627, 4.84712274 ], [ 34.005, 4.24988495 ], [ 33.39, 3.79 ], [ 32.68642, 3.79232 ], [ 31.88145, 3.55827 ], [ 31.24556, 3.7819 ], [ 30.83385242, 3.5091716 ], [ 30.83385, 3.50917 ], [ 29.95349, 4.1737 ], [ 29.71599531, 4.60080476 ], [ 29.1590784, 4.38926728 ], [ 28.69667769, 4.45507722 ], [ 28.42899377, 4.28715465 ], [ 27.97997725, 4.4084134 ], [ 27.37422611, 5.2339444 ], [ 27.21340905, 5.55095348 ], [ 26.46590946, 5.94671743 ], [ 26.21341841, 6.5466033 ], [ 25.79664798, 6.9793159 ], [ 25.12413089, 7.50008515 ], [ 25.11493249, 7.82510407 ], [ 24.56736901, 8.22918793 ], [ 23.88697958, 8.61972971 ], [ 24.19406772, 8.72869647 ], [ 24.53741516, 8.91753757 ], [ 24.79492575, 9.81024092 ], [ 25.0696037, 10.27375996 ], [ 25.79063333, 10.41109894 ], [ 25.96230705, 10.13642099 ], [ 26.47732821, 9.55273033 ], [ 26.75200617, 9.46689347 ], [ 27.11252098, 9.63856719 ], [ 27.83355061, 9.60423245 ], [ 27.97088959, 9.39822399 ], [ 28.96659717, 9.39822399 ], [ 29.00093191, 9.60423245 ], [ 29.51595308, 9.79307354 ], [ 29.61895731, 10.08491887 ], [ 29.9966395, 10.29092734 ], [ 30.83784073, 9.70723668 ], [ 31.3528619, 9.81024092 ], [ 31.85071569, 10.53127055 ], [ 32.40007159, 11.08062645 ], [ 32.31423473, 11.68148448 ], [ 32.07389152, 11.9733298 ], [ 32.67474955, 12.02483192 ], [ 32.74341904, 12.24800776 ], [ 33.20693808, 12.17933827 ], [ 33.08676648, 11.44114127 ], [ 33.20693808, 10.72011164 ], [ 33.72195925, 10.32526208 ], [ 33.84213085, 9.98191464 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Senegal", "sov_a3": "SEN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Senegal", "adm0_a3": "SEN", "geou_dif": 0.000000, "geounit": "Senegal", "gu_a3": "SEN", "su_dif": 0.000000, "subunit": "Senegal", "su_a3": "SEN", "brk_diff": 0.000000, "name": "Senegal", "name_long": "Senegal", "brk_a3": "SEN", "brk_name": "Senegal", "brk_group": null, "abbrev": "Sen.", "postal": "SN", "formal_en": "Republic of Senegal", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Senegal", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 6.000000, "mapcolor9": 5.000000, "mapcolor13": 5.000000, "pop_est": 13711597.000000, "gdp_md_est": 21980.000000, "pop_year": -99.000000, "lastcensus": 2002.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "SN", "iso_a3": "SEN", "iso_n3": "686", "un_a3": "686", "wb_a2": "SN", "wb_a3": "SEN", "woe_id": -99.000000, "adm0_a3_is": "SEN", "adm0_a3_us": "SEN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Western Africa", "region_wb": "Sub-Saharan Africa", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -12.17075029, 14.61683421 ], [ -12.12488746, 13.99472748 ], [ -11.92771603, 13.4220751 ], [ -11.55339779, 13.14121369 ], [ -11.46789914, 12.75451895 ], [ -11.51394284, 12.44298758 ], [ -11.65830095, 12.38658275 ], [ -12.20356483, 12.46564769 ], [ -12.27859901, 12.35444001 ], [ -12.49905067, 12.33208995 ], [ -13.21781816, 12.57587352 ], [ -13.70047604, 12.58618297 ], [ -15.54847694, 12.62817007 ], [ -15.81657427, 12.51556712 ], [ -16.14771684, 12.54776154 ], [ -16.67745195, 12.38485159 ], [ -16.84152462, 13.15139395 ], [ -15.93129595, 13.13028413 ], [ -15.69100054, 13.27035309 ], [ -15.51181251, 13.27856965 ], [ -15.1411633, 13.50951162 ], [ -14.71219723, 13.29820669 ], [ -14.27770179, 13.28058503 ], [ -13.84496334, 13.50504161 ], [ -14.04699236, 13.7940679 ], [ -14.37671383, 13.62568024 ], [ -14.68703081, 13.63035696 ], [ -15.0817354, 13.87649181 ], [ -15.39877031, 13.86036876 ], [ -15.62459632, 13.62358735 ], [ -16.71372881, 13.5949586 ], [ -17.12610674, 14.37351573 ], [ -17.62504269, 14.72954051 ], [ -17.1851729, 14.91947724 ], [ -16.70070635, 15.62152741 ], [ -16.46309811, 16.13503612 ], [ -16.12069007, 16.45566254 ], [ -15.62366614, 16.36933706 ], [ -15.13573727, 16.58728242 ], [ -14.57734758, 16.59826366 ], [ -14.09952145, 16.30430227 ], [ -13.43573768, 16.03938304 ], [ -12.83065833, 15.30369151 ], [ -12.17075029, 14.61683421 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Solomon Islands", "sov_a3": "SLB", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Solomon Islands", "adm0_a3": "SLB", "geou_dif": 0.000000, "geounit": "Solomon Islands", "gu_a3": "SLB", "su_dif": 0.000000, "subunit": "Solomon Islands", "su_a3": "SLB", "brk_diff": 0.000000, "name": "Solomon Is.", "name_long": "Solomon Islands", "brk_a3": "SLB", "brk_name": "Solomon Is.", "brk_group": null, "abbrev": "S. Is.", "postal": "SB", "formal_en": null, "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Solomon Islands", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 4.000000, "mapcolor9": 1.000000, "mapcolor13": 6.000000, "pop_est": 595613.000000, "gdp_md_est": 1078.000000, "pop_year": -99.000000, "lastcensus": 2009.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "SB", "iso_a3": "SLB", "iso_n3": "090", "un_a3": "090", "wb_a2": "SB", "wb_a3": "SLB", "woe_id": -99.000000, "adm0_a3_is": "SLB", "adm0_a3_us": "SLB", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Oceania", "region_un": "Oceania", "subregion": "Melanesia", "region_wb": "East Asia & Pacific", "name_len": 11.000000, "long_len": 15.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 162.11902469, -10.48271901 ], [ 162.39864587, -10.82636728 ], [ 161.70003218, -10.82001108 ], [ 161.31979699, -10.20475148 ], [ 161.91738325, -10.44670053 ], [ 162.11902469, -10.48271901 ] ] ], [ [ [ 160.85222863, -9.87293711 ], [ 160.46258833, -9.89520965 ], [ 159.84944746, -9.79402719 ], [ 159.64000288, -9.63997975 ], [ 159.70294478, -9.24294972 ], [ 160.36295617, -9.40030446 ], [ 160.68851769, -9.61016245 ], [ 160.85222863, -9.87293711 ] ] ], [ [ [ 161.67998172, -9.59998219 ], [ 161.5293966, -9.78431203 ], [ 160.78825321, -8.91754323 ], [ 160.57999719, -8.32000864 ], [ 160.92002811, -8.32000864 ], [ 161.28000614, -9.12001149 ], [ 161.67998172, -9.59998219 ] ] ], [ [ [ 159.8750273, -8.33732024 ], [ 159.91740197, -8.53828989 ], [ 159.1336772, -8.11418141 ], [ 158.58611372, -7.7548235 ], [ 158.21114953, -7.42187225 ], [ 158.35997766, -7.320018 ], [ 158.82000126, -7.56000335 ], [ 159.64000288, -8.02002695 ], [ 159.8750273, -8.33732024 ] ] ], [ [ [ 157.53842573, -7.34781992 ], [ 157.33941979, -7.40476735 ], [ 156.90203047, -7.17687428 ], [ 156.49135786, -6.76594329 ], [ 156.54282759, -6.59933847 ], [ 157.14000044, -7.02163828 ], [ 157.53842573, -7.34781992 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Sierra Leone", "sov_a3": "SLE", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Sierra Leone", "adm0_a3": "SLE", "geou_dif": 0.000000, "geounit": "Sierra Leone", "gu_a3": "SLE", "su_dif": 0.000000, "subunit": "Sierra Leone", "su_a3": "SLE", "brk_diff": 0.000000, "name": "Sierra Leone", "name_long": "Sierra Leone", "brk_a3": "SLE", "brk_name": "Sierra Leone", "brk_group": null, "abbrev": "S.L.", "postal": "SL", "formal_en": "Republic of Sierra Leone", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Sierra Leone", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 4.000000, "mapcolor9": 1.000000, "mapcolor13": 7.000000, "pop_est": 6440053.000000, "gdp_md_est": 4285.000000, "pop_year": -99.000000, "lastcensus": 2004.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "SL", "iso_a3": "SLE", "iso_n3": "694", "un_a3": "694", "wb_a2": "SL", "wb_a3": "SLE", "woe_id": -99.000000, "adm0_a3_is": "SLE", "adm0_a3_us": "SLE", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Western Africa", "region_wb": "Sub-Saharan Africa", "name_len": 12.000000, "long_len": 12.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -10.23009355, 8.40620555 ], [ -10.69559486, 7.93946402 ], [ -11.14670427, 7.39670645 ], [ -11.19980181, 7.10584565 ], [ -11.43877947, 6.78591686 ], [ -11.70819455, 6.86009837 ], [ -12.42809892, 7.262942 ], [ -12.94904904, 7.79864574 ], [ -13.12402544, 8.16394644 ], [ -13.24655026, 8.90304861 ], [ -12.71195757, 9.3427117 ], [ -12.59671912, 9.6201883 ], [ -12.42592851, 9.83583405 ], [ -12.1503381, 9.85857168 ], [ -11.91727739, 10.04698395 ], [ -11.11748125, 10.04587291 ], [ -10.83915198, 9.68824616 ], [ -10.62239519, 9.26791006 ], [ -10.65477047, 8.97717845 ], [ -10.49431515, 8.71554068 ], [ -10.50547726, 8.34889639 ], [ -10.23009355, 8.40620555 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "El Salvador", "sov_a3": "SLV", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "El Salvador", "adm0_a3": "SLV", "geou_dif": 0.000000, "geounit": "El Salvador", "gu_a3": "SLV", "su_dif": 0.000000, "subunit": "El Salvador", "su_a3": "SLV", "brk_diff": 0.000000, "name": "El Salvador", "name_long": "El Salvador", "brk_a3": "SLV", "brk_name": "El Salvador", "brk_group": null, "abbrev": "El. S.", "postal": "SV", "formal_en": "Republic of El Salvador", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "El Salvador", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 4.000000, "mapcolor9": 6.000000, "mapcolor13": 8.000000, "pop_est": 7185218.000000, "gdp_md_est": 43630.000000, "pop_year": -99.000000, "lastcensus": 2007.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "SV", "iso_a3": "SLV", "iso_n3": "222", "un_a3": "222", "wb_a2": "SV", "wb_a3": "SLV", "woe_id": -99.000000, "adm0_a3_is": "SLV", "adm0_a3_us": "SLV", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "North America", "region_un": "Americas", "subregion": "Central America", "region_wb": "Latin America & Caribbean", "name_len": 11.000000, "long_len": 11.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -87.79311113, 13.3844805 ], [ -87.90411211, 13.14901683 ], [ -88.48330156, 13.16395132 ], [ -88.84322791, 13.25973359 ], [ -89.25674272, 13.45853282 ], [ -89.81239356, 13.52062206 ], [ -90.09555457, 13.73533763 ], [ -90.0646779, 13.88196951 ], [ -89.72193397, 14.13422801 ], [ -89.53421933, 14.24481558 ], [ -89.5873427, 14.36258617 ], [ -89.35332598, 14.4241328 ], [ -89.05851193, 14.34002941 ], [ -88.84307288, 14.1405067 ], [ -88.54123084, 13.98015473 ], [ -88.50399797, 13.84548595 ], [ -88.06534258, 13.96462596 ], [ -87.85951535, 13.89331249 ], [ -87.72350298, 13.78505036 ], [ -87.79311113, 13.3844805 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Somaliland", "sov_a3": "SOL", "adm0_dif": 0.000000, "level": 2.000000, "type": "Indeterminate", "admin": "Somaliland", "adm0_a3": "SOL", "geou_dif": 0.000000, "geounit": "Somaliland", "gu_a3": "SOL", "su_dif": 0.000000, "subunit": "Somaliland", "su_a3": "SOL", "brk_diff": 1.000000, "name": "Somaliland", "name_long": "Somaliland", "brk_a3": "B30", "brk_name": "Somaliland", "brk_group": null, "abbrev": "Solnd.", "postal": "SL", "formal_en": "Republic of Somaliland", "formal_fr": null, "note_adm0": "Self admin.", "note_brk": "Self admin.; Claimed by Somalia", "name_sort": "Somaliland", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 6.000000, "mapcolor9": 5.000000, "mapcolor13": 2.000000, "pop_est": 3500000.000000, "gdp_md_est": 12250.000000, "pop_year": -99.000000, "lastcensus": -99.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "-99", "iso_a3": "-99", "iso_n3": "-99", "un_a3": "-099", "wb_a2": "-99", "wb_a3": "-99", "woe_id": -99.000000, "adm0_a3_is": "SOM", "adm0_a3_us": "SOM", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Eastern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 10.000000, "long_len": 10.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 44.11780358, 10.44553844 ], [ 44.61425907, 10.44220531 ], [ 45.55694055, 10.69802949 ], [ 46.64540124, 10.81654938 ], [ 47.52565759, 11.12722809 ], [ 48.02159631, 11.19306387 ], [ 48.37878381, 11.37548168 ], [ 48.94820641, 11.41062165 ], [ 48.94820476, 11.41061728 ], [ 48.94200524, 11.39426606 ], [ 48.93849125, 10.98232738 ], [ 48.93823286, 9.97350007 ], [ 48.93812951, 9.45174897 ], [ 48.48673587, 8.83762625 ], [ 47.78942, 8.003 ], [ 46.94832848, 7.99687653 ], [ 43.67875, 9.18358 ], [ 43.29697513, 9.5404774 ], [ 42.92812, 10.02194 ], [ 42.55876, 10.57258 ], [ 42.77685184, 10.92687857 ], [ 43.1453048, 11.4620397 ], [ 43.47065962, 11.27770987 ], [ 43.66666833, 10.86416922 ], [ 44.11780358, 10.44553844 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Somalia", "sov_a3": "SOM", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Somalia", "adm0_a3": "SOM", "geou_dif": 0.000000, "geounit": "Somalia", "gu_a3": "SOM", "su_dif": 0.000000, "subunit": "Somalia", "su_a3": "SOM", "brk_diff": 0.000000, "name": "Somalia", "name_long": "Somalia", "brk_a3": "SOM", "brk_name": "Somalia", "brk_group": null, "abbrev": "Som.", "postal": "SO", "formal_en": "Federal Republic of Somalia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Somalia", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 8.000000, "mapcolor9": 6.000000, "mapcolor13": 7.000000, "pop_est": 9832017.000000, "gdp_md_est": 5524.000000, "pop_year": -99.000000, "lastcensus": 1987.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "SO", "iso_a3": "SOM", "iso_n3": "706", "un_a3": "706", "wb_a2": "SO", "wb_a3": "SOM", "woe_id": -99.000000, "adm0_a3_is": "SOM", "adm0_a3_us": "SOM", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Eastern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 41.58513, -1.68325 ], [ 40.993, -0.85829 ], [ 40.98105, 2.78452 ], [ 41.85508309, 3.91891192 ], [ 42.12861, 4.23413 ], [ 42.76967, 4.25259 ], [ 43.66087, 4.95755 ], [ 44.9636, 5.00162 ], [ 47.78942, 8.003 ], [ 48.48673587, 8.83762625 ], [ 48.93812951, 9.45174897 ], [ 48.93823286, 9.97350007 ], [ 48.93849125, 10.98232738 ], [ 48.94200524, 11.39426606 ], [ 48.94820476, 11.41061728 ], [ 49.26776, 11.43033 ], [ 49.72862, 11.5789 ], [ 50.25878, 11.67957 ], [ 50.73202, 12.0219 ], [ 51.1112, 12.02464 ], [ 51.13387, 11.74815 ], [ 51.04153, 11.16651 ], [ 51.04531, 10.6409 ], [ 50.83418, 10.27972 ], [ 50.55239, 9.19874 ], [ 50.07092, 8.08173 ], [ 49.4527, 6.80466 ], [ 48.59455, 5.33911 ], [ 47.74079, 4.2194 ], [ 46.56476, 2.85529 ], [ 45.56399, 2.04576 ], [ 44.06815, 1.05283 ], [ 43.13597, 0.2922 ], [ 42.04157, -0.91916 ], [ 41.81095, -1.44647 ], [ 41.58513, -1.68325 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Republic of Serbia", "sov_a3": "SRB", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Republic of Serbia", "adm0_a3": "SRB", "geou_dif": 0.000000, "geounit": "Republic of Serbia", "gu_a3": "SRB", "su_dif": 0.000000, "subunit": "Republic of Serbia", "su_a3": "SRB", "brk_diff": 0.000000, "name": "Serbia", "name_long": "Serbia", "brk_a3": "SRB", "brk_name": "Serbia", "brk_group": null, "abbrev": "Serb.", "postal": "RS", "formal_en": "Republic of Serbia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Serbia", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 3.000000, "mapcolor9": 2.000000, "mapcolor13": 10.000000, "pop_est": 7379339.000000, "gdp_md_est": 80340.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "RS", "iso_a3": "SRB", "iso_n3": "688", "un_a3": "688", "wb_a2": "YF", "wb_a3": "SRB", "woe_id": -99.000000, "adm0_a3_is": "SRB", "adm0_a3_us": "SRB", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Southern Europe", "region_wb": "Europe & Central Asia", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 21.48352624, 45.18117015 ], [ 21.56202274, 44.76894725 ], [ 22.14508792, 44.47842235 ], [ 22.45902225, 44.7025172 ], [ 22.70572554, 44.57800283 ], [ 22.47400842, 44.40922761 ], [ 22.65714969, 44.234923 ], [ 22.4104464, 44.00806346 ], [ 22.50015669, 43.64281444 ], [ 22.98601851, 43.2111612 ], [ 22.60480147, 42.89851879 ], [ 22.43659468, 42.58032115 ], [ 22.54501183, 42.46136201 ], [ 22.38052575, 42.32025951 ], [ 21.91708, 42.30364 ], [ 21.57663599, 42.2452244 ], [ 21.54332, 42.32025 ], [ 21.66292, 42.43922 ], [ 21.77505, 42.6827 ], [ 21.63302, 42.67717 ], [ 21.43866, 42.86255 ], [ 21.27421, 42.90959 ], [ 21.143395, 43.068685 ], [ 20.95651, 43.13094 ], [ 20.81448, 43.27205 ], [ 20.63508, 43.21671 ], [ 20.49679, 42.88469 ], [ 20.25758, 42.81275 ], [ 20.3398, 42.89852 ], [ 19.95857, 43.10604 ], [ 19.63, 43.21377997 ], [ 19.48389, 43.35229 ], [ 19.21852, 43.52384 ], [ 19.454, 43.5681 ], [ 19.59976, 44.03847 ], [ 19.11761, 44.42307 ], [ 19.36803, 44.863 ], [ 19.00548, 44.86023 ], [ 19.0054846, 44.86023449 ], [ 19.3904757, 45.23651561 ], [ 19.072769, 45.52151114 ], [ 18.82982479, 45.90887236 ], [ 18.82982, 45.90888 ], [ 19.59604455, 46.17172984 ], [ 20.2201925, 46.12746898 ], [ 20.76217492, 45.73457307 ], [ 20.87431278, 45.41637543 ], [ 21.48352624, 45.18117015 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Suriname", "sov_a3": "SUR", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Suriname", "adm0_a3": "SUR", "geou_dif": 0.000000, "geounit": "Suriname", "gu_a3": "SUR", "su_dif": 0.000000, "subunit": "Suriname", "su_a3": "SUR", "brk_diff": 0.000000, "name": "Suriname", "name_long": "Suriname", "brk_a3": "SUR", "brk_name": "Suriname", "brk_group": null, "abbrev": "Sur.", "postal": "SR", "formal_en": "Republic of Suriname", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Suriname", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 4.000000, "mapcolor9": 7.000000, "mapcolor13": 6.000000, "pop_est": 481267.000000, "gdp_md_est": 4254.000000, "pop_year": -99.000000, "lastcensus": 2004.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "SR", "iso_a3": "SUR", "iso_n3": "740", "un_a3": "740", "wb_a2": "SR", "wb_a3": "SUR", "woe_id": -99.000000, "adm0_a3_is": "SUR", "adm0_a3_us": "SUR", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "South America", "region_un": "Americas", "subregion": "South America", "region_wb": "Latin America & Caribbean", "name_len": 8.000000, "long_len": 8.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -55.03325029, 6.02529145 ], [ -53.9580446, 5.75654816 ], [ -54.47863298, 4.89675568 ], [ -54.3995422, 4.2126114 ], [ -54.00693051, 3.62003775 ], [ -54.18172604, 3.18977977 ], [ -54.26970517, 2.73239167 ], [ -54.5247542, 2.31184886 ], [ -55.09758745, 2.52374807 ], [ -55.56975501, 2.42150625 ], [ -55.97332211, 2.51036388 ], [ -56.07334184, 2.22079499 ], [ -55.90560015, 2.02199575 ], [ -55.995698, 1.81766714 ], [ -56.53938575, 1.89952261 ], [ -57.15009783, 2.76892691 ], [ -57.28143348, 3.33349193 ], [ -57.60156898, 3.33465465 ], [ -58.04469438, 4.06086355 ], [ -57.86020952, 4.57680105 ], [ -57.91428891, 4.81262645 ], [ -57.30724586, 5.0735666 ], [ -57.14743649, 5.97314993 ], [ -55.94931841, 5.77287792 ], [ -55.84177975, 5.95312531 ], [ -55.03325029, 6.02529145 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Slovakia", "sov_a3": "SVK", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Slovakia", "adm0_a3": "SVK", "geou_dif": 0.000000, "geounit": "Slovakia", "gu_a3": "SVK", "su_dif": 0.000000, "subunit": "Slovakia", "su_a3": "SVK", "brk_diff": 0.000000, "name": "Slovakia", "name_long": "Slovakia", "brk_a3": "SVK", "brk_name": "Slovakia", "brk_group": null, "abbrev": "Svk.", "postal": "SK", "formal_en": "Slovak Republic", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Slovak Republic", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 4.000000, "mapcolor9": 4.000000, "mapcolor13": 9.000000, "pop_est": 5463046.000000, "gdp_md_est": 119500.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "SK", "iso_a3": "SVK", "iso_n3": "703", "un_a3": "703", "wb_a2": "SK", "wb_a3": "SVK", "woe_id": -99.000000, "adm0_a3_is": "SVK", "adm0_a3_us": "SVK", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Eastern Europe", "region_wb": "Europe & Central Asia", "name_len": 8.000000, "long_len": 8.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 22.55813765, 49.08573802 ], [ 22.28084191, 48.82539216 ], [ 22.08560835, 48.42226431 ], [ 21.87223636, 48.31997081 ], [ 20.80129398, 48.62385407 ], [ 20.47356205, 48.56285004 ], [ 20.2390544, 48.32756725 ], [ 19.76947066, 48.20269115 ], [ 19.66136356, 48.2666149 ], [ 19.17436486, 48.11137889 ], [ 18.77702477, 48.0817683 ], [ 18.69651289, 47.88095368 ], [ 17.8571326, 47.75842886 ], [ 17.48847293, 47.86746613 ], [ 16.97966678, 48.12349702 ], [ 16.87998294, 48.47001333 ], [ 16.96028812, 48.59698233 ], [ 17.1019849, 48.8169689 ], [ 17.54500695, 48.80001903 ], [ 17.88648482, 48.90347525 ], [ 17.91351159, 48.99649282 ], [ 18.10497277, 49.04398347 ], [ 18.17049849, 49.2715148 ], [ 18.39999352, 49.31500052 ], [ 18.55497114, 49.49501537 ], [ 18.85314416, 49.49622976 ], [ 18.90957482, 49.43584585 ], [ 19.32071252, 49.571574 ], [ 19.82502282, 49.21712535 ], [ 20.41583947, 49.43145336 ], [ 20.88795536, 49.32877228 ], [ 21.60780806, 49.47010733 ], [ 22.55813765, 49.08573802 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Slovenia", "sov_a3": "SVN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Slovenia", "adm0_a3": "SVN", "geou_dif": 0.000000, "geounit": "Slovenia", "gu_a3": "SVN", "su_dif": 0.000000, "subunit": "Slovenia", "su_a3": "SVN", "brk_diff": 0.000000, "name": "Slovenia", "name_long": "Slovenia", "brk_a3": "SVN", "brk_name": "Slovenia", "brk_group": null, "abbrev": "Slo.", "postal": "SLO", "formal_en": "Republic of Slovenia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Slovenia", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 3.000000, "mapcolor9": 2.000000, "mapcolor13": 12.000000, "pop_est": 2005692.000000, "gdp_md_est": 59340.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "SI", "iso_a3": "SVN", "iso_n3": "705", "un_a3": "705", "wb_a2": "SI", "wb_a3": "SVN", "woe_id": -99.000000, "adm0_a3_is": "SVN", "adm0_a3_us": "SVN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Southern Europe", "region_wb": "Europe & Central Asia", "name_len": 8.000000, "long_len": 8.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 16.56480838, 46.50375092 ], [ 15.76873294, 46.23810822 ], [ 15.67152958, 45.83415355 ], [ 15.32395389, 45.73178254 ], [ 15.32767459, 45.45231639 ], [ 14.93524377, 45.47169505 ], [ 14.59510949, 45.6349409 ], [ 14.41196821, 45.46616568 ], [ 13.71505985, 45.5003238 ], [ 13.93763024, 45.59101594 ], [ 13.69810998, 46.01677806 ], [ 13.80647546, 46.50930614 ], [ 14.63247155, 46.43181733 ], [ 15.13709191, 46.6587027 ], [ 16.01166385, 46.68361074 ], [ 16.20229821, 46.85238597 ], [ 16.370505, 46.84132722 ], [ 16.56480838, 46.50375092 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Sweden", "sov_a3": "SWE", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Sweden", "adm0_a3": "SWE", "geou_dif": 0.000000, "geounit": "Sweden", "gu_a3": "SWE", "su_dif": 0.000000, "subunit": "Sweden", "su_a3": "SWE", "brk_diff": 0.000000, "name": "Sweden", "name_long": "Sweden", "brk_a3": "SWE", "brk_name": "Sweden", "brk_group": null, "abbrev": "Swe.", "postal": "S", "formal_en": "Kingdom of Sweden", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Sweden", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 4.000000, "mapcolor9": 2.000000, "mapcolor13": 4.000000, "pop_est": 9059651.000000, "gdp_md_est": 344300.000000, "pop_year": -99.000000, "lastcensus": -99.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "1. High income: OECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "SE", "iso_a3": "SWE", "iso_n3": "752", "un_a3": "752", "wb_a2": "SE", "wb_a3": "SWE", "woe_id": -99.000000, "adm0_a3_is": "SWE", "adm0_a3_us": "SWE", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Northern Europe", "region_wb": "Europe & Central Asia", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 23.90337853, 66.0069274 ], [ 22.18317346, 65.72374055 ], [ 21.21351688, 65.02600536 ], [ 21.36963138, 64.41358796 ], [ 19.77887577, 63.60955435 ], [ 17.84777917, 62.74940013 ], [ 17.11955488, 61.34116568 ], [ 17.83134606, 60.63658336 ], [ 18.7877218, 60.08191437 ], [ 17.86922489, 58.95376618 ], [ 16.82918501, 58.71982697 ], [ 16.44770959, 57.04111807 ], [ 15.8797856, 56.10430187 ], [ 14.66668135, 56.20088512 ], [ 14.10072106, 55.40778107 ], [ 12.9429106, 55.36173737 ], [ 12.62510054, 56.30708019 ], [ 11.78794234, 57.44181713 ], [ 11.02736861, 58.8561494 ], [ 11.46827193, 59.4323933 ], [ 12.30036584, 60.11793285 ], [ 12.63114668, 61.29357168 ], [ 11.99206424, 61.80036245 ], [ 11.93056929, 63.12831757 ], [ 12.57993534, 64.06621898 ], [ 13.57191613, 64.04911408 ], [ 13.91990523, 64.44542064 ], [ 13.55568973, 64.7870277 ], [ 15.10841149, 66.19386689 ], [ 16.10871219, 67.30245555 ], [ 16.76887861, 68.01393667 ], [ 17.72918176, 68.01055187 ], [ 17.99386844, 68.56739126 ], [ 19.8785596, 68.40719432 ], [ 20.025269, 69.06513866 ], [ 20.64559289, 69.10624726 ], [ 21.97853478, 68.61684561 ], [ 23.5394731, 67.93600861 ], [ 23.56587975, 66.39605093 ], [ 23.90337853, 66.0069274 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Swaziland", "sov_a3": "SWZ", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Swaziland", "adm0_a3": "SWZ", "geou_dif": 0.000000, "geounit": "Swaziland", "gu_a3": "SWZ", "su_dif": 0.000000, "subunit": "Swaziland", "su_a3": "SWZ", "brk_diff": 0.000000, "name": "Swaziland", "name_long": "Swaziland", "brk_a3": "SWZ", "brk_name": "Swaziland", "brk_group": null, "abbrev": "Swz.", "postal": "SW", "formal_en": "Kingdom of Swaziland", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Swaziland", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 6.000000, "mapcolor9": 2.000000, "mapcolor13": 5.000000, "pop_est": 1123913.000000, "gdp_md_est": 5702.000000, "pop_year": -99.000000, "lastcensus": 2007.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "SZ", "iso_a3": "SWZ", "iso_n3": "748", "un_a3": "748", "wb_a2": "SZ", "wb_a3": "SWZ", "woe_id": -99.000000, "adm0_a3_is": "SWZ", "adm0_a3_us": "SWZ", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Southern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 9.000000, "long_len": 9.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 31.83777795, -25.8433318 ], [ 31.98577925, -26.29177988 ], [ 32.07166548, -26.73382008 ], [ 31.86806034, -27.17792734 ], [ 31.28277306, -27.28587941 ], [ 30.68596195, -26.74384531 ], [ 30.67660851, -26.3980783 ], [ 30.94966678, -26.02264902 ], [ 31.04407962, -25.73145233 ], [ 31.33315759, -25.66019053 ], [ 31.83777795, -25.8433318 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Syria", "sov_a3": "SYR", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Syria", "adm0_a3": "SYR", "geou_dif": 0.000000, "geounit": "Syria", "gu_a3": "SYR", "su_dif": 0.000000, "subunit": "Syria", "su_a3": "SYR", "brk_diff": 0.000000, "name": "Syria", "name_long": "Syria", "brk_a3": "SYR", "brk_name": "Syria", "brk_group": null, "abbrev": "Syria", "postal": "SYR", "formal_en": "Syrian Arab Republic", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Syrian Arab Republic", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 6.000000, "mapcolor9": 2.000000, "mapcolor13": 6.000000, "pop_est": 20178485.000000, "gdp_md_est": 98830.000000, "pop_year": -99.000000, "lastcensus": 2004.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "SY", "iso_a3": "SYR", "iso_n3": "760", "un_a3": "760", "wb_a2": "SY", "wb_a3": "SYR", "woe_id": -99.000000, "adm0_a3_is": "SYR", "adm0_a3_us": "SYR", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Western Asia", "region_wb": "Middle East & North Africa", "name_len": 5.000000, "long_len": 5.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 38.79234053, 33.37868643 ], [ 36.83406213, 32.31293753 ], [ 35.71991825, 32.70919241 ], [ 35.70079797, 32.7160137 ], [ 35.83639693, 32.86812328 ], [ 35.8211007, 33.27742646 ], [ 36.0664604, 33.82491242 ], [ 36.61175012, 34.20178864 ], [ 36.44819421, 34.59393525 ], [ 35.99840254, 34.64491405 ], [ 35.90502323, 35.41000947 ], [ 36.14976281, 35.82153474 ], [ 36.41755008, 36.04061697 ], [ 36.68538903, 36.25969921 ], [ 36.73949426, 36.81752045 ], [ 37.0667611, 36.6230362 ], [ 38.16772749, 36.90121044 ], [ 38.69989139, 36.71292735 ], [ 39.52258019, 36.71605378 ], [ 40.67325931, 37.09127635 ], [ 41.21208947, 37.07435232 ], [ 42.3495911, 37.22987254 ], [ 41.83706424, 36.60585379 ], [ 41.28970747, 36.3588146 ], [ 41.38396529, 35.62831656 ], [ 41.00615889, 34.41937226 ], [ 38.79234053, 33.37868643 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Chad", "sov_a3": "TCD", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Chad", "adm0_a3": "TCD", "geou_dif": 0.000000, "geounit": "Chad", "gu_a3": "TCD", "su_dif": 0.000000, "subunit": "Chad", "su_a3": "TCD", "brk_diff": 0.000000, "name": "Chad", "name_long": "Chad", "brk_a3": "TCD", "brk_name": "Chad", "brk_group": null, "abbrev": "Chad", "postal": "TD", "formal_en": "Republic of Chad", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Chad", "name_alt": null, "mapcolor7": 6.000000, "mapcolor8": 1.000000, "mapcolor9": 8.000000, "mapcolor13": 6.000000, "pop_est": 10329208.000000, "gdp_md_est": 15860.000000, "pop_year": -99.000000, "lastcensus": 2009.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "TD", "iso_a3": "TCD", "iso_n3": "148", "un_a3": "148", "wb_a2": "TD", "wb_a3": "TCD", "woe_id": -99.000000, "adm0_a3_is": "TCD", "adm0_a3_us": "TCD", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Middle Africa", "region_wb": "Sub-Saharan Africa", "name_len": 4.000000, "long_len": 4.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 23.83766, 19.58047 ], [ 23.88689, 15.61084 ], [ 23.02459, 15.68072 ], [ 22.56795, 14.94429 ], [ 22.30351, 14.32682 ], [ 22.51202, 14.09318 ], [ 22.18329, 13.78648 ], [ 22.29658, 13.37232 ], [ 22.03759, 12.95546 ], [ 21.93681, 12.58818 ], [ 22.28801, 12.64605 ], [ 22.49762, 12.26024 ], [ 22.50869, 11.67936 ], [ 22.87622, 11.38461 ], [ 22.86416548, 11.14239513 ], [ 22.23112918, 10.97188874 ], [ 21.72382165, 10.56705557 ], [ 21.00086836, 9.47598522 ], [ 20.0596855, 9.012706 ], [ 19.09400801, 9.07484691 ], [ 18.81200972, 8.98291454 ], [ 18.91102176, 8.63089468 ], [ 18.38955488, 8.28130362 ], [ 17.96492964, 7.89091401 ], [ 16.7059884, 7.50832754 ], [ 16.45618452, 7.73477367 ], [ 16.29056156, 7.75430736 ], [ 16.10623172, 7.49708792 ], [ 15.27946048, 7.42192455 ], [ 15.43609175, 7.6928124 ], [ 15.12086551, 8.38215017 ], [ 14.97999556, 8.79610423 ], [ 14.54446659, 8.96586131 ], [ 13.95421838, 9.54949494 ], [ 14.1714661, 10.02137828 ], [ 14.62720056, 9.9209193 ], [ 14.90935388, 9.99212942 ], [ 15.46787276, 9.98233674 ], [ 14.92356489, 10.89132518 ], [ 14.96015181, 11.55557404 ], [ 14.89336, 12.21905 ], [ 14.49578739, 12.85939627 ], [ 14.59578128, 13.33042695 ], [ 13.95447676, 13.3534488 ], [ 13.95669885, 13.99669119 ], [ 13.54039351, 14.36713369 ], [ 13.97217, 15.68437 ], [ 15.24773115, 16.62730581 ], [ 15.30044111, 17.92794994 ], [ 15.68574059, 19.95718008 ], [ 15.9032467, 20.38761892 ], [ 15.48714806, 20.73041454 ], [ 15.47106, 21.04845 ], [ 15.09688765, 21.30851879 ], [ 14.8513, 22.86295 ], [ 15.86085, 23.40972 ], [ 19.84926, 21.49509 ], [ 23.83766, 19.58047 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 6.000000, "sovereignt": "Togo", "sov_a3": "TGO", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Togo", "adm0_a3": "TGO", "geou_dif": 0.000000, "geounit": "Togo", "gu_a3": "TGO", "su_dif": 0.000000, "subunit": "Togo", "su_a3": "TGO", "brk_diff": 0.000000, "name": "Togo", "name_long": "Togo", "brk_a3": "TGO", "brk_name": "Togo", "brk_group": null, "abbrev": "Togo", "postal": "TG", "formal_en": "Togolese Republic", "formal_fr": "Rublique Togolaise", "note_adm0": null, "note_brk": null, "name_sort": "Togo", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 1.000000, "mapcolor9": 3.000000, "mapcolor13": 5.000000, "pop_est": 6019877.000000, "gdp_md_est": 5118.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "TG", "iso_a3": "TGO", "iso_n3": "768", "un_a3": "768", "wb_a2": "TG", "wb_a3": "TGO", "woe_id": -99.000000, "adm0_a3_is": "TGO", "adm0_a3_us": "TGO", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Western Africa", "region_wb": "Sub-Saharan Africa", "name_len": 4.000000, "long_len": 4.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 0.89956302, 10.99733938 ], [ 0.77233565, 10.47080821 ], [ 1.07779504, 10.17560659 ], [ 1.42506066, 9.82539541 ], [ 1.46304284, 9.33462434 ], [ 1.66447757, 9.1285904 ], [ 1.61895064, 6.83203807 ], [ 1.86524051, 6.1421577 ], [ 1.0601217, 5.92883739 ], [ 0.83693119, 6.27997875 ], [ 0.57038415, 6.91435863 ], [ 0.49095747, 7.41174429 ], [ 0.71202925, 8.3124645 ], [ 0.46119185, 8.6772226 ], [ 0.36590051, 9.46500397 ], [ 0.36757999, 10.19121288 ], [ -0.04978472, 10.70691783 ], [ 0.02380252, 11.01868175 ], [ 0.89956302, 10.99733938 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Thailand", "sov_a3": "THA", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Thailand", "adm0_a3": "THA", "geou_dif": 0.000000, "geounit": "Thailand", "gu_a3": "THA", "su_dif": 0.000000, "subunit": "Thailand", "su_a3": "THA", "brk_diff": 0.000000, "name": "Thailand", "name_long": "Thailand", "brk_a3": "THA", "brk_name": "Thailand", "brk_group": null, "abbrev": "Thai.", "postal": "TH", "formal_en": "Kingdom of Thailand", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Thailand", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 6.000000, "mapcolor9": 8.000000, "mapcolor13": 1.000000, "pop_est": 65905410.000000, "gdp_md_est": 547400.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "5. Emerging region: G20", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "TH", "iso_a3": "THA", "iso_n3": "764", "un_a3": "764", "wb_a2": "TH", "wb_a3": "THA", "woe_id": -99.000000, "adm0_a3_is": "THA", "adm0_a3_us": "THA", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "South-Eastern Asia", "region_wb": "East Asia & Pacific", "name_len": 8.000000, "long_len": 8.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 105.21877689, 14.27321178 ], [ 104.28141808, 14.41674307 ], [ 102.98842207, 14.22572114 ], [ 102.3480994, 13.39424734 ], [ 102.58493249, 12.18659496 ], [ 101.68715783, 12.64574006 ], [ 100.83180952, 12.62708487 ], [ 100.97846724, 13.41272167 ], [ 100.09779748, 13.40685639 ], [ 100.01873254, 12.30700104 ], [ 99.47892053, 10.84636669 ], [ 99.15377241, 9.96306143 ], [ 99.22239872, 9.23925548 ], [ 99.87383182, 9.20786205 ], [ 100.27964684, 8.2951529 ], [ 100.45927412, 7.42957266 ], [ 101.01732792, 6.8568686 ], [ 101.62307905, 6.74062246 ], [ 102.14118696, 6.22163605 ], [ 101.81428185, 5.81080842 ], [ 101.15421878, 5.69138418 ], [ 101.07551558, 6.20486705 ], [ 100.25959639, 6.64282482 ], [ 100.08575687, 6.46448945 ], [ 99.69069055, 6.8482128 ], [ 99.51964155, 7.34345388 ], [ 98.9882528, 7.90799307 ], [ 98.50378625, 8.3823052 ], [ 98.3396619, 7.79451162 ], [ 98.15000939, 8.35000743 ], [ 98.25915002, 8.97392284 ], [ 98.55355065, 9.93295991 ], [ 99.03812056, 10.96054576 ], [ 99.587286, 11.89276276 ], [ 99.19635379, 12.80474844 ], [ 99.21201175, 13.26929373 ], [ 99.09775516, 13.82750255 ], [ 98.43081913, 14.6220277 ], [ 98.19207401, 15.1237025 ], [ 98.53737593, 15.30849742 ], [ 98.90334842, 16.1778242 ], [ 98.49376102, 16.8378356 ], [ 97.85912276, 17.56794607 ], [ 97.37589644, 18.44543773 ], [ 97.79778283, 18.62708039 ], [ 98.25372399, 19.70820303 ], [ 98.95967573, 19.75298066 ], [ 99.54330936, 20.1865976 ], [ 100.11598758, 20.41784964 ], [ 100.54888106, 20.10923798 ], [ 100.60629357, 19.50834443 ], [ 101.2820146, 19.46258495 ], [ 101.03593143, 18.40892833 ], [ 101.05954756, 17.51249726 ], [ 102.11359175, 18.10910167 ], [ 102.413005, 17.93278168 ], [ 102.99870568, 17.96169465 ], [ 103.20019209, 18.30963207 ], [ 103.95647668, 18.24095409 ], [ 104.71694706, 17.42885895 ], [ 104.77932051, 16.44186494 ], [ 105.58903853, 15.57031607 ], [ 105.54433841, 14.72393362 ], [ 105.21877689, 14.27321178 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Tajikistan", "sov_a3": "TJK", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Tajikistan", "adm0_a3": "TJK", "geou_dif": 0.000000, "geounit": "Tajikistan", "gu_a3": "TJK", "su_dif": 0.000000, "subunit": "Tajikistan", "su_a3": "TJK", "brk_diff": 0.000000, "name": "Tajikistan", "name_long": "Tajikistan", "brk_a3": "TJK", "brk_name": "Tajikistan", "brk_group": null, "abbrev": "Tjk.", "postal": "TJ", "formal_en": "Republic of Tajikistan", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Tajikistan", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 6.000000, "mapcolor9": 2.000000, "mapcolor13": 5.000000, "pop_est": 7349145.000000, "gdp_md_est": 13160.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "TJ", "iso_a3": "TJK", "iso_n3": "762", "un_a3": "762", "wb_a2": "TJ", "wb_a3": "TJK", "woe_id": -99.000000, "adm0_a3_is": "TJK", "adm0_a3_us": "TJK", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Central Asia", "region_wb": "Europe & Central Asia", "name_len": 10.000000, "long_len": 10.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 71.01419803, 40.24436555 ], [ 70.64801883, 39.93575389 ], [ 69.55960982, 40.10321137 ], [ 69.46488692, 39.52668325 ], [ 70.54916182, 39.6041979 ], [ 71.78469364, 39.2794632 ], [ 73.67537927, 39.43123688 ], [ 73.92885217, 38.50581533 ], [ 74.25751428, 38.60650686 ], [ 74.86481571, 38.37884634 ], [ 74.82998579, 37.99000703 ], [ 74.98000248, 37.41999014 ], [ 73.94869592, 37.42156627 ], [ 73.26005578, 37.49525686 ], [ 72.63688968, 37.04755809 ], [ 72.19304081, 36.94828767 ], [ 71.8446383, 36.73817129 ], [ 71.44869348, 37.06564484 ], [ 71.54191776, 37.90577444 ], [ 71.23940392, 37.95326508 ], [ 71.34813114, 38.25890534 ], [ 70.80682051, 38.48628164 ], [ 70.37630415, 38.1383959 ], [ 70.27057417, 37.7351647 ], [ 70.1165784, 37.58822276 ], [ 69.51878543, 37.60899669 ], [ 69.19627282, 37.1511435 ], [ 68.85944584, 37.34433584 ], [ 68.13556237, 37.02311514 ], [ 67.82999963, 37.144994 ], [ 68.39203251, 38.15702525 ], [ 68.17602502, 38.90155345 ], [ 67.44221968, 39.14014354 ], [ 67.70142866, 39.58047842 ], [ 68.53641646, 39.53345287 ], [ 69.01163293, 40.08615815 ], [ 69.32949466, 40.72782441 ], [ 70.66662235, 40.96021332 ], [ 70.45815962, 40.49649486 ], [ 70.60140669, 40.21852733 ], [ 71.01419803, 40.24436555 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Turkmenistan", "sov_a3": "TKM", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Turkmenistan", "adm0_a3": "TKM", "geou_dif": 0.000000, "geounit": "Turkmenistan", "gu_a3": "TKM", "su_dif": 0.000000, "subunit": "Turkmenistan", "su_a3": "TKM", "brk_diff": 0.000000, "name": "Turkmenistan", "name_long": "Turkmenistan", "brk_a3": "TKM", "brk_name": "Turkmenistan", "brk_group": null, "abbrev": "Turkm.", "postal": "TM", "formal_en": "Turkmenistan", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Turkmenistan", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 2.000000, "mapcolor9": 1.000000, "mapcolor13": 9.000000, "pop_est": 4884887.000000, "gdp_md_est": 29780.000000, "pop_year": -99.000000, "lastcensus": 1995.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "TM", "iso_a3": "TKM", "iso_n3": "795", "un_a3": "795", "wb_a2": "TM", "wb_a3": "TKM", "woe_id": -99.000000, "adm0_a3_is": "TKM", "adm0_a3_us": "TKM", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Central Asia", "region_wb": "Europe & Central Asia", "name_len": 12.000000, "long_len": 12.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 66.51860681, 37.36278433 ], [ 66.21738488, 37.39379019 ], [ 65.74563073, 37.66116405 ], [ 65.58894779, 37.30521678 ], [ 64.74610518, 37.11181774 ], [ 64.54647912, 36.31207327 ], [ 63.98289595, 36.00795747 ], [ 63.19353845, 35.85716564 ], [ 62.98466231, 35.40404084 ], [ 62.23065148, 35.27066397 ], [ 61.21081709, 35.65007233 ], [ 61.12307051, 36.49159719 ], [ 60.37763797, 36.52738312 ], [ 59.234762, 37.41298798 ], [ 58.43615441, 37.52230948 ], [ 57.33043379, 38.02922944 ], [ 56.61936608, 38.12139435 ], [ 56.18037479, 37.93512665 ], [ 55.5115784, 37.96411713 ], [ 54.80030399, 37.39242076 ], [ 53.92159793, 37.19891836 ], [ 53.7355111, 37.90613618 ], [ 53.88092858, 38.952093 ], [ 53.10102787, 39.29057364 ], [ 53.35780806, 39.97528636 ], [ 52.69397261, 40.03362906 ], [ 52.91525109, 40.87652334 ], [ 53.85813928, 40.63103445 ], [ 54.73684533, 40.95101492 ], [ 54.00831099, 41.55121084 ], [ 53.72171349, 42.12319143 ], [ 52.91674971, 41.86811656 ], [ 52.81468876, 41.13537059 ], [ 52.50245975, 41.78331554 ], [ 52.94429325, 42.11603425 ], [ 54.07941776, 42.3241094 ], [ 54.75534549, 42.04397146 ], [ 55.45525109, 41.25985912 ], [ 55.96819136, 41.30864167 ], [ 57.09639123, 41.32231009 ], [ 56.9322152, 41.82602611 ], [ 57.78652998, 42.17055288 ], [ 58.62901086, 42.75155101 ], [ 59.97642215, 42.22308198 ], [ 60.08334069, 41.42514619 ], [ 60.465953, 41.22032665 ], [ 61.54717899, 41.26637035 ], [ 61.88271406, 41.08485688 ], [ 62.37426029, 40.05388622 ], [ 63.51801476, 39.36325654 ], [ 64.17022302, 38.89240672 ], [ 65.21599898, 38.40269501 ], [ 66.54615034, 37.97468496 ], [ 66.51860681, 37.36278433 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "East Timor", "sov_a3": "TLS", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "East Timor", "adm0_a3": "TLS", "geou_dif": 0.000000, "geounit": "East Timor", "gu_a3": "TLS", "su_dif": 0.000000, "subunit": "East Timor", "su_a3": "TLS", "brk_diff": 0.000000, "name": "Timor-Leste", "name_long": "Timor-Leste", "brk_a3": "TLS", "brk_name": "Timor-Leste", "brk_group": null, "abbrev": "T.L.", "postal": "TL", "formal_en": "Democratic Republic of Timor-Leste", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Timor-Leste", "name_alt": "East Timor", "mapcolor7": 2.000000, "mapcolor8": 2.000000, "mapcolor9": 4.000000, "mapcolor13": 3.000000, "pop_est": 1131612.000000, "gdp_md_est": 2520.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "TL", "iso_a3": "TLS", "iso_n3": "626", "un_a3": "626", "wb_a2": "TP", "wb_a3": "TMP", "woe_id": -99.000000, "adm0_a3_is": "TLS", "adm0_a3_us": "TLS", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "South-Eastern Asia", "region_wb": "East Asia & Pacific", "name_len": 11.000000, "long_len": 11.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 125.08852014, -9.39317311 ], [ 125.07001997, -9.08998748 ], [ 124.96868249, -8.89279022 ], [ 125.08624637, -8.6568873 ], [ 125.94707238, -8.43209482 ], [ 126.64470422, -8.39824676 ], [ 126.95724328, -8.27334482 ], [ 127.33592818, -8.39731658 ], [ 126.96799198, -8.66825612 ], [ 125.92588504, -9.10600718 ], [ 125.08852014, -9.39317311 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 5.000000, "sovereignt": "Trinidad and Tobago", "sov_a3": "TTO", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Trinidad and Tobago", "adm0_a3": "TTO", "geou_dif": 0.000000, "geounit": "Trinidad and Tobago", "gu_a3": "TTO", "su_dif": 0.000000, "subunit": "Trinidad and Tobago", "su_a3": "TTO", "brk_diff": 0.000000, "name": "Trinidad and Tobago", "name_long": "Trinidad and Tobago", "brk_a3": "TTO", "brk_name": "Trinidad and Tobago", "brk_group": null, "abbrev": "Tr.T.", "postal": "TT", "formal_en": "Republic of Trinidad and Tobago", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Trinidad and Tobago", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 6.000000, "mapcolor9": 2.000000, "mapcolor13": 5.000000, "pop_est": 1310000.000000, "gdp_md_est": 29010.000000, "pop_year": -99.000000, "lastcensus": 2011.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "2. High income: nonOECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "TT", "iso_a3": "TTO", "iso_n3": "780", "un_a3": "780", "wb_a2": "TT", "wb_a3": "TTO", "woe_id": -99.000000, "adm0_a3_is": "TTO", "adm0_a3_us": "TTO", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "North America", "region_un": "Americas", "subregion": "Caribbean", "region_wb": "Latin America & Caribbean", "name_len": 19.000000, "long_len": 19.000000, "abbrev_len": 5.000000, "tiny": 2.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -60.935, 10.11 ], [ -61.77, 10.0 ], [ -61.95, 10.09 ], [ -61.66, 10.365 ], [ -61.68, 10.76 ], [ -61.105, 10.89 ], [ -60.895, 10.855 ], [ -60.935, 10.11 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Tunisia", "sov_a3": "TUN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Tunisia", "adm0_a3": "TUN", "geou_dif": 0.000000, "geounit": "Tunisia", "gu_a3": "TUN", "su_dif": 0.000000, "subunit": "Tunisia", "su_a3": "TUN", "brk_diff": 0.000000, "name": "Tunisia", "name_long": "Tunisia", "brk_a3": "TUN", "brk_name": "Tunisia", "brk_group": null, "abbrev": "Tun.", "postal": "TN", "formal_en": "Republic of Tunisia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Tunisia", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 3.000000, "mapcolor9": 3.000000, "mapcolor13": 2.000000, "pop_est": 10486339.000000, "gdp_md_est": 81710.000000, "pop_year": -99.000000, "lastcensus": 2004.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "TN", "iso_a3": "TUN", "iso_n3": "788", "un_a3": "788", "wb_a2": "TN", "wb_a3": "TUN", "woe_id": -99.000000, "adm0_a3_is": "TUN", "adm0_a3_us": "TUN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Northern Africa", "region_wb": "Middle East & North Africa", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 11.48878747, 33.13699575 ], [ 11.43225345, 32.3689031 ], [ 10.94478967, 32.08181468 ], [ 10.63690148, 31.7614208 ], [ 9.95022505, 31.37606965 ], [ 10.05657515, 30.96183137 ], [ 9.97001712, 30.53932486 ], [ 9.48213993, 30.30755606 ], [ 9.05560265, 32.10269196 ], [ 8.43910282, 32.5062849 ], [ 8.43047285, 32.74833731 ], [ 7.61264164, 33.3441149 ], [ 7.52448164, 34.09737641 ], [ 8.14098148, 34.65514598 ], [ 8.37636763, 35.479876 ], [ 8.21782433, 36.43317699 ], [ 8.42096439, 36.94642731 ], [ 9.50999352, 37.34999441 ], [ 10.21000248, 37.23000174 ], [ 10.18065026, 36.72403779 ], [ 11.02886722, 37.09210318 ], [ 11.10002567, 36.89999604 ], [ 10.60000451, 36.41000011 ], [ 10.59328657, 35.94744436 ], [ 10.93951867, 35.69898408 ], [ 10.80784712, 34.83350719 ], [ 10.14959273, 34.33077302 ], [ 10.33965864, 33.78574169 ], [ 10.85683638, 33.76874014 ], [ 11.1085006, 33.2933428 ], [ 11.48878747, 33.13699575 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Turkey", "sov_a3": "TUR", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Turkey", "adm0_a3": "TUR", "geou_dif": 0.000000, "geounit": "Turkey", "gu_a3": "TUR", "su_dif": 0.000000, "subunit": "Turkey", "su_a3": "TUR", "brk_diff": 0.000000, "name": "Turkey", "name_long": "Turkey", "brk_a3": "TUR", "brk_name": "Turkey", "brk_group": null, "abbrev": "Tur.", "postal": "TR", "formal_en": "Republic of Turkey", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Turkey", "name_alt": null, "mapcolor7": 6.000000, "mapcolor8": 3.000000, "mapcolor9": 8.000000, "mapcolor13": 4.000000, "pop_est": 76805524.000000, "gdp_md_est": 902700.000000, "pop_year": -99.000000, "lastcensus": 2000.000000, "gdp_year": -99.000000, "economy": "4. Emerging region: MIKT", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "TR", "iso_a3": "TUR", "iso_n3": "792", "un_a3": "792", "wb_a2": "TR", "wb_a3": "TUR", "woe_id": -99.000000, "adm0_a3_is": "TUR", "adm0_a3_us": "TUR", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Western Asia", "region_wb": "Europe & Central Asia", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 36.91312707, 41.33535838 ], [ 38.34766483, 40.94858613 ], [ 39.51260664, 41.10276276 ], [ 40.37343265, 41.01367259 ], [ 41.5540841, 41.53565624 ], [ 42.61954878, 41.58317272 ], [ 43.5827458, 41.09214326 ], [ 43.75265791, 40.74020091 ], [ 43.6564364, 40.25356395 ], [ 44.40000858, 40.00500031 ], [ 44.7939897, 39.71300263 ], [ 44.10922529, 39.4281363 ], [ 44.42140262, 38.28128124 ], [ 44.22575565, 37.97158438 ], [ 44.77269901, 37.17044465 ], [ 44.7726771, 37.17043693 ], [ 44.29345178, 37.00151439 ], [ 43.94225874, 37.25622753 ], [ 42.7791256, 37.38526358 ], [ 42.3495911, 37.22987254 ], [ 41.21208947, 37.07435232 ], [ 40.67325931, 37.09127635 ], [ 39.52258019, 36.71605378 ], [ 38.69989139, 36.71292735 ], [ 38.16772749, 36.90121044 ], [ 37.0667611, 36.6230362 ], [ 36.73949426, 36.81752045 ], [ 36.68538903, 36.25969921 ], [ 36.41755008, 36.04061697 ], [ 36.14976281, 35.82153474 ], [ 35.782085, 36.27499543 ], [ 36.16082157, 36.65060558 ], [ 35.55093631, 36.56544282 ], [ 34.71455326, 36.79553213 ], [ 34.02689497, 36.21996003 ], [ 32.50915816, 36.10756379 ], [ 31.69959517, 36.64427521 ], [ 30.62162479, 36.6778649 ], [ 30.39109623, 36.26298066 ], [ 29.69997562, 36.14435741 ], [ 28.73290287, 36.67683137 ], [ 27.64118656, 36.65882213 ], [ 27.04876794, 37.65336091 ], [ 26.31821821, 38.20813325 ], [ 26.80470015, 38.9857602 ], [ 26.17078535, 39.46361217 ], [ 27.28001997, 40.42001374 ], [ 28.81997765, 40.4600113 ], [ 29.2400037, 41.21999075 ], [ 31.14593387, 41.08762157 ], [ 32.34797936, 41.73626415 ], [ 33.51328291, 42.01896007 ], [ 35.16770389, 42.04022492 ], [ 36.91312707, 41.33535838 ] ] ], [ [ [ 27.19237674, 40.6905657 ], [ 26.35800907, 40.15199392 ], [ 26.04335127, 40.61775361 ], [ 26.05694217, 40.82412344 ], [ 26.29460209, 40.9362613 ], [ 26.60419559, 41.56211457 ], [ 26.11704186, 41.82690461 ], [ 27.13573937, 42.14148489 ], [ 27.99672041, 42.00735871 ], [ 28.11552453, 41.62288605 ], [ 28.98844282, 41.29993419 ], [ 28.80643843, 41.05496206 ], [ 27.61901737, 40.99982331 ], [ 27.19237674, 40.6905657 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Taiwan", "sov_a3": "TWN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Taiwan", "adm0_a3": "TWN", "geou_dif": 0.000000, "geounit": "Taiwan", "gu_a3": "TWN", "su_dif": 0.000000, "subunit": "Taiwan", "su_a3": "TWN", "brk_diff": 1.000000, "name": "Taiwan", "name_long": "Taiwan", "brk_a3": "B77", "brk_name": "Taiwan", "brk_group": null, "abbrev": "Taiwan", "postal": "TW", "formal_en": null, "formal_fr": null, "note_adm0": null, "note_brk": "Self admin.; Claimed by China", "name_sort": "Taiwan", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 5.000000, "mapcolor9": 7.000000, "mapcolor13": 2.000000, "pop_est": 22974347.000000, "gdp_md_est": 712000.000000, "pop_year": -99.000000, "lastcensus": -99.000000, "gdp_year": -99.000000, "economy": "2. Developed region: nonG7", "income_grp": "2. High income: nonOECD", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "TW", "iso_a3": "TWN", "iso_n3": "158", "un_a3": "-099", "wb_a2": "-99", "wb_a3": "-99", "woe_id": -99.000000, "adm0_a3_is": "TWN", "adm0_a3_us": "TWN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Eastern Asia", "region_wb": "East Asia & Pacific", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 121.17563236, 22.79085725 ], [ 120.74707971, 21.9705714 ], [ 120.22008345, 22.81486095 ], [ 120.10618859, 23.55626272 ], [ 120.6946798, 24.53845083 ], [ 121.49504439, 25.29545889 ], [ 121.95124393, 24.99759593 ], [ 121.77781782, 24.39427359 ], [ 121.17563236, 22.79085725 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "United Republic of Tanzania", "sov_a3": "TZA", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "United Republic of Tanzania", "adm0_a3": "TZA", "geou_dif": 0.000000, "geounit": "Tanzania", "gu_a3": "TZA", "su_dif": 0.000000, "subunit": "Tanzania", "su_a3": "TZA", "brk_diff": 0.000000, "name": "Tanzania", "name_long": "Tanzania", "brk_a3": "TZA", "brk_name": "Tanzania", "brk_group": null, "abbrev": "Tanz.", "postal": "TZ", "formal_en": "United Republic of Tanzania", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Tanzania", "name_alt": null, "mapcolor7": 3.000000, "mapcolor8": 6.000000, "mapcolor9": 2.000000, "mapcolor13": 2.000000, "pop_est": 41048532.000000, "gdp_md_est": 54250.000000, "pop_year": -99.000000, "lastcensus": 2002.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "TZ", "iso_a3": "TZA", "iso_n3": "834", "un_a3": "834", "wb_a2": "TZ", "wb_a3": "TZA", "woe_id": -99.000000, "adm0_a3_is": "TZA", "adm0_a3_us": "TZA", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Eastern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 8.000000, "long_len": 8.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 30.76986, -1.01455 ], [ 31.86617, -1.02736 ], [ 31.86619736, -1.02735896 ], [ 31.86619999, -1.02737884 ], [ 31.83602095, -1.62930592 ], [ 31.64802209, -2.32921152 ], [ 31.92655806, -2.714511 ], [ 32.37309411, -2.48992523 ], [ 32.9517668, -2.43044565 ], [ 33.07672041, -2.54713104 ], [ 33.64717655, -2.30089284 ], [ 33.25174849, -1.95796803 ], [ 33.57942875, -1.50600595 ], [ 34.07262862, -1.05983164 ], [ 34.07262917, -1.05982515 ], [ 37.69869, -3.09699 ], [ 37.7669, -3.67712 ], [ 39.20222, -4.67677 ], [ 38.74054, -5.90895 ], [ 38.79977, -6.47566 ], [ 39.44, -6.84 ], [ 39.47, -7.1 ], [ 39.19469, -7.7039 ], [ 39.25203, -8.00781 ], [ 39.18652, -8.48551 ], [ 39.53574, -9.11237 ], [ 39.9496, -10.0984 ], [ 40.31658623, -10.31709775 ], [ 40.31659, -10.3171 ], [ 39.521, -10.89688 ], [ 38.42755659, -11.28520233 ], [ 37.82764, -11.26879 ], [ 37.47129, -11.56876 ], [ 36.77515099, -11.59453745 ], [ 36.51408166, -11.720938 ], [ 35.3123979, -11.43914642 ], [ 34.93283431, -11.47994429 ], [ 34.9370203, -11.46343434 ], [ 34.6078931, -11.08051198 ], [ 34.52422896, -10.03013681 ], [ 33.99557905, -9.49544077 ], [ 33.93879963, -9.69087147 ], [ 33.9387996, -9.69087156 ], [ 33.73972, -9.41715 ], [ 32.75937544, -9.23059905 ], [ 32.19186486, -8.93035898 ], [ 31.5563481, -8.76204884 ], [ 31.15775134, -8.59457875 ], [ 31.10725827, -8.56380814 ], [ 31.1072581, -8.56380779 ], [ 30.60415816, -7.5419166 ], [ 30.52803877, -6.92272959 ], [ 29.72204146, -6.24411468 ], [ 29.95122643, -5.86098561 ], [ 29.75842167, -5.46690114 ], [ 29.79195967, -5.04088063 ], [ 29.60008508, -4.89639332 ], [ 29.6476907, -4.4645691 ], [ 29.7535124, -4.45238942 ], [ 30.11632, -4.09012 ], [ 30.50554, -3.56858 ], [ 30.75224, -3.35931 ], [ 30.74301, -3.03431 ], [ 30.52766, -2.80762 ], [ 30.46967365, -2.41385476 ], [ 30.46967, -2.41383 ], [ 30.75830895, -2.28725026 ], [ 30.81613488, -1.69891408 ], [ 30.41910485, -1.13465911 ], [ 30.76986, -1.01455 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Uganda", "sov_a3": "UGA", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Uganda", "adm0_a3": "UGA", "geou_dif": 0.000000, "geounit": "Uganda", "gu_a3": "UGA", "su_dif": 0.000000, "subunit": "Uganda", "su_a3": "UGA", "brk_diff": 0.000000, "name": "Uganda", "name_long": "Uganda", "brk_a3": "UGA", "brk_name": "Uganda", "brk_group": null, "abbrev": "Uga.", "postal": "UG", "formal_en": "Republic of Uganda", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Uganda", "name_alt": null, "mapcolor7": 6.000000, "mapcolor8": 3.000000, "mapcolor9": 6.000000, "mapcolor13": 4.000000, "pop_est": 32369558.000000, "gdp_md_est": 39380.000000, "pop_year": -99.000000, "lastcensus": 2002.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "UG", "iso_a3": "UGA", "iso_n3": "800", "un_a3": "800", "wb_a2": "UG", "wb_a3": "UGA", "woe_id": -99.000000, "adm0_a3_is": "UGA", "adm0_a3_us": "UGA", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Eastern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 34.005, 4.24988495 ], [ 34.47913, 3.5556 ], [ 34.59607, 3.05374 ], [ 35.03599, 1.90584 ], [ 34.6721, 1.17694 ], [ 34.18, 0.515 ], [ 33.89356897, 0.10981354 ], [ 33.8940477, 0.05978836 ], [ 33.85036828, 0.12815786 ], [ 33.33184696, 0.32499339 ], [ 32.90613651, 0.08676504 ], [ 32.27284183, -0.05612029 ], [ 31.81514367, -0.64042571 ], [ 31.86619736, -1.02735896 ], [ 31.86617, -1.02736 ], [ 30.76986, -1.01455 ], [ 30.41910485, -1.13465911 ], [ 29.82151859, -1.44332244 ], [ 29.57946618, -1.34131316 ], [ 29.58783776, -0.58740569 ], [ 29.8195, -0.2053 ], [ 29.87577884, 0.59737987 ], [ 30.0861536, 1.06231273 ], [ 30.46850752, 1.58380545 ], [ 30.85267012, 1.84939647 ], [ 31.1741492, 2.20446524 ], [ 30.77332, 2.33989 ], [ 30.83385, 3.50917 ], [ 30.83385242, 3.5091716 ], [ 31.24556, 3.7819 ], [ 31.88145, 3.55827 ], [ 32.68642, 3.79232 ], [ 33.39, 3.79 ], [ 34.005, 4.24988495 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Ukraine", "sov_a3": "UKR", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Ukraine", "adm0_a3": "UKR", "geou_dif": 0.000000, "geounit": "Ukraine", "gu_a3": "UKR", "su_dif": 0.000000, "subunit": "Ukraine", "su_a3": "UKR", "brk_diff": 0.000000, "name": "Ukraine", "name_long": "Ukraine", "brk_a3": "UKR", "brk_name": "Ukraine", "brk_group": null, "abbrev": "Ukr.", "postal": "UA", "formal_en": "Ukraine", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Ukraine", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 1.000000, "mapcolor9": 6.000000, "mapcolor13": 3.000000, "pop_est": 45700395.000000, "gdp_md_est": 339800.000000, "pop_year": -99.000000, "lastcensus": 2001.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "UA", "iso_a3": "UKR", "iso_n3": "804", "un_a3": "804", "wb_a2": "UA", "wb_a3": "UKR", "woe_id": -99.000000, "adm0_a3_is": "UKR", "adm0_a3_us": "UKR", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Europe", "region_un": "Europe", "subregion": "Eastern Europe", "region_wb": "Europe & Central Asia", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 33.75269982, 52.33507457 ], [ 34.39173058, 51.76888174 ], [ 34.14197839, 51.56641348 ], [ 34.22481571, 51.25599315 ], [ 35.02218306, 51.20757233 ], [ 35.37792362, 50.77395539 ], [ 35.35611616, 50.57719737 ], [ 36.62616784, 50.22559093 ], [ 37.39345951, 50.38395336 ], [ 38.01063114, 49.91566153 ], [ 38.59498823, 49.9264619 ], [ 40.06905847, 49.60105541 ], [ 40.08078902, 49.30742992 ], [ 39.67466393, 48.78381847 ], [ 39.89563236, 48.2324051 ], [ 39.73827762, 47.89893708 ], [ 38.77058475, 47.82560822 ], [ 38.25511234, 47.54640046 ], [ 38.22353804, 47.10218985 ], [ 37.42513716, 47.02222057 ], [ 36.75985477, 46.69870026 ], [ 35.82368452, 46.64596446 ], [ 34.96234175, 46.27319652 ], [ 35.02078779, 45.65121898 ], [ 35.51000858, 45.40999339 ], [ 36.529998, 45.46998973 ], [ 36.33471276, 45.11321564 ], [ 35.23999922, 44.93999624 ], [ 33.88251102, 44.36147858 ], [ 33.32642093, 44.56487702 ], [ 33.54692427, 45.03477082 ], [ 32.45417443, 45.32746613 ], [ 32.63080448, 45.5191857 ], [ 33.58816206, 45.85156851 ], [ 33.29856734, 46.08059846 ], [ 31.74414025, 46.33334789 ], [ 31.67530724, 46.70624502 ], [ 30.74874881, 46.58310008 ], [ 30.37760868, 46.03241018 ], [ 29.60328902, 45.29330801 ], [ 29.14972497, 45.46492544 ], [ 28.67977949, 45.30403087 ], [ 28.2335535, 45.48828319 ], [ 28.4852694, 45.59690705 ], [ 28.65998742, 45.93998688 ], [ 28.93371748, 46.25883047 ], [ 28.86297245, 46.43788931 ], [ 29.07210697, 46.51767772 ], [ 29.17065392, 46.3792624 ], [ 29.75997196, 46.3499877 ], [ 30.02465864, 46.42393667 ], [ 29.83821008, 46.52532583 ], [ 29.90885176, 46.67436066 ], [ 29.55967411, 46.92858287 ], [ 29.41513513, 47.34664521 ], [ 29.05086795, 47.51022696 ], [ 29.1226982, 47.84909516 ], [ 28.67089115, 48.11814851 ], [ 28.25954675, 48.15556224 ], [ 27.52253747, 48.46711945 ], [ 26.85782352, 48.36821076 ], [ 26.61933679, 48.22072622 ], [ 26.19745039, 48.22088125 ], [ 25.9459412, 47.98714875 ], [ 25.20774336, 47.89105642 ], [ 24.86631717, 47.73752574 ], [ 24.40205611, 47.98187775 ], [ 23.76095829, 47.98559846 ], [ 23.14223636, 48.09634105 ], [ 22.71053145, 47.88219392 ], [ 22.64081994, 48.15023957 ], [ 22.08560835, 48.42226431 ], [ 22.28084191, 48.82539216 ], [ 22.55813765, 49.08573802 ], [ 22.7764189, 49.02739533 ], [ 22.51845015, 49.47677359 ], [ 23.42650842, 50.30850576 ], [ 23.9227572, 50.42488109 ], [ 24.02998579, 50.7054066 ], [ 23.52707075, 51.57845409 ], [ 24.00507775, 51.61744396 ], [ 24.55310632, 51.88846101 ], [ 25.32778771, 51.91065603 ], [ 26.33795861, 51.83228872 ], [ 27.4540662, 51.59230337 ], [ 28.24161502, 51.57222708 ], [ 28.61761275, 51.42771393 ], [ 28.99283532, 51.60204438 ], [ 29.25493819, 51.36823436 ], [ 30.15736372, 51.41613841 ], [ 30.55511722, 51.31950349 ], [ 30.61945438, 51.8228061 ], [ 30.92754927, 52.04235342 ], [ 31.78599245, 52.10167757 ], [ 31.78599816, 52.10167796 ], [ 32.15941206, 52.06126699 ], [ 32.41205814, 52.28869497 ], [ 32.71576053, 52.23846548 ], [ 33.75269982, 52.33507457 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Uruguay", "sov_a3": "URY", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Uruguay", "adm0_a3": "URY", "geou_dif": 0.000000, "geounit": "Uruguay", "gu_a3": "URY", "su_dif": 0.000000, "subunit": "Uruguay", "su_a3": "URY", "brk_diff": 0.000000, "name": "Uruguay", "name_long": "Uruguay", "brk_a3": "URY", "brk_name": "Uruguay", "brk_group": null, "abbrev": "Ury.", "postal": "UY", "formal_en": "Oriental Republic of Uruguay", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Uruguay", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 2.000000, "mapcolor9": 2.000000, "mapcolor13": 10.000000, "pop_est": 3494382.000000, "gdp_md_est": 43160.000000, "pop_year": -99.000000, "lastcensus": 2004.000000, "gdp_year": -99.000000, "economy": "5. Emerging region: G20", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "UY", "iso_a3": "URY", "iso_n3": "858", "un_a3": "858", "wb_a2": "UY", "wb_a3": "URY", "woe_id": -99.000000, "adm0_a3_is": "URY", "adm0_a3_us": "URY", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "South America", "region_un": "Americas", "subregion": "South America", "region_wb": "Latin America & Caribbean", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -53.37366167, -33.76837778 ], [ -53.80642595, -34.39681487 ], [ -54.93586605, -34.95264658 ], [ -55.67408973, -34.75265879 ], [ -56.215297, -34.85983571 ], [ -57.13968502, -34.43045623 ], [ -57.81786068, -34.4625473 ], [ -58.42707414, -33.90945444 ], [ -58.34961117, -33.26318898 ], [ -58.13264767, -33.04056691 ], [ -58.14244036, -32.04450368 ], [ -57.8749373, -31.01655608 ], [ -57.62513343, -30.21629485 ], [ -56.97602576, -30.10968637 ], [ -55.97324459, -30.88307586 ], [ -55.60151018, -30.85387868 ], [ -54.57245154, -31.49451141 ], [ -53.78795163, -32.04724253 ], [ -53.209589, -32.72766611 ], [ -53.65054399, -33.20200408 ], [ -53.37366167, -33.76837778 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "United States of America", "sov_a3": "US1", "adm0_dif": 1.000000, "level": 2.000000, "type": "Country", "admin": "United States of America", "adm0_a3": "USA", "geou_dif": 0.000000, "geounit": "United States of America", "gu_a3": "USA", "su_dif": 0.000000, "subunit": "United States of America", "su_a3": "USA", "brk_diff": 0.000000, "name": "United States", "name_long": "United States", "brk_a3": "USA", "brk_name": "United States", "brk_group": null, "abbrev": "U.S.A.", "postal": "US", "formal_en": "United States of America", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "United States of America", "name_alt": null, "mapcolor7": 4.000000, "mapcolor8": 5.000000, "mapcolor9": 1.000000, "mapcolor13": 1.000000, "pop_est": 313973000.000000, "gdp_md_est": 15094000.000000, "pop_year": 0.000000, "lastcensus": 2010.000000, "gdp_year": 0.000000, "economy": "1. Developed region: G7", "income_grp": "1. High income: OECD", "wikipedia": 0.000000, "fips_10": null, "iso_a2": "US", "iso_a3": "USA", "iso_n3": "840", "un_a3": "840", "wb_a2": "US", "wb_a3": "USA", "woe_id": -99.000000, "adm0_a3_is": "USA", "adm0_a3_us": "USA", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "North America", "region_un": "Americas", "subregion": "Northern America", "region_wb": "North America", "name_len": 13.000000, "long_len": 13.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -155.54211, 19.08348 ], [ -155.68817, 18.91619 ], [ -155.93665, 19.05939 ], [ -155.90806, 19.33888 ], [ -156.07347, 19.70294 ], [ -156.02368, 19.81422 ], [ -155.85008, 19.97729 ], [ -155.91907, 20.17395 ], [ -155.86108, 20.26721 ], [ -155.78505, 20.2487 ], [ -155.40214, 20.07975 ], [ -155.22452, 19.99302 ], [ -155.06226, 19.8591 ], [ -154.80741, 19.50871 ], [ -154.83147, 19.45328 ], [ -155.22217, 19.23972 ], [ -155.54211, 19.08348 ] ] ], [ [ [ -156.07926, 20.64397 ], [ -156.41445, 20.57241 ], [ -156.58673, 20.783 ], [ -156.70167, 20.8643 ], [ -156.71055, 20.92676 ], [ -156.61258, 21.01249 ], [ -156.25711, 20.91745 ], [ -155.99566, 20.76404 ], [ -156.07926, 20.64397 ] ] ], [ [ [ -156.75824, 21.17684 ], [ -156.78933, 21.06873 ], [ -157.32521, 21.09777 ], [ -157.25027, 21.21958 ], [ -156.75824, 21.17684 ] ] ], [ [ [ -157.65283, 21.32217 ], [ -157.70703, 21.26442 ], [ -157.7786, 21.27729 ], [ -158.12667, 21.31244 ], [ -158.2538, 21.53919 ], [ -158.29265, 21.57912 ], [ -158.0252, 21.71696 ], [ -157.94161, 21.65272 ], [ -157.65283, 21.32217 ] ] ], [ [ [ -159.34512, 21.982 ], [ -159.46372, 21.88299 ], [ -159.80051, 22.06533 ], [ -159.74877, 22.1382 ], [ -159.5962, 22.23618 ], [ -159.36569, 22.21494 ], [ -159.34512, 21.982 ] ] ], [ [ [ -94.81758, 49.38905 ], [ -94.64, 48.84 ], [ -94.32914, 48.67074 ], [ -93.63087, 48.60926 ], [ -92.61, 48.45 ], [ -91.64, 48.14 ], [ -90.83, 48.27 ], [ -89.6, 48.01 ], [ -89.59999266, 48.01000022 ], [ -89.60000342, 48.00998973 ], [ -90.61999285, 47.68000987 ], [ -91.33000119, 47.28000845 ], [ -92.00877113, 46.85843212 ], [ -92.01192339, 46.71167105 ], [ -91.00999488, 46.92000458 ], [ -90.39703488, 46.5764855 ], [ -89.62498898, 46.8308369 ], [ -88.82260902, 47.15479645 ], [ -87.93992388, 47.48591319 ], [ -88.26122209, 46.95858104 ], [ -87.69427995, 46.83104361 ], [ -86.9900077, 46.45000743 ], [ -86.10262, 46.67265534 ], [ -85.11999264, 46.76001435 ], [ -84.91000546, 46.4800056 ], [ -84.6049078, 46.43959463 ], [ -84.60411309, 46.44087504 ], [ -84.6049, 46.4396 ], [ -84.33670581, 46.40877067 ], [ -84.33670712, 46.40876964 ], [ -83.83919227, 46.01021516 ], [ -84.71999122, 45.9199881 ], [ -84.75355506, 45.92448395 ], [ -85.53999285, 46.03000723 ], [ -86.31999691, 45.8299936 ], [ -87.00000709, 45.73999909 ], [ -87.59643063, 45.09370779 ], [ -87.98831885, 44.73331635 ], [ -87.85282325, 44.61505484 ], [ -87.1180619, 45.25933076 ], [ -86.96747677, 45.26287059 ], [ -87.48635983, 44.49335684 ], [ -87.71221168, 43.79650015 ], [ -87.9021484, 43.23051402 ], [ -87.7767297, 42.74085399 ], [ -87.80344642, 42.49399567 ], [ -87.79569495, 42.2341149 ], [ -87.52617652, 41.7085139 ], [ -87.43421831, 41.64071442 ], [ -87.09444577, 41.64616629 ], [ -86.82443641, 41.75618541 ], [ -86.62191647, 41.89441987 ], [ -86.21604977, 42.38170279 ], [ -86.18842872, 43.04140412 ], [ -86.52001055, 43.65999685 ], [ -86.47027198, 44.08423452 ], [ -86.20935767, 44.5747989 ], [ -85.95983802, 44.91059235 ], [ -85.55999162, 45.15000926 ], [ -85.46710324, 44.81457754 ], [ -85.29044735, 45.3082425 ], [ -85.06999569, 45.40999339 ], [ -84.93000424, 45.78999604 ], [ -84.08000444, 45.58998241 ], [ -83.33999793, 45.20000621 ], [ -83.25878842, 44.74574453 ], [ -83.34999732, 44.29001008 ], [ -83.89998959, 43.88998282 ], [ -83.84870073, 43.63831859 ], [ -83.65000485, 43.62999868 ], [ -83.02999101, 44.06999767 ], [ -82.65998776, 43.97000377 ], [ -82.47999875, 43.39001333 ], [ -82.4300018, 42.98001252 ], [ -82.42999111, 42.98001798 ], [ -82.43, 42.98 ], [ -82.9, 42.43 ], [ -83.11999152, 42.0800135 ], [ -83.12001136, 42.08001577 ], [ -83.46283281, 41.69396699 ], [ -82.84610043, 41.48710623 ], [ -82.3474487, 41.43592072 ], [ -81.62351356, 41.56893586 ], [ -81.03119829, 41.84550812 ], [ -80.51644935, 41.98033194 ], [ -79.76220598, 42.2696166 ], [ -78.90057899, 42.86671194 ], [ -78.92000453, 42.96497627 ], [ -78.92, 42.965 ], [ -79.00870152, 43.26559959 ], [ -78.53499407, 43.3799881 ], [ -77.74915056, 43.34283275 ], [ -76.93000159, 43.25999543 ], [ -76.17999569, 43.59000113 ], [ -76.23926856, 43.9791505 ], [ -76.34161477, 44.11906006 ], [ -75.31821, 44.81645 ], [ -74.867, 45.00048 ], [ -73.34783, 45.00738 ], [ -71.50506, 45.0082 ], [ -71.405, 45.255 ], [ -71.08482, 45.30524 ], [ -70.66, 45.46 ], [ -70.305, 45.915 ], [ -69.99997, 46.69307 ], [ -69.237216, 47.447781 ], [ -68.905, 47.185 ], [ -68.23444, 47.35486 ], [ -67.79046, 47.06636 ], [ -67.79134, 45.70281 ], [ -67.13741, 45.13753 ], [ -66.96466, 44.8097 ], [ -68.03252, 44.3252 ], [ -69.06, 43.98 ], [ -70.11617, 43.68405 ], [ -70.64547563, 43.09023835 ], [ -70.81489, 42.8653 ], [ -70.825, 42.335 ], [ -70.495, 41.805 ], [ -70.08, 41.78 ], [ -70.185, 42.145 ], [ -69.88497, 41.92283 ], [ -69.96503, 41.63717 ], [ -70.64, 41.475 ], [ -71.12039, 41.49445 ], [ -71.86, 41.32 ], [ -72.295, 41.27 ], [ -72.87643, 41.22065 ], [ -73.71, 40.93110235 ], [ -72.24126, 41.11948 ], [ -71.945, 40.93 ], [ -73.345, 40.63 ], [ -73.982, 40.628 ], [ -73.952325, 40.75075 ], [ -74.25671, 40.47351 ], [ -73.96244, 40.42763 ], [ -74.17838, 39.70926 ], [ -74.90604, 38.93954 ], [ -74.98041, 39.1964 ], [ -75.20002, 39.24845 ], [ -75.52805, 39.4985 ], [ -75.32, 38.96 ], [ -75.07183476, 38.78203223 ], [ -75.05673, 38.40412 ], [ -75.37747, 38.01551 ], [ -75.94023, 37.21689 ], [ -76.03127, 37.2566 ], [ -75.72205, 37.93705 ], [ -76.23287, 38.319215 ], [ -76.35, 39.15 ], [ -76.542725, 38.717615 ], [ -76.32933, 38.08326 ], [ -76.98999793, 38.23999177 ], [ -76.30162, 37.917945 ], [ -76.25874, 36.9664 ], [ -75.9718, 36.89726 ], [ -75.86804, 36.55125 ], [ -75.72749, 35.55074 ], [ -76.36318, 34.80854 ], [ -77.397635, 34.51201 ], [ -78.05496, 33.92547 ], [ -78.55435, 33.86133 ], [ -79.06067, 33.49395 ], [ -79.20357, 33.15839 ], [ -80.301325, 32.509355 ], [ -80.86498, 32.0333 ], [ -81.33629, 31.44049 ], [ -81.49042, 30.72999 ], [ -81.31371, 30.03552 ], [ -80.98, 29.18 ], [ -80.535585, 28.47213 ], [ -80.53, 28.04 ], [ -80.05653928, 26.88 ], [ -80.088015, 26.205765 ], [ -80.13156, 25.816775 ], [ -80.38103, 25.20616 ], [ -80.68, 25.08 ], [ -81.17213, 25.20126 ], [ -81.33, 25.64 ], [ -81.71, 25.87 ], [ -82.24, 26.73 ], [ -82.70515, 27.49504 ], [ -82.85526, 27.88624 ], [ -82.65, 28.55 ], [ -82.93, 29.1 ], [ -83.70959, 29.93656 ], [ -84.1, 30.09 ], [ -85.10882, 29.63615 ], [ -85.28784, 29.68612 ], [ -85.7731, 30.15261 ], [ -86.4, 30.4 ], [ -87.53036, 30.27433 ], [ -88.41782, 30.3849 ], [ -89.18049, 30.31598 ], [ -89.59383118, 30.159994 ], [ -89.413735, 29.89419 ], [ -89.43, 29.48864 ], [ -89.21767, 29.29108 ], [ -89.40823, 29.15961 ], [ -89.77928, 29.30714 ], [ -90.15463, 29.11743 ], [ -90.880225, 29.148535 ], [ -91.626785, 29.677 ], [ -92.49906, 29.5523 ], [ -93.22637, 29.78375 ], [ -93.84842, 29.71363 ], [ -94.69, 29.48 ], [ -95.60026, 28.73863 ], [ -96.59404, 28.30748 ], [ -97.14, 27.83 ], [ -97.37, 27.38 ], [ -97.38, 26.69 ], [ -97.33, 26.21 ], [ -97.14, 25.87 ], [ -97.53, 25.84 ], [ -98.24, 26.06 ], [ -99.02, 26.37 ], [ -99.3, 26.84 ], [ -99.52, 27.54 ], [ -100.11, 28.11 ], [ -100.45584, 28.69612 ], [ -100.9576, 29.38071 ], [ -101.6624, 29.7793 ], [ -102.48, 29.76 ], [ -103.11, 28.97 ], [ -103.94, 29.27 ], [ -104.45697, 29.57196 ], [ -104.70575, 30.12173 ], [ -105.03737, 30.64402 ], [ -105.63159, 31.08383 ], [ -106.1429, 31.39995 ], [ -106.50759, 31.75452 ], [ -108.24, 31.75485372 ], [ -108.24194, 31.34222 ], [ -109.035, 31.34194 ], [ -111.02361, 31.33472 ], [ -113.30498, 32.03914 ], [ -114.815, 32.52528 ], [ -114.72139, 32.72083 ], [ -115.99135, 32.61239 ], [ -117.12776, 32.53534 ], [ -117.29593769, 33.04622462 ], [ -117.944, 33.62123643 ], [ -118.41060228, 33.74090922 ], [ -118.51989482, 34.02778158 ], [ -119.081, 34.078 ], [ -119.43884064, 34.34847718 ], [ -120.36778, 34.44711 ], [ -120.62286, 34.60855 ], [ -120.74433, 35.15686 ], [ -121.71457, 36.16153 ], [ -122.54747, 37.55176 ], [ -122.51201, 37.78339 ], [ -122.95319, 38.11371 ], [ -123.7272, 38.95166 ], [ -123.86517, 39.76699 ], [ -124.39807, 40.3132 ], [ -124.17886, 41.14202 ], [ -124.2137, 41.99964 ], [ -124.53284, 42.76599 ], [ -124.14214, 43.70838 ], [ -124.020535, 44.615895 ], [ -123.89893, 45.52341 ], [ -124.079635, 46.86475 ], [ -124.39567, 47.72017 ], [ -124.68721008, 48.18443298 ], [ -124.56610107, 48.37971497 ], [ -123.12, 48.04 ], [ -122.58736, 47.096 ], [ -122.34, 47.36 ], [ -122.5, 48.18 ], [ -122.84, 49.0 ], [ -120.0, 49.0 ], [ -117.03121, 49.0 ], [ -116.04818, 49.0 ], [ -113.0, 49.0 ], [ -110.05, 49.0 ], [ -107.05, 49.0 ], [ -104.04826, 48.99986 ], [ -100.65, 49.0 ], [ -97.22872, 49.0007 ], [ -95.15906951, 49.0 ], [ -95.15609, 49.38425 ], [ -94.81758, 49.38905 ] ] ], [ [ [ -153.00631405, 57.11584219 ], [ -154.0050903, 56.73467683 ], [ -154.51640276, 56.99274893 ], [ -154.6709928, 57.46119579 ], [ -153.76277951, 57.81657461 ], [ -153.22872942, 57.96896841 ], [ -152.56479062, 57.90142731 ], [ -152.14114722, 57.59105866 ], [ -153.00631405, 57.11584219 ] ] ], [ [ [ -165.57916419, 59.90998688 ], [ -166.19277015, 59.75444082 ], [ -166.84833737, 59.94140616 ], [ -167.45527707, 60.21306916 ], [ -166.46779212, 60.38416983 ], [ -165.67442969, 60.29360688 ], [ -165.57916419, 59.90998688 ] ] ], [ [ [ -171.73165687, 63.78251537 ], [ -171.11443356, 63.59219107 ], [ -170.49111243, 63.69497549 ], [ -169.68250546, 63.43111563 ], [ -168.68943946, 63.29750621 ], [ -168.77194088, 63.18859813 ], [ -169.52943987, 62.97693146 ], [ -170.2905562, 63.19443757 ], [ -170.67138567, 63.37582185 ], [ -171.55306312, 63.31778921 ], [ -171.7911106, 63.40584585 ], [ -171.73165687, 63.78251537 ] ] ], [ [ [ -155.06779029, 71.14777639 ], [ -154.34416521, 70.6964086 ], [ -153.90000627, 70.88998851 ], [ -152.21000607, 70.82999217 ], [ -152.27000241, 70.60000621 ], [ -150.73999244, 70.43001659 ], [ -149.72000302, 70.53001048 ], [ -147.61336158, 70.21403494 ], [ -145.6899898, 70.12000967 ], [ -144.92001096, 69.98999177 ], [ -143.58944618, 70.15251415 ], [ -142.07251035, 69.85193818 ], [ -140.986, 69.712 ], [ -140.98598752, 69.71199839 ], [ -140.98598833, 69.7119984 ], [ -140.99249875, 66.00002859 ], [ -140.99776975, 60.3063968 ], [ -140.01299782, 60.27683788 ], [ -139.03900042, 60.00000723 ], [ -138.34089, 59.56211 ], [ -137.4525, 58.905 ], [ -136.47972, 59.46389 ], [ -135.47583, 59.78778 ], [ -134.945, 59.27056 ], [ -134.27111, 58.86111 ], [ -133.35554888, 58.41028514 ], [ -132.73042, 57.69289 ], [ -131.70781, 56.55212 ], [ -130.00778, 55.91583 ], [ -129.97999426, 55.28499787 ], [ -130.53610895, 54.80275448 ], [ -130.53611019, 54.8027534 ], [ -131.08581824, 55.17890616 ], [ -131.96721147, 55.49777558 ], [ -132.25001074, 56.36999624 ], [ -133.53918108, 57.17888744 ], [ -134.07806292, 58.12306753 ], [ -135.03821103, 58.18771475 ], [ -136.62806231, 58.21220938 ], [ -137.80000628, 58.49999543 ], [ -139.86778704, 59.53776154 ], [ -140.82527382, 59.7275174 ], [ -142.57444354, 60.08444652 ], [ -143.95888099, 59.99918041 ], [ -145.92555682, 60.45860973 ], [ -147.11437395, 60.88465607 ], [ -148.2243062, 60.67298941 ], [ -148.01806556, 59.97832897 ], [ -148.57082252, 59.91417268 ], [ -149.72785784, 59.70565827 ], [ -150.60824337, 59.36821117 ], [ -151.71639279, 59.15582103 ], [ -151.85943315, 59.74498404 ], [ -151.409719, 60.72580272 ], [ -150.34694149, 61.03358755 ], [ -150.62111081, 61.28442495 ], [ -151.8958392, 60.72719798 ], [ -152.57832984, 60.06165721 ], [ -154.01917213, 59.35027945 ], [ -153.28751136, 58.86472769 ], [ -154.23249244, 58.1463736 ], [ -155.30749142, 57.7277945 ], [ -156.30833472, 57.42277436 ], [ -156.55609738, 56.97998485 ], [ -158.11721656, 56.4636081 ], [ -158.4333213, 55.99415355 ], [ -159.6033274, 55.5666861 ], [ -160.28971961, 55.64358063 ], [ -161.22304766, 55.36473461 ], [ -162.23776608, 55.02418692 ], [ -163.06944658, 54.68973705 ], [ -164.78556922, 54.40417308 ], [ -164.94222633, 54.57222484 ], [ -163.84833961, 55.03943146 ], [ -162.87000139, 55.34804312 ], [ -161.80417497, 55.89498648 ], [ -160.5636047, 56.00805451 ], [ -160.07055986, 56.41805532 ], [ -158.68444292, 57.01667512 ], [ -158.46109738, 57.21692129 ], [ -157.72277035, 57.57000052 ], [ -157.55027442, 58.32832632 ], [ -157.04167497, 58.91888459 ], [ -158.19473121, 58.61580231 ], [ -158.51721798, 58.78778148 ], [ -159.05860613, 58.4241861 ], [ -159.71166704, 58.93139029 ], [ -159.98128883, 58.57254914 ], [ -160.35527117, 59.07112336 ], [ -161.35500343, 58.67083771 ], [ -161.9688936, 58.67166454 ], [ -162.05498654, 59.26692536 ], [ -161.8741707, 59.63362132 ], [ -162.51805905, 59.98972362 ], [ -163.81834144, 59.79805573 ], [ -164.66221758, 60.26748444 ], [ -165.3463877, 60.50749563 ], [ -165.35083188, 61.07389517 ], [ -166.12137916, 61.50001903 ], [ -165.73445187, 62.07499685 ], [ -164.91917864, 62.63307648 ], [ -164.5625079, 63.14637849 ], [ -163.75333249, 63.21944896 ], [ -163.06722449, 63.05945873 ], [ -162.26055539, 63.54193574 ], [ -161.53444984, 63.45581696 ], [ -160.77250668, 63.7661081 ], [ -160.95833513, 64.22279857 ], [ -161.51806841, 64.40278758 ], [ -160.77777768, 64.78860383 ], [ -161.39192624, 64.77723501 ], [ -162.4530501, 64.55944469 ], [ -162.75778602, 64.33860546 ], [ -163.54639421, 64.55916047 ], [ -164.96082984, 64.4469451 ], [ -166.42528826, 64.68667206 ], [ -166.84500424, 65.08889558 ], [ -168.11056007, 65.66999706 ], [ -166.70527117, 66.08831778 ], [ -164.47470964, 66.57666006 ], [ -163.65251177, 66.57666006 ], [ -163.78860165, 66.07720734 ], [ -161.67777442, 66.1161197 ], [ -162.48971453, 66.73556509 ], [ -163.71971697, 67.11639456 ], [ -164.43099138, 67.6163382 ], [ -165.39028683, 68.04277212 ], [ -166.76444068, 68.35887686 ], [ -166.2047074, 68.88303091 ], [ -164.43081051, 68.91553539 ], [ -163.16861365, 69.37111481 ], [ -162.93056617, 69.85806184 ], [ -161.90889726, 70.33332998 ], [ -160.93479652, 70.44768993 ], [ -159.03917579, 70.89164216 ], [ -158.11972287, 70.82472118 ], [ -156.58082455, 71.35776358 ], [ -155.06779029, 71.14777639 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Uzbekistan", "sov_a3": "UZB", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Uzbekistan", "adm0_a3": "UZB", "geou_dif": 0.000000, "geounit": "Uzbekistan", "gu_a3": "UZB", "su_dif": 0.000000, "subunit": "Uzbekistan", "su_a3": "UZB", "brk_diff": 0.000000, "name": "Uzbekistan", "name_long": "Uzbekistan", "brk_a3": "UZB", "brk_name": "Uzbekistan", "brk_group": null, "abbrev": "Uzb.", "postal": "UZ", "formal_en": "Republic of Uzbekistan", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Uzbekistan", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 3.000000, "mapcolor9": 5.000000, "mapcolor13": 4.000000, "pop_est": 27606007.000000, "gdp_md_est": 71670.000000, "pop_year": -99.000000, "lastcensus": 1989.000000, "gdp_year": -99.000000, "economy": "6. Developing region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "UZ", "iso_a3": "UZB", "iso_n3": "860", "un_a3": "860", "wb_a2": "UZ", "wb_a3": "UZB", "woe_id": -99.000000, "adm0_a3_is": "UZB", "adm0_a3_us": "UZB", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Central Asia", "region_wb": "Europe & Central Asia", "name_len": 10.000000, "long_len": 10.000000, "abbrev_len": 4.000000, "tiny": 5.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 70.96231489, 42.26615428 ], [ 71.25924767, 42.16771068 ], [ 70.42002241, 41.51999828 ], [ 71.15785851, 41.14358714 ], [ 71.87011478, 41.39290009 ], [ 73.05541711, 40.86603303 ], [ 71.77487512, 40.14584443 ], [ 71.01419803, 40.24436555 ], [ 70.60140669, 40.21852733 ], [ 70.45815962, 40.49649486 ], [ 70.66662235, 40.96021332 ], [ 69.32949466, 40.72782441 ], [ 69.01163293, 40.08615815 ], [ 68.53641646, 39.53345287 ], [ 67.70142866, 39.58047842 ], [ 67.44221968, 39.14014354 ], [ 68.17602502, 38.90155345 ], [ 68.39203251, 38.15702525 ], [ 67.82999963, 37.144994 ], [ 67.0757821, 37.35614391 ], [ 66.51860681, 37.36278433 ], [ 66.54615034, 37.97468496 ], [ 65.21599898, 38.40269501 ], [ 64.17022302, 38.89240672 ], [ 63.51801476, 39.36325654 ], [ 62.37426029, 40.05388622 ], [ 61.88271406, 41.08485688 ], [ 61.54717899, 41.26637035 ], [ 60.465953, 41.22032665 ], [ 60.08334069, 41.42514619 ], [ 59.97642215, 42.22308198 ], [ 58.62901086, 42.75155101 ], [ 57.78652998, 42.17055288 ], [ 56.9322152, 41.82602611 ], [ 57.09639123, 41.32231009 ], [ 55.96819136, 41.30864167 ], [ 55.92891727, 44.99585847 ], [ 58.50312707, 45.58680431 ], [ 58.68998905, 45.50001374 ], [ 60.23997196, 44.78403677 ], [ 61.05831994, 44.40581696 ], [ 62.01330041, 43.50447663 ], [ 63.18578698, 43.65007498 ], [ 64.90082442, 43.72808055 ], [ 66.09801232, 42.99766002 ], [ 66.02339155, 41.99464631 ], [ 66.51064863, 41.98764415 ], [ 66.71404707, 41.16844351 ], [ 67.98585575, 41.13599071 ], [ 68.25989587, 40.66232453 ], [ 68.63248294, 40.66868073 ], [ 69.0700273, 41.38424429 ], [ 70.38896488, 42.08130768 ], [ 70.96231489, 42.26615428 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Venezuela", "sov_a3": "VEN", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Venezuela", "adm0_a3": "VEN", "geou_dif": 0.000000, "geounit": "Venezuela", "gu_a3": "VEN", "su_dif": 0.000000, "subunit": "Venezuela", "su_a3": "VEN", "brk_diff": 0.000000, "name": "Venezuela", "name_long": "Venezuela", "brk_a3": "VEN", "brk_name": "Venezuela", "brk_group": null, "abbrev": "Ven.", "postal": "VE", "formal_en": "Bolivarian Republic of Venezuela", "formal_fr": "Replica Bolivariana de Venezuela", "note_adm0": null, "note_brk": null, "name_sort": "Venezuela, RB", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 3.000000, "mapcolor9": 1.000000, "mapcolor13": 4.000000, "pop_est": 26814843.000000, "gdp_md_est": 357400.000000, "pop_year": -99.000000, "lastcensus": 2001.000000, "gdp_year": -99.000000, "economy": "5. Emerging region: G20", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "VE", "iso_a3": "VEN", "iso_n3": "862", "un_a3": "862", "wb_a2": "VE", "wb_a3": "VEN", "woe_id": -99.000000, "adm0_a3_is": "VEN", "adm0_a3_us": "VEN", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "South America", "region_un": "Americas", "subregion": "South America", "region_wb": "Latin America & Caribbean", "name_len": 9.000000, "long_len": 9.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ -59.75828488, 8.36703482 ], [ -60.55058794, 7.77960297 ], [ -60.63797279, 7.4149999 ], [ -60.2956681, 7.04391144 ], [ -60.54399919, 6.85658438 ], [ -61.15933631, 6.69607738 ], [ -61.13941505, 6.23429678 ], [ -61.4103029, 5.9590681 ], [ -60.73357418, 5.20027721 ], [ -60.60117917, 4.91809805 ], [ -60.96689328, 4.5364676 ], [ -62.08542965, 4.16212352 ], [ -62.80453305, 4.00696503 ], [ -63.0931976, 3.77057119 ], [ -63.88834286, 4.0205301 ], [ -64.62865943, 4.14848094 ], [ -64.81606401, 4.05644522 ], [ -64.36849443, 3.79721039 ], [ -64.40882789, 3.1267862 ], [ -64.26999915, 2.49700552 ], [ -63.4228674, 2.41106761 ], [ -63.36878801, 2.20089956 ], [ -64.0830855, 1.91636913 ], [ -64.19930579, 1.49285493 ], [ -64.61101193, 1.32873058 ], [ -65.3547133, 1.09528229 ], [ -65.54826738, 0.78925446 ], [ -66.32576514, 0.72445222 ], [ -66.87632585, 1.2533605 ], [ -67.18129432, 2.25063813 ], [ -67.44709205, 2.60028087 ], [ -67.80993812, 2.82065502 ], [ -67.30317318, 3.31845409 ], [ -67.33756385, 3.54234223 ], [ -67.6218359, 3.83948172 ], [ -67.82301225, 4.50393728 ], [ -67.74469662, 5.22112865 ], [ -67.52153195, 5.55687043 ], [ -67.34143958, 6.09546804 ], [ -67.69508725, 6.26731802 ], [ -68.26505246, 6.15326813 ], [ -68.98531857, 6.20680492 ], [ -69.38947995, 6.09986054 ], [ -70.09331295, 6.96037649 ], [ -70.67423357, 7.08778474 ], [ -71.96017575, 6.9916149 ], [ -72.19835242, 7.34043081 ], [ -72.44448727, 7.4237849 ], [ -72.47967892, 7.63250601 ], [ -72.36090064, 8.00263845 ], [ -72.43986223, 8.40527538 ], [ -72.66049476, 8.62528779 ], [ -72.78872982, 9.08502717 ], [ -73.30495154, 9.15199982 ], [ -73.02760413, 9.73677033 ], [ -72.90528602, 10.45034435 ], [ -72.61465776, 10.82197541 ], [ -72.22757545, 11.10870209 ], [ -71.97392168, 11.60867158 ], [ -71.33158362, 11.77628408 ], [ -71.36000566, 11.5399936 ], [ -71.94704993, 11.42328238 ], [ -71.62086829, 10.96945995 ], [ -71.63306393, 10.44649445 ], [ -72.07417396, 9.86565135 ], [ -71.69564409, 9.07226309 ], [ -71.26455929, 9.13719453 ], [ -71.03999936, 9.85999278 ], [ -71.35008379, 10.21193513 ], [ -71.40062334, 10.96896902 ], [ -70.15529883, 11.37548168 ], [ -70.29384335, 11.84682241 ], [ -69.94324459, 12.16230703 ], [ -69.5843001, 11.45961091 ], [ -68.88299923, 11.44338451 ], [ -68.23327145, 10.88574413 ], [ -68.19412655, 10.55465323 ], [ -67.29624854, 10.54586823 ], [ -66.22786414, 10.64862682 ], [ -65.6552376, 10.20079886 ], [ -64.89045224, 10.07721467 ], [ -64.32947873, 10.3895987 ], [ -64.31800656, 10.64141795 ], [ -63.07932248, 10.70172435 ], [ -61.88094601, 10.71562531 ], [ -62.73011898, 10.42026866 ], [ -62.38851193, 9.94820445 ], [ -61.58876746, 9.87306692 ], [ -60.83059669, 9.38133983 ], [ -60.67125241, 8.58017426 ], [ -60.15009559, 8.60275686 ], [ -59.75828488, 8.36703482 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "Vietnam", "sov_a3": "VNM", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Vietnam", "adm0_a3": "VNM", "geou_dif": 0.000000, "geounit": "Vietnam", "gu_a3": "VNM", "su_dif": 0.000000, "subunit": "Vietnam", "su_a3": "VNM", "brk_diff": 0.000000, "name": "Vietnam", "name_long": "Vietnam", "brk_a3": "VNM", "brk_name": "Vietnam", "brk_group": null, "abbrev": "Viet.", "postal": "VN", "formal_en": "Socialist Republic of Vietnam", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Vietnam", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 6.000000, "mapcolor9": 5.000000, "mapcolor13": 4.000000, "pop_est": 86967524.000000, "gdp_md_est": 241700.000000, "pop_year": -99.000000, "lastcensus": 2009.000000, "gdp_year": -99.000000, "economy": "5. Emerging region: G20", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "VN", "iso_a3": "VNM", "iso_n3": "704", "un_a3": "704", "wb_a2": "VN", "wb_a3": "VNM", "woe_id": -99.000000, "adm0_a3_is": "VNM", "adm0_a3_us": "VNM", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "South-Eastern Asia", "region_wb": "East Asia & Pacific", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 5.000000, "tiny": 2.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 108.05018029, 21.55237987 ], [ 106.71506799, 20.69685069 ], [ 105.88168216, 19.75205048 ], [ 105.66200565, 19.05816519 ], [ 106.42681685, 18.004121 ], [ 107.36195357, 16.69745657 ], [ 108.26949507, 16.07974234 ], [ 108.87710656, 15.27669058 ], [ 109.33526981, 13.42602835 ], [ 109.20013594, 11.66685924 ], [ 108.36613, 11.00832062 ], [ 107.22092858, 10.36448395 ], [ 106.40511275, 9.53083975 ], [ 105.15826379, 8.59975963 ], [ 104.79518517, 9.24103832 ], [ 105.07620161, 9.91849051 ], [ 104.33433475, 10.48654369 ], [ 105.19991499, 10.8893098 ], [ 106.24967004, 10.96181184 ], [ 105.81052372, 11.56761465 ], [ 107.49140303, 12.33720592 ], [ 107.61454797, 13.53553071 ], [ 107.38272749, 14.2024409 ], [ 107.56452518, 15.20217316 ], [ 107.31270593, 15.90853832 ], [ 106.55600793, 16.60428396 ], [ 105.92576216, 17.48531546 ], [ 105.09459842, 18.6669746 ], [ 103.89653202, 19.26518098 ], [ 104.18338789, 19.62466808 ], [ 104.82257368, 19.88664175 ], [ 104.43500044, 20.75873322 ], [ 103.20386112, 20.7665622 ], [ 102.75489627, 21.67513723 ], [ 102.17043583, 22.46475312 ], [ 102.70699222, 22.70879507 ], [ 103.5045146, 22.70375662 ], [ 104.47685835, 22.81915009 ], [ 105.32920943, 23.3520633 ], [ 105.81124719, 22.9768924 ], [ 106.72540327, 22.79426789 ], [ 106.56727339, 22.21820486 ], [ 107.04342004, 21.81189891 ], [ 108.05018029, 21.55237987 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 4.000000, "sovereignt": "Vanuatu", "sov_a3": "VUT", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Vanuatu", "adm0_a3": "VUT", "geou_dif": 0.000000, "geounit": "Vanuatu", "gu_a3": "VUT", "su_dif": 0.000000, "subunit": "Vanuatu", "su_a3": "VUT", "brk_diff": 0.000000, "name": "Vanuatu", "name_long": "Vanuatu", "brk_a3": "VUT", "brk_name": "Vanuatu", "brk_group": null, "abbrev": "Van.", "postal": "VU", "formal_en": "Republic of Vanuatu", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Vanuatu", "name_alt": null, "mapcolor7": 6.000000, "mapcolor8": 3.000000, "mapcolor9": 7.000000, "mapcolor13": 3.000000, "pop_est": 218519.000000, "gdp_md_est": 988.500000, "pop_year": -99.000000, "lastcensus": 2009.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "VU", "iso_a3": "VUT", "iso_n3": "548", "un_a3": "548", "wb_a2": "VU", "wb_a3": "VUT", "woe_id": -99.000000, "adm0_a3_is": "VUT", "adm0_a3_us": "VUT", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Oceania", "region_un": "Oceania", "subregion": "Melanesia", "region_wb": "East Asia & Pacific", "name_len": 7.000000, "long_len": 7.000000, "abbrev_len": 4.000000, "tiny": 2.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 167.84487674, -16.4663331 ], [ 167.51518111, -16.59784962 ], [ 167.18000777, -16.15999521 ], [ 167.21680139, -15.89184621 ], [ 167.84487674, -16.4663331 ] ] ], [ [ [ 167.10771244, -14.93392018 ], [ 167.27002811, -15.74002085 ], [ 167.00120731, -15.61460215 ], [ 166.79315799, -15.66881072 ], [ 166.64985925, -15.39270355 ], [ 166.629137, -14.62649708 ], [ 167.10771244, -14.93392018 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Yemen", "sov_a3": "YEM", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Yemen", "adm0_a3": "YEM", "geou_dif": 0.000000, "geounit": "Yemen", "gu_a3": "YEM", "su_dif": 0.000000, "subunit": "Yemen", "su_a3": "YEM", "brk_diff": 0.000000, "name": "Yemen", "name_long": "Yemen", "brk_a3": "YEM", "brk_name": "Yemen", "brk_group": null, "abbrev": "Yem.", "postal": "YE", "formal_en": "Republic of Yemen", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Yemen, Rep.", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 3.000000, "mapcolor9": 3.000000, "mapcolor13": 11.000000, "pop_est": 23822783.000000, "gdp_md_est": 55280.000000, "pop_year": -99.000000, "lastcensus": 2004.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "YE", "iso_a3": "YEM", "iso_n3": "887", "un_a3": "887", "wb_a2": "RY", "wb_a3": "YEM", "woe_id": -99.000000, "adm0_a3_is": "YEM", "adm0_a3_us": "YEM", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Asia", "region_un": "Asia", "subregion": "Western Asia", "region_wb": "Middle East & North Africa", "name_len": 5.000000, "long_len": 5.000000, "abbrev_len": 4.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 53.10857263, 16.65105113 ], [ 52.38520593, 16.3824112 ], [ 52.19172936, 15.93843313 ], [ 52.16816491, 15.59742036 ], [ 51.17251509, 15.17524974 ], [ 49.57457645, 14.70876659 ], [ 48.67923058, 14.00320242 ], [ 48.23894738, 13.9480895 ], [ 47.93891402, 14.00723318 ], [ 47.35445357, 13.59221975 ], [ 46.71707645, 13.3996992 ], [ 45.87759281, 13.34776439 ], [ 45.62505008, 13.29094615 ], [ 45.40645877, 13.02690542 ], [ 45.14435591, 12.9539383 ], [ 44.98953332, 12.6995869 ], [ 44.49457645, 12.72165274 ], [ 44.17511275, 12.58595043 ], [ 43.48295861, 12.63680004 ], [ 43.22287113, 13.22095043 ], [ 43.2514482, 13.76758373 ], [ 43.08794396, 14.06263032 ], [ 42.89224531, 14.80224925 ], [ 42.60487267, 15.21333527 ], [ 42.8050155, 15.2619628 ], [ 42.70243778, 15.71888581 ], [ 42.82367069, 15.91174226 ], [ 42.77933231, 16.34789134 ], [ 43.21837528, 16.66688996 ], [ 43.11579756, 17.08844046 ], [ 43.38079431, 17.57998668 ], [ 43.79151859, 17.31997671 ], [ 44.06261315, 17.41035879 ], [ 45.21665124, 17.43332897 ], [ 45.39999922, 17.33333507 ], [ 46.36665856, 17.23331533 ], [ 46.74999434, 17.28333812 ], [ 47.00000492, 16.94999929 ], [ 47.46669478, 17.11668163 ], [ 48.18334354, 18.16666922 ], [ 49.11667158, 18.61666759 ], [ 52.0000098, 19.00000336 ], [ 52.78218428, 17.34974234 ], [ 53.10857263, 16.65105113 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 2.000000, "sovereignt": "South Africa", "sov_a3": "ZAF", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "South Africa", "adm0_a3": "ZAF", "geou_dif": 0.000000, "geounit": "South Africa", "gu_a3": "ZAF", "su_dif": 0.000000, "subunit": "South Africa", "su_a3": "ZAF", "brk_diff": 0.000000, "name": "South Africa", "name_long": "South Africa", "brk_a3": "ZAF", "brk_name": "South Africa", "brk_group": null, "abbrev": "S.Af.", "postal": "ZA", "formal_en": "Republic of South Africa", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "South Africa", "name_alt": null, "mapcolor7": 2.000000, "mapcolor8": 3.000000, "mapcolor9": 4.000000, "mapcolor13": 2.000000, "pop_est": 49052489.000000, "gdp_md_est": 491000.000000, "pop_year": -99.000000, "lastcensus": 2001.000000, "gdp_year": -99.000000, "economy": "5. Emerging region: G20", "income_grp": "3. Upper middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "ZA", "iso_a3": "ZAF", "iso_n3": "710", "un_a3": "710", "wb_a2": "ZA", "wb_a3": "ZAF", "woe_id": -99.000000, "adm0_a3_is": "ZAF", "adm0_a3_us": "ZAF", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Southern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 12.000000, "long_len": 12.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 31.19140913, -22.2515097 ], [ 31.67039798, -23.65896901 ], [ 31.93058882, -24.3694166 ], [ 31.75240848, -25.48428395 ], [ 31.83777795, -25.8433318 ], [ 31.33315759, -25.66019053 ], [ 31.04407962, -25.73145233 ], [ 30.94966678, -26.02264902 ], [ 30.67660851, -26.3980783 ], [ 30.68596195, -26.74384531 ], [ 31.28277306, -27.28587941 ], [ 31.86806034, -27.17792734 ], [ 32.07166548, -26.73382008 ], [ 32.83012048, -26.74219166 ], [ 32.58026493, -27.47015757 ], [ 32.4621326, -28.30101124 ], [ 32.20338871, -28.75240488 ], [ 31.52100142, -29.25738698 ], [ 31.32556115, -29.40197763 ], [ 30.90176273, -29.90995696 ], [ 30.62281335, -30.42377573 ], [ 30.05571618, -31.14026946 ], [ 28.92555261, -32.17204111 ], [ 28.21975589, -32.77195281 ], [ 27.46460819, -33.2269638 ], [ 26.41945235, -33.61495045 ], [ 25.90966434, -33.6670403 ], [ 25.78062829, -33.94464609 ], [ 25.17286177, -33.7968515 ], [ 24.67785322, -33.9871758 ], [ 23.59404341, -33.79447438 ], [ 22.98818892, -33.91643076 ], [ 22.57415734, -33.86408253 ], [ 21.54279911, -34.2588388 ], [ 20.68905277, -34.41717539 ], [ 20.07126102, -34.79513681 ], [ 19.61640506, -34.81916636 ], [ 19.19327844, -34.46259897 ], [ 18.85531457, -34.44430552 ], [ 18.42464318, -33.99787282 ], [ 18.37741092, -34.13652068 ], [ 18.24449914, -33.86775156 ], [ 18.25008019, -33.28143076 ], [ 17.92519046, -32.61129079 ], [ 18.24790978, -32.42913136 ], [ 18.22176151, -31.66163299 ], [ 17.56691776, -30.72572112 ], [ 17.06441613, -29.87864105 ], [ 17.06291751, -29.87595387 ], [ 16.34497684, -28.57670501 ], [ 16.82401737, -28.08216155 ], [ 17.21892866, -28.35594329 ], [ 17.38749719, -28.78351409 ], [ 17.83615197, -28.85637786 ], [ 18.46489912, -29.04546193 ], [ 19.00212731, -28.97244313 ], [ 19.89473433, -28.46110483 ], [ 19.89576786, -24.76779022 ], [ 20.16572554, -24.91796193 ], [ 20.75860925, -25.86813649 ], [ 20.66647017, -26.4774533 ], [ 20.889609, -26.82854298 ], [ 21.60589603, -26.72653371 ], [ 22.10596887, -26.28025604 ], [ 22.57953169, -25.97944752 ], [ 22.82427127, -25.50045867 ], [ 23.3120968, -25.26868987 ], [ 23.73356978, -25.39012949 ], [ 24.21126672, -25.67021575 ], [ 25.02517053, -25.7196701 ], [ 25.66466638, -25.48681609 ], [ 25.76584883, -25.17484547 ], [ 25.94165205, -24.69637339 ], [ 26.48575321, -24.61632659 ], [ 26.78640669, -24.24069061 ], [ 27.11940962, -23.57432301 ], [ 28.01723596, -22.82775359 ], [ 29.43218835, -22.09131276 ], [ 29.8390369, -22.10221649 ], [ 30.32288334, -22.27161183 ], [ 30.65986535, -22.15156748 ], [ 31.19140913, -22.2515097 ] ], [ [ 28.10720462, -30.54573211 ], [ 28.29106937, -30.22621673 ], [ 28.84839969, -30.07005055 ], [ 29.01841515, -29.74376556 ], [ 29.32516646, -29.25738698 ], [ 28.97826257, -28.95559661 ], [ 28.54170007, -28.64750172 ], [ 28.07433841, -28.8514686 ], [ 27.53251102, -29.24271087 ], [ 26.99926192, -29.87595387 ], [ 27.74939701, -30.64510589 ], [ 28.10720462, -30.54573211 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Zambia", "sov_a3": "ZMB", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Zambia", "adm0_a3": "ZMB", "geou_dif": 0.000000, "geounit": "Zambia", "gu_a3": "ZMB", "su_dif": 0.000000, "subunit": "Zambia", "su_a3": "ZMB", "brk_diff": 0.000000, "name": "Zambia", "name_long": "Zambia", "brk_a3": "ZMB", "brk_name": "Zambia", "brk_group": null, "abbrev": "Zambia", "postal": "ZM", "formal_en": "Republic of Zambia", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Zambia", "name_alt": null, "mapcolor7": 5.000000, "mapcolor8": 8.000000, "mapcolor9": 5.000000, "mapcolor13": 13.000000, "pop_est": 11862740.000000, "gdp_md_est": 17500.000000, "pop_year": -99.000000, "lastcensus": 2010.000000, "gdp_year": -99.000000, "economy": "7. Least developed region", "income_grp": "4. Lower middle income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "ZM", "iso_a3": "ZMB", "iso_n3": "894", "un_a3": "894", "wb_a2": "ZM", "wb_a3": "ZMB", "woe_id": -99.000000, "adm0_a3_is": "ZMB", "adm0_a3_us": "ZMB", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Eastern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 6.000000, "long_len": 6.000000, "abbrev_len": 6.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 30.8060063, -8.57833913 ], [ 31.02211714, -8.78654347 ], [ 31.18903202, -8.7299061 ], [ 31.10725827, -8.56380814 ], [ 31.1072581, -8.56380779 ], [ 31.15775134, -8.59457875 ], [ 31.5563481, -8.76204884 ], [ 32.19186486, -8.93035898 ], [ 32.75937544, -9.23059905 ], [ 33.23138797, -9.67672169 ], [ 33.4856877, -10.52555877 ], [ 33.3153105, -10.79654998 ], [ 33.11428918, -11.60719817 ], [ 33.30642215, -12.43577809 ], [ 32.99176436, -12.78387054 ], [ 32.68816532, -13.71285776 ], [ 33.21402469, -13.97186004 ], [ 30.17948124, -14.79609913 ], [ 30.27425581, -15.50778696 ], [ 29.51683434, -15.64467783 ], [ 28.94746341, -16.04305145 ], [ 28.82586877, -16.38974863 ], [ 28.46790612, -16.46840016 ], [ 27.59824344, -17.29083058 ], [ 27.04442712, -17.93802622 ], [ 26.70677331, -17.96122894 ], [ 26.38193526, -17.84604217 ], [ 25.2642257, -17.73653981 ], [ 25.08444339, -17.66181569 ], [ 25.07695031, -17.57882334 ], [ 24.68234907, -17.35341074 ], [ 24.03386153, -17.29584319 ], [ 23.21504846, -17.52311614 ], [ 22.56247847, -16.89845143 ], [ 21.88784264, -16.08031015 ], [ 21.93388635, -12.89843719 ], [ 24.01613651, -12.91104624 ], [ 23.93092207, -12.56584767 ], [ 24.07990523, -12.19129689 ], [ 23.90415368, -11.72228159 ], [ 24.01789351, -11.23729827 ], [ 23.9122152, -10.92682627 ], [ 24.25715539, -10.95199269 ], [ 24.31451623, -11.26282643 ], [ 24.78316979, -11.23869354 ], [ 25.41811812, -11.33093597 ], [ 25.7523096, -11.7849651 ], [ 26.5530876, -11.92443979 ], [ 27.16441979, -11.60874847 ], [ 27.38879886, -12.13274749 ], [ 28.15510868, -12.27248056 ], [ 28.52356164, -12.69860442 ], [ 28.93428592, -13.24895843 ], [ 29.69961389, -13.25722666 ], [ 29.61600142, -12.17889455 ], [ 29.34154789, -12.36074391 ], [ 28.64241743, -11.9715687 ], [ 28.37225305, -11.79364674 ], [ 28.49606978, -10.78988372 ], [ 28.67368167, -9.60592498 ], [ 28.44987105, -9.16491831 ], [ 28.73486657, -8.52655934 ], [ 29.00291223, -8.40703175 ], [ 30.34608605, -8.23825652 ], [ 30.52177417, -8.28363628 ], [ 30.46442508, -8.49818898 ], [ 30.8060063, -8.57833913 ] ] ] ] } },
{ "type": "Feature", "properties": { "scalerank": 1, "featurecla": "Admin-0 country", "labelrank": 3.000000, "sovereignt": "Zimbabwe", "sov_a3": "ZWE", "adm0_dif": 0.000000, "level": 2.000000, "type": "Sovereign country", "admin": "Zimbabwe", "adm0_a3": "ZWE", "geou_dif": 0.000000, "geounit": "Zimbabwe", "gu_a3": "ZWE", "su_dif": 0.000000, "subunit": "Zimbabwe", "su_a3": "ZWE", "brk_diff": 0.000000, "name": "Zimbabwe", "name_long": "Zimbabwe", "brk_a3": "ZWE", "brk_name": "Zimbabwe", "brk_group": null, "abbrev": "Zimb.", "postal": "ZW", "formal_en": "Republic of Zimbabwe", "formal_fr": null, "note_adm0": null, "note_brk": null, "name_sort": "Zimbabwe", "name_alt": null, "mapcolor7": 1.000000, "mapcolor8": 5.000000, "mapcolor9": 3.000000, "mapcolor13": 9.000000, "pop_est": 12619600.000000, "gdp_md_est": 9323.000000, "pop_year": 0.000000, "lastcensus": 2002.000000, "gdp_year": 0.000000, "economy": "5. Emerging region: G20", "income_grp": "5. Low income", "wikipedia": -99.000000, "fips_10": null, "iso_a2": "ZW", "iso_a3": "ZWE", "iso_n3": "716", "un_a3": "716", "wb_a2": "ZW", "wb_a3": "ZWE", "woe_id": -99.000000, "adm0_a3_is": "ZWE", "adm0_a3_us": "ZWE", "adm0_a3_un": -99.000000, "adm0_a3_wb": -99.000000, "continent": "Africa", "region_un": "Africa", "subregion": "Eastern Africa", "region_wb": "Sub-Saharan Africa", "name_len": 8.000000, "long_len": 8.000000, "abbrev_len": 5.000000, "tiny": -99.000000, "homepart": 1.000000 }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 31.19140913, -22.2515097 ], [ 30.65986535, -22.15156748 ], [ 30.32288334, -22.27161183 ], [ 29.8390369, -22.10221649 ], [ 29.43218835, -22.09131276 ], [ 28.7946562, -21.63945403 ], [ 28.02137007, -21.48597503 ], [ 27.72722782, -20.85180185 ], [ 27.72474735, -20.49905853 ], [ 27.29650475, -20.39151987 ], [ 26.16479089, -19.29308563 ], [ 25.85039147, -18.71441294 ], [ 25.64916345, -18.53602589 ], [ 25.2642257, -17.73653981 ], [ 26.38193526, -17.84604217 ], [ 26.70677331, -17.96122894 ], [ 27.04442712, -17.93802622 ], [ 27.59824344, -17.29083058 ], [ 28.46790612, -16.46840016 ], [ 28.82586877, -16.38974863 ], [ 28.94746341, -16.04305145 ], [ 29.51683434, -15.64467783 ], [ 30.27425581, -15.50778696 ], [ 30.33895471, -15.88083913 ], [ 31.173064, -15.8609437 ], [ 31.63649824, -16.07199025 ], [ 31.85204064, -16.31941701 ], [ 32.32823897, -16.39207407 ], [ 32.84763879, -16.71339813 ], [ 32.84986087, -17.97905731 ], [ 32.6548857, -18.67208994 ], [ 32.61199426, -19.41938283 ], [ 32.77270796, -19.71559214 ], [ 32.65974328, -20.30429005 ], [ 32.50869307, -20.39529225 ], [ 32.24498823, -21.11648854 ], [ 31.19140913, -22.2515097 ] ] ] ] } }
]
}

if(typeof module !== 'undefined') {
    module.exports = worldData;
}
if (typeof require !== 'undefined') {
	var glMatrix = require('./glMatrix-0.9.5.min.js');
	var vec3 = glMatrix[0];
	var mat3 = glMatrix[1];
	var mat4 = glMatrix[2];
	var quat4 = glMatrix[3];
	
	var Canvas3D = require('./Canvas3D.js');
	var Buffer3D = Canvas3D.Buffer3D;
	var earcut = require('./earcut.js');
}

var Building = function(canvas) {
	this.editMode = 0;

	var gl = canvas.gl;
	this.canvas = canvas;
	this.canvas.building = this;
	this.killqueue = [];
	this.cbKill = null;

	this.refresh = function() {
		var aVertices = [], aColors = [], aTexCoord = [], aNormal = [];
		var r = 1, g = 1, b = 1, a = 1;
		if (this.isTotalView) {
			if (!this.canvas.isDark) {
				r = 0.7;
				g = 0.7;
				b = 0.7;
			}
			else {
				r = 0.4;
				g = 0.4;
				b = 0.4;
			}
		}
		var xl = -10000, xh = 10000, yl = -10000, yh = 10000, hl = 0;
		aVertices.push(xl, hl, yl,  xh, hl, yh,  xh, hl, yl,  xl, hl, yh,  xh, hl, yh,  xl, hl, yl);
		aColors.push(r, g, b, a,  r, g, b, a,  r, g, b, a,  r, g, b, a,  r, g, b, a,  r, g, b, a);
		aTexCoord.push(-10000, -10000,  10000, 10000,  10000, -10000,  -10000, 10000,  10000, 10000,  -10000, -10000);
		aNormal.push(0, 1, 0,  0, 1, 0,  0, 1, 0,  0, 1, 0,  0, 1, 0,  0, 1, 0);

		var fVertices = new Float32Array(aVertices);
		var fColors = new Float32Array(aColors);
		var fTexCoord = new Float32Array(aTexCoord);
		var fNormal = new Float32Array(aNormal);

		this.transparent = this.wallBuf;
		this.solid = this.nwallBuf;
		this.object = this.objBuf;
		this.text = this.textBuf;
		this.textbill = this.textBillBuf;

		//draw each line
		var mat = [];
		mat4.identity(mat);

		if (!!this.floor) {
			this.floor.draw(this.canvas, mat);
			this.nwallBuf.lightHeight = this.isTotalView ? 0 : this.floor.floorHeight;
		}

		this.defaultBuf.apply(fVertices, fColors, fTexCoord, fNormal);
		this.defaultBuf.textureId = this.isTotalView ? 1 : 0;
		this.wallBuf.refresh().empty();
		this.nwallBuf.refresh().empty();
		this.objBuf.refresh().empty();
		this.textBuf.refresh().empty();
		this.textBillBuf.refresh().empty();
	};
	this.destroy = function() {
		this.defaultBuf.destroy();
		this.objBuf.destroy();
		this.textBuf.destroy();
		this.nwallBuf.destroy();
		this.wallBuf.destroy();
		this.cursorBuf.destroy();
		this.textBillBuf.destroy();
		this.pickBuf.destroy();

		gl.deleteTexture(this.tex);
		gl.deleteTexture(this.walltex);
		gl.deleteTexture(this.ledtex);
	};
	this.draw = function() {
		this.kill();
		var canvas = this.canvas;
		var ppos = canvas.lastppos;
		
		(function drawCursor() {
			var aVertices = [], aColors = [], aTexCoord = [], aNormal = [];
			this.solid = this.object = this.transparent = this.text = {
				'vertices':aVertices,
				'colors':aColors,
				'texture':aTexCoord,
				'normal':aNormal
			};
			var r = 1, g = 0, b = 0, a = 1;

			if (!!this.magpoint) {
				r = 0;
				g = 0.8;
				b = 0;
			}
			else if (!!this.magline) {
				r = 0;
				g = 0.5;
				b = 1;
			}

			if (this.floor.selObj instanceof Point) {
				var pos = this.floor.selObj.pos;
				var xl = -.1 + pos[0], xh = .1 + pos[0], yl = -.1 + pos[2], yh = .1 + pos[2], hl = 0.001 + ppos[1];

				aVertices.push(xl, hl, yl,  xh, hl, yh,  xh, hl, yl,  xl, hl, yh,  xh, hl, yh,  xl, hl, yl);
				aColors.push(1, 0, 0, 1,  1, 0, 0, 1,  1, 0, 0, 1,  1, 0, 0, 1,  1, 0, 0, 1,  1, 0, 0, 1);
				aTexCoord.push(0, 0,  1, 1,  1, 0,  0, 1,  1, 1,  0, 0);
				aNormal.push(0, 1, 0,  0, 1, 0,  0, 1, 0,  0, 1, 0,  0, 1, 0,  0, 1, 0);
			}
			if (!this.startPoint) {
				var xl = -.1 + ppos[0], xh = .1 + ppos[0], yl = -.1 + ppos[2], yh = .1 + ppos[2], hl = 0.001 + ppos[1];

				aVertices.push(xl, hl, yl,  xh, hl, yh,  xh, hl, yl,  xl, hl, yh,  xh, hl, yh,  xl, hl, yl);
				aColors.push(r, g, b, a,  r, g, b, a,  r, g, b, a,  r, g, b, a,  r, g, b, a,  r, g, b, a);
				aTexCoord.push(0, 0,  1, 1,  1, 0,  0, 1,  1, 1,  0, 0);
				aNormal.push(0, 1, 0,  0, 1, 0,  0, 1, 0,  0, 1, 0,  0, 1, 0,  0, 1, 0);
			}
			else if (this.editMode == 2) {
				var start = this.startPoint;
				var hl = 0.01, d = 0.1, dh = 0;//2.5;
				var p0 = start.pos, p1 = ppos;
				var x = p0[0], y = p0[2], xn = p1[0], yn = p1[2];

				if (x > xn) {
					var t = x;
					x = xn;
					xn = t;
				}
				if (y > yn) {
					var t = y;
					y = yn;
					yn = t;
				}

				var x1 = x - d, y1 = y + d;
				var x0 = x - d, y0 = y - d;
				var x3 = xn + d, y3 = y + d;
				var x2 = xn + d, y2 = y - d;

				canvas.drawBox([x0, hl, y0], [x1, hl, y1], [x2, hl, y2], [x3, hl, y3], dh, 0x20, [r, g, b, a], this.solid);
				x1 = x - d; y1 = yn + d;
				x0 = x - d; y0 = yn - d;
				x3 = xn + d; y3 = yn + d;
				x2 = xn + d; y2 = yn - d;
				canvas.drawBox([x0, hl, y0], [x1, hl, y1], [x2, hl, y2], [x3, hl, y3], dh, 0x20, [r, g, b, a], this.solid);

				x1 = x - d; y1 = y + d;
				x0 = x + d; y0 = y + d;
				x3 = x - d; y3 = yn - d;
				x2 = x + d; y2 = yn - d;
				canvas.drawBox([x0, hl, y0], [x1, hl, y1], [x2, hl, y2], [x3, hl, y3], dh, 0x20, [r, g, b, a], this.solid);
				x1 = xn - d; y1 = y + d;
				x0 = xn + d; y0 = y + d;
				x3 = xn - d; y3 = yn - d;
				x2 = xn + d; y2 = yn - d;
				canvas.drawBox([x0, hl, y0], [x1, hl, y1], [x2, hl, y2], [x3, hl, y3], dh, 0x20, [r, g, b, a], this.solid);

			}
			else {
				var start = this.startPoint;
				var hl = 0.01, d = 0.1, dh = 0;//2.5;
				var p0 = start.pos, p1 = ppos;
				var x = p0[0], y = p0[2], xn = p1[0], yn = p1[2];
				var dx1 = yn - y, dy1 = xn - x;
				var d1 = Math.sqrt(dx1*dx1 + dy1*dy1);
				dx1 /= d1;
				dy1 /= d1;
				var x1 = x - dx1 * d, y1 = y + dy1 * d;
				var x0 = x + dx1 * d, y0 = y - dy1 * d;
				var x3 = xn - dx1 * d, y3 = yn + dy1 * d;
				var x2 = xn + dx1 * d, y2 = yn - dy1 * d;

				canvas.drawBox([x0, hl, y0], [x1, hl, y1], [x2, hl, y2], [x3, hl, y3], dh, 0x20, [r, g, b, a], this.solid);
			}

			if (!!this.cursorObject && !!this.cursorObject.type) {
				if (!this.magline) {
					var mat = [];
					mat4.identity(mat);
					mat4.translate(mat, ppos);
					if (this.floor.selObj instanceof Obj) {
						mat4.rotateY(mat, this.floor.selObj.rotate);
					}
					
					this.cursorObject.draw(this, mat);
					canvas.refresh();
				}
				else {
					var vec = this.magline.end.pos.slice();
					vec3.subtract(vec, this.magline.start.pos);
					var len = vec3.length(vec);
					vec = this.maglinepos.slice();
					vec3.subtract(vec, this.magline.start.pos);
					var len2 = vec3.length(vec);
					var key = len2/len;

					if (!this.magline.objs[key]) {
						this.magline.objs[key] = new Obj({
							'type':this.cursorObject.name,
							'name':this.cursorObject.name,
							'rotate':0,
							'posX':0,
							'posY':0,
							'posH':ppos[1],
							'color':this.blockColor.slice(),
							'childs':[]
						});
						canvas.refresh();
						delete this.magline.objs[key];
					}
				}
			}

			var fVertices = new Float32Array(aVertices);
			var fColors = new Float32Array(aColors);
			var fTexCoord = new Float32Array(aTexCoord);
			var fNormal = new Float32Array(aNormal);

			delete this.solid;
			delete this.object;
			delete this.transparent;

			this.cursorBuf.apply(fVertices, fColors, fTexCoord, fNormal);
		}).call(this);

		if (this.editMode == 0) {
			(function moveSelectedItem() {
				if (this.floor.selObj === this.moveObj) {
					var lastppos = canvas.prevppos;
					var dx = ppos[0] - lastppos[0], dy = ppos[2] - lastppos[2];
					var obj = this.floor.selObj;
					if (obj instanceof Point) {
						obj.pos[0] += dx;
						obj.pos[2] += dy;
						this.refresh();
					}
					else if (obj instanceof Wall) {
						obj.start.pos[0] += dx;
						obj.start.pos[2] += dy;
						obj.end.pos[0] += dx;
						obj.end.pos[2] += dy;
						this.refresh();
					}
					else if (obj instanceof Obj) {
						var type = ObjTypes[obj.type];
						if (!type.isWall) {
							obj.posX += dx;
							obj.posY += dy;
						}
						else if (!!this.magline) {
							var vec = this.magline.end.pos.slice();
							vec3.subtract(vec, this.magline.start.pos);
							var len = vec3.length(vec);
							vec = this.maglinepos.slice();
							vec3.subtract(vec, this.magline.start.pos);
							var len2 = vec3.length(vec);
							var key = len2/len;

							if (!(key in this.magline.objs)) {
								this.floor.deleteObj(obj, true);
								this.magline.objs[key] = obj;
							}
						}
						this.refresh();
					}
					else if (obj instanceof Plane) {
					}
				}
			}).call(this);
		}

//		if (this.floor.planes.length > 0 && this.floor.planes[0].isInside(this.cameraObj.pos[0], this.cameraObj.pos[2])) {
//			msgbox.println("hit");
//		}

//		var lastppos = [0, 0, 0];
//		if (!!this.lastppos)
//			lastppos = this.lastppos.slice();

			this.textBillBuf.blendType = this.canvas.isDark ? "plus" : "minus";
			this.defaultBuf.blendType = this.canvas.isDark ? "plus" : "minus";
	};
	this.mousedown = function(e, clientX, clientY) {
		var canvas = this.canvas;
		if (this.editMode == 0) {
			var obj = canvas.pickObj(clientX, clientY);

			if (obj instanceof Obj) {
				this.moveObj = obj;
			}
			else if (!!this.magpoint) {
				this.moveObj = this.magpoint;
			}
			else if (!!this.magline) {
				this.moveObj = this.magline;
			}
			else {
				this.moveObj = obj;
			}
		}
	};
	this.mouseup = function(e, clientX, clientY) {
		var canvas = this.canvas;
		delete this.moveObj;
		if (!!canvas.lastppos && canvas.movedist < 5) {
			if (e.button == 2) {
				if (!!this.startPoint && this.startPoint.lines.length == 0)
					this.floor.deletePoint(this.startPoint);
				delete this.startPoint;

				this.floor.selObj = null;
				if (!!this.cbChange)
					this.cbChange(this.floor.selObj);
				canvas.refresh();
			}
			else if (!!this.cursorObject && !!this.cursorObject.type) {
				var ppos = canvas.lastppos.slice();
				if (this.floor.selObj instanceof Obj && !!ObjTypes[this.floor.selObj.type].rangeX) {
					var m = this.floor.selObj.getMatrix();
					mat4.multiplyVec3(m, ppos);
				}

				var obj = new Obj({
					'type':this.cursorObject.name,
					'name':this.cursorObject.name,
					//'rotate':0,
					'posX':ppos[0],
					'posY':ppos[2],
					'posH':ppos[1],
					'childs':[]
				});
				if (!!ObjTypes[obj.type].userColor)
					obj.color = this.blockColor.slice();
				if (!!this.magline) {
					obj.posX = 0;
					obj.posY = 0;

					var vec = this.magline.end.pos.slice();
					vec3.subtract(vec, this.magline.start.pos);
					var len = vec3.length(vec);
					vec = this.maglinepos.slice();
					vec3.subtract(vec, this.magline.start.pos);
					var len2 = vec3.length(vec);
					var key = len2/len;

					if (!this.magline.objs[key]) {
						this.magline.objs[key] = obj;
					}
				}
				
				var map = this.floor.getObjMap();
				var name, i = 0;
				do {
					name = this.cursorObject.name + '_' + i;
					i++;
				} while (!!map[name]);
				obj.name = name;

				if (this.floor.selObj instanceof Obj && !!ObjTypes[this.floor.selObj.type].rangeX) {
					this.floor.selObj.childs.push(obj);
					if (!!this.cbChange)
						this.cbChange(this.floor.selObj);
					obj.parent = this.floor.selObj;
					if (!!obj.parent.parent)
						obj.parent = obj.parent;
				}
				else {
					if (!!this.cbSelect)
						this.cbSelect(obj);
				}
				this.floor.objects.push(obj);
				canvas.refresh();
			}
			//editor
			else if (this.editMode == 0) {
				var obj = canvas.pickObj(clientX, clientY);
				
				if (canvas.viewMode == 3) {
					if (obj instanceof Obj) {
						var objType = ObjTypes[obj.type];

						if (!!objType.onclick) {
							objType.onclick.call(obj);
						}
					}
				}
				else if (obj instanceof Obj) {
					if (!!this.cbSelect)
						this.cbSelect(obj);
					this.floor.selObj = obj;
				}
				else if (!!this.magpoint) {
					this.floor.selObj = this.magpoint;
				}
				else if (!!this.magline) {
					this.floor.selObj = this.magline;
				}
				else {
					this.floor.selObj = obj;
				}
				canvas.refresh();
			}
			else if (this.editMode == 3) {
				var obj = this.pickObj(clientX, clientY);
					
				if (obj instanceof Obj) {
					if (this.floor.selObj instanceof Obj && this.floor.selObj !== obj) {
						var olink = new ObjLink(this.floor.selObj, obj);
						this.floor.objlinks.push(olink);
					}
					if (!!this.cbSelect)
						this.cbSelect(obj);
					this.floor.selObj = obj;
				}
				else {
					this.floor.selObj = null;
				}
				canvas.refresh();
			}
			else {
				var point = this.magpoint;
				var prevpoint = this.startPoint;
				
				if (this.editMode == 1) {
					if (!!this.maglinepos && canvas.lastppos[0] == this.maglinepos[0] && canvas.lastppos[2] == this.maglinepos[2]) {
						point = this.floor.splitWall(this.magline, this.maglinepos);
					}
					if (!point) {
						point = this.floor.getPoint(canvas.lastppos);
					}
//					else if (!!prevpoint) {
//						this.floor.addWall(prevpoint, point);
//					}
					if (!!prevpoint) {
						var line = new Wall(this.floor, prevpoint, point, this.blockColor);
					}
				}
				else if (this.editMode == 2) {
					if (!prevpoint && !point) {
						point = this.floor.getPoint(canvas.lastppos);
					}
					if (!!prevpoint) {
						//find duplicated font
						var p1 = this.floor.getPoint([canvas.lastppos[0], prevpoint.pos[1], prevpoint.pos[2]]);
						point = this.floor.getPoint(canvas.lastppos);
						var p2 = this.floor.getPoint([prevpoint.pos[0], prevpoint.pos[1], point.pos[2]]);
						new Wall(this.floor, prevpoint, p1, this.blockColor);
						new Wall(this.floor, p1, point, this.blockColor);
						new Wall(this.floor, point, p2, this.blockColor);
						//this.floor.addWall(p2, prevpoint);
						new Wall(this.floor, p2, prevpoint, this.blockColor);
						point = undefined;
					}
				}

				this.startPoint = point;
				canvas.refresh();
			}
			//--editor
		}
//		else {
//			if (!!this.cbDirection)
//				this.cbDirection();
//		}
	};
	this.mousemove = function() {
		return (!this.floor.selObj || this.floor.selObj !== this.moveObj);
	};
	this.keyup = function(e) {
		var canvas = this.canvas;
/*		if (e.keyCode == 46) {
			//editor
			this.floor.remove(this.floor.selObj);
			this.floor.selObj = null;
			if (!!this.cbChange)
				this.cbChange(this.floor.selObj);
			canvas.refresh();
			//--editor
		}*/
		if (e.keyCode == 49) {
			canvas.viewMode = 0;
		}
		if (e.keyCode == 50) {
			canvas.viewMode = 1;
		}
		if (e.keyCode == 51) {
			canvas.viewMode = 2;
		}
		if (e.keyCode == 53) {
			canvas.direction = (canvas.direction + 1) % 4;
		}
	};
	this.pickdraw = function() {
		this.solid = this.object = this.transparent = this.text = this.pickBuf;
		var mat = [];
		mat4.identity(mat);

		//building
/*		this.floor.planes.forEach(function(plane, i) {
			plane.draw(canvas, mat, [1, (i >> 8)/255, (i & 255)/255, 1]);
		});*/

		this.floor.lines.forEach(function(l, i) {
			l.draw(canvas, mat, true);
		});

		var drawObj = (function (o, i, mat) {
			var color = [127/255, (i >> 8)/255, (i & 255)/255, 1];
			var m = o.draw(canvas, mat, color, undefined, undefined, true);
			o.childs.forEach((function(obj) {
				var j = this.floor.objects.indexOf(obj);
				drawObj(obj, j, m);
			}).bind(this));
		}).bind(this);

		this.floor.objects.forEach((function(o, i) {
			if (!!o.parent || ObjTypes[o.type].isWall)
				return;
			drawObj(o, i, mat);
		}).bind(this));

		this.floor.objlinks.forEach(function(ol, i) {
			var color = [192/255, (i >> 8)/255, (i & 255)/255, 1];
			ol.draw(canvas, mat, color);
		});

		this.pickBuf.refresh().empty();

		this.pickBuf.draw();
	};
	this.pickobj = function(pixels) {
		var i = (pixels[1] << 8) | pixels[2];
		if (pixels[0] == 127) {
			return this.floor.objects[i];
		}
		else if (pixels[0] == 192) {
			return this.floor.objlinks[i];
		}
		else if (pixels[0] == 255) {
			return this.floor.planes[i];
		}
		return null;
	};

	this.defaultBuf = new Buffer3D(canvas, {"cullFace":false, "depthTest":false, "blendType":"normal", "textureId":0, "light":1, "billboard":0, "lightHeight":0});
	this.objBuf = new Buffer3D(canvas, {"blendType":"normal", "cullFace":true, "depthTest":true, "textureId":2});
	this.textBuf = new Buffer3D(canvas, {"textureId": 3, "blendType":"plus"});
	this.nwallBuf = new Buffer3D(canvas, {"blendType":"normal", "lightHeight":0, "cullFace":false, "textureId": 1});
	this.wallBuf = new Buffer3D(canvas, {"cullFace":true, "depthMask":false, "blendType":"multiply"});
	this.cursorBuf = new Buffer3D(canvas, {"depthMask":true, "lightHeight":0, "depthTest":false, "cullFace":false, "blendType":"normal", "textureId":1, "light":0});
	this.textBillBuf = new Buffer3D(canvas, {"blendType":"minus", "cullFace":false, "textureId":3, "billboard":1, "light":0});
	this.pickBuf = new Buffer3D(canvas, {"blendType":"normal", "lightHeight":0, "depthTest":true, "cullFace":false, "textureId":1, "light":0, "billboard":0});

	canvas.drawBufs.push(this.defaultBuf, this.objBuf, this.textBuf, this.nwallBuf, this.wallBuf, this.cursorBuf, this.textBillBuf);
	canvas.cbRefreshs.push(this.refresh.bind(this));	
	canvas.cbDestroys.push(this.destroy.bind(this));
	canvas.cbDraws.push(this.draw.bind(this));
	canvas.cbPickDraws.push(this.pickdraw.bind(this));
	canvas.cbPickObjs.push(this.pickobj.bind(this));
	canvas.cbMouseUps.push(this.mouseup.bind(this));
	canvas.cbMouseDowns.push(this.mousedown.bind(this));
	canvas.cbMouseMoves.push(this.mousemove.bind(this));
	canvas.cbKeyUps.push(this.keyup.bind(this));

	this.tex = gl.createTexture();
	this.walltex = gl.createTexture();
	this.ledtex = gl.createTexture();
	this.isTotalView = false;

	var trect = canvas.trect;
	this.ctxcanvas = document.createElement("canvas");
	this.ctxcanvas.width = trect;
	this.ctxcanvas.height = trect;
	this.ctx = this.ctxcanvas.getContext("2d");
	this.ctx.fillStyle = "black";
	this.ctx.fillRect(0, 0, trect, trect);
	this.ctx.strokeStyle = "rgba(255, 255, 255, .1)";
	for (var i = 0; i < trect; i+= 4) {
		this.ctx.moveTo(i + 0.5, 0);
		this.ctx.lineTo(i + 0.5, trect);
		this.ctx.moveTo(0, i + 0.5);
		this.ctx.lineTo(trect, i + 0.5);
	}
	this.ctx.stroke();
	this.ctx.strokeStyle = "rgba(255, 255, 255, .2)";
	this.ctx.lineWidth = 1;
	this.ctx.strokeRect(0.5, 0.5, trect, trect);
	gl.activeTexture(gl.TEXTURE0);
	gl.bindTexture(gl.TEXTURE_2D, this.tex);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST_MIPMAP_LINEAR);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
	gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, this.ctxcanvas);
	gl.generateMipmap(gl.TEXTURE_2D);

	gl.activeTexture(gl.TEXTURE1);
	gl.bindTexture(gl.TEXTURE_2D, this.walltex);
	this.ctx.fillStyle = "white";
	this.ctx.fillRect(0, 0, trect, trect);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
	gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, this.ctxcanvas);

	gl.activeTexture(gl.TEXTURE2);
	gl.bindTexture(gl.TEXTURE_2D, this.ledtex);
	this.ctxcanvas.height = this.ledtexsize = trect*4;
	this.ctx.fillStyle = "rgba(0, 0, 0, 1)";
	this.ctx.fillRect(0, trect+0, trect, trect*2);
	this.ctx.fillStyle = "white";
	this.ctx.fillRect(5, trect+12, trect-10, trect-20);
	this.ctx.fillRect(10, trect+5, trect-20, 15);
	this.ctx.fillRect(0, 0, trect, trect);
	this.ctx.fillRect(5, trect*2+5, trect-10, trect-20);
	this.ctx.fillRect(10, trect*2+9, trect-20, 15);

	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
	gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, this.ctxcanvas);

	this.floors = [new Floor('1층')];
	this.floor = this.floors[0];
	this.name = "NewBuilding";
}
Building.prototype = {
	onSelect: function (cb) {
		this.cbSelect = cb;
		return this;
	},
	onChange: function (cb) {
		this.cbChange = cb;
		return this;
	},
	setFloors: function(floors) {
		this.floors = floors;
	},
	setFloor: function(floor) {
		this.floor = floor;
	},
	getFloorByName: function(name) {
		var result = this.floors.filter(function(f) {
			return (f.name === name);
		});

		return result[0];
	},
	setProperty: function(path, value, obj) {
		var token = path.split("/");
		var i = 0;
		if (!obj) {
			var floor = this.floor;
			var i = 0;
			if (token[i] == '') {
				i++;
				//var map = floorlist.mapByName();
				floor = this.getFloorByName(token[i]);//map[token[i]];
				i++;
			}
			else if (!floor)
				return false;
			var objmap = floor.getObjMap();
			obj = objmap[token[i++]]; 
			if (!obj)
				return false;
		}
		else {
			if (token[i] == '')
				i+=2;
			i++;
		}

		return obj.setProperty(token.slice(i).join("/"), value);
	},
	getProperty: function(path, iobj) {
		var token = path.split("/");
		var i = 0, obj = iobj;
		if (!obj) {
			var floor = this.floor;
			if (token[i] == '') {
				i++;
				//var map = floorlist.mapByName();
				floor = this.getFloorByName(token[i]);//map[token[i]];
				i++;
			}
			else if (!floor)
				return false;
			var objmap = floor.getObjMap();
			obj = objmap[token[i++]]; 
			if (!obj)
				return false;
		}
		else {
			if (token[i] == '')
				i+=2;
			i++;
		}

		return obj.getProperty(token.slice(i).join("/"));
	},
	loadData: function(data) {
		function makeObj(objs) {
			var arr = [];
			objs.forEach(function(o) {
				var obj = new Obj(o);
				arr.push(obj);
			});
			return arr;
		}

		var obj = JSON.parse(data);
		if (!(obj instanceof Array)) {
			this.name = obj.name;
			obj = obj.floors;
		}
		else {
			this.name = "NewBuilding";
		}
		this.floors = [];
		obj.forEach((function(e, i) {
			var floor = new Floor(e.name);
			var points = new Object();
			e.points.forEach(function(p) {
				points[p[0]+'_'+p[2]] =	new Point(floor, p);
			});
			floor.objects = makeObj(e.objects);
			var objs = new Object();
			floor.objects.forEach(function(o) {
				objs[o.name] = o;
			});
			floor.objects.forEach(function(o) {
				if (!!o.childs) {
					var childs = [];
					o.childs.forEach(function(c) {
						childs.push(objs[c]);
					});
					o.childs = childs;
				}
				if (o.parent === undefined)
					return;
				o.parent = objs[o.parent];
			});
			e.lines.forEach(function(l) {
				var wall = new Wall(floor, points[l.start[0]+'_'+l.start[2]], points[l.end[0]+'_'+l.end[2]], l.color, true);
				for (var key in l.objs) {
					wall.objs[key] = objs[l.objs[key]];
				}
			});
			e.planes.forEach(function(p) {
				var arr = [];
				p.p.forEach(function (point) {
					arr.push(points[point[0]+'_'+point[2]]);
				});
				floor.planes.push(new Plane(arr));
			});
			if (!e.objlinks)
				e.objlinks = [];
			e.objlinks.forEach(function(l, i) {
				e.objlinks[i] = new ObjLink(objs[l.start], objs[l.end]);
			});
			this.floors.push(floor);
		}).bind(this));
	},
	saveData: function() {
		var data = [];
		this.floors.forEach(function(e, i) {
			if (!i)
				return;
			delete e.selObj;
			data.push(e);
		});
		data = {
			'name':this.name,
			'floors':data
		};

		return data;
	},
	touch: function(obj) {
		var canvas = this.canvas;
		if (typeof obj !== "object")
			return;

		obj.lastupdate = canvas.frame;
		var idx = this.killqueue.indexOf(obj);
		if (idx >= 0)
			this.killqueue.splice(idx, 1);
		this.killqueue.push(obj);
	},
	kill: function() {
		var canvas = this.canvas;
		var changed = false;
		var lastidx = -1;
		var defaulttime = this.lifetime;
		this.killqueue.every((function(obj, i) {
			var lifetime = defaulttime;
			if (obj.lifetime !== undefined)
				lifetime = obj.lifetime;
			if (lifetime === undefined)
				return;
			lastidx = i;
			if (canvas.frame - obj.lastupdate > lifetime) {
				this.floor.remove(obj);
				if (!!this.cbKill)
					this.cbKill(obj);
				changed = true;
				return true;
			}
			return false;
		}).bind(this));
		this.killqueue.splice(0, lastidx);
		if (changed)
			canvas.refresh();
	}
}

var Floor = function(name) {
	this.points = [];
	this.lines = [];
	this.planes = [];
	this.objects = [];
	this.objlinks = [];
	this.name = name;
	this.selObj = null;
	this.floorHeight = 3;
	this.ceilingHeight = 2.5;
}
Floor.prototype = {
	getObjMap: function() {
		var objs = new Object();
		this.objects.forEach(function(o) {
			objs[o.name] = o;
		});
		return objs;
	},
	getPoint: function(pos) {
		var ret = null;
		this.points.forEach(function(p) {
			if (p.pos[0] == pos[0] && Math.abs(p.pos[1] - pos[1]) < 0.01 && p.pos[2] == pos[2])
				ret = p;
		});
		if (!!ret)
			return ret;
	
		return new Point(this, pos);
	},
	deleteObj: function(obj, unlinkOnly) {
		if (!!ObjTypes[obj.type].isWall) {
			this.lines.forEach(function(l) {
				for (var key in l.objs) {
					if (l.objs[key] === obj)
						delete l.objs[key];
				}
			});
		}

		if (!!obj.childs) {
			while (obj.childs.length > 0) {
				this.deleteObj(obj.childs[0]);
			}
		}

		if (!!obj.parent) {
			var i = obj.parent.childs.indexOf(obj);
			if (i >= 0)
				obj.parent.childs.splice(i, 1);
		}

		if (!unlinkOnly) {
			var i = this.objects.indexOf(obj);
			if (i >= 0)
				this.objects.splice(i, 1);
		}
	},
	deletePoint: function(p) {
		var idx = this.points.indexOf(p);
		if (idx < 0)
			return;

		this.points.splice(idx, 1);
	},
	deletePlane: function(p) {
		var idx = this.planes.indexOf(p);
		if (idx < 0)
			return;

		this.planes.splice(idx, 1);
	},
	deleteObjLink: function(l) {
		var idx = this.objlinks.indexOf(l);
		if (idx < 0)
			return;

		this.objlinks.splice(idx, 1);
	},
	deleteWall: function(l) {		
		var orphaned = false;
		if (l.start.lines.length == 1) {
			this.deletePoint(l.start);
			orphaned = true;
		}
		else {
			l.start.lines.splice(l.start.lines.indexOf(l), 1);
		}
		if (l.end.lines.length == 1) {
			this.deletePoint(l.end);
			orphaned = true;
		}
		else {
			l.end.lines.splice(l.end.lines.indexOf(l), 1);
		}

		if (!orphaned) {
			var planes = this.planes.filter(function(p) {
				return (p.p.indexOf(l.start) >= 0 && p.p.indexOf(l.end) >= 0);
			});

			if (planes.length == 1) {
				this.deletePlane(planes[0]);
			}
			else if (planes.length == 2) {
/*				function findPoint(planes, p, l, arr) {
					if (planes[0].indexOf(p) < 0 || planes[1].indexOf(p) < 0) {
						return p;
					}
					if (p.lines.length == 1) {
						if (p.lines[0] == l)
							return null;
						l = p.lines[0];
					}
					else if (p.lines.length == 0) {
						//exception
						return null;
					}
					else if (p.lines.length == 2) {
						if (p.lines[0] == l)
							l = p.lines[1];
						else
							l = p.lines[0];
					}
					else {
						//todo
						return null;
					}

				}*/
			}

/*			var getplanes = (function (p) {
				return this.planes.filter(function(plane) {
					return (plane.p.indexOf(p) >= 0);
				});
			}).bind(this);
			var start = getplanes(l.start), end = getplanes(l.end);
			console.log(start, end);*/
		}

		var idx = this.lines.indexOf(l);
		if (idx < 0)
			return;

		this.lines.splice(idx, 1);


	},
	remove: function(any) {
		if (any instanceof Obj)
			return this.deleteObj(any);
		else if (any instanceof Wall)
			return this.deleteWall(any);
		else if (any instanceof Plane)
			return this.deletePlane(any);
		else if (any instanceof ObjLink)
			return this.deleteObjLink(any);
	},
	draw: function(canvas, mat) {
		this.points.forEach(function(d) {
			if (!d.lines.length)
				return;

			if (d.lines.length == 1) {
				//single line end
				delete d.cp;
				delete d.p0;
				delete d.p1;
			}
			else {
				//merge
				var p0 = d.lines[0], p1 = d.lines[1];
				if (p0.start === d) {
					p0.sstart = -1;
					p0 = p0.end.pos;
				}
				else if(p0.end === d) {
					p0.send = 1;
					p0 = p0.start.pos;
				}
				else
					return;

				if (p1.start === d) {
					p1.sstart = 1;
					p1 = p1.end.pos;
				}
				else if (p1.end === d) {
					p1.send = -1;
					p1 = p1.start.pos;
				}
				else
					return;

				var dx0 = d.pos[2] - p0[2], dy0 = d.pos[0] - p0[0];
				var dx1 = p1[2] - d.pos[2], dy1 = p1[0] - d.pos[0];
				var d0 = Math.sqrt(dx0*dx0 + dy0*dy0);
				var d1 = Math.sqrt(dx1*dx1 + dy1*dy1);
				var dl = 0.1;
				dx0/=d0; dy0/=d0;
				dx1/=d1; dy1/=d1;
				var x3 = (dx1 - dx0) * dl, y3 = (dy1 - dy0) * dl;
				var d3 = x3*x3 + y3*y3;
				var dot = dx0 * (-dy1) + dy0 * dx1;
				//console.log(dot);
				var cp = -Math.sign(dot) * Math.sqrt((dl*dl*d3) / (4*dl*dl - d3));
				
				d.cp = cp;
				d.p0 = [d.pos[0] + dx1 * dl + dy1 * cp, d.pos[1], d.pos[2] - dy1 * dl + dx1 * cp];
				d.p1 = [d.pos[0] - dx1 * dl - dy1 * cp, d.pos[1], d.pos[2] + dy1 * dl - dx1 * cp];
				//console.log(d);
			}
		});

		this.lines.forEach(function(l) {
			l.reference = 0;
		});

		this.planes.forEach((function(plane, i) {
			var lp = plane.p[plane.p.length - 1];
			plane.p.forEach(function(p) {
				var line = p.lines.filter(function(l) {
					return ((l.start == lp && l.end == p) || (l.start == p && l.end == lp));
				});
				if (!!line[0]) {
					line[0].reference++;
				}
				lp = p;
			});
			var color = undefined;
			if (plane === this.selObj) {
				color = [1, 0, 0, 1];
			}
			plane.draw(canvas, mat, color, this.ceilingHeight);
		}).bind(this));

		this.lines.forEach((function(l) {
			l.draw(canvas, mat, false, this.floorHeight);
		}).bind(this));

		var drawObj = (function(o, mat, bx, by) {
			var color = undefined;

			if (o === this.selObj || o.childs.indexOf(this.selObj) >= 0) {
				color = [1, 0, 0, 1];
			}
			if (!o._text) {
				o._text = new Object();
				canvas.addText(o._text, o.name, canvas.building.textbill);
			}
			canvas.drawTextBill([o.posX + bx, o.posH + 0.3, o.posY + by], /*canvas.isDark ?*/ [1, 1, 1, 1]/* : [0, 0, 0, 1]*/, o._text, canvas.building.textbill);
			var m = o.draw(canvas, mat, color, undefined, undefined, true);
			o.childs.forEach((function(obj) {
				drawObj(obj, m, o.posX + bx, o.posY + by);
			}).bind(this));
		}).bind(this);

		this.objects.forEach((function(o, i) {
			if (!!o.parent || ObjTypes[o.type].isWall)
				return;

			drawObj(o, mat, 0, 0);
		}).bind(this));

		this.objlinks.forEach((function(l) {
			if (l.name !== undefined) {
				if (!l._text) {
					l._text = new Object();
					canvas.addText(l._text, l.name);
				}
				var vec = [(l.start.posX + l.end.posX)/2, (l.start.posH + l.end.posH)/2, (l.start.posY + l.end.posY)/2];
				canvas.drawTextBill(vec, canvas.isDark ? [1, 1, 1, 1] : [0, 0, 0, 1], l._text, canvas.building.textbill);
			}

			l.draw(canvas, mat, this.selObj === l ? [1, 0, 0, 1] : l.color);
		}).bind(this));
	},
	snap: function(canvas, ppos) {
		var mag = false;
		canvas.magpoint = null;
		canvas.magline = null;

		var ret = new Object();
		this.lines.forEach(function(l) {
			var dy = (l.end.pos[2] - l.start.pos[2]), dx = (l.end.pos[0] - l.start.pos[0]);
			var d = (ppos[0] - l.start.pos[0]);
			var len = Math.sqrt(dy*dy + dx*dx);
			if (dx) {
				var a = dy/dx, b = -1, c = l.start.pos[2] - a * l.start.pos[0];
				d = (a * ppos[0] + b * ppos[2] + c) / Math.sqrt(a*a + b*b);
			}
			if (Math.abs(d) < 0.2) {
				if (dx < 0)
					len = -len;
				var ox = ppos[0] - dy*d/len, oy = ppos[2] + dx*d/len;
				var ix = false, iy = false;
				if (l.end.pos[2] >= l.start.pos[2]) {
				   if (l.start.pos[2] <= oy && l.end.pos[2] >= oy)
					   iy = true;
				}
				else {
				   if (l.start.pos[2] > oy && l.end.pos[2] < oy)
					   iy = true;
				}
				if (l.end.pos[0] >= l.start.pos[0]) {
				   if (l.start.pos[0] <= ox && l.end.pos[0] >= ox)
					   ix = true;
				}
				else {
				   if (l.start.pos[0] > ox && l.end.pos[0] < ox)
					   ix = true;
				}
				if (ix && iy) {
					ppos[0] = ox;
					ppos[2] = oy;
					canvas.magline = l;
					canvas.maglinepos = [ox, 0, oy];
					mag = true;
				}						
			}
		});
		this.points.forEach(function(p) {
			function test(pposx, pposy, magx, magy) {
				var x = p.pos[0] - pposx, y = p.pos[2] - pposy;
				var l = Math.sqrt(x*x + y*y);

				if (l < 0.2) {
					if (magx)
						ppos[0] = p.pos[0];
					if (magy)
						ppos[2] = p.pos[2];
					mag = true;
					canvas.magpoint = p;
					canvas.magline = null;
					canvas.maglinepos = null;
				}
			}
			test(ppos[0], ppos[2], true, true);
			if (canvas.editMode == 2) {
				var spos = canvas.startPoint;
				if (!!spos) {
					spos = spos.pos;
					test(spos[0], ppos[2], false, true);
					test(ppos[0], spos[2], true, false);
				}
			}
		});

		return mag;
	},
	concat: function(floor, base, objPrefix, isTotal) {
		var obj = new Object();
		var e = floor;
		if (base === undefined)
			base = 0;
		e.points.forEach((function(p) {
			obj[p.pos[0]+'_'+p.pos[2]] = new Point(this, [p.pos[0], base, p.pos[2]]);
		}).bind(this));
		e.planes.forEach((function(p) {
			var arr = [];
			p.p.forEach(function(elem) {
				arr.push(obj[elem.pos[0]+'_'+elem.pos[2]]);
			});
			var plane = new Plane(arr, p);
			if (!!isTotal) {
				plane.height = floor.ceilingHeight;
			}
			this.planes.push(plane);
		}).bind(this));
		var objs = new Object();
		e.objects.forEach((function(o) {
			var clone = o.clone(base);
			objs[o.name] = clone;
			this.objects.push(clone);
		}).bind(this));
		for (var key in objs) {
			var o = objs[key];
			if (!!o.parent)
				o.parent = objs[o.parent.name];
			var childs = [];
			o.childs.forEach(function(c) {
				childs.push(objs[c.name]);
			});
			o.childs = childs;
		}

		e.lines.forEach((function(l) {
			var nl = new Wall(this, obj[l.start.pos[0]+'_'+l.start.pos[2]], obj[l.end.pos[0]+'_'+l.end.pos[2]], l.color, true);
			nl.base = base;
			if (!!isTotal) {
				nl.height = floor.floorHeight;
				nl.lowheight = floor.ceilingHeight;
			}
			for (var key in l.objs) {
				nl.objs[key] = objs[l.objs[key].name];
			};
		}).bind(this));

		if (objPrefix !== undefined) {
			for (var key in objs) {
				var o = objs[key];
				o.name = objPrefix + o.name;
			}
		}
		e.objlinks.forEach((function(l) {
			this.objlinks.push(new ObjLink(objs[l.start.name], objs[l.end.name]));
		}).bind(this));
	},
	splitWall: function(wall, pos) {
		var target = wall;
		if (pos[0] == wall.start.pos[0] && Math.abs(pos[1] - wall.start.pos[1]) < 0.01 && pos[2] == wall.start.pos[2])
			return;
		if (pos[0] == wall.end.pos[0] && Math.abs(pos[1] - wall.end.pos[1]) < 0.01 && pos[2] == wall.end.pos[2])
			return;
		var point = this.getPoint(pos);
		point.lines.push(target);
		var line = new Wall(this, point, target.end, target.color, true);
		target.end = point;
		line.end.lines[line.end.lines.indexOf(target)] = line;

		//this.points.push(point);
		//this.lines.push(line);
		this.planes.forEach(function(plane) {
			var p = plane.p;
			var idx1 = p.indexOf(target.start), idx2 = p.indexOf(line.end);
			if (idx1 < 0 || idx2 < 0)
				return;

			if (idx1 == p.length - 1 && idx2 == 0)
				p.splice(idx2, 0, point); 
			else if (idx1 == 0 && idx2 == p.length - 1)
				p.splice(idx1, 0, point); 
			else if (idx1 < idx2)
				p.splice(idx2, 0, point); 
			else
				p.splice(idx1, 0, point); 
		 });
		return point;
	},
	addWall: function(pStart, pEnd) {
		var prevpoint = pStart, point = pEnd;
		var plane = new Plane();
		this.planes.every(function(cp, i) {
			var p = cp.p;
			//둘중에 하나가 해당 플래인 안에 있으면 종점을 찾는다. 두놈이 다른 플레인 안에 있으면 선을 짤라야 되는데...
			//중간에 있는 포인트들을 삽입 (방향이 다름)
			//var pi = p.indexOf(point), ppi = p.indexOf(prevpoint);
			var pl = [], ppl = [];
			var pi = cp.findPoint(point, pl), ppi = cp.findPoint(prevpoint, ppl);
			if (pi < 0 || ppi < 0)
				return true;

			if (pi < ppi) {
				cp.p = p.slice(pi, ppi + 1).concat(ppl.reverse(), pl);
				plane.p = p.slice(0, pi + 1).concat(pl.reverse(), ppl.reverse(), p.slice(ppi));
				//msgbox.println("1 " + pi + " " + ppi);
			}
			else {
				cp.p = p.slice(ppi, pi + 1).concat(pl.reverse(), ppl);
				plane.p = p.slice(0, ppi + 1).concat(ppl.reverse(), pl.reverse(), p.slice(pi));
//				cp.p = pl.concat(ppl.reverse(), p.slice(ppi, pi + 1).reverse());
//				plane.p = p.slice(0, ppi + 1).concat(ppl, pl.reverse(), p.slice(pi));
				//msgbox.println("2 " + ppi + " " + pi);
			}
			return false; 
		});
		if (plane.p.length == 0 && (pStart.lines.length == 1 || pEnd.lines.length == 1)) {
			var start = pStart, end = pEnd;
			if (pStart.lines.length > 1) {
				start = pEnd;
				end = pStart;
			}

			var ll = start.lines[0], pos = start;
			plane.p.push(pos);
			var step = 0;
			for (;;) {
				step++;
				if (step > 100) {
					console.log(plane.p);
					return;
				}

				var nextpos = ll.start;
				if (ll.start == pos)
					nextpos = ll.end;

				var linevec = nextpos.pos.slice();
				vec3.subtract(linevec, pos.pos);
				vec3.normalize(linevec);

				var minval = Math.PI * 2, minl = null;
				nextpos.lines.forEach(function(l) {
					if (l == ll)
						return;
					var np = l.start;
					if (l.start == nextpos)
						np = l.end;

					var lvec = np.pos.slice();
					vec3.subtract(lvec, pos.pos);
					vec3.normalize(lvec);

					var sin = [];
					var cos = vec3.dot(linevec, lvec);
					vec3.cross(linevec, lvec, sin);
					var theta = Math.acos(cos) + (sin[1]<0?Math.PI:0);
					if (theta == 0)
						return;
					if (theta < minval) {
						minval = theta;
						minl = l;
					}
				});
				console.log(minval, minl);
			
				pos = nextpos;
				plane.p.push(pos);
				if (nextpos == end)
					break;
				
				//nextpos.lines.forEach(function(l) {
				//});
/*				var nextline = nextpos.lines[0];
				if (nextline == ll)
					nextline = nextpos.lines[1];*/
				nextline = minl;

				ll = nextline;
				if (!ll) {
					plane.p = [];
					break;
				}
			}
//			this.points.forEach(function(p) {
//				plane.p.push(p);
//			});
		}
		if (plane.p.length > 0)
			this.planes.push(plane);
	},
	getProperties: function() {
		return [
			['name', 'string'],
			['floorHeight', 'number'],
			['ceilingHeight', 'number'],
		];
	},
	getProperty: function(key) {
		return this[key];
	},
	setProperty: function(key, value) {
		this[key] = value;
	},
	getName: function() {
		return this.name;
	}
}

var Point = function(floor, pos) {
	this.lines = [];
	this.pos = pos.slice();

	if (!!floor)
		floor.points.push(this);
}
Point.prototype = {
	toJSON: function() {
		return this.pos;
	}
}

var Wall = function(floor, pStart, pEnd, color, manual) {
	this.start = pStart;
	this.end = pEnd;
	this.sstart = 1;
	this.send = 1;
	this.base = 0;
	this.color = color;
	this.objs = new Object();

	if (!manual) {
		var overlapped = false;
		floor.lines.forEach(function(l) {
			if (Math.abs(pStart.pos[1] - l.start.pos[1]) > 0.01 || Math.abs(pEnd.pos[1] - l.end.pos[1]) > 0.01)
				return;
			var p1 = l.testPoint(pStart.pos, 0.01), p2 = l.testPoint(pEnd.pos, 0.01);

			if (p1 && p2);
			else if (p1)
				floor.splitWall(l, pStart.pos);
			else if (p2)
				floor.splitWall(l, pEnd.pos);

			if (!p1 || !p2)
				return;

			overlapped = true;
		});

		if (overlapped) {
			return;
		}

		if (pStart.lines.length && pEnd.lines.length) {
			floor.addWall(pStart, pEnd);
			//console.log('addWall', pStart.pos, pEnd.pos);
		}
	}

	pStart.lines.push(this);
	pEnd.lines.push(this);
	floor.lines.push(this);
}
Wall.prototype = {
	toJSON: function() {
		var objs = new Object();
		for (var key in this.objs) {
			objs[key] = this.objs[key].name;
		}

		return {
			start: this.start,
			end: this.end,
			color: this.color,
			objs: objs 
		}
	},
	testHit: function(p1, p2) {
		var r = [], s = [], p = p2, q = this.start.pos, q_p = [], rxs = [], tv = [], uv = [];
		vec3.subtract(p2, p1, r);
		vec3.subtract(this.end.pos, this.start.pos, s);
		vec3.subtract(q, p, q_p);
		vec3.cross(r, s, rxs);
		vec3.cross(q_p, s, tv);
		vec3.cross(q_p, r, uv);
		var rxs2 = rxs[0]*rxs[0]+rxs[1]*rxs[1]+rxs[2]*rxs[2];
		if (rxs2 == 0)
			return false;
		var t = vec3.dot(tv, rxs) / rxs2;
		var u = vec3.dot(uv, rxs) / rxs2;

		//console.log(t, u);
		if (t >= 0 && t <= 1 && u >= 0 && u <= 1)
			return true;
		return false;
	},
	testPoint: function(ppos, dlimit) {
		var l = this;
		var dy = (l.end.pos[2] - l.start.pos[2]), dx = (l.end.pos[0] - l.start.pos[0]);
		var d = (ppos[0] - l.start.pos[0]);
		var len = Math.sqrt(dy*dy + dx*dx);
		if (dx) {
			var a = dy/dx, b = -1, c = l.start.pos[2] - a * l.start.pos[0];
			d = (a * ppos[0] + b * ppos[2] + c) / Math.sqrt(a*a + b*b);
		}
		if (Math.abs(d) < dlimit) {
			if (dx < 0)
				len = -len;
			var ox = ppos[0] - dy*d/len, oy = ppos[2] + dx*d/len;
			var ix = false, iy = false;
			if (l.end.pos[2] >= l.start.pos[2]) {
			   if (l.start.pos[2] - dlimit <= oy && l.end.pos[2] + dlimit >= oy)
				   iy = true;
			}
			else {
			   if (l.start.pos[2] + dlimit >= oy && l.end.pos[2] - dlimit <= oy)
				   iy = true;
			}
			if (l.end.pos[0] >= l.start.pos[0]) {
			   if (l.start.pos[0] - dlimit <= ox && l.end.pos[0] + dlimit >= ox)
				   ix = true;
			}
			else {
			   if (l.start.pos[0] + dlimit >= ox && l.end.pos[0] - dlimit <= ox)
				   ix = true;
			}
			if (ix && iy) {
				//ppos[0] = ox;
				//ppos[2] = oy;
				//canvas.magline = l;
				//canvas.maglinepos = [ox, 0, oy];
				//mag = true;
				return [ox, 0, oy];
			}					
		}
		return null;
	},
	draw: function(canvas, mat, objOnly, dh) {
		var l = this;
		var vec = l.end.pos.slice();
		vec3.subtract(vec, l.start.pos);
		var len = vec3.length(vec);
		var points = [];
		var sel = null;
		points.push(l.start.pos);
		
		var poss = Object.keys(l.objs).sort(function(a, b) {return a-b});;
		
		for (var i = 0; i < poss.length; i++) {
			var pos = poss[i];
			var obj = l.objs[pos];
			var v2 = [];
			var type = ObjTypes[obj.type];
			var width = type.width / (len * 2);

			pos = parseFloat(pos);
			vec3.scale(vec, pos - width, v2);
			vec3.add(v2, l.start.pos);
			points.push(v2.concat([type.lowH, type.highH]));
			v2 = [];
			vec3.scale(vec, pos + width, v2);
			vec3.add(v2, l.start.pos);
			points.push(v2);
			v2 = [];
			vec3.scale(vec, pos, v2);
			vec3.add(v2, l.start.pos);

			var m = [];
			mat4.identity(m);
			mat4.translate(m, [v2[0], 0, v2[2]]);
			mat4.rotateY(m, Math.atan2(-vec[2], vec[0]));
			var color = undefined;
			if (!!objOnly) {
				var j = canvas.floor.objects.indexOf(obj);
				color = [127/255, (j >> 8)/255, (j & 255)/255, 1];
			}
			else if (obj === canvas.floor.selObj) {
				color = [1, 0, 0, 1];
				sel = i;
			}
			obj.draw(canvas, m, color);
		}
		//console.log(points);
		points.push(l.end.pos);

		if (!!objOnly)
			return;

		if (dh === undefined) {
			dh = 2.49;
		}
		if (l.height !== undefined) {
			dh = l.height;
		}
		if (l.reference > 1 && l.lowheight !== undefined)
			dh = l.lowheight;
		for (var i = 0; i < points.length - 1; i++) {
			var r = 1, g = 1, b = 1, a = 1;
			var hl = l.base, d = 0.1;
			//var p0 = l.start.pos, p1 = l.end.pos;
			var p0 = points[i], p1 = points[i + 1];
			var x = p0[0], y = p0[2], xn = p1[0], yn = p1[2];
			var dx1 = yn - y, dy1 = xn - x;
			var d1 = Math.sqrt(dx1*dx1 + dy1*dy1);
			dx1 /= d1;
			dy1 /= d1;
			var x1 = x - dx1 * d, y1 = y + dy1 * d;
			var x0 = x + dx1 * d, y0 = y - dy1 * d;
			var x3 = xn - dx1 * d, y3 = yn + dy1 * d;
			var x2 = xn + dx1 * d, y2 = yn - dy1 * d;
			var ddh = dh;

			var color = l.color;
			if (l.color[3] == 0)
				color = [0.6, 0.6, 0.6, 0.8];
			if (l === canvas.floor.selObj)
				color = [1, 0, 0, 1];

			var v = 0;
			if (l === canvas.floor.selObj || canvas.isTotalView)
				v = 1;

			if (i & 1) {
				hl += p0[4];
				ddh -= p0[4];
				v = 1;
				
				if ((i-1)/2 == sel) {
					color = [1, 0, 0, 1];
				}
			}

			if (i == 0 && l.start.cp !== undefined) {
				var cp = l.start.cp * l.sstart;
				x1-=cp*dy1;
				y1-=cp*dx1;
				x0+=cp*dy1;
				y0+=cp*dx1;
			}
			if (i + 1 == points.length - 1 && l.end.cp !== undefined) {
				var cp = l.end.cp * l.send;
				x2-=cp*dy1;
				y2-=cp*dx1;
				x3+=cp*dy1;
				y3+=cp*dx1;
			}
			
			if (l.color[3] == 0)
				canvas.drawBox([x0, hl, y0], [x1, hl, y1], [x2, hl, y2], [x3, hl, y3], 0.02, 0x20, color, canvas.building.transparent);
			else if (l.color[3] < 1)
				canvas.drawBox([x0, hl, y0], [x1, hl, y1], [x2, hl, y2], [x3, hl, y3], ddh, 0x3f, color, canvas.building.transparent, [1, 1, 1, 1,  1, 1, 1, 1,  1, 1, 1, 1,  1, 1, 1, 1,  1, 1, 1, 1,  v, v, v, v]);
			else
				canvas.drawBox([x0, hl, y0], [x1, hl, y1], [x2, hl, y2], [x3, hl, y3], ddh, 0x3f, color, canvas.building.solid, [1, 1, 1, 1,  1, 1, 1, 1,  1, 1, 1, 1,  1, 1, 1, 1,  1, 1, 1, 1,  v, v, v, v]);
		}
	}
}

var Plane = function(array, clone) {
	if (!array)
		this.p = [];
	else
		this.p = array;
	this.base = 0;
	this.name = '';
	if (!!clone) {
		for (var key in clone) {
			if (key == "p")
				continue;
			this[key] = clone[key];
		}
	}
}
Plane.prototype = {
	setSlope: function(x, y, h) {
		if (this.p.length != 4) {
			this.base = h;
			return;
		}
		var dist = this.p.map(function(p, i) {
			var src = [x, 0, y];
			vec3.subtract(src, p.pos);
			return [vec3.length(src), i];
		});
		dist.sort(function(a, b) {
			return a[0] - b[0];
		});
		if (this.slopeA !== undefined  && dist[0][1] != this.slopeA && dist[1][1] != this.slopeB) {
			this.base = h;
		}
		else {
			this.slopeA = dist[0][1];
			this.slopeB = dist[1][1];
			this.slopeH = h;
		}
	},
	draw: function(canvas, mat, color, high) {
		var p = this.p;
		var solid = canvas.building.solid;
		var aV = solid.vertices, aC = solid.colors, aT = solid.texture, aN = solid.normal;
		var indices = [];
		p.forEach(function(pt) {
			indices.push(pt.pos[0], pt.pos[2]);
		});

		var r = 0.5;
		var g = 0.5;
		var b = 0.5;
		var a = 1;
		if (!canvas.isTotalView) {
			r = 0;
			g = 0;
			b = 0;
			a = 0.7;
		}

		if (!color && !!this.color)
			color = this.color;
		if (!!color) {
			r = color[0];
			g = color[1];
			b = color[2];
			a = color[3];
		}

		var triangles = earcut(indices);
		triangles.forEach((function (t) {
			var pos = p[t].pos;
			var h = this.base;
			if (t == this.slopeA || t == this.slopeB)
				h = this.slopeH;
			aV.push(p[t].pos[0], p[t].pos[1] + h, p[t].pos[2]);
			//aC.push(0.5 + 0.5 * (i&4), 0.5 + 0.5 * (i&2), 0.5 + 0.5 * (i&1), 1);
			aC.push(r, g, b, a);
			aT.push(0, 0);
			aN.push(0, 1, 0);
		}).bind(this));

		if (!canvas.isTotalView)
			return;

		if (high === undefined)
			high = 2.4;
		if (this.height !== undefined)
			high = this.height;

		triangles.forEach((function (t) {
			var pos = p[t].pos;
			var h = this.base;
			if (t == this.slopeA || t == this.slopeB)
				h = this.slopeH;
			aV.push(p[t].pos[0], p[t].pos[1] + h + high, p[t].pos[2]);
			//aC.push(0.5 + 0.5 * (i&4), 0.5 + 0.5 * (i&2), 0.5 + 0.5 * (i&1), 1);
			aC.push(1, 1, 1, 1);
			aT.push(0, 0);
			aN.push(0, -1, 0);
		}).bind(this));
	},
	insert: function(pPos, pNew) {

	},
	isInside: function(x, y) {
/*		var plane = this;
		var lp = plane.p[plane.p.length - 1];
		var totalth = 0;
		plane.p.forEach(function(p) {
			if (!!lp) {
				var x1 = lp.pos[0] - x, y1 = lp.pos[2] - y;
				var x2 = p.pos[0] - x, y2 = p.pos[2] - y;
				var d1d2 = Math.sqrt((x1*x1 + y1*y1) * (x2*x2 + y2*y2));
				var c = (x1*x2 + y1*y2) / d1d2;
				totalth += Math.acos(c);
			}
			lp = p;
		});
		return (Math.abs(totalth - 6.2831853) < 0.01);*/
		var indices = [];
		var p = this.p;
		p.forEach(function(pt) {
			indices.push(pt.pos[0], pt.pos[2]);
		});
		var triangles = earcut(indices);
		var lp;
		var j = 0;
		var totalth = 0;
		var result = triangles.every(function (t, i) {
			if (j == 0) {
				lp = p[triangles[i + 2]]; 
				totalth = 0;
			}
			var x1 = lp.pos[0] - x, y1 = lp.pos[2] - y;
			var x2 = p[t].pos[0] - x, y2 = p[t].pos[2] - y;
			var d1d2 = Math.sqrt((x1*x1 + y1*y1) * (x2*x2 + y2*y2));
			var c = (x1*x2 + y1*y2) / d1d2;
			totalth += Math.acos(c);

			if (j == 2) {
				if (Math.abs(totalth - Math.PI*2) < 0.01)
					return false;
			}

			lp = p[t];
			j++;
			if (j >= 3)
				j = 0;
			return true;
		});

		return !result;
	},
	findPoint: function(pos, poslist, next) {
		var plane = this;
		var idx = plane.p.indexOf(pos);
		if (idx >= 0)
			return idx;
		if (!next) {
			if (pos.lines.length == 1)
				next = pos.lines[0];
			else
				return idx;
		}

		var ll = next, startll = next, step = 0;
		poslist.push(pos);
		for (;;) {
			var nextpos = ll.start;
			if (ll.start == pos)
				nextpos = ll.end;

			idx = plane.p.indexOf(nextpos);
			if (idx >= 0)
				return idx;
			//if (nextpos.lines.length != 2)
			//	return idx;

			if (!plane.isInside(nextpos.pos[0], nextpos.pos[2]))
				return -1;
			poslist.push(nextpos);

			var nextline = nextpos.lines[0];
			if (nextpos.lines.length == 1)
				return -1;
			if (nextline == ll && nextpos.lines.length == 2)
				nextline = nextpos.lines[1];
			else {
				for (var i = 0; i < nextpos.lines.length; i++) {
					nextline = nextpos.lines[i];
					if (nextline == ll)
						continue;

					var addposlist = [];
					var ret = this.findPoint(nextpos, addposlist, nextline);
					if (ret >= 0) {
						console.log(poslist, addposlist);
						addposlist.forEach(function(item) {
							poslist.push(item);
						});
						return ret;
					}
				}
				return -1;
			}

			if (step && ll == startll)
				return -1;
			ll = nextline;
			pos = nextpos;
			step++;
		}
		return idx;
	}
}

var Obj = function(opt) {
	for (var key in opt) {
		if (key in Obj.prototype)
			continue;
		this[key] = opt[key];
	}
	this.overrides = new Object();
}
Obj.prototype = {
	toJSON: function() {
		var obj = new Object();
		for (var key in this) {
			if (key.substring(0, 1) == '_')
				continue;
			obj[key] = this[key];
			if (key == "parent") {
				obj[key] = this[key].name;
			}
			else if (key == "childs") {
				obj[key] = [];
				this[key].forEach(function(o) {
					obj[key].push(o.name);
				});
			}
		}

		return obj;
	},
	getMatrix: function() {
		var m = [];
		mat4.identity(m);
		mat4.rotateY(m, this.rotate * Math.PI / 180);
		mat4.translate(m, [-this.posX, -this.posH, -this.posY]);
		return m;
	},
	clone: function(h) {
		var obj = new Obj(this);
		if (h !== undefined && !this.parent)
			obj.posH += h;

		var childs = [];
		obj.childs.forEach(function (o, i) {
			childs.push(o.clone());
		});
		obj.childs = childs;
		return obj;
	},
	draw: function(canvas, mat, color, base, path, noDrawChild) {
		if (!base) {
			base = this;
			path = this.name + '/';
		}

		var o = this;
		var m = [], r = 0;

		mat4.translate(mat, [o.posX, o.posH, o.posY], m);
		if (o.centerX !== undefined) {
			mat4.translate(m, [o.centerX, 0, o.centerY]);
		}
		if (o.rotate !== undefined) {
			var rotate = canvas.building.getProperty(path + 'rotate');
			if (o.type == 'box' || o.type == 'plane' || o.type == 'sphere' || o.type == 'nop') {
				r += rotate;
			}
		}
		if (r) {
			mat4.rotateY(m, r * Math.PI / 180);
		}
		var m2 = m.slice();
		if (o.centerX !== undefined) {
			mat4.translate(m, [-o.centerX, 0, -o.centerY]);
		}
		if (o.scale !== undefined) {
			mat4.scale(m, [o.scale, o.scale, o.scale]);
		}
		if (o.type == 'nop') {
		}
		else if (o.type == 'box') {
			var v0 = [0, 0, 0], v1 = [0, 0, o.sizeY], v2 = [o.sizeX, 0, 0], v3 = [o.sizeX, 0, o.sizeY], vh = [0, o.sizeH, 0];
			mat4.multiplyVec3(m, v0);
			mat4.multiplyVec3(m, v1);
			mat4.multiplyVec3(m, v2);
			mat4.multiplyVec3(m, v3);
			mat4.multiplyVec3(m, vh);
			var boxcolor = canvas.building.getProperty(path + 'color');
			if (!boxcolor)
				boxcolor = o.color;
			boxcolor = !!color ? color : boxcolor;
			canvas.drawBox(v0, v1, v2, v3, vh[1], 0x3f, boxcolor, boxcolor[3] < 1 ? canvas.building.transparent : canvas.building.object, [1,1,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1], 0.01, canvas.tsize/canvas.building.ledtexsize - 0.01, !!color);
		}
		else if (o.type == 'sphere') {
			var v0 = [0, 0, 0];
			mat4.multiplyVec3(m, v0);
			var boxcolor = canvas.building.getProperty(path + 'color');
			if (!boxcolor)
				boxcolor = o.color;
			boxcolor = !!color ? color : boxcolor;
			canvas.drawSphere(v0, o.sizeX, boxcolor, boxcolor[3] < 1 ? canvas.building.transparent : canvas.building.object);
		}
		else if (o.type == 'plane') {
			var color = canvas.building.getProperty(path + 'color');
			if (!color)
				color = o.color;
			var v0 = [0, 0, 0], v2 = [o.sizeX, 0, 0], v1 = [0, o.sizeY, 0], v3 = [o.sizeX, o.sizeY, 0];
			var r = color[0], g = color[1], b = color[2], a = color[3];
			var tl = (canvas.trect*o.texture)/canvas.building.ledtexsize + 0.01, th = (canvas.trect*(o.texture+1))/canvas.building.ledtexsize - 0.01;
			mat4.multiplyVec3(m, v0);
			mat4.multiplyVec3(m, v1);
			mat4.multiplyVec3(m, v2);
			mat4.multiplyVec3(m, v3);
			canvas.building.object.vertices.push(v0[0], v0[1], v0[2],  v1[0], v1[1], v1[2],  v2[0], v2[1], v2[2],  v2[0], v2[1], v2[2],  v1[0], v1[1], v1[2],  v3[0], v3[1], v3[2]);
			canvas.building.object.colors.push(r, g, b, a,  r, g, b, a,  r, g, b, a,  r, g, b, a,  r, g, b, a,  r, g, b, a);
			canvas.building.object.texture.push(0, tl,  0, th,  1, tl,  1, tl,  0, th,  1, th);
			canvas.building.object.normal.push(0, 1, 0,  0, 1, 0,  0, 1, 0,  0, 1, 0,  0, 1, 0,  0, 1, 0);
		}
		else if (o.type == 'label') {
			var color = canvas.building.getProperty(path + 'color');
			if (!color)
				color = o.color;
			if (!o._text) {
				o._text = new Object();
				canvas.addText(o._text, o.text);
			}
			var slen = (o._text.textWidth - 2) / canvas.sztext;
			var v0 = [0, 0, 0], v2 = [o.sizeX * slen, 0, 0], v1 = [0, o.sizeY, 0], v3 = [o.sizeX * slen, o.sizeY, 0];
			mat4.multiplyVec3(m, v0);
			mat4.multiplyVec3(m, v1);
			mat4.multiplyVec3(m, v2);
			mat4.multiplyVec3(m, v3);
			canvas.drawText(v0, v2, v3, v1, color, o._text, canvas.building.text);
		}
		else if (!!ObjTypes[o.type]) {
			if (!color && !!ObjTypes[o.type].userColor && !!o.color)
				color = o.color;
			if (o.rotate !== undefined)
				mat4.rotateY(m, o.rotate * Math.PI / 180);
//			if (o.centerX !== undefined) {
//				mat4.translate(m, [-o.centerX, 0, -o.centerY]);
//			}
			ObjTypes[o.type].draw(canvas, m, color, base, path);
		}
		if (!!noDrawChild)
			return m;
		if (!!o.childs) {
			o.childs.forEach(function(obj) {
//				if (!!obj.parent)
//					return;
				obj.draw(canvas, m, color, base, path + obj.name + '/');
			});
		}

		return m;
	},
	getProperties: function() {
		return ObjTypes[this.type].properties;
	},
	getProperty: function(key) {
		var obj = this;
		var token = key.split("/");
		var i = 0;
		var ret = obj[token[i]];
		if (ret === undefined) {
			ret = obj.overrides[token.slice(i).join("/")];
			if (ret !== undefined)
				return ret;

			var type = ObjTypes[obj.type];
			if (!type)
				type = obj;
			while (i < token.length - 1) {
				if (type.type !== undefined) {
					var newtype = ObjTypes[type.type];
					if (!!newtype)
						type = newtype;
				}
				if (!!type.childs) {
					type.childs.every(function(c) {
						if (c.name == token[i]) {
							type = c;
							return false;
						}
						return true;
					});
				}
				i++;
			}
			return type[token[i]];
		}
		else
			return ret;
	},
	setProperty: function(key, value) {
		var obj = this, iobj = this;
		var token = key.split("/");
		var i = 0;

		if (typeof value === 'string') {
			var props = obj.getProperties();
			if (!!props && key in props) {
				var prop = props[key];
				if (prop == 'string');
				else if (prop == 'color') {
					value = value.split(",").map(parseFloat);
				}
				else if (prop == 'number') {
					value = parseFloat(value);
				}
			}
		}		

		if (token[i] in obj) {
			obj[token[i++]] = value;
			return true;
		}

		obj.overrides[token.slice(i).join("/")] = value;
		return true;
	},
	getName: function() {
		return this.name;
	}
}

var ObjLink = function(oStart, oEnd) {
	this.start = oStart;
	this.end = oEnd;
	this.thickness = 0.02;
	this.color = [0.5, 0.5, 0.5, 1];
}
ObjLink.prototype = {
	toJSON: function() {
		return {
			start:this.start.name,
			end:this.end.name
		};
	},
	draw: function(canvas, mat, color) {
		var l = this;
		var start = l.start, end = l.end;
		var x = start.posX, y = start.posY, xn = end.posX, yn = end.posY;
		while (!!start.parent) {
			x+=start.parent.posX;
			y+=start.parent.posY;
			start = start.parent;
		}
		while (!!end.parent) {
			xn+=end.parent.posX;
			yn+=end.parent.posY;
			end = end.parent;
		}
		if (!color)
			color = this.color;
		var hl = 0.01, d = this.thickness;
		var h = start.posH + hl, hn = end.posH + hl;
		var dx1 = yn - y, dy1 = xn - x;
		var d1 = Math.sqrt(dx1*dx1 + dy1*dy1);
		dx1 /= d1;
		dy1 /= d1;
		var x1 = x - dx1 * d, y1 = y + dy1 * d;
		var x0 = x + dx1 * d, y0 = y - dy1 * d;
		var x3 = xn - dx1 * d, y3 = yn + dy1 * d;
		var x2 = xn + dx1 * d, y2 = yn - dy1 * d;

		canvas.drawBox([x0, h, y0], [x1, h, y1], [x2, hn, y2], [x3, hn, y3], 0.02, 0x20, color, canvas.building.solid);
	},
	getProperties: function() {
		return [
			['thickness', 'number'],
			['color', 'color'],
		];
	},
	getProperty: function(key) {
		return this[key];
	},
	setProperty: function(key, value) {
		this[key] = value;
	},
	getName: function() {
		return this.start.name + ' - ' + this.end.name;
	}
}

Building.Floor = Floor;
Building.Point = Point;
Building.Wall = Wall;
Building.Plane = Plane;
Building.Obj = Obj;
Building.ObjLink = ObjLink;

var ObjTypes = {
'cloud':new Obj({
	'type':'sphere',
	'name':'cloud',
	'posX':0,
	'posY':0,
	'posH':1.5,
	'sizeX':1.5,
	'color':[0.8, 0.9, 1, 1],
	'childs':[new Obj({
		'type':'sphere',
		'name':'cloud',
		'posX':1.5,
		'posY':0,
		'posH':-0.3,
		'sizeX':1,
		'color':[0.8, 0.9, 1, 1],
	}), new Obj({
		'type':'sphere',
		'name':'cloud',
		'posX':-1.5,
		'posY':0,
		'posH':-0.2,
		'sizeX':1.1,
		'color':[0.8, 0.9, 1, 1],
	})]
}),
'door':new Obj({
	'type':'box',
	'isWall':true,
	'lowH':0,
	'highH':2,
	'width':1,
	'name':'door',
	'posX':-0.5,
	'posY':-0.05,
	'posH':0,
	'sizeX':1,
	'sizeY':0.1,
	'sizeH':2,
	'centerX':0,
	'centerY':0.05,
	'userColor':true,
	'properties':{
		'color': 'color',
	},
	'rotate':0,
	'color':[0.7, 0.6, 0.5, 1],
	'onclick':function() {
		var rot = this.getProperty('rotate');
		if (!rot)
			this.setProperty('rotate', 90);
		else
			this.setProperty('rotate', 0);
	}
}),
'table':new Obj({
	'type':'box',
	'name':'table',
	'posX':-0.8,
	'posY':-0.4,
	'posH':0.67,
	'sizeX':1.6,
	'sizeY':0.8,
	'sizeH':0.05,
	'centerX':0.8,
	'centerY':0.4,
	'color':[0.7, 0.6, 0.5, 1],
	'childs':[new Obj({
		'type':'box',
		'name':'foot1',
		'posX':0,
		'posY':0,
		'posH':-0.67,
		'sizeX':0.05,
		'sizeY':0.05,
		'sizeH':0.67,
		'color':[0.1, 0.1, 0.1, 1],
	}),new Obj({
		'type':'box',
		'name':'foot2',
		'posX':1.6-0.05,
		'posY':0,
		'posH':-0.67,
		'sizeX':0.05,
		'sizeY':0.05,
		'sizeH':0.67,
		'color':[0.1, 0.1, 0.1, 1],
	}),new Obj({
		'type':'box',
		'name':'foot3',
		'posX':0,
		'posY':0.8-0.05,
		'posH':-0.67,
		'sizeX':0.05,
		'sizeY':0.05,
		'sizeH':0.67,
		'color':[0.1, 0.1, 0.1, 1],
	}),new Obj({
		'type':'box',
		'name':'foot4',
		'posX':1.6-0.05,
		'posY':0.8-0.05,
		'posH':-0.67,
		'sizeX':0.05,
		'sizeY':0.05,
		'sizeH':0.67,
		'color':[0.1, 0.1, 0.1, 1],
	})]
}),
'rack42u':new Obj({
	'type':'box',
	'name':'rack42u',
	'posX':-0.3,
	'posY':-0.5,
	'posH':0.05,
	'sizeX':0.6,
	'sizeY':1,
	'sizeH':0.1,
	'rangeX':[0, 0, 0],
	'rangeY':[-0.43, -0.43, 0],
	'rangeH':[0.16, 1.98245, 0.04445],
	'color':[0.1, 0.1, 0.1, 1],
	'childs':[new Obj({
		'type':'box',
		'name':'left',
		'posX':0,
		'posY':0,
		'posH':0.1,
		'sizeX':0.05,
		'sizeY':1,
		'sizeH':1.9,
		'color':[0.1, 0.1, 0.1, 1],
	}),new Obj({
		'type':'box',
		'name':'right',
		'posX':0.55,
		'posY':0,
		'posH':0.1,
		'sizeX':0.05,
		'sizeY':1,
		'sizeH':1.9,
		'color':[0.1, 0.1, 0.1, 1],
	}),new Obj({
		'type':'box',
		'name':'top',
		'posX':0,
		'posY':0,
		'posH':2,
		'sizeX':0.6,
		'sizeY':1,
		'sizeH':0.1,
		'color':[0.1, 0.1, 0.1, 1],
	})]
}),
'server':new Obj({
	'type':'box',
	'name':'server',
	'posX':-0.24,
	'posY':0,
	'posH':0,
	'sizeX':0.48,
	'sizeY':0.42,
	'sizeH':0.086,
	'centerX':0.22,
	'centerY':0,
	'color':[0.3, 0.3, 0.3, 1],
	'properties':{
		'color': 'color',
		'p1/color': 'color',
		'p2/color': 'color',
		'p3/color': 'color',
		'p4/color': 'color'
	},
	'childs':[new Obj({
		'type':'label',
		'name':'label',
		'posX':0.2,
		'posY':-0.001,
		'posH':0.005,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'text':'Logpresso',
		'color':[0, 1, 0, 1]
	}),new Obj({
		'type':'plane',
		'name':'p1',
		'posX':0.14,
		'posY':-0.001,
		'posH':0.005,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p2',
		'posX':0.12,
		'posY':-0.001,
		'posH':0.005,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p3',
		'posX':0.1,
		'posY':-0.001,
		'posH':0.005,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p4',
		'posX':0.08,
		'posY':-0.001,
		'posH':0.005,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	})]
}),
'EX3200-24T':new Obj({
	'type':'box',
	'name':'EX3200-24T',
	'posX':-0.24,
	'posY':0,
	'posH':0,
	'sizeX':0.48,
	'sizeY':0.42,
	'sizeH':0.043,
	'centerX':0.22,
	'centerY':0,
	'color':[0.3, 0.3, 0.3, 1],
	'properties':{
		'24P/p0/color': 'color',
		'24P/p1/color': 'color',
		'24P/p2/color': 'color',
		'24P/p3/color': 'color',
		'24P/p4/color': 'color',
		'24P/p5/color': 'color',
		'24P/p6/color': 'color',
		'24P/p7/color': 'color',
		'24P/p8/color': 'color',
		'24P/p9/color': 'color',
		'24P/p10/color': 'color',
		'24P/p11/color': 'color',
		'24P/p12/color': 'color',
		'24P/p13/color': 'color',
		'24P/p14/color': 'color',
		'24P/p15/color': 'color',
		'24P/p16/color': 'color',
		'24P/p17/color': 'color',
		'24P/p18/color': 'color',
		'24P/p19/color': 'color',
		'24P/p20/color': 'color',
		'24P/p21/color': 'color',
		'24P/p22/color': 'color',
		'24P/p23/color': 'color',
	},
	'childs':[new Obj({
		'type':'24P',
		'name':'24P',
		'posX':0,
		'posY':0,
		'posH':0,
		'rotate':0,
	})]
}),
'24P':new Obj({
	'type':'nop',
	'name':'24P',
	'list':false,
	'posX':0,
	'posY':0,
	'posH':0,
	'rotate':0,
	'childs':[new Obj({
		'type':'plane',
		'name':'p0',
		'posX':0.455,
		'posY':-0.001,
		'posH':0.0215,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p1',
		'posX':0.455,
		'posY':-0.001,
		'posH':0.0015,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':1,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p2',
		'posX':0.435,
		'posY':-0.001,
		'posH':0.0215,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p3',
		'posX':0.435,
		'posY':-0.001,
		'posH':0.0015,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':1,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p4',
		'posX':0.415,
		'posY':-0.001,
		'posH':0.0215,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p5',
		'posX':0.415,
		'posY':-0.001,
		'posH':0.0015,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':1,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p6',
		'posX':0.395,
		'posY':-0.001,
		'posH':0.0215,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p7',
		'posX':0.395,
		'posY':-0.001,
		'posH':0.0015,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':1,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p8',
		'posX':0.375,
		'posY':-0.001,
		'posH':0.0215,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p9',
		'posX':0.375,
		'posY':-0.001,
		'posH':0.0015,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':1,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p10',
		'posX':0.355,
		'posY':-0.001,
		'posH':0.0215,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p11',
		'posX':0.355,
		'posY':-0.001,
		'posH':0.0015,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':1,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p12',
		'posX':0.33,
		'posY':-0.001,
		'posH':0.0215,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p13',
		'posX':0.33,
		'posY':-0.001,
		'posH':0.0015,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':1,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p14',
		'posX':0.31,
		'posY':-0.001,
		'posH':0.0215,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p15',
		'posX':0.31,
		'posY':-0.001,
		'posH':0.0015,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':1,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p16',
		'posX':0.29,
		'posY':-0.001,
		'posH':0.0215,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p17',
		'posX':0.29,
		'posY':-0.001,
		'posH':0.0015,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':1,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p18',
		'posX':0.27,
		'posY':-0.001,
		'posH':0.0215,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p19',
		'posX':0.27,
		'posY':-0.001,
		'posH':0.0015,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':1,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p20',
		'posX':0.25,
		'posY':-0.001,
		'posH':0.0215,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p21',
		'posX':0.25,
		'posY':-0.001,
		'posH':0.0015,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':1,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p22',
		'posX':0.23,
		'posY':-0.001,
		'posH':0.0215,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p23',
		'posX':0.23,
		'posY':-0.001,
		'posH':0.0015,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':1,
		'color':[0.3, 0.3, 0.3, 1]
	})]
}),
'SG90D-08':new Obj({
	'type':'box',
	'name':'SG90D-08',
	'posX':-0.08,
	'posY':-0.05,
	'posH':0,
	'sizeX':0.16,
	'sizeY':0.10,
	'sizeH':0.03,
	'centerX':0.08,
	'centerY':0.04,
	'color':[0.2, 0.2, 0.2, 1],
	'properties':{
		'p1/color': 'color',
		'p2/color': 'color',
		'p3/color': 'color',
		'p4/color': 'color',
		'p5/color': 'color',
		'p6/color': 'color',
		'p7/color': 'color',
		'p8/color': 'color'
	},
	'childs':[new Obj({
		'type':'plane',
		'name':'p1',
		'posX':0.14,
		'posY':-0.001,
		'posH':0.005,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p2',
		'posX':0.12,
		'posY':-0.001,
		'posH':0.005,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p3',
		'posX':0.1,
		'posY':-0.001,
		'posH':0.005,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p4',
		'posX':0.08,
		'posY':-0.001,
		'posH':0.005,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p5',
		'posX':0.06,
		'posY':-0.001,
		'posH':0.005,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p6',
		'posX':0.04,
		'posY':-0.001,
		'posH':0.005,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p7',
		'posX':0.02,
		'posY':-0.001,
		'posH':0.005,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	}),new Obj({
		'type':'plane',
		'name':'p8',
		'posX':0,
		'posY':-0.001,
		'posH':0.005,
		'sizeX':0.02,
		'sizeY':0.02,
		'centerX':0.01,
		'centerY':0.005,
		'texture':2,
		'color':[0.3, 0.3, 0.3, 1]
	})]
})};
Building.ObjTypes = ObjTypes;

if (typeof module !== 'undefined') {
	module.exports = Building;
}
if (typeof require !== 'undefined') {
	var glMatrix = require('./glMatrix-0.9.5.min.js');
	var vec3 = glMatrix[0];
	var mat3 = glMatrix[1];
	var mat4 = glMatrix[2];
	var quat4 = glMatrix[3];
}

var Buffer3D = function(canvas, opts) {
	this.canvas = canvas;
	this.disabled = false;
	var gl = this.canvas.gl;
	this.VertexPositionBuffer = gl.createBuffer();
	this.VertexColorBuffer = gl.createBuffer();
	this.TextureCoordBuffer = gl.createBuffer();
	this.VertexNormalBuffer = gl.createBuffer();
	this.numItems = 0;
	this.vertices = [];
	this.colors = [];
	this.texture = [];
	this.normal = [];
	
	if (opts !== undefined) {
		for (var key in opts) {
			this[key] = opts[key];
		}
	}
};
Buffer3D.prototype = {
	apply: function(fVertices, fColors, fTexCoord, fNormal) {
		if (this.disabled)
			return;
		var gl = this.canvas.gl;
		gl.bindBuffer(gl.ARRAY_BUFFER, this.VertexPositionBuffer);
		gl.bufferData(gl.ARRAY_BUFFER, fVertices, gl.STATIC_DRAW);
		gl.bindBuffer(gl.ARRAY_BUFFER, this.VertexColorBuffer);
		gl.bufferData(gl.ARRAY_BUFFER, fColors, gl.STATIC_DRAW);
		gl.bindBuffer(gl.ARRAY_BUFFER, this.TextureCoordBuffer);
		gl.bufferData(gl.ARRAY_BUFFER, fTexCoord, gl.STATIC_DRAW);
		gl.bindBuffer(gl.ARRAY_BUFFER, this.VertexNormalBuffer);
		gl.bufferData(gl.ARRAY_BUFFER, fNormal, gl.STATIC_DRAW);
		this.numItems = fVertices.length / 3;
	},
	draw: function() {
		if (this.disabled)
			return;
		var gl = this.canvas.gl;
		var program = this.canvas.programs.default;
		if ("program" in this) {
			program = this.canvas.programs[this.program];
		}
		gl.useProgram(program.program);

		if ("cullFace" in this) {
			this.cullFace ? gl.enable(gl.CULL_FACE) : gl.disable(gl.CULL_FACE);
		}
		if ("cullFaceSide" in this) {
			if (this.cullFaceSide == "front")
				gl.cullFace(gl.FRONT);
			else if (this.cullFaceSide == "back")
				gl.cullFace(gl.BACK);
		}
		if ("depthTest" in this) {
			this.depthTest ? gl.enable(gl.DEPTH_TEST) : gl.disable(gl.DEPTH_TEST);
		}
		if ("depthMask" in this) {
			gl.depthMask(this.depthMask);
		}
		if ("blendType" in this) {
			switch (this.blendType) {
				case "multiply":
					gl.blendFunc(gl.DST_COLOR, gl.SRC_COLOR);
					gl.blendEquation(gl.FUNC_ADD);
					break;
				case "normal":
					gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
					gl.blendEquation(gl.FUNC_ADD);
					break;
				case "plus":
					gl.blendFunc(gl.SRC_COLOR, gl.SRC_ALPHA);
					gl.blendEquation(gl.FUNC_ADD);
					break;
				case "minus":
					gl.blendFuncSeparate(gl.ZERO, gl.ONE_MINUS_SRC_COLOR, gl.ONE_MINUS_SRC_ALPHA, gl.SRC_ALPHA);
					gl.blendEquationSeparate(gl.FUNC_REVERSE_SUBTRACT, gl.FUNC_REVERSE_SUBTRACT);
					break;
			}
		}

		for (var key in program.options) {
			var option = program.options[key];
			var keyName = key;
			if ("keyName" in option)
				keyName = option.keyName;

			if (!!option.isAttrib) {
				gl.bindBuffer(gl.ARRAY_BUFFER, this[keyName]);
				gl.enableVertexAttribArray(option.location);
				gl.vertexAttribPointer(option.location, option.numItems, gl.FLOAT, false, 0, 0);
			}
			else {
				if (option.uType === "Matrix4fv") {
					var value = this.canvas[keyName];
					if (keyName in this)
						value = this[keyName];

					gl.uniformMatrix4fv(option.location, false, value);
				}
				else if (option.uType === "4f") {
					var v = this[keyName];
					gl.uniform4f(option.location, v[0], v[1], v[2], v[3]);
				} 
				else if (option.uType === "3f") {
					var v = this[keyName];
					gl.uniform3f(option.location, v[0], v[1], v[2]);
				} 
				else if (keyName in this)
					gl["uniform" + option.uType](option.location, this[keyName]);
			}
		}

		if (this.numItems > 0)
			gl.drawArrays(("drawType" in this) ? this.drawType : gl.TRIANGLES, 0, this.numItems);
	},
	destroy: function() {
		var gl = this.canvas.gl;
		this.disabled = true;
		gl.deleteBuffer(this.VertexPositionBuffer);
		gl.deleteBuffer(this.VertexColorBuffer);
		gl.deleteBuffer(this.TextureCoordBuffer);
		gl.deleteBuffer(this.VertexNormalBuffer);
	},
	refresh: function() {
		this.apply(new Float32Array(this.vertices), new Float32Array(this.colors), new Float32Array(this.texture), new Float32Array(this.normal));
		return this;
	},
	empty: function() {
		this.vertices.splice(0, this.vertices.length);
		this.colors.splice(0, this.colors.length);
		this.texture.splice(0, this.texture.length);
		this.normal.splice(0, this.normal.length);
		return this;
	}
};

var sztext = 32;
var szrect = 8192;
var szline = szrect / sztext;

var Canvas3D = function(element) {
	this.element = element;
	this.gl = element.getContext('experimental-webgl');
	var gl = this.gl;

	this.sztext = sztext;
	this.rotmatrix = [];
	mat4.identity(this.rotmatrix);
	mat4.rotateY(this.rotmatrix, Math.PI/2);

	this.prevppos = [0, 0, 0];
	this.lastppos = [0, 0, 0];
	this.viewMode = 1;
	this.viewportWidth = 0;
	this.viewportHeight = 0;
	this.paused = false;
	this.direction = 0;
	this.rotateSpeed = 600;

	this.frame = (new Date()).getTime();

	this.programs = new Object();
//	this.defaultProgram = gl.createProgram();
//	this.defaultFragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
//	gl.shaderSource(this.defaultFragmentShader, '\
	var fscode = '\
	precision mediump float;\
	uniform sampler2D u_texture;\
	varying vec2 v_texcoord;\
	varying vec4 vColor;\
	varying highp vec3 vLighting;\
	\
	void main(void) {\
		vec4 c = texture2D(u_texture, v_texcoord);\
		gl_FragColor = vec4(c.r * vColor.r * vLighting.x, c.g * vColor.g * vLighting.y, c.b * vColor.b * vLighting.z, c.a * vColor.a);\
	}';

	var vscode = '\
	precision mediump float;\
	attribute vec3 aVertexPosition;\
	attribute vec3 aVertexNormal;\
	attribute vec4 aVertexColor;\
	attribute vec2 a_texcoord;\
	\
	uniform mat4 uPMatrix;\
	uniform mat4 uMVMatrix;\
	uniform mat4 uNMatrix;\
	uniform float fLight;\
	uniform float fHeight;\
	uniform float fBoard;\
	\
	varying vec2 v_texcoord;\
	varying mediump vec4 vColor;\
	varying highp vec3 vLighting;\
	\
	void main(void) {\
		highp vec3 ambientLight = vec3(0.8, 0.8, 0.8);\
		highp vec3 directionalLightColor = vec3(0.3, 0.3, 0.3);\
		highp vec3 directionalVector = (uNMatrix * vec4(-0.85, 0.8, -0.75, 1.0)).xyz;\
		highp vec4 transformedNormal = uNMatrix * vec4(aVertexNormal, 1.0);\
		highp float directional = max(dot(transformedNormal.xyz, directionalVector), 0.0);\
		if (fHeight > 0.0)\
			directional = directional * aVertexPosition.y/fHeight;\
		vLighting = ambientLight + (directionalLightColor * directional);\
		if (fLight == 0.0)\
			vLighting = vec3(1.0, 1.0, 1.0);\
		gl_Position = uMVMatrix * vec4(aVertexPosition, 1.0);\
		if (fBoard > 0.0)\
			gl_Position = gl_Position + vec4(aVertexNormal, 0.0);\
		gl_Position = uPMatrix * gl_Position;\
		v_texcoord = a_texcoord;\
		vColor = aVertexColor;\
	}';

	this.addProgram("default", vscode, fscode, {
		"aVertexPosition":{"isAttrib":true, "keyName":"VertexPositionBuffer", "numItems":3},
		"aVertexNormal":{"isAttrib":true, "keyName":"VertexNormalBuffer", "numItems":3},
		"aVertexColor":{"isAttrib":true, "keyName":"VertexColorBuffer", "numItems":4},
		"a_texcoord":{"isAttrib":true, "keyName":"TextureCoordBuffer", "numItems":2},
		"uPMatrix":{"uType":"Matrix4fv", "keyName":"pMatrix"},
		"uMVMatrix":{"uType":"Matrix4fv", "keyName":"mvMatrix"},
		"uNMatrix":{"uType":"Matrix4fv", "keyName":"nMatrix"},
		"u_texture":{"uType":"1i", "keyName":"textureId"},
		"fLight":{"uType":"1f", "keyName":"light"},
		"fHeight":{"uType":"1f", "keyName":"lightHeight"},
		"fBoard":{"uType":"1f", "keyName":"billboard"}
	});

	this.drawBufs = [];
	this.cbRefreshs = [];
	this.cbDestroys = [];
	this.cbDraws = [];
	this.cbPickDraws = [];
	this.cbPickObjs = [];

	this.cbMouseDowns = [];
	this.cbMouseUps = [];
	this.cbMouseMoves = [];
	this.cbKeyUps = [];
	this.cbClicks = [];
	this.cbDblClicks = [];

	this.texttex = gl.createTexture();

	this.isDark = false;
	var trect = 32;
	this.trect = trect;

	this.ctxcanvas = document.createElement("canvas");
	this.ctxcanvas.width = szrect;
	this.ctxcanvas.height = szrect;
	this.ctx = this.ctxcanvas.getContext("2d");
	this.ctx.fillStyle = "black";
	this.ctx.fillRect(0, 0, szrect, szrect);
	this.font = (sztext - 1) + 'px Roboto, "Apple SD Gothic Neo", "Malgun Gothic", "Nanum Gothic", "Helvetica Neue", Helvetica, Arial, sans-serif';

	this.textReset = false;
	this.lineData = [];
	for (var i = 0; i < szline; i++) {
		var line = new Object();
		line.width = 0;
		line.array = [];
		this.lineData.push(line);
	}
	gl.activeTexture(gl.TEXTURE3);
	gl.bindTexture(gl.TEXTURE_2D, this.texttex);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
	//gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
	//gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, this.ctxcanvas);
	gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, this.ctxcanvas);
	
	this.showMode = false;
	this.centerpos = [0, 0, 0];
	this.cameraMode = 0;
	this.setCamera({
		"pos": [0, 2, 10],
		"dir": [0, 0, -1],
		"up": [0, 1, 0]
	});

	gl.enable(gl.CULL_FACE);
	gl.enable(gl.DEPTH_TEST);
	gl.enable(gl.BLEND);
	gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

	this.refresh();

	this.keyTable = [];
	this.requestId = window.requestAnimationFrame((function() {
		this.draw();
	}).bind(this));
	this.mousedown = (function(e) {
		var clientX = e.clientX, clientY = e.clientY;
		if ("$" in window) {
			var offset = $(e.target).offset();
			clientX += document.body.scrollLeft - offset.left;
			clientY += document.body.scrollTop - offset.top;		
		}
		//document.getElementById("mainframe").focus();
		this.element.focus();

		this.cbMouseDowns.forEach(function(cb) {
			cb(e, clientX, clientY);
		});

		this.lastX = clientX;
		this.lastY = clientY;
		this.movedist = 0;
		this.mousemove(e);
		
		e.preventDefault();
	}).bind(this);
	this.mouseup = (function(e) {
		var clientX = e.clientX, clientY = e.clientY;
		if ("$" in window) {
			var offset = $(e.target).offset();
			clientX += document.body.scrollLeft - offset.left;
			clientY += document.body.scrollTop - offset.top;		
		}

		this.cbMouseUps.forEach(function(cb) {
			cb(e, clientX, clientY);
		});

		delete this.lastX;
		delete this.lastY;
		e.preventDefault();
	}).bind(this);
	this.mousemove = (function(e) {
		var clientX = e.clientX, clientY = e.clientY;
		if ("$" in window) {
			var offset = $(e.target).offset();
			clientX += document.body.scrollLeft - offset.left;
			clientY += document.body.scrollTop - offset.top;		
		}

		this.pickpos = [];
		var r = 1;
		if (this.viewMode == 1 || this.viewMode == 3 || this.viewMode === undefined) {
			r = Math.tan(75 * Math.PI / 360) * 2;
		}
		else if (this.viewMode == 2) {
			r = 1/10000;
		}

		this.pickpos[0] = (clientX - this.viewportWidth/2) * 10000 * r / this.viewportHeight;
		this.pickpos[1] = (this.viewportHeight/2 - clientY) * 10000 * r / this.viewportHeight;
		this.pickpos[2] = -10000;

		if (this.lastX === undefined)
			return;

		var dx = clientX - this.lastX;
		var dy = clientY - this.lastY;
		this.movedist += dx*dx + dy*dy;

		var rundefault = true;
		this.cbMouseMoves.forEach(function(cb) {
			rundefault = rundefault && cb(e, dx, dy);
		});
		if (rundefault) {
			this.autoRotate = false;
			this.camRotateHorz(dx/this.viewportHeight);
			this.camRotateVert(-dy/this.viewportHeight);
		}

		this.lastX = clientX;
		this.lastY = clientY;
		this.moved = true;
		e.preventDefault();
	}).bind(this);
	this.mousewheel = (function(e) {
		var delta = e.detail ? e.detail : e.wheelDelta;
		if (delta >= 120 || delta <= -120)
			delta /= 600;
		this.camMoveFB(delta * this.delta);
	}).bind(this);
	this.dblclick = (function(e) {
		e.preventDefault();
		var clientX = e.clientX, clientY = e.clientY;
		if ("$" in window) {
			var offset = $(e.target).offset();
			clientX += document.body.scrollLeft - offset.left;
			clientY += document.body.scrollTop - offset.top;		
		}
		this.cbDblClicks.forEach(function(cb) {
			cb(e, clientX, clientY);
		});
	}).bind(this);
	this.click = (function(e) {
		e.preventDefault();
		var clientX = e.clientX, clientY = e.clientY;
		if ("$" in window) {
			var offset = $(e.target).offset();
			clientX += document.body.scrollLeft - offset.left;
			clientY += document.body.scrollTop - offset.top;		
		}
		this.cbClicks.forEach(function(cb) {
			cb(e, clientX, clientY);
		});
	}).bind(this);
	this.keydown = (function(e) {
		this.keyTable[e.keyCode] = 1;

		if (e.keyCode == 32 && this.cameraMode != 0)
			this.setShowMode(!this.showMode);
	}).bind(this);
	this.keyup = (function(e) {
		this.keyTable[e.keyCode] = 0;

		if (e.keyCode == 37 || e.keyCode == 39) {
			if (!!this.cbDirection)
				this.cbDirection();
		}
		this.cbKeyUps.forEach(function(cb) {
			cb(e);
		});
	}).bind(this);
	this.contextmenu = function(e) {
		e.preventDefault();	
	};

	var elem = this.element;//document.getElementById("mainframe");
	elem.addEventListener("mousedown", this.mousedown, false);
	elem.addEventListener("mouseup", this.mouseup, false);
	elem.addEventListener("mousemove", this.mousemove, false);
	elem.addEventListener("mousewheel", this.mousewheel, false);
	elem.addEventListener("dblclick", this.dblclick, false);
	elem.addEventListener("click", this.click, false);
	elem.addEventListener("contextmenu", this.contextmenu, false);
	element.addEventListener("keydown", this.keydown, false);
	element.addEventListener("keyup", this.keyup, false);
	element.focus();
}

Canvas3D.prototype = {
	setShowMode:function(showMode) {
		this.showMode = !!showMode;
		if (this.showModeCallback !== undefined) {
			this.showModeCallback();
		}
	},
	setCenter:function(v) {
		if (!v)
			this.centerpos = [0, 0, 0];
		else
			this.centerpos = v;

	},
	takePicture: function() {
		var gl = this.gl;

		var width = this.viewportWidth, height = this.viewportHeight;
		gl.activeTexture(gl.TEXTURE4);
		this.texture = gl.createTexture();
		gl.bindTexture(gl.TEXTURE_2D, this.texture);
		gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);

		this.renderbuffer = gl.createRenderbuffer();
		gl.bindRenderbuffer(gl.RENDERBUFFER, this.renderbuffer);
		gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, width, height);

		this.framebuffer = gl.createFramebuffer();
		gl.bindFramebuffer(gl.FRAMEBUFFER, this.framebuffer);
		gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, this.texture, 0);
		gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, this.renderbuffer);

		this.updateMatrix();

		gl.viewport(0, 0, width, height);
		if (!this.isTotalView) {
			if (!this.isDark)
				gl.clearColor(1, 1, 1, 1);
			else
				gl.clearColor(0, 0, 0, 1);
		}
		else {
			if (!this.isDark)
				gl.clearColor(0.7, 0.9, 1, 1);
			else
				gl.clearColor(0, 0.1, 0.3, 1);
		}
		gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

		mat4.inverse(this.mvMatrix, this.nMatrix);
		mat4.transpose(this.nMatrix);

		this.cbDraws.forEach(function(cb) {
			cb();
		});

		this.drawBufs.forEach(function(buf) {
			buf.draw();
		});

		gl.flush();

		var origdata = new Uint8Array(width * height * 4);
		gl.readPixels(0, 0, width, height, gl.RGBA, gl.UNSIGNED_BYTE, origdata);
		var data = new Uint8Array(width * height * 4);
		for (var i = 0; i < height; i++) {
			data.set(origdata.subarray(i * width * 4, (i + 1) * width * 4), (height - 1 - i) * width * 4);
		}

		var canvas = document.createElement('canvas');
		canvas.width = width;
		canvas.height = height;
		var context = canvas.getContext('2d');

		var imageData = context.createImageData(width, height);
		imageData.data.set(data);
		context.putImageData(imageData, 0, 0);

		gl.bindTexture(gl.TEXTURE_2D, null);
		gl.bindRenderbuffer(gl.RENDERBUFFER, null);
		gl.bindFramebuffer(gl.FRAMEBUFFER, null);
		gl.deleteTexture(this.texture);
		gl.deleteRenderbuffer(this.renderbuffer);
		gl.deleteFramebuffer(this.framebuffer);

		return canvas.toDataURL('image/png');
	},
	addProgram: function (name, vscode, fscode, options) {
		var program = this.programs[name] = new Object();
		program.vs = this.gl.createShader(this.gl.VERTEX_SHADER);
		this.gl.shaderSource(program.vs, vscode);
		this.gl.compileShader(program.vs);
		if (!this.gl.getShaderParameter(program.vs, this.gl.COMPILE_STATUS))
			console.log(this.gl.getShaderInfoLog(program.vs));

		program.fs = this.gl.createShader(this.gl.FRAGMENT_SHADER);
		this.gl.shaderSource(program.fs, fscode);
		this.gl.compileShader(program.fs);
		if (!this.gl.getShaderParameter(program.fs, this.gl.COMPILE_STATUS))
			console.log(this.gl.getShaderInfoLog(program.fs));

		program.program = this.gl.createProgram();

		this.gl.attachShader(program.program, program.fs);
		this.gl.attachShader(program.program, program.vs);

		this.gl.linkProgram(program.program);
		this.gl.useProgram(program.program);
	
		program.options = options;

		for (var key in options) {
			var option = options[key];
			if (!!option.isAttrib)
				option.location = this.gl.getAttribLocation(program.program, key);
			else
				option.location = this.gl.getUniformLocation(program.program, key);
		}
	},
	onDirection: function (cb) {
		this.cbDirection = cb;
		return this;
	},
	resetText: function () {
		console.log('resetText');
		this.textReset = false;
		for (var i = 0; i < szline; i++) {
			var line = this.lineData[i]
			line.width = 0;
			var array = line.array;
			line.array = [];
			for (var j = 0; j < array.length; j++) {
				var obj = array[j];
				if (!obj.textPos)
					continue;

				if (line.width != obj.xPos) {
					//move texture
					this.renderText(obj, line.width, i);
				}
				line.array.push(obj);
				line.width += obj.textWidth;
			}
		}

/*		for (var i = 0; i < szline; i++) {
			var line = this.lineData[i];
			var linewidth = 0;
			var del = null;
			for (var j = 0; j < line.array.length; j++) {
				if (line.array[j].data === undefined)
					del = j;
				if (del !== null)
					line.array[j].textPos = null;
				else
					linewidth+=line.array[j].textWidth;
				//console.log(j, linewidth);
			}
			if (del !== null) {
				line.array.splice(0, del);
				line.width -= linewidth;
			}
		}*/
		this.maxwidth = szrect;
	},
	renderText: function(obj, x, y) {
		this.ctxcanvas.width = obj.textWidth;
		this.ctxcanvas.height = sztext;
		this.ctx.font = this.font;
		this.ctx.fillStyle = "rgba(0, 0, 0, 1)";
		this.ctx.fillRect(0, 0, obj.textWidth, sztext);
		this.ctx.textBaseline = "top";
		this.ctx.fillStyle = "white";
		this.ctx.fillText(obj.text, 0, -2); //line.width, i * 16 + 13);
		obj.xPos = x;
		obj.textPos = [(x+0.2)/szrect, (y * sztext + sztext-0.2)/szrect, (x+obj.textWidth-2.2)/szrect, (y * sztext+0.2)/szrect];
		this.gl.activeTexture(this.gl.TEXTURE3);
		this.gl.bindTexture(this.gl.TEXTURE_2D, this.texttex);
		this.gl.texSubImage2D(this.gl.TEXTURE_2D, 0, x, y * sztext, this.gl.RGBA, this.gl.UNSIGNED_BYTE, this.ctxcanvas);
	},
	addText: function (obj, str, buffer) {
		this.ctx.font = this.font;
		var width = this.ctx.measureText(str).width+2;
		var i = 0, line;
		var maxwidth = 0;

		if (width > szrect)
			width = szrect;
		if (width > this.maxwidth) {
			obj.textPos = null;
			return;
		}

		for (i = 0; i < szline; i++) {
			line = this.lineData[i];
			var freewidth = szrect - line.width;
			if (freewidth > maxwidth)
				maxwidth = freewidth;
			if (freewidth >= width)
				break;
		}
		if (i >= szline) {
//			this.resetText();
//			return this.addText(obj, str);
			obj.textPos = null;//[0, 0, 0, 0];
			this.maxwidth = maxwidth;
			if (maxwidth < sztext*10)
				this.textReset = true;
			return;
		}

		obj.textWidth = width;
		obj.text = '' + str;
		this.renderText(obj, line.width, i);
		line.width += width;
		line.array.push(obj);
		return;
	},
	drawText: function(p0, p1, p2, p3, color, o, text) {
		if (!o.textPos) {
			this.addText(o, o.text);
			if (!o.textPos)
				return;
		}
		var subvec = [], va = [], vb = [];
		var r = color[0], g = color[1], b = color[2], a = color[3];
		vec3.subtract(p1, p0, va);
		vec3.subtract(p3, p0, vb);
		vec3.cross(vb, va, subvec);
		text.vertices.push(p3[0], p3[1], p3[2],  p2[0], p2[1], p2[2],  p0[0], p0[1], p0[2],  p0[0], p0[1], p0[2],  p2[0], p2[1], p2[2],  p1[0], p1[1], p1[2]);
		text.colors.push(r, g, b, a,  r, g, b, a,  r, g, b, a,  r, g, b, a,  r, g, b, a,  r, g, b, a);
		text.texture.push(o.textPos[2], o.textPos[3],  o.textPos[0], o.textPos[3],  o.textPos[2], o.textPos[1],  o.textPos[2], o.textPos[1],  o.textPos[0], o.textPos[3],  o.textPos[0], o.textPos[1]);
		text.normal.push(subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2]);
	},
	drawTextBill: function(p, color, o, textbill) {
		if (!o.textPos) {
			this.addText(o, o.text);
			if (!o.textPos)
				return;
		}
		var slen = (o.textWidth - 2) / sztext;
		var size = 0.5;
		var p0 = [0, 0, 0], p1 = [slen * size, 0, 0], p3 = [0, size, 0], p2 = [slen * size, size, 0];
		var r = color[0], g = color[1], b = color[2], a = color[3];
		textbill.vertices.push(p[0], p[1], p[2],  p[0], p[1], p[2],  p[0], p[1], p[2],  p[0], p[1], p[2],  p[0], p[1], p[2],  p[0], p[1], p[2]);
		textbill.colors.push(r, g, b, a,  r, g, b, a,  r, g, b, a,  r, g, b, a,  r, g, b, a,  r, g, b, a);
		textbill.texture.push(o.textPos[0], o.textPos[3],  o.textPos[2], o.textPos[3],  o.textPos[0], o.textPos[1],  o.textPos[0], o.textPos[1],  o.textPos[2], o.textPos[3],  o.textPos[2], o.textPos[1]);
		textbill.normal.push(p3[0], p3[1], p3[2],  p2[0], p2[1], p2[2],  p0[0], p0[1], p0[2],  p0[0], p0[1], p0[2],  p2[0], p2[1], p2[2],  p1[0], p1[1], p1[2]);
	},

	drawSphere: function(pos, radius, c, dest) {
		var aVertices = dest.vertices, aColors = dest.colors, aTexCoord = dest.texture, aNormal = dest.normal;
		var step = 1/16;
		for (var h = -1; h < 1 ; h += step) {
			var lth = 0;
			if (h >= 1 - 0.125)
				step = 1/16;
			else if (h > -1 + 0.125)
				step = 1/8;

			for (var th = 0.125; th <= 2; th += 0.125) {
				var cth = th * Math.PI;
				var hh = h + step;
				var rl = Math.sqrt(1 - h*h), rh = Math.sqrt(1 - hh*hh);
				var p0 = [Math.cos(lth) * rl, h, Math.sin(lth) * rl];
				var p1 = [Math.cos(cth) * rl, h, Math.sin(cth) * rl];
				var p2 = [Math.cos(lth) * rh, hh, Math.sin(lth) * rh];
				var p3 = [Math.cos(cth) * rh, hh, Math.sin(cth) * rh];
				if (h != -1)
					aNormal.push(p0[0], p0[1], p0[2], p2[0], p2[1], p2[2], p1[0], p1[1], p1[2]);
				if (hh != 1)
					aNormal.push(p1[0], p1[1], p1[2], p2[0], p2[1], p2[2], p3[0], p3[1], p3[2]);
				vec3.scale(p0, radius);
				vec3.scale(p1, radius);
				vec3.scale(p2, radius);
				vec3.scale(p3, radius);
				vec3.add(p0, pos);
				vec3.add(p1, pos);
				vec3.add(p2, pos);
				vec3.add(p3, pos);
				if (h != -1) {
					aVertices.push(p0[0], p0[1], p0[2], p2[0], p2[1], p2[2], p1[0], p1[1], p1[2]);
					aColors.push(c[0], c[1], c[2], c[3], c[0], c[1], c[2], c[3], c[0], c[1], c[2], c[3]);
					aTexCoord.push(0, 0, 0, 0, 0, 0);
				}
				if (hh != 1) {
					aVertices.push(p1[0], p1[1], p1[2], p2[0], p2[1], p2[2], p3[0], p3[1], p3[2]);
					aColors.push(c[0], c[1], c[2], c[3], c[0], c[1], c[2], c[3], c[0], c[1], c[2], c[3]);
					aTexCoord.push(0, 0, 0, 0, 0, 0);
				}

				lth = cth;
			}
		}
	},
	drawBox: function(p0, p1, p2, p3, dh, drawPlane, color, dest, l, tl, th) {
		var aVertices = dest.vertices, aColors = dest.colors, aTexCoord = dest.texture, aNormal = dest.normal;
		var subvec = [];
		if (!l) {
			l = [1, 1, 1, 1,  1, 1, 1, 1,  1, 1, 1, 1,  1, 1, 1, 1,  1, 1, 1, 1,  1, 1, 1, 1];
		}
		if (tl === undefined)
			tl = 0;
		if (th === undefined)
			th = 1;

		if (drawPlane & 0x01) {
			var f = 1;//!!full ? 1 : 0.95;
			var r = color[0]*f, g = color[1]*f, b = color[2]*f, a = color[3];

			vec3.subtract(p2, p0, subvec);
			var vlen = vec3.length(subvec);

			mat4.multiplyVec3(this.rotmatrix, subvec);
			vec3.normalize(subvec);

			aVertices.push(p0[0], p0[1] + dh, p0[2],  p2[0], p2[1] + dh, p2[2],  p0[0], p0[1], p0[2],  p0[0], p0[1], p0[2],  p2[0], p2[1] + dh, p2[2],  p2[0], p2[1], p2[2]);
			aColors.push(r*l[1], g*l[1], b*l[1], a,  r*l[0], g*l[0], b*l[0], a,  r*l[3], g*l[3], b*l[3], a,  r*l[3], g*l[3], b*l[3], a,  r*l[0], g*l[0], b*l[0], a,  r*l[2], g*l[2], b*l[2], a);
			aTexCoord.push(1, th,  0, th,  1, tl,  1, tl,  0, th,  0, tl);
			aNormal.push(subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2]);
		}
		if (drawPlane & 0x02) {
			vec3.subtract(p0, p1, subvec);
			mat4.multiplyVec3(this.rotmatrix, subvec);
			vec3.normalize(subvec);
			//vec3.negate(subvec);

			var f = 1;//!!full ? 1 : 0.9;
			var r = color[0]*f, g = color[1]*f, b = color[2]*f, a = color[3];
			aVertices.push(p1[0], p1[1] + dh, p1[2],  p0[0], p0[1] + dh, p0[2],  p1[0], p1[1], p1[2],  p1[0], p1[1], p1[2],  p0[0], p0[1] + dh, p0[2],  p0[0], p0[1], p0[2]);
			aColors.push(r*l[5], g*l[5], b*l[5], a,  r*l[4], g*l[4], b*l[4], a,  r*l[7], g*l[7], b*l[7], a,  r*l[7], g*l[7], b*l[7], a,  r*l[4], g*l[4], b*l[4], a,  r*l[6], g*l[6], b*l[6], a);
			aTexCoord.push(1, th,  0, th,  1, tl,  1, tl,  0, th,  0, tl);
			aNormal.push(subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2]);
		}
		if (drawPlane & 0x04) {
			var f = 1;//!!full ? 1 : 0.95;
			var r = color[0]*f, g = color[1]*f, b = color[2]*f, a = color[3];

			vec3.subtract(p3, p1, subvec);
			var vlen = vec3.length(subvec);

			mat4.multiplyVec3(this.rotmatrix, subvec);
			vec3.normalize(subvec);
			vec3.negate(subvec);

			aVertices.push(p1[0], p1[1], p1[2],  p3[0], p3[1] + dh, p3[2],  p1[0], p1[1] + dh, p1[2],  p3[0], p3[1], p3[2],  p3[0], p3[1] + dh, p3[2],  p1[0], p1[1], p1[2]);
			aColors.push(r*l[10], g*l[10], b*l[10], a,  r*l[9], g*l[9], b*l[9], a,  r*l[8], g*l[8], b*l[8], a,  r*l[11], g*l[11], b*l[11], a,  r*l[9], g*l[9], b*l[9], a,  r*l[10], g*l[10], b*l[10], a);
			aTexCoord.push(1, tl,  0, th,  1, th,  0, tl,  0, th,  1, tl);
			aNormal.push(subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2]);
		}
		if (drawPlane & 0x08) {
			vec3.subtract(p2, p3, subvec);
			mat4.multiplyVec3(this.rotmatrix, subvec);
			vec3.normalize(subvec);
			vec3.negate(subvec);

			var f = 1;//!!full ? 1 : 0.9;
			var r = color[0]*f, g = color[1]*f, b = color[2]*f, a = color[3];
			aVertices.push(p3[0], p3[1], p3[2],  p2[0], p2[1] + dh, p2[2],  p3[0], p3[1] + dh, p3[2],  p2[0], p2[1], p2[2],  p2[0], p2[1] + dh, p2[2],  p3[0], p3[1], p3[2]);
			aColors.push(r*l[14], g*l[14], b*l[14], a,  r*l[13], g*l[13], b*l[13], a,  r*l[12], g*l[12], b*l[12], a,  r*l[15], g*l[15], b*l[15], a,  r*l[13], g*l[13], b*l[13], a,  r*l[14], g*l[14], b*l[14], a);
			aTexCoord.push(1, tl,  0, th,  1, th,  0, tl,  0, th,  1, tl);
			aNormal.push(subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2],  subvec[0], subvec[1], subvec[2]);
		}
		if (drawPlane & 0x10) {
			var f = 1;//!!full ? 1 : 0.85;
			var r = color[0]*f, g = color[1]*f, b = color[2]*f, a = color[3];
			aVertices.push(p0[0], p0[1], p0[2],  p3[0], p3[1], p3[2],  p1[0], p1[1], p1[2],  p2[0], p2[1], p2[2],  p3[0], p3[1], p3[2],  p0[0], p0[1], p0[2]);
			aColors.push(r*l[18], g*l[18], b*l[18], a,  r*l[17], g*l[17], b*l[17], a,  r*l[16], g*l[16], b*l[16], a,  r*l[19], g*l[19], b*l[19], a,  r*l[17], g*l[17], b*l[17], a,  r*l[18], g*l[18], b*l[18], a);
			aTexCoord.push(0, tl,  1, th,  1, tl,  0, th,  1, th,  0, tl);
			aNormal.push(0, -1, 0,  0, -1, 0,  0, -1, 0,  0, -1, 0,  0, -1, 0,  0, -1, 0);
		}
		if (drawPlane & 0x20) {
			var f = 1;//!!full ? 1 : 1;
			var r = color[0]*f, g = color[1]*f, b = color[2]*f, a = color[3];
			aVertices.push(p1[0], p1[1] + dh, p1[2],  p3[0], p3[1] + dh, p3[2],  p0[0], p0[1] + dh, p0[2],  p0[0], p0[1] + dh, p0[2],  p3[0], p3[1] + dh, p3[2],  p2[0], p2[1] + dh, p2[2]);
			aColors.push(r*l[21], g*l[21], b*l[21], a,  r*l[20], g*l[20], b*l[20], a,  r*l[23], g*l[23], b*l[23], a,  r*l[23], g*l[23], b*l[23], a,  r*l[20], g*l[20], b*l[20], a,  r*l[22], g*l[22], b*l[22], a);
			aTexCoord.push(1, tl,  1, th,  0, tl,  0, tl,  1, th,  0, th);
			aNormal.push(0, 1, 0,  0, 1, 0,  0, 1, 0,  0, 1, 0,  0, 1, 0,  0, 1, 0);
		}
	},
	refresh: function() {
		var gl = this.gl;

		if (!!this.textReset)
			this.resetText();
		
		this.cbRefreshs.forEach(function(cb) {
			cb();
		});

	},
	pause: function() {
		this.paused = true;
	},
	resume: function() {
		if (this.paused) {
			this.paused = false;
			this.draw();
		}
	},
	updateMatrix: function() {
		this.pMatrix = [];
		this.mvMatrix = [];
		this.nMatrix = [];
		var look = [];
		var ratio = this.viewportWidth / this.viewportHeight;
		if (this.viewMode == 1 || this.viewMode == 3 || this.viewMode === undefined) {
			mat4.perspective(75, ratio, 0.1, 10000.0, this.pMatrix);
			vec3.add(this.cameraObj.pos, this.cameraObj.dir, look);
			mat4.lookAt(this.cameraObj.pos, look, this.cameraObj.up, this.mvMatrix);
		}
		else if (this.viewMode == 0) {
			mat4.ortho(-ratio*this.cameraObj.pos[1]/2, ratio*this.cameraObj.pos[1]/2, -1*this.cameraObj.pos[1]/2, 1*this.cameraObj.pos[1]/2, 0, 10000.0, this.pMatrix);
			this.cameraObj.dir = [0, -1, 0];
			this.cameraObj.up = [0, 0, -1];
			var mat = [];
			mat4.identity(mat);
			mat4.rotateY(mat, this.direction * Math.PI/2);
			mat4.multiplyVec3(mat, this.cameraObj.up);
			vec3.add(this.cameraObj.pos, this.cameraObj.dir, look);
			mat4.lookAt(this.cameraObj.pos, look, this.cameraObj.up, this.mvMatrix);
		}
		else {
			mat4.ortho(-ratio*this.cameraObj.pos[1]/2, ratio*this.cameraObj.pos[1]/2, -1*this.cameraObj.pos[1]/2, 1*this.cameraObj.pos[1]/2, -10000.0, 10000.0, this.pMatrix);
			mat4.identity(this.mvMatrix);
			vec3.negate(this.cameraObj.pos, look);
			mat4.rotateX(this.mvMatrix, 35.264*3.141592/180);
			mat4.rotateY(this.mvMatrix, 45*3.141592/180);
			mat4.rotateY(this.mvMatrix, this.direction * Math.PI/2);
			mat4.translate(this.mvMatrix, look);
			this.cameraObj.dir = [0, 0, 1];
			this.cameraObj.up = [0, 1, 0];
			vec3.add(this.cameraObj.pos, this.cameraObj.dir, look);
		}
	},
	pickObj: function(x, y) {
		var gl = this.gl;
		var canvas = this;
		this.updateMatrix();

		gl.activeTexture(gl.TEXTURE4);
		this.texture = gl.createTexture();
		gl.bindTexture(gl.TEXTURE_2D, this.texture);
		gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, this.viewportWidth, this.viewportHeight, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);

		this.renderbuffer = gl.createRenderbuffer();
		gl.bindRenderbuffer(gl.RENDERBUFFER, this.renderbuffer);
		gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, this.viewportWidth, this.viewportHeight);

		this.framebuffer = gl.createFramebuffer();
		gl.bindFramebuffer(gl.FRAMEBUFFER, this.framebuffer);
		gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, this.texture, 0);
		gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, this.renderbuffer);

		gl.viewport(0, 0, this.viewportWidth, this.viewportHeight);
		gl.clearColor(0, 0, 0, 1);
		gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

		mat4.inverse(this.mvMatrix, this.nMatrix);
		mat4.transpose(this.nMatrix);

		this.cbPickDraws.forEach(function(cb) {
			cb();
		});
		gl.flush();

		var pixels = new Uint8Array([0, 0, 0, 0]);
		gl.readPixels(x, this.viewportHeight - y, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, pixels);

		gl.bindTexture(gl.TEXTURE_2D, null);
		gl.bindRenderbuffer(gl.RENDERBUFFER, null);
		gl.bindFramebuffer(gl.FRAMEBUFFER, null);
		gl.deleteTexture(this.texture);
		gl.deleteRenderbuffer(this.renderbuffer);
		gl.deleteFramebuffer(this.framebuffer);

		var selObj = null;
		this.cbPickObjs.every(function(cb) {
			var obj = cb(pixels);
			if (obj !== undefined && obj !== null) {
				selObj = obj;
				return false;
			}
			return true;
		});
		return selObj;
	},

	draw: function(force) {
		if (!force && this.paused)
			return;
		var frame = (new Date()).getTime();
		this.delta = (frame - this.frame) * (0.06);
		this.frame = frame;
		var gl = this.gl;
		var displayWidth = this.element.clientWidth;
		var displayHeight = this.element.clientHeight;
		if (this.viewportWidth != displayWidth || this.viewportHeight != displayHeight) {
			var scale = window.devicePixelRatio || 1;
			this.element.width = displayWidth * scale;
			this.element.height = displayHeight * scale;
			this.viewportWidth = displayWidth;
			this.viewportHeight = displayHeight;
		}

		var arrvec = [0, 0, 0];
		var nextpos = undefined;
		if (this.viewMode == 3)
			nextpos = this.cameraObj.pos.slice();

		if (this.keyTable[87])
			arrvec[0]++;
		if (this.keyTable[83])
			arrvec[0]--;
		if (this.keyTable[65])
			arrvec[2]++;
		if (this.keyTable[68])
			arrvec[2]--;
		var len = vec3.length(arrvec);
		if (len) {
			vec3.scale(arrvec, 1/len);
			var rad = Math.atan2(arrvec[2], arrvec[0]);
			this.camMove(0.25 * this.delta, rad, nextpos);
		}

		if ((this.keyTable[32] && !this.cameraMode) || this.keyTable[33]) {
			if (this.viewMode == 3) {
				this.cameraObj.vel[1] = 0.6;
			}
			else
				this.cameraObj.pos[1]+=0.25;
		}
		if (this.keyTable[34])
			this.cameraObj.pos[1]-=0.25;

		if (this.keyTable[37])
			this.camRotateHorz(0.02);
		if (this.keyTable[39])
			this.camRotateHorz(-0.02);
		if (this.keyTable[38])
			this.camRotateVert(-0.02);
		if (this.keyTable[40])
			this.camRotateVert(0.02);

		if (this.viewMode == 3) {
			(function doArcadeModeCollisionCheck() {
				this.cameraObj.vel[1] -= 0.08;
				vec3.add(nextpos, this.cameraObj.vel);

				if (this.cameraObj.pos[1] >= 1 && nextpos[1] < 1) {
					nextpos[1] = 1;
					this.cameraObj.vel[1] = 0;
				}
				else {
					this.floor.planes.every(function(f) {
						if (f.p.length < 1)
							return true;
						var h = f.p[0].pos[1];
						if (this.cameraObj.pos[1] >= h + 1 && nextpos[1] < h + 1) {
							if (f.isInside(this.cameraObj.pos[0], this.cameraObj.pos[2])) {
								nextpos[1] = h + 1;
								this.cameraObj.vel[1] = 0;
								return false;
							}
						}
						return true;
					});
				}

				var p1 = this.cameraObj.pos.slice(), p2 = nextpos.slice();
				p1[1]--; p2[1]--;
				this.floor.lines.every(function(l) {
					if (p2[1] != l.start.pos[1])
						return true;
					if (l.testHit(p1, p2)) {
						p2[0] = p1[0];
						p2[2] = p1[2];
						return false;
					}
					return true;
				});
				nextpos[0] = p2[0];
				nextpos[2] = p2[2];

				this.cameraObj.pos = nextpos;
			}).call(this);
		}

		if (!!this.pickpos) {
			var ppos = [];
			(function get3DPickPos() {
				var mat = [];
				var spos = [];
				if (this.viewMode == 2) {
					mat4.identity(mat);
					mat4.rotateY(mat, (-45 - this.direction * 90)*3.141592/180);
					var r = this.cameraObj.pos[1];
					ppos = [this.pickpos[0]*r, 0, -(this.pickpos[1]+Math.cos(35.264*3.141592/180))*r*1.73];
					mat4.multiplyVec3(mat, ppos);
					vec3.add(ppos, this.cameraObj.pos);
					ppos[1] = 0;
				}
				else {
					mat4.identity(mat);
					mat4.lookAt([0, 0, 0], this.cameraObj.dir, this.cameraObj.up, mat);
					mat4.inverse(mat);
					mat4.multiplyVec3(mat, this.pickpos, ppos);
					vec3.normalize(ppos);

					var axis = 1, base = 0, obj = null, type = null;
					//it should be in the building.js
					vec3.scale(ppos, 1/ppos[axis]);
					vec3.scale(ppos, this.cameraObj.pos[axis] - base, spos);
					vec3.subtract(this.cameraObj.pos, spos, ppos);
				}

				if (!this.startppos && this.lastX !== undefined)
					this.startppos = ppos.slice();
				if (!!this.startppos && this.lastX === undefined)
					delete this.startppos;

				this.prevppos = this.lastppos;
				this.lastppos = ppos;
				var ix = Math.floor(ppos[0]), iy = Math.floor(ppos[2]);
				var mx = ppos[0] - ix, my = ppos[2] - iy;
				if (mx < 0.1)
					ppos[0] = ix;
				else if (mx > 0.9)
					ppos[0] = ix + 1;

				if (my < 0.1)
					ppos[2] = iy;
				else if (my > 0.9)
					ppos[2] = iy + 1;
				ppos[0] = Math.floor(ppos[0] * 8 + 0.5) / 8;
				ppos[2] = Math.floor(ppos[2] * 8 + 0.5) / 8;

//				this.floor.snap(this, ppos);
			}).call(this);	
		}	

//TODO:rotate camera
			var dvec = [];
			vec3.subtract(this.cameraObj.pos, this.centerpos, dvec);
			var len = vec3.length(dvec);
			vec3.scale(dvec, this.distance/len);
			vec3.add(dvec, this.centerpos);
			vec3.scale(dvec, 0.25);
			vec3.add(dvec, this.cameraObj.pos);
			vec3.scale(dvec, 1/1.25, this.cameraObj.pos);

		if (this.cameraMode == 1 && !!this.autoRotate) {
			this.cameraObj.up[0] *= 0.9;
			this.cameraObj.up[1] = this.cameraObj.up[1] * 0.9 + 0.1;
			this.cameraObj.up[2] *= 0.9;
			vec3.normalize(this.cameraObj.up);

			var vdot = this.cameraObj.pos[1];
			this.camRotateVert(vdot * 0.001);

			if (Math.abs(vdot) < 0.001)
				this.autoRotate = false;
		}
	
		if (!!this.showMode) {
			if (this.cameraMode == 1) {
				this.camRotateHorz(this.delta/this.rotateSpeed);
			}
			else {
				var rm = mat4.create();
				mat4.identity(rm);
				mat4.rotate(rm, this.delta/this.rotateSpeed, this.cameraObj.up);
				//var dvec = [];
				vec3.subtract(this.cameraObj.pos, this.centerpos, dvec);
				mat4.multiplyVec3(rm, dvec, this.cameraObj.pos);
				mat4.multiplyVec3(rm, this.cameraObj.dir);
				vec3.add(this.cameraObj.pos, this.centerpos);
			}
		}

		if (!!this.showMode || !!this.autoRotate) {
			if (this.cameraMode != 1) {
				vec3.subtract(this.centerpos, this.cameraObj.pos, dvec);
				vec3.normalize(dvec);
				var vdot = vec3.dot(dvec, this.cameraObj.up);
				this.camRotateVert(-vdot * 0.1);

				var outvec = [];
				vec3.cross(this.cameraObj.up, this.cameraObj.dir, outvec);
				var hdot = vec3.dot(dvec, outvec);
				this.camRotateHorz(hdot * 0.1);

				if (Math.abs(vdot) < 0.001 && Math.abs(hdot) < 0.001)
					this.autoRotate = false;
			}
		}

//===

		if (this.cameraMode == 0)
			this.camRotateVert(0);
		this.updateMatrix();

		gl.viewport(0, 0, this.element.width, this.element.height);
		if (!this.isTotalView) {
			if (!this.isDark)
				gl.clearColor(1, 1, 1, 1);
			else
				gl.clearColor(0, 0, 0, 1);
		}
		else {
			if (!this.isDark)
				gl.clearColor(0.7, 0.9, 1, 1);
			else
				gl.clearColor(0, 0.1, 0.3, 1);
		}
		gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

		mat4.inverse(this.mvMatrix, this.nMatrix);
		mat4.transpose(this.nMatrix);

		this.cbDraws.forEach(function(cb) {
			cb();
		});

		this.drawBufs.forEach(function(buf) {
			buf.draw();
		});

		if (!force && !this.paused) {
			this.requestId = window.requestAnimationFrame((function() {
				this.draw();
			}).bind(this));
		}
	},
	setCamera: function(obj) {
		this.cameraObj = obj;

		var subvec = this.cameraObj.pos.slice();
		vec3.subtract(subvec, this.centerpos);
		this.distance = vec3.length(subvec);
	},
	camRotateHorz: function(delta) {
		if (this.cameraMode == 0) {
			if (this.viewMode != 1 && this.viewMode != 3) {
				this.camMove(delta * this.cameraObj.pos[1], Math.PI/2);
				return;
			}
			var rm = mat4.create();
			mat4.identity(rm);
			mat4.rotate(rm, delta, [0, 1, 0]);
			mat4.multiplyVec3(rm, this.cameraObj.dir);
			vec3.normalize(this.cameraObj.dir);
		}
		else if (this.cameraMode == 1) {
			var outvec = [];
//			vec3.cross( this.cameraObj.up, this.cameraObj.dir, outvec );
//			vec3.scale( outvec, delta * this.distance );
//			vec3.add( this.cameraObj.pos, outvec );

			vec3.cross( this.cameraObj.up, this.cameraObj.dir, outvec );
			var camlen = vec3.length( this.cameraObj.pos );
			vec3.scale( this.cameraObj.pos, this.distance/camlen );
			vec3.cross( this.cameraObj.dir, outvec, this.cameraObj.up );
			vec3.normalize( this.cameraObj.up );

			var rm = mat4.create();
			mat4.identity(rm);
			mat4.rotate(rm, -delta, this.cameraObj.up);
			mat4.multiplyVec3(rm, this.cameraObj.pos);
			vec3.normalize( this.cameraObj.pos, this.cameraObj.dir );
			vec3.negate( this.cameraObj.dir );

			if (this.distance < 100 + 30) {
				var rm = mat4.create();
				var dir = [];

				vec3.normalize(this.cameraObj.pos, dir);
				vec3.negate(dir);
				
				vec3.cross( this.cameraObj.up, dir, outvec );
				mat4.identity(rm);
				var delta = ((this.distance - (100 + 30)) / 80) * Math.PI;
				mat4.rotate( rm, delta, outvec );
				mat4.multiplyVec3( rm, dir, this.cameraObj.dir );

				mat4.identity(rm);
				mat4.rotate( rm, -Math.PI/2, outvec );
				mat4.multiplyVec3( rm, dir, this.cameraObj.up );
			}
		}
		else if (this.cameraMode == 2) {
			var rm = mat4.create();
			mat4.identity(rm);
			mat4.rotate( rm, delta, this.cameraObj.up );
			var outvec = [];
			mat4.multiplyVec3( rm, this.cameraObj.pos, outvec );
			mat4.multiplyVec3( rm, this.cameraObj.dir );
		}
	},
	camRotateVert: function(delta) {
		if (this.cameraMode == 0) {
			if (this.viewMode != 1 && this.viewMode != 3) {
				this.camMove(delta * this.cameraObj.pos[1], Math.PI);
				return;
			}
			var outvec = [];
			vec3.cross(this.cameraObj.up, this.cameraObj.dir, outvec);
			outvec[1] = 0;
			var rm = mat4.create();
			mat4.identity(rm);
			mat4.rotate(rm, delta, outvec);
			mat4.multiplyVec3(rm, this.cameraObj.dir);
			vec3.cross(this.cameraObj.dir, outvec, this.cameraObj.up);
			vec3.normalize(this.cameraObj.dir);
			vec3.normalize(this.cameraObj.up);
		}
		else if (this.cameraMode == 1) {
			var outvec = this.cameraObj.up.slice();
			vec3.scale( outvec, -delta * this.distance );
			vec3.add( this.cameraObj.pos, outvec );

			vec3.cross( this.cameraObj.up, this.cameraObj.dir, outvec );
			var camlen = vec3.length( this.cameraObj.pos );
			vec3.scale( this.cameraObj.pos, this.distance/camlen );
			vec3.normalize( this.cameraObj.pos, this.cameraObj.dir );
			vec3.negate( this.cameraObj.dir );
			vec3.cross( this.cameraObj.dir, outvec, this.cameraObj.up );
			vec3.normalize( this.cameraObj.up );

			if (this.distance < 100 + 30) {
				var dir = [];
				vec3.normalize(this.cameraObj.pos, dir);
				vec3.negate(dir);

				var rm = mat4.create();
				mat4.identity(rm);
				var delta = ((this.distance - (100 + 30)) / 80) * Math.PI;
				mat4.rotate( rm, delta, outvec );
				mat4.multiplyVec3( rm, dir, this.cameraObj.dir );

				mat4.identity(rm);
				mat4.rotate( rm, -Math.PI/2, outvec );
				mat4.multiplyVec3( rm, dir, this.cameraObj.up );
			}
		}
		else if (this.cameraMode == 2) {
			var outvec = [];
			vec3.cross( this.cameraObj.up, this.cameraObj.dir, outvec );
			var rm = mat4.create();
			mat4.identity(rm);
			mat4.rotate( rm, delta, outvec );
			mat4.multiplyVec3( rm, this.cameraObj.pos, outvec );
			mat4.multiplyVec3( rm, this.cameraObj.up );
			mat4.multiplyVec3( rm, this.cameraObj.dir );
		}
	},
	camMoveFB: function(delta) {
		if (this.cameraMode == 0) {
			var dir = this.cameraObj.dir;
			if (this.viewMode == 2) {
				if (this.direction & 1)
					dir = [1, -1, 1];
				else
					dir = [1, -1, -1];
				if (this.direction & 2) {
					dir[0] = -dir[0];
					dir[2] = -dir[2];
				}
				vec3.normalize(dir);
			}
			var vec = [];
			vec3.scale(dir, delta, vec);
			vec3.add(this.cameraObj.pos, vec);

			var subvec = this.cameraObj.pos.slice();
			vec3.subtract(subvec, this.centerpos);
			this.distance = vec3.length(subvec);
		}
		else if (this.cameraMode == 1) {
			this.distance -= delta;
			var dir = [], dir2 = [];
			vec3.normalize(this.cameraObj.pos, dir);
			vec3.negate(dir);
			vec3.scale(dir, delta, dir2);
			vec3.add(this.cameraObj.pos, dir2);

			if (this.distance < 100 + 30) {
				var outvec = [];
				vec3.cross( this.cameraObj.up, dir, outvec );
				var rm = mat4.create();
				mat4.identity(rm);
				var delta = ((this.distance - (100 + 30)) / 80) * Math.PI;
				mat4.rotate( rm, delta, outvec );
				mat4.multiplyVec3( rm, dir, this.cameraObj.dir );

				mat4.identity(rm);
				mat4.rotate( rm, -Math.PI/2, outvec );
				mat4.multiplyVec3( rm, dir, this.cameraObj.up );
			}
		}
		else if (this.cameraMode == 2) {
			var vec = [];
			vec3.scale( this.cameraObj.dir, delta, vec );
			vec3.add( this.cameraObj.pos, vec );

			var subvec = this.cameraObj.pos.slice();
			vec3.subtract(subvec, this.centerpos);
			this.distance = vec3.length(subvec);
		}
	},
	camMove: function(delta, rad, nextpos) {
		if (this.cameraMode == 0) {
			var dir = [this.cameraObj.dir[0], 0, this.cameraObj.dir[2]];
			vec3.normalize(dir);
			if (this.viewMode == 2) {
				dir = [0, 0, -1];
				rad += (-this.direction - 0.5) * Math.PI/2;
			}
			else if (this.viewMode == 0) {
				dir = [0, 0, -1];
				rad += this.direction * Math.PI/2;
			}
			var rm = [];
			mat4.identity(rm);
			mat4.rotate(rm, rad, [0, 1, 0]);
			mat4.multiplyVec3(rm, dir);
			vec3.scale(dir, delta);
			vec3.add(this.cameraObj.pos, dir, nextpos);
		}
		else if (this.cameraMode == 1) {
			var dir = [], dir2 = [];
			vec3.normalize(this.cameraObj.pos, dir);
			vec3.negate(dir);
			vec3.scale(dir, Math.cos(rad) * delta, dir2);
			vec3.add(this.cameraObj.pos, dir2, nextpos);

			if (this.distance < 100 + 30) {
				var outvec = [];
/*				vec3.cross( this.cameraObj.up, dir, outvec );
				var rm = mat4.create();
				mat4.identity(rm);
				var delta = ((this.distance - (100 + 30)) / 80) * Math.PI;
				mat4.rotate( rm, delta, outvec );
				mat4.multiplyVec3( rm, dir, this.cameraObj.dir );

				mat4.identity(rm);
				mat4.rotate( rm, -Math.PI/2, outvec );
				mat4.multiplyVec3( rm, dir, this.cameraObj.up );*/
				var rm = mat4.create();
				var dir = [];

				vec3.normalize(this.cameraObj.pos, dir);
				vec3.negate(dir);

				vec3.cross( this.cameraObj.up, dir, outvec );
				mat4.identity(rm);
				var delta = ((this.distance - (100 + 30)) / 80) * Math.PI;
				mat4.rotate( rm, delta, outvec );
				mat4.multiplyVec3( rm, dir, this.cameraObj.dir );

				mat4.identity(rm);
				mat4.rotate( rm, -Math.PI/2, outvec );
				mat4.multiplyVec3( rm, dir, this.cameraObj.up );
				
			}

		}
		else if (this.cameraMode == 2) {
			var rm = [];
			var dir = [];
			mat4.identity(rm);
			mat4.rotate(rm, rad, this.cameraObj.up);
			mat4.multiplyVec3(rm, this.cameraObj.dir, dir);
			vec3.scale(dir, delta);
			vec3.add(this.cameraObj.pos, dir, nextpos);

		}

		var subvec = this.cameraObj.pos.slice();
		vec3.subtract(subvec, this.centerpos);
		this.distance = vec3.length(subvec);
		if (this.cameraMode == 1 && this.distance < 100 + 10) {
			vec3.scale(this.cameraObj.pos, (100 + 10)/this.distance);
			this.distance = 100 + 10;
		}
	},
	close: function() {
		this.pause();
		window.cancelAnimationFrame(this.requestId);
		var gl = this.gl;
		this.element.removeEventListener("mousedown", this.mousedown);
		this.element.removeEventListener("mouseup", this.mouseup);
		this.element.removeEventListener("mousemove", this.mousemove);
		this.element.removeEventListener("mousewheel", this.mousewheel);
		this.element.removeEventListener("dblclick", this.dblclick);
		this.element.removeEventListener("contextmenu", this.contextmenu);
		this.element.removeEventListener("click", this.click);
		this.element.removeEventListener("keydown", this.keydown);
		this.element.removeEventListener("keyup", this.keyup);

		this.cbDestroys.forEach(function (cb) {
			cb();
		});

		for (var key in this.programs) {
			var program = this.programs[key];

			gl.deleteProgram(program.program);
			gl.deleteShader(program.vs);
			gl.deleteShader(program.fs);
		}

		gl.deleteTexture(this.texttex);

//		gl.deleteProgram(this.defaultProgram);
//		gl.deleteShader(this.defaultVertexShader);
//		gl.deleteShader(this.defaultFragmentShader);
	}
}

var Player = function() {
	this.pos = [0, 2, 10];
	this.dir = [0, 0, 1];
	this.up = [0, 1, 0];
	this.vel = [0, 0, 0];
}
Player.prototype = {
	
}

Canvas3D.Buffer3D = Buffer3D;

if (typeof module !== 'undefined') {
	module.exports = Canvas3D;
}

var UIWindow = function(x, y, width, height, centerx, centery, title, base) {
	this.element = document.createElement("div");
	this.element.className = "uiwindow";
	this.element.style.left = x < 0 ? 'calc(100% - '+(-x)+'px)': x + 'px';
	this.element.style.top = y < 0 ? 'calc(100% - '+(-y)+'px)': y + 'px';
	this.element.style.width = width < 0 ? 'calc(100% - '+(-width)+'px)': (width+1) + 'px';
	this.element.style.height = height < 0 ? 'calc(100% - '+(-height)+'px)': (height+1) + 'px';
	this.element.style.position = "absolute";
	this.element.style.backgroundColor = "white";
	this.element.style.color = "black";
	this.element.style.boxShadow = "0px 2px 5px rgba(0, 0, 0, 0.5)";
	if (!!centerx) {
		this.element.style.left = 'calc(50% + '+x+'px)';
	}
	if (!!centery) {
		this.element.style.top = 'calc(50% + '+y+'px)';	
	}
	if (title !== undefined) {
		this.element.innerHTML = '<div class="windowtitle" style="position:absolute; background-color:#235292; width:100%; height:40px; line-height:40px; color:white;">' + title + '</div>';
	}

	if (base === undefined)
		base = document.body;
	base.appendChild(this.element);
	this.base = base;

	this.bodyelement = document.createElement("div");
	this.bodyelement.className = "windowbody";
	this.bodyelement.style.top = "40px";
	this.bodyelement.style.width = "100%";
	this.bodyelement.style.height = "calc(100% - 40px)";
	this.bodyelement.style.position = "absolute";
	this.element.appendChild(this.bodyelement);
	this.element.addEventListener('mousemove', function(e) {
		e.preventDefault();
	});
}
UIWindow.prototype = {
	addControl: function(control) {
		control.parent = this;
		this.bodyelement.appendChild(control.element);
	},
	close: function() {
		this.base.removeChild(this.element);
	}
}

var UIScroll = function(x, y, width, height) {
	this.element = document.createElement("div");
	this.element.className = "msgbox";
	this.element.style.left = x < 0 ? 'calc(100% - '+(-x)+'px)': x + 'px';
	this.element.style.top = y < 0 ? 'calc(100% - '+(-y)+'px)': y + 'px';
	this.element.style.width = width < 0 ? 'calc(100% - '+(-width)+'px)': width + 'px';
	this.element.style.height = height < 0 ? 'calc(100% - '+(-height)+'px)': height + 'px';
	this.element.style.position = "absolute";
	this.element.style.overflowY = "scroll";
}
UIScroll.prototype = {
	addControl: function(control) {
		control.parent = this.parent;
		this.element.appendChild(control.element);
	}
}

var UIEdit = function(x, y, width, height) {
	this.element = document.createElement("input");
	this.element.style.left = x < 0 ? 'calc(100% - '+(-x)+'px)': x + 'px';
	this.element.style.top = y < 0 ? 'calc(100% - '+(-y)+'px)': y + 'px';
	this.element.style.width = width < 0 ? 'calc(100% - '+(-width)+'px)': width + 'px';
	this.element.style.height = height < 0 ? 'calc(100% - '+(-height)+'px)': height + 'px';
	this.element.style.position = "absolute";
	this.element.addEventListener("keydown", (function(e) {
		if (e.keyCode == 13) {
			if (!!this.lineCallback) {
				this.lineCallback(this, this.element.value);
			}
			this.element.value = "";
		}
	}).bind(this));
	this.value = '';
}
UIEdit.prototype = {
	setLineCallback: function(callback) {
		this.lineCallback = callback;
		return this;
	},
	setText: function(text) {
		this.element.value = text;
		this.value = '' + text;
		return this;
	},
	getText: function() {
		return this.element.value;
	},
	focus: function() {
		this.element.focus();
		return this;
	},
	isChanged: function() {
		return (this.element.value != this.value);
	}
}


var UIMsgBox = function(x, y, width, height) {
	this.element = document.createElement("div");
	this.element.className = "msgbox";
	this.element.style.left = x < 0 ? 'calc(100% - '+(-x)+'px)': x + 'px';
	this.element.style.top = y < 0 ? 'calc(100% - '+(-y)+'px)': y + 'px';
	this.element.style.width = width < 0 ? 'calc(100% - '+(-width)+'px)': width + 'px';
	this.element.style.height = height < 0 ? 'calc(100% - '+(-height)+'px)': height + 'px';
	this.element.style.position = "absolute";

	this.element.addEventListener('click', function(e) {
		if (e.target.tagName == "AA") {
			openHelp(e.target.getAttribute("href"));
		}
	});
}
UIMsgBox.prototype = {
	println: function(str) {
		this.element.innerHTML += str + "<br>";
		this.element.scrollTop = this.element.scrollHeight;
		return this;
	},
	cprintln: function(str, color) {
		return this.println('<span style="color:'+color+'">' + str + '</span>');
	},
	setText: function(str) {
		this.element.innerHTML = str;
		this.element.scrollTop = 0;
		return this;
	}
}

var UIListBox = function(x, y, width, height) {
	this.element = document.createElement("div");
	this.element.className = "msgbox";
	this.element.style.left = x < 0 ? 'calc(100% - '+(-x)+'px)': x + 'px';
	this.element.style.top = y < 0 ? 'calc(100% - '+(-y)+'px)': y + 'px';
	this.element.style.width = width < 0 ? 'calc(100% - '+(-width)+'px)': width + 'px';
	this.element.style.height = height < 0 ? 'calc(100% - '+(-height)+'px)': height + 'px';
	this.element.style.position = "absolute";

	this.element.innerHTML = '';

	var selected = null;
	this.selected = null;
	this.element.addEventListener('mousedown', (function(e) {
		var pos = e.clientY - this.element.offsetTop - this.element.parentNode.offsetTop + this.element.scrollTop;
		selected = null;
		var idx = -1;
		this.element.childNodes.forEach(function(elem, i) {
			if (!selected && pos >= elem.offsetTop && pos <= elem.offsetTop + elem.offsetHeight) {
				idx = i;
				selected = elem;
			}
		});
		if (idx >= 0)
			this.select(idx);
		e.preventDefault();
	}).bind(this));
	this.element.addEventListener('mousemove', (function(e) {
		var pos = e.clientY - this.element.offsetTop - this.element.parentNode.offsetTop + this.element.scrollTop;
		e.preventDefault();

		if (!selected || selected.offsetTop == 0)
			return;

		var hit = null;
		this.element.childNodes.forEach(function(elem) {
			if (!hit && pos >= elem.offsetTop && pos <= elem.offsetTop + elem.offsetHeight) {
				hit = elem;
			}
		});

		if (!!hit) {
			if (hit !== selected && hit.offsetTop > 0) {
				this.element.insertBefore(selected, hit);
			}
		}
		else {
			this.element.appendChild(selected);
		}
	}).bind(this));
	this.element.addEventListener('mouseup', (function(e) {
		e.preventDefault();
		if (!!selected) {
			this.selectElem(selected);
		}
		selected = null;
	}).bind(this));
	this.element.addEventListener('dblclick', (function(e) {
		e.preventDefault();

		if (!!this.cbDblClick)
			this.cbDblClick();
	}).bind(this));
}
UIListBox.prototype = {
	onChanged: function(cb) {
		this.cbChanged = cb;
		return this;
	},
	onDblClick: function(cb) {
		this.cbDblClick = cb;
		return this;
	},
	update: function(i) {
		var elem = this.element.childNodes[i];
		var exp = elem.childNodes[0];
		if (elem.userobj.childs.length) {
			if (!elem.isExpanded)
				exp.innerHTML = '+';
			else
				exp.innerHTML = '-';
		}
		else {
			exp.innerHTML = '';
		}
	},
	expand: function(i) {
		var elem = this.element.childNodes[i];
		if (!elem.userobj.childs)
			return;
		if (!!elem.isExpanded)
			return;
		elem.userobj.childs.forEach((function(e, j) {
			this.insert(i+1+j, e, 'childnode');
			elem.isExpanded = true;
		}).bind(this));
		this.update(i);
	},
	collapse: function(i) {
		var elem = this.element.childNodes[i];
		if (!elem.userobj.childs)
			return;
		if (!elem.isExpanded)
			return;
		elem.userobj.childs.forEach((function(e, j) {
			this.remove(i+1);
		}).bind(this));
		elem.isExpanded = false;
		this.update(i);
	},
	toggle: function(i) {
		var elem = this.element.childNodes[i];
		if (!elem.isExpanded)
			this.expand(i);
		else
			this.collapse(i);
	},
	insert: function(i, item, optclass) {
		var elem = document.createElement("div");
		elem.userobj = item;
		elem.className = "listitem selected";
		if (!!optclass) {
			elem.optclass = " " + optclass;
			elem.className += elem.optclass;
		}
		else {
			elem.optclass = "";
		}
		elem.innerHTML = '<span class="listexpand"></span>'+item.name;
		var exp = elem.childNodes[0];
		var idx = i;
		if (idx < 0)
			idx = this.count();
		exp.addEventListener('mouseup', (function(e) {
			e.preventDefault();
			this.toggle(this.index(e.target.parentNode));
		}).bind(this));
		if (i < 0)
			this.element.appendChild(elem);
		else
			this.element.insertBefore(elem, this.element.childNodes[i]);
		return this.selectElem(elem);
	},
	add: function(item) {
		return this.insert(-1, item);
	},
	count: function() {
		return this.element.childNodes.length;
	},
	index: function(target) {
		var idx = -1;
		if (!target)
			target = this.selected;
		this.element.childNodes.forEach(function(e, i) {
			if (target === e)
				idx = i;
		});
		return idx;
	},
	remove: function(i) {
		this.element.removeChild(this.element.childNodes[i]);
		this.selected = null;
		return this;
	},
	removeAll: function() {
		this.element.innerHTML = '';
	   	this.selected = null;	
		return this;
	},
	selectElem: function(e) {
		if (!!this.selected) {
			this.selected.className = "listitem" + this.selected.optclass;
		}
		if (!e) {
			this.selected = null;
		}
		else {
			this.selected = e;
			this.selected.className = "listitem selected" + this.selected.optclass;
		}
		if (!!this.selected) {
			if (this.selected.offsetTop < this.element.scrollTop)
				this.element.scrollTop = this.selected.offsetTop;
			if (this.selected.offsetTop + this.selected.offsetHeight > this.element.scrollTop + this.element.clientHeight)
				this.element.scrollTop = this.selected.offsetTop;
		}
		if (!!this.cbChanged)
			this.cbChanged();
		return this;
	},
	select: function(i) {
		return this.selectElem(this.element.childNodes[i]);
	},
	item: function() {
		if (!this.selected)
			return null;
		return this.selected.userobj;
	},
	items: function() {
		var items = [];
		this.element.childNodes.forEach(function(e) {
			items.push(e.userobj);
		});
		return items;
	},
	mapByName: function() {
		var items = new Object();
		this.element.childNodes.forEach(function(e) {
			items[e.userobj.name] = e.userobj;
		});
		return items;
	}
}

var UIButton = function(x, y, width, height, title) {
	this.element = document.createElement("div");
	this.element.className = "button";
	this.element.style.left = x < 0 ? 'calc(100% - '+(-x)+'px)': x + 'px';
	this.element.style.top = y < 0 ? 'calc(100% - '+(-y)+'px)': y + 'px';
	this.element.style.width = width < 0 ? 'calc(100% - '+(-width)+'px)': width + 'px';
	this.element.style.height = height < 0 ? 'calc(100% - '+(-height)+'px)': height + 'px';
	this.element.style.position = "absolute";
	this.element.style.backgroundColor = "#235292";
	this.element.style.borderRadius = "3px";
	this.element.style.textAlign = "center";
	this.element.style.color = "white";

	this.element.innerHTML = title;
	this.element.addEventListener('mousedown', (function(e) {
		this.element.className = "button pressed";
		e.preventDefault();
	}).bind(this));
	this.element.addEventListener('mouseup', (function(e) {
		this.element.className = "button";
		e.preventDefault();
		if (!!this.cbClick)
			this.cbClick.call(this);
	}).bind(this));
	this.element.addEventListener('mouseout', (function(e) {
		this.element.className = "button";
		e.preventDefault();
	}).bind(this));
}
UIButton.prototype = {
	onClick: function(cb) {
		this.cbClick = cb;
		return this;
	}
}

var UILabel = function(x, y, width, height, text) {
	this.element = document.createElement("div");
	this.element.className = "label";
	this.element.style.left = x < 0 ? 'calc(100% - '+(-x)+'px)': x + 'px';
	this.element.style.top = y < 0 ? 'calc(100% - '+(-y)+'px)': y + 'px';
	this.element.style.width = width < 0 ? 'calc(100% - '+(-width)+'px)': width + 'px';
	this.element.style.height = height < 0 ? 'calc(100% - '+(-height)+'px)': height + 'px';
	this.element.style.position = "absolute";

	this.element.innerHTML = text;
}
UILabel.prototype = {
	setText: function(text) {
		this.element.innerHTML = text;
		return this;
	}
}

var UISlot = function(x, y, width, height, type) {
	this.element = document.createElement("div");
	this.element.className = "slot";
	this.element.style.left = x < 0 ? 'calc(100% - '+(-x)+'px)': x + 'px';
	this.element.style.top = y < 0 ? 'calc(100% - '+(-y)+'px)': y + 'px';
	this.element.style.width = width < 0 ? 'calc(100% - '+(-width)+'px)': width + 'px';
	this.element.style.height = height < 0 ? 'calc(100% - '+(-height)+'px)': height + 'px';	
	this.element.style.position = "absolute";

	this.element.addEventListener('mousedown', (function(e) {
		e.preventDefault();
	}).bind(this));
	this.element.addEventListener('mouseup', (function(e) {
		e.preventDefault();
		if (!!this.cbClick)
			this.cbClick.call(this);
	}).bind(this));

}
UISlot.prototype = {
	onClick: function(cb) {
		this.cbClick = cb;
		return this;
	},
	setShortcut: function(key) {
		this.element.innerHTML = key; 
		return this;
	},
	select: function() {
		this.element.style.borderColor = 'white';
	},
	deSelect: function() {
		this.element.style.borderColor = '';		
	}
}

var UITable = function(x, y, width, height) {
	this.element = document.createElement("table");
	this.element.className = "uitable";
	this.element.style.left = x < 0 ? 'calc(100% - '+(-x)+'px)': x + 'px';
	this.element.style.top = y < 0 ? 'calc(100% - '+(-y)+'px)': y + 'px';
	this.element.style.minWidth = width < 0 ? 'calc(100% - '+(-width)+'px)': width + 'px';
	this.thead = document.createElement("thead");
	this.tbody = document.createElement("tbody");
	this.element.appendChild(this.thead);
	this.element.appendChild(this.tbody);
	//this.element.style.height = height < 0 ? 'calc(100% - '+(-height)+'px)': height + 'px';
}
UITable.prototype = {
	setHeader: function(data) {
		var text = "<tr>";
		data.forEach((function(d, i) {
			if (i == 0)
				text += "<th style='min-width:50px'><div style='position:fixed; width:"+this.element.offsetWidth+"px; background-color:silver; height:20px;'></div><div style='position:fixed'>" + d.name + "</div></th>";
			else
				text += "<th style='min-width:50px'><div style='position:fixed'>" + d.name + "</div></th>";
		}).bind(this));
		this.thead.innerHTML = text + "</tr>";
		this.header = data;
		return this;
	},
	setData: function(data) {
		var text = "<tr><td>&nbsp;</td></tr>";
		data.forEach((function(d) {
			text += "<tr>";
			d.forEach((function(v, i) {
				var align = this.header[i].align;
				if (!!align)
					text += '<td align="' + align + '">';
				else
					text += '<td>';
				text += v + "</td>";
			}).bind(this));
			text += "</tr>";
		}).bind(this));
		this.tbody.innerHTML = text;
		return this;
	}
}

UIWindow.UIScroll = UIScroll;
UIWindow.UIEdit = UIEdit;
UIWindow.UIListBox = UIListBox;
UIWindow.UIButton = UIButton;
UIWindow.UILabel = UILabel;
UIWindow.UITable = UITable;

if( typeof module !== 'undefined') {
	module.exports = UIWindow;
}
if (typeof require !== 'undefined') {
	var glMatrix = require('./glMatrix-0.9.5.min.js');
	var vec3 = glMatrix[0];
	var mat3 = glMatrix[1];
	var mat4 = glMatrix[2];
	var quat4 = glMatrix[3];

	var Canvas3D = require('./Canvas3D.js');
	var Buffer3D = Canvas3D.Buffer3D;
}

function NetworkGraph3D(canvas) {
	var shaders = {
	'dotshader_fs':
		"precision mediump float;\n"+
		"uniform float inv;\n"+
		"varying mediump vec4 vColor;\n"+
		"\n"+
		"void main(void) {\n"+
		"	float dist = length(gl_PointCoord.xy - vec2(0.5, 0.5))*2.0;\n"+
		"	if (inv < 1.5 && dist > 1.0 ) {\n"+
		"		gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);\n"+
		"	}\n"+
		"	else if (inv > 1.5 && dist > 0.36) {\n"+
		"		gl_FragColor = vec4(0.0, 0.0, 0.0, 0.0);\n"+
		"	}\n"+
		"	else if ( dist > 0.36 ) {\n"+
		"		gl_FragColor = vColor * (1.0 - dist);\n"+
		"		gl_FragColor.a = 1.0;\n"+
		"	}\n"+
		"	else {\n"+
		"		gl_FragColor = vColor;\n"+
		"		gl_FragColor.a = 1.0;\n"+
		"	}\n"+
		"}\n",
	'lineshader_fs':
		"precision mediump float;\n"+
		"varying lowp vec4 vColor;\n"+
		"\n"+
		"void main(void) {\n"+
		"	gl_FragColor = vColor;\n"+
		"}\n",
	'labelshader_fs':
		"precision mediump float;\n"+
		"\n"+
		"uniform sampler2D u_texture;\n"+
		"varying vec2 v_texcoord2;\n"+
		"varying lowp vec4 vColor;\n"+
		"varying float z;\n"+
		"\n"+
		"void main(void) {\n"+
		"	vec4 c = texture2D(u_texture, v_texcoord2);\n"+
		"	gl_FragColor = vec4(c.r * vColor.r * z, c.g * vColor.g * z, c.b * vColor.b * z, 1.0);\n"+
		"}\n",
	'dotshader_vs':
		"precision mediump float;\n"+
		"attribute vec3 aVertexPosition;\n"+
		"attribute vec4 aVertexColor;\n"+
		"\n"+
		"uniform mat4 uMVMatrix;\n"+
		"uniform mat4 uPMatrix;\n"+
		"uniform float inv;\n"+
		"\n"+
		"varying mediump vec4 vColor;\n"+
		"\n"+
		"void main(void) {\n"+
		"	gl_Position = uPMatrix * uMVMatrix * vec4(aVertexPosition, 1.0);\n"+
		"	gl_PointSize = (1000.0 * abs(aVertexColor.a)) / gl_Position.z;\n"+
		"	if (inv < 0.5) {\n"+
		"		vColor = 1.0 - aVertexColor;\n"+
		"	}\n"+
		"	else {\n"+
		"		vColor = aVertexColor;\n"+
		"	}\n"+
		"	if (inv < 1.5 && aVertexColor.a < 0.0) {\n"+
		"		vColor = vColor * 0.3;\n"+
		"	}\n"+
		"}\n",
	'lineshader_vs':
		"precision mediump float;\n"+
		"attribute vec3 aVertexPosition;\n"+
		"attribute vec4 aVertexColor;\n"+
		"\n"+
		"uniform mat4 uMVMatrix;\n"+
		"uniform mat4 uPMatrix;\n"+
		"\n"+
		"varying lowp vec4 vColor;\n"+
		"\n"+
		"void main(void) {\n"+
		"	gl_Position = uPMatrix * uMVMatrix * vec4(aVertexPosition, 1.0);\n"+
		"	float z = clamp(100.0 / (gl_Position.z), 0.3, 1.0);\n"+
		"	vColor = aVertexColor * z;\n"+
		"	vColor.a = 1.0;\n"+
		"}\n",
	'labelshader_vs':
		"precision mediump float;\n"+
		"attribute vec3 aVertexPosition;\n"+
		"attribute vec3 aVertexCenter;\n"+
		"attribute vec2 a_texcoord;\n"+
		"attribute vec4 aVertexColor;\n"+
		"\n"+
		"uniform mat4 uMVMatrix;\n"+
		"uniform mat4 uPMatrix;\n"+
		"\n"+
		"varying vec2 v_texcoord2;\n"+
		"varying lowp vec4 vColor;\n"+
		"varying float z;\n"+
		"\n"+
		"void main(void) {\n"+
		"	gl_Position = uPMatrix * (uMVMatrix * vec4(aVertexCenter, 1.0) + vec4(aVertexPosition, 1.0));\n"+
		"	v_texcoord2 = a_texcoord;\n"+
		"	vColor = aVertexColor;\n"+
		"	z = clamp((50.0 * vColor.a) / (gl_Position.z), 0.0, 1.0);\n"+
		"	vColor.a = 1.0;\n"+
		"}\n"
	};

	canvas.addProgram("dot", shaders.dotshader_vs, shaders.dotshader_fs, {
		"aVertexPosition":{"isAttrib":true, "keyName":"VertexPositionBuffer", "numItems":3},
		"aVertexColor":{"isAttrib":true, "keyName":"VertexColorBuffer", "numItems":4},
		"uPMatrix":{"uType":"Matrix4fv", "keyName":"pMatrix"},
		"uMVMatrix":{"uType":"Matrix4fv", "keyName":"mvMatrix"},
		"inv":{"uType":"1f"},
	});
	canvas.addProgram("line", shaders.lineshader_vs, shaders.lineshader_fs, {
		"aVertexPosition":{"isAttrib":true, "keyName":"VertexPositionBuffer", "numItems":3},
		"aVertexColor":{"isAttrib":true, "keyName":"VertexColorBuffer", "numItems":4},
		"uPMatrix":{"uType":"Matrix4fv", "keyName":"pMatrix"},
		"uMVMatrix":{"uType":"Matrix4fv", "keyName":"mvMatrix"},
	});
	canvas.addProgram("label", shaders.labelshader_vs, shaders.labelshader_fs, {
		"aVertexPosition":{"isAttrib":true, "keyName":"VertexPositionBuffer", "numItems":3},
		"aVertexCenter":{"isAttrib":true, "keyName":"VertexNormalBuffer", "numItems":3},
		"a_texcoord":{"isAttrib":true, "keyName":"TextureCoordBuffer", "numItems":2},
		"aVertexColor":{"isAttrib":true, "keyName":"VertexColorBuffer", "numItems":4},
		"uPMatrix":{"uType":"Matrix4fv", "keyName":"pMatrix"},
		"uMVMatrix":{"uType":"Matrix4fv", "keyName":"mvMatrix"},
		"u_texture":{"uType":"1i", "keyName":"textureId"},
	});

	this.dotBuf = new Buffer3D(canvas, {"cullFace":false, "depthTest":false, "blendType":"minus", "program":"dot", "drawType":canvas.gl.POINTS, "inv":0});
	this.lineBuf = new Buffer3D(canvas, {"program":"line", "drawType":canvas.gl.LINES});
	this.labelBuf = new Buffer3D(canvas, {"program":"label", "textureId":3});
	canvas.drawBufs.push(this.dotBuf, this.lineBuf, this.labelBuf);

	this.pickBuf = new Buffer3D(canvas, {"cullFace":false, "blendType":"normal", "depthTest":false, "program":"dot", "drawType":canvas.gl.POINTS, "inv":2});

	this.cbRefresh = (function() {
		//this.force = true;
		this.refresh();
	}).bind(this);
	this.cbDraw = (function() {
		if (this.autoTick) {
			var tick = (new Date()).getTime();
			this.updateTick(tick - this.lastTick);
			this.lastTick = tick;
		}
		if (!this.canvas.isDark) {
			this.dotBuf.blendType = "minus";
			//this.globeBuf.inv = 1;
			this.dotBuf.inv = 0;
		}
		else {
			this.dotBuf.blendType = "plus";
			//this.globeBuf.inv = 0;
			this.dotBuf.inv = 1;
		}

		this.kill();
		if (!!this.dataQueue) {
			for (var i = 0; i < 100; i++) {
				if (i + this.dataQueueIdx >= this.dataQueue.length) {
					this.dataQueue = null;
					this.updateTick(this.dataQueueTick);
					break;
				}
				this.addData(this.dataQueue[this.dataQueueIdx + i]);
			}
			this.dataQueueIdx += 100;
		}
		else if (!!this.autoFit) {
			if (!this.autoFitCount)
				this.autoFitCount = 1;
			else
				this.autoFitCount++;

			if (this.autoFitCount > 30) {
				this.autoFitCount = 0;
				this.autoFit = false;
				this.selectObj(null);
				this.force = true;
				this.maxNodeLen = 0;
				this.maxNodeCount = 0;
				this.refresh();
				this.canvas.distance = this.maxNodeLen * 1.5 + 30;
				this.canvas.autoRotate = true;
				return;
			}
		}
		this.refresh();
		//this.cbPickDraw();
	}).bind(this);
	this.cbPickDraw = (function() {
		if (this.vertices instanceof Float32Array) {
			var colors = new Float32Array(this.objtable.length * 4);
			var vertices = new Float32Array(this.objtable.length * 3);
			var len = this.objtable.length - 1;
			this.objtable.forEach((function(obj, idx) {
				var i = idx + 1, idxx = len - idx;
				colors[idxx*4] = ((i >> 16) & 255) / 255;
				colors[idxx*4 + 1] = ((i >> 8) & 255) / 255;
				colors[idxx*4 + 2] = (i & 255) / 255;
				colors[idxx*4 + 3] = this.colors[idx*4 + 3];
				vertices[idxx*3] = this.vertices[idx*3];
				vertices[idxx*3 + 1] = this.vertices[idx*3 + 1];
				vertices[idxx*3 + 2] = this.vertices[idx*3 + 2];
			}).bind(this));
			this.pickBuf.apply(vertices, colors, this.nulls, this.nulls);
			this.pickBuf.draw();
		}
	}).bind(this);
	this.cbPickObj = (function(pixels) {
		var i = (pixels[0] << 16) | (pixels[1] << 8) | pixels[2];
		if (i == 0)
			return null;
		console.log(this.objtable[i - 1], pixels);
		
		return this.objtable[i - 1];	
	}).bind(this);
	this.cbClick = (function(e, clientX, clientY) {
		if (this.canvas.movedist < 5) {
			var selObj = this.canvas.pickObj(clientX, clientY);
			this.selectObj(selObj);
			this.maxNodeLen = 0;
			this.maxNodeCount = 0;
			this.force = true;
			this.refresh();
			var dvec = [];
			vec3.subtract(this.canvas.cameraObj.pos, this.canvas.centerpos, dvec);
			this.canvas.distance = vec3.length(dvec);
		}
	}).bind(this);
	this.cbDblClick = (function(e, clientX, clientY) {
		this.canvas.distance = this.maxNodeLen * 1.5 + 30;
		this.canvas.autoRotate = true;
	}).bind(this);
	this.cbDestroy = (function() {
		this.dotBuf.destroy();
		this.lineBuf.destroy();
		this.labelBuf.destroy();
		this.pickBuf.destroy();
	}).bind(this);
	canvas.cbRefreshs.push(this.cbRefresh);
	canvas.cbDraws.push(this.cbDraw);
	canvas.cbPickDraws.push(this.cbPickDraw);
	canvas.cbPickObjs.push(this.cbPickObj);
	canvas.cbClicks.push(this.cbClick);
	canvas.cbDblClicks.push(this.cbDblClick);
	canvas.cbDestroys.push(this.cbDestroy);
	canvas.cameraMode = 2;

	this.canvas = canvas;
	this.autoTick = false;
	this.updateTick(0);
	this.lastTick = this.frame;
	this.childData = new Object();
	this.childData.data = new Object();
	this.childData.dir = [0, 0, 0];
	this.childData.pos = [0, 0, 0];
	this.childData.count = 0;
	this.childData.br = 0;
	this.dotCount = 0;
	this.dotMax = 10000;

	this.depthList = [new Object()];
	this.depthList[0][''] = this.childData;

	this.selObj = null;

	this.rows = [];

	this.locked = false;

	this.nulls = new Float32Array(0);
	this.redrawAll();

	this.colorset = [];
	for (var i = 0; i < 256; i++) {
		this.colorset.push([Math.random(), Math.random(), Math.random(), 1]);
	}
};

NetworkGraph3D.prototype = {
	updateTick: function(advance) {
		if (!this.frame)
			this.frame = (new Date()).getTime();
		else
			this.frame += advance;
	},
	setColorMap: function(color_map) {
		for (var i = 0; i < color_map.length; i++) {
			var color = color_map[i];
			var r = parseInt(color.substr(1,2),16);
			var g = parseInt(color.substr(3,2),16);
			var b = parseInt(color.substr(5,2),16);
			this.colorset[i + 1] = [r/255,g/255,b/255,1];
		}
	},
	selectObj: function(mobj) {
		if ((!mobj && !this.selObj) || (mobj === this.selObj))
			return;

		var br = 1;
		if (!!mobj) {
			br = 0.4;
		}

		for (var depth = 0; depth < this.depthList.length; depth++ ) {
			var globalObj = this.depthList[depth];
			for (var objKey in globalObj) {
				var data = globalObj[objKey];
				data.br = br;
			}
		}

		this.selObj = mobj;
		//this.selDepth = mdepth;
		if (this.selObjCallback !== undefined) {
			this.selObjCallback();
		}
		this.force = true;

		if (this.selObj !== null) {
			for (var i = 0; i < this.selObj.rows.length; i++) {
				var row = this.selObj.rows[i];
				for (var j = 2; j < row.length; j++) {
					var obj = this.depthList[j-1][row[j]];
					if (obj === undefined)
						continue;
					obj.br = 1;
				}
			}
			this.canvas.setCenter(this.selObj.pos);
		}
		else
			this.canvas.setCenter();

		//this.redrawAll();
		this.canvas.refresh();
	},
	redrawAll: function() {
		this.vertices = [];
		this.colors = [];
		this.lines = [];
		this.linec = [];
		this.labels = [];
		this.labelp = [];
		this.labelc = [];
		this.labelt = [];
		this.objtable = [];
		this.force = true;
	},
	clear: function() {
		this.childData = new Object();
		this.childData.data = new Object();
		this.childData.dir = [0, 0, 0];
		this.childData.pos = [0, 0, 0];
		this.childData.count = 0;
		this.childData.br = 0;
		this.dotCount = 0;
		this.depthList = [new Object()];
		this.depthList[0][''] = this.childData;

		this.selObj = null;
		this.rows = [];
		this.locked = false;

		this.redrawAll();
	},
	addData: function(array, id) {
		if (this.dotCount + array.length >= this.dotMax) {
			return;
		}
		var selected = false;
		var object = this.childData;
		var data = object.data;
		var isUpdate = true;

		//push single array -> ref
		var row = [this.frame, id].concat(array);

		//row: last updated frame
		object.count++;

		for (var i = 0; i < array.length; i++) {
			if ( this.depthList.length <= i + 1 )
				this.depthList.push(new Object());

			var globalObj = this.depthList[i + 1];
			var obj = globalObj[array[i]];
			if (obj === undefined || obj === null) {
				obj = new Object();
				obj.data = new Object();
				obj.count = 0;
				this.dotCount++;

				var rth = Math.random() * 2.0 * 3.14159265358979;
				var rz = Math.random() * 2.0 - 1.0;
				var rr = Math.sqrt(1 - rz * rz);
				var dir = [rr * Math.cos(rth), rr * Math.sin(rth), rz];
				obj.pos = dir;//.slice();
				obj.dir = dir.slice();//[0,0,0];
				obj.key = '' + array[i];
				obj.parentObj = null;
				obj.textPos = null;
				obj.nextObj = null;
				obj.firstObj = null;
				obj.curObj = null;
				obj.skip = 0;
				obj.frame = null;//frame;
				obj.prevCounts = new Object(); //이놈이 이전노드로부터의 참조 카운트를 들고 있어야 되는 것이지 말이지 말입니다.
				obj.rows = [];
				obj.br = 1;
				if (this.selObj !== null) {
					obj.br = 0.4;
					if ("depth" in this.selObj) {
						if (i + 1 == this.selObj.depth && obj.key == this.selObj.key) {
							this.selObj = obj;
							this.canvas.setCenter(this.selObj.pos);
						}
					}
				}
				isUpdate = false;

				globalObj[array[i]] = obj;
			}
			if (obj == this.selObj) {
				selected = true;
			}

			//vec3.add(cdir, dir);
			if (!(array[i] in data)) {
				obj.parentObj = object;
				if ( obj.nextObj == null ) {
					obj.nextObj = object.firstObj;
					object.firstObj = obj;
				}
				data[array[i]] = obj;
				isUpdate = false;
			}
			object = obj;
			//여기서 이전노드로 부터의 카운트를 증가합니다.
			if (i > 0) {
				if (!(array[i-1] in object.prevCounts)) {
					object.prevCounts[array[i-1]] = 0;
					isUpdate = false;
				}
				object.prevCounts[array[i-1]]++;
			}
			else {
				if (!("" in object.prevCounts)) {
					object.prevCounts[""] = 0;
					isUpdate = false;
				}
				object.prevCounts[""]++;
			}
			object.rows.push(row);
			object.count++; //참조횟수를 증가해 줍니다.
			object.skip = 0;
			//object.frame = frame;
			data = object.data;
		}

		if (isUpdate) {
			var remove = null;
			for (var j = 0; j < this.rows.length; j++) {
				var match = 0;
				var r = this.rows[j];
				for (var i = 0; i < array.length; i++) {
					if (array[i] == r[i+1]) {
						match++;
					}
				}
				if (match == array.length) {
					remove = r;
					this.rows.splice(j, 1);
					break;
				}
			}

			if (remove !== null) {
				object = this.childData;
				object.count--;
				for (var i = 0; i < array.length; i++) {
					var globalObj = this.depthList[i + 1];
					object = globalObj[array[i]];
					object.count--;
					for (var j = 0; j < object.rows.length; j++) {
						if (object.rows[j] == remove) {
							object.rows.splice(j, 1);
							break;
						}
					}
				}
			}
		}
		else {
			this.redrawAll();
		}
		if (selected) {
			for (var i = 2; i < row.length; i++) {
				var obj = this.depthList[i-1][row[i]];
				if (obj === undefined) {
					continue;
				}
				obj.br = 1;
			}
		}
		this.rows.push(row);
	},
	kill: function () {
		var i = 0;
		if (this.rows.length > this.dotMax) {
			for (i = 0; i < this.rows.length - this.dotMax; i++) {
				var row = this.rows[i];
				this.removeRow(row);
			}
			this.rows.splice(0, i);
		}
		if (this.lifeTime === undefined || this.lifeTime === null || this.lifeTime == 0) {
			return;
		}
		for (i = 0; i < this.rows.length; i++) {
			var row = this.rows[i];

			if (i >= 30 || this.frame - row[0] < this.lifeTime) {
				break;
			}

			this.removeRow(row);
		}
		this.rows.splice(0, i);
		if (this.canvas.textReset) {
			this.canvas.resetText();
			this.redrawAll();
		}
	},
	removeData: function(id) {
		for (var i = 0; i < this.rows.length; i++) {
			var row = this.rows[i];
			if (row[1] === id) {
				this.removeRow(row);
				this.rows.splice(i, 1);
				return true;
			}
		}
		return false;
	},
	removeRow: function(row) {
		this.childData.count--;
		for (var j = 2; j < row.length; j++) {
			var globalObj = this.depthList[j-1];
			var object = globalObj[row[j]];
			if (object === undefined)
				continue;
			object.count--;
			if (object.count > 0) {
				continue;
			}

			if (object == this.selObj) {
				for (var depth = 0; depth < this.depthList.length; depth++ ) {
					var globalObj2 = this.depthList[depth];
					for (var objKey in globalObj2) {
						var data = globalObj2[objKey];
						data.br = 0.4;
						object.depth = depth;
					}
				}
			}

			this.redrawAll();

			for (var objKey2 in globalObj) {
				var obj2 = globalObj[objKey2];
				if ( obj2.nextObj == object ) {
					obj2.skip = 0;
					obj2.nextObj = object.nextObj;
				}
			}

			for (var prev in object.prevCounts) {
				var prevObj = this.depthList[j-2][prev];
				delete prevObj.data[object.key];
				prevObj.skip = 0;
				prevObj.curObj = null;
				if (prevObj.firstObj == object) {
					prevObj.firstObj = object.nextObj;
				}
			}

			for (var next in object.data) {
				var nextObj = object.data[next];
				delete nextObj.prevCounts[object.key];
				if (nextObj.parentObj == object) {
					for (var prev in nextObj.prevCounts) {
						nextObj.parentObj = globalObj[prev];
						break;
					}
				}
			}

			this.dotCount--;
			delete object.textPos;
			delete object.rows;
			delete object.data;
			delete object.prevCounts;
			delete globalObj[object.key];
		}
	},
	refresh: function () {
		var cvertices = false;
		var ccolors = false;
		var clines = false;
		var clinec = false;
		var clabels = false;
		var clabelp = false;
		var clabelc = false;
		var clabelt = false;

		if (this.force) {
			this.locked = false;
			cvertices = true;
			ccolors = true;
			clines = true;
			clinec = true;
			clabels = true;
			clabelp = true;
			clabelc = true;
			clabelt = true;
		}

		if (this.locked)
			return;

		var vertices = this.vertices;
		var colors = this.colors;
		var lines = this.lines;
		var linec = this.linec;
		var labels = this.labels;
		var labelp = this.labelp;
		var labelt = this.labelt;
		var labelc = this.labelc;
		var i3 = 0, i4 = 0, li3 = 0, li4 = 0; //array index
		var vecsum = [0, 0, 0];
		var veccnt = 0;
		var box0 = [0.25, 0, 0], box1 = [], box2 = [], box3 = [];
		var pos = this.canvas.cameraObj.pos.slice(), camdir = this.canvas.cameraObj.dir.slice();
		var lockcnt = 0;
		vec3.negate(camdir);

		var br = 1.0;
		if ( this.selObj ) {
			br = 0.4;
		}
	
		var ppos = null;
		var mobj = null, mdist = 10000;
		var mdepth = null;

		for (var depth = 0; depth < this.depthList.length; depth++ ) {
			var globalObj = this.depthList[depth];
			for (var objKey in globalObj) {
				var data = globalObj[objKey];
				var key1 = objKey;
				var obj1 = data;

				if ( !data.skip && data.parentObj != null ) {
					for (var p = 0; p < 10; p++) {
						var obj2 = obj1.parentObj.curObj;
						if ( obj2 == null ) {
							obj2 = obj1.parentObj.firstObj;
							if ( obj2 == null )
								break;
						}
						obj1.parentObj.curObj = obj2.nextObj;
						var key2 = obj2.key;
						if (key1 == key2)
							break;

						var dir = [];
						vec3.subtract(obj1.pos, obj2.pos, dir);
						var d = vec3.length(dir);

						if (d < 0.1) {
							var rth = Math.random() * 2.0 * 3.14159265358979;
							var rz = Math.random() * 2.0 - 1.0;
							var rr = Math.sqrt(1 - rz * rz);
							dir = [rr * Math.cos(rth), rr * Math.sin(rth), rz];
							d = vec3.length(dir);
							obj2.skip = 0;
							obj2.parentObj.skip = 0;
						}
						var c = 10;// + obj1.count + obj2.count;
						//if (c < 1)
						//	c = 1;
						vec3.scale(dir, c/(d*d*d));
						vec3.add(obj1.dir, dir);
						vec3.subtract(obj2.dir, dir);
					}
				}

				var obj = data;
				var nbr = obj.br;
				if ( !obj.skip || vertices.length <= i3 + 2 || this.force ) {
					var subvec = [];
					vec3.subtract( obj.pos, pos, subvec );
					var dist = vec3.length( subvec );
					var psize = Math.pow(obj.count + 1, 1/2) * 1.3;
					var costh = vec3.dot( subvec, camdir ) / dist;

					if (this.force) {
						vec3.add(vecsum, obj.pos);
						veccnt++;
					}

					if (depth > 0) {
						vertices[i3] = obj.pos[0];
						vertices[i3+1] = obj.pos[1];
						vertices[i3+2] = obj.pos[2];
						cvertices = true;
					}
//					if (this.canvas.isDark) {
						colors[i4] = this.colorset[depth][0];// * nbr;
						colors[i4+1] = this.colorset[depth][1];// * nbr;
						colors[i4+2] = this.colorset[depth][2];// * nbr;
//					}
//					else {
//						colors[i4] = (1 - this.colorset[depth][0]) * nbr;
//						colors[i4+1] = (1 - this.colorset[depth][1]) * nbr;
//						colors[i4+2] = (1 - this.colorset[depth][2]) * nbr;
//					}
					if (nbr != 1)
						colors[i4+3] = -psize;
					else
						colors[i4+3] = psize;
					this.objtable[Math.floor(i3/3)] = obj;
					ccolors = true;

					if ( costh <= -0.6 ) {
						if ( depth > 0 && ppos != null && dist < psize * 100 )
						{
							var pdot = Math.abs(vec3.dot(subvec, ppos));
							var plen = Math.sqrt(dist * dist - pdot * pdot);

							if ( pdot > 1 && plen < psize * 0.5 && pdot < mdist ) {
								mobj = obj;
								mdepth = depth;
								mdist = pdot;
							}
						}
					}
					if (!this.canvas.textReset && obj.textPos === null ) {
						this.canvas.addText(obj, objKey);
					}
					var slen = (obj.textWidth-2) / (this.canvas.sztext * 2);
					var size = psize;
					box2 = [0.25, 0.5 * size, 0];
					box1 = [0.25 + slen * size, 0, 0];
					box3 = [0.25 + slen * size, 0.5 * size, 0];

					var lli3 = i3 * 6, lli4 = i4 * 6, lli2 = lli4 / 2;
					labels[lli3] = box0[0]; labels[lli3+1] = box0[1]; labels[lli3+2] = box0[2];
					labels[lli3+3] = box1[0]; labels[lli3+4] = box1[1]; labels[lli3+5] = box1[2];
					labels[lli3+6] = box2[0]; labels[lli3+7] = box2[1]; labels[lli3+8] = box2[2];
					labels[lli3+9] = box1[0]; labels[lli3+10] = box1[1]; labels[lli3+11] = box1[2];
					labels[lli3+12] = box2[0]; labels[lli3+13] = box2[1]; labels[lli3+14] = box2[2];
					labels[lli3+15] = box3[0]; labels[lli3+16] = box3[1]; labels[lli3+17] = box3[2];

					labelp[lli3] = labelp[lli3+3] = labelp[lli3+6] = labelp[lli3+9] = labelp[lli3+12] = labelp[lli3+15] = obj.pos[0];
					labelp[lli3+1] = labelp[lli3+4] = labelp[lli3+7] = labelp[lli3+10] = labelp[lli3+13] = labelp[lli3+16] = obj.pos[1];
					labelp[lli3+2] = labelp[lli3+5] = labelp[lli3+8] = labelp[lli3+11] = labelp[lli3+14] = labelp[lli3+17] = obj.pos[2];

					labelc[lli4] = labelc[lli4+4] = labelc[lli4+8] = labelc[lli4+12] = labelc[lli4+16] = labelc[lli4+20] = nbr;
					labelc[lli4+1] = labelc[lli4+5] = labelc[lli4+9] = labelc[lli4+13] = labelc[lli4+17] = labelc[lli4+21] = nbr;
					labelc[lli4+2] = labelc[lli4+6] = labelc[lli4+10] = labelc[lli4+14] = labelc[lli4+18] = labelc[lli4+22] = nbr;
					labelc[lli4+3] = labelc[lli4+7] = labelc[lli4+11] = labelc[lli4+15] = labelc[lli4+19] = labelc[lli4+23] = psize;

					if (!obj.textPos ) {
						labelt[lli2] = labelt[lli2+1] = labelt[lli2+2] = labelt[lli2+3] = 0;
						labelt[lli2+4] = labelt[lli2+5] = labelt[lli2+6] = labelt[lli2+7] = 0;
						labelt[lli2+8] = labelt[lli2+9] = labelt[lli2+10] = labelt[lli2+11] = 0;
					}
					else {
						labelt[lli2] = obj.textPos[0]; labelt[lli2+1] = obj.textPos[1];
						labelt[lli2+2] = obj.textPos[2]; labelt[lli2+3] = obj.textPos[1];
						labelt[lli2+4] = obj.textPos[0]; labelt[lli2+5] = obj.textPos[3];
						labelt[lli2+6] = obj.textPos[2]; labelt[lli2+7] = obj.textPos[1];
						labelt[lli2+8] = obj.textPos[0]; labelt[lli2+9] = obj.textPos[3];
						labelt[lli2+10] = obj.textPos[2]; labelt[lli2+11] = obj.textPos[3];
					}
					clabels = clabelp = clabelc = clabelt = true;
				}


				if ( !data.skip && data.parentObj != null ) {
					var dir = [];
					vec3.subtract(data.parentObj.pos, obj.pos, dir);
					var d = vec3.length(dir);
					if (d > 0.1) {
						var count;

						if (depth == 0)
							count = data.parentObj.count * 0.3 + Math.sqrt(obj.count) * 7.0;
						else
							count = Math.pow(obj.count + data.parentObj.count,3/5);// - 0.001 * obj.count * obj.count;

						if (count < 3)
							count = 3;
						vec3.scale(dir, (0.1*(d-count))/d);
						//vec3.subtract(data.dir, dir);
						vec3.add(obj.dir, dir);
					}

					vec3.add(obj.pos, obj.dir);
					vec3.scale(obj.dir, 0.7);

				}

				if ( depth > 0 ) {
					for (var o in data.data) {
						var ob = data.data[o];
						if ( ob.skip + obj.skip != 2 || lines.length < li3 + 6 || this.force ) {
//						lines.push(ob.pos[0], ob.pos[1], ob.pos[2], data.pos[0], data.pos[1], data.pos[2]);
						lines[li3] = ob.pos[0];
						lines[li3+1] = ob.pos[1];
						lines[li3+2] = ob.pos[2];
						lines[li3+3] = data.pos[0];
						lines[li3+4] = data.pos[1];
						lines[li3+5] = data.pos[2];
						clines = clinec = true;

						if ( this.selObj === null ) {
//							linec.push(0.1,0.1,0.1,1.0, 0.1,0.1,0.1,1.0);
							linec[li4] = linec[li4+1] = linec[li4+2] = linec[li4+4] = linec[li4+5] = linec[li4+6] = 0.45;
							linec[li4+3] = linec[li4+7] = 1.0;

							var veclen = vec3.length(ob.pos);
//							if ( veclen > this.maxNodeLen )
//								this.maxNodeLen = veclen;
							this.maxNodeLen = (this.maxNodeLen * this.maxNodeCount + veclen) / (this.maxNodeCount + 1)
							this.maxNodeCount++;
						}
//						else if ( this.selObj == data || ob == this.selObj ) {
						else if ( obj.br == 1 && ob.br == 1 ) {
//							linec.push(0.3,0.3,0.3,1.0, 0.3,0.3,0.3,1.0);
							linec[li4] = linec[li4+1] = linec[li4+2] = linec[li4+4] = linec[li4+5] = linec[li4+6] = 1.0;
							linec[li4+3] = linec[li4+7] = 1.0;

							var vec = [];
							vec3.subtract(ob.pos, this.selObj.pos, vec);
							var veclen = vec3.length(vec);
//							if ( veclen > this.maxNodeLen )
//								this.maxNodeLen = veclen;
							this.maxNodeLen = (this.maxNodeLen * this.maxNodeCount + veclen) / (this.maxNodeCount + 1)
							this.maxNodeCount++;

						}
						else {
							linec[li4] = linec[li4+1] = linec[li4+2] = linec[li4+4] = linec[li4+5] = linec[li4+6] = 0;
							linec[li4+3] = linec[li4+7] = 1.0;
						}
						}
						li3 += 6;
						li4 += 8;
					}
				}
				if ( !obj.skip && vec3.length(obj.dir) < 0.1 )
					obj.skip = 1;

				if (!obj.skip)
					lockcnt++;

				i3 += 3;
				i4 += 4;
			}
		}
		if (lockcnt == 0)
			this.locked = true;
		this.force = false;

		if (!(this.vertices instanceof Float32Array)) {
			this.vertices = new Float32Array(this.vertices);
			this.colors = new Float32Array(this.colors);
			this.lines = new Float32Array(this.lines);
			this.linec = new Float32Array(this.linec);
			this.labels = new Float32Array(this.labels);
			this.labelp = new Float32Array(this.labelp);
			this.labelt = new Float32Array(this.labelt);
			this.labelc = new Float32Array(this.labelc);
			cvertices = clines = clabels = true;
		}	

		if (cvertices || ccolors)
			this.dotBuf.apply(this.vertices, this.colors, this.nulls, this.nulls);

		if (clines || clinec) 
			this.lineBuf.apply(this.lines, this.linec, this.nulls, this.nulls);

		if (clabels || clabelp || clabelc || clabelt)
			this.labelBuf.apply(this.labels, this.labelc, this.labelt, this.labelp);
	},
	destroy: function() {
		this.canvas.close();
	}
};

function NetworkGraph3DResourceTest() {
	var canvas = new Canvas3D(document.getElementById('mainframe'));
	networkgraph3d = new NetworkGraph3D(canvas);
	networkgraph3d.dotMax = 10000;
	networkgraph3d.lifeTime = 20000;
	for (var i = 0; i < 10000; i++) {
		var data = [Math.floor(Math.random()*10),Math.floor(Math.random()*10),Math.floor(Math.random()*90+10),Math.floor(Math.random()*1000)];
		networkgraph3d.addData([data[0], data[0] + '' + data[1], data[0] + '' + data[1] + '' + data[2], data[0] + '' + data[1] + '' + data[2] + '' + data[3]]);
	}

	function release() {
		networkgraph3d.canvas.close();
		NetworkGraph3DResourceTest();
	}

	setTimeout(release, 1000);
}

function NetworkGraph3DTest() {
//	NetworkGraph3DResourceTest();
//	return;
	addData = function() {
		currentId++;
		var data = [Math.floor(Math.random()*10),Math.floor(Math.random()*10),Math.floor(Math.random()*10),Math.floor(Math.random()*10)];
		networkgraph3d.addData([data[0], data[0] + '' + data[1], data[0] + '' + data[1] + '' + data[2], data[0] + '' + data[1] + '' + data[2] + '' + data[3]], '' + currentId);
	};

	removeData = function() {
		if (currentId <= 0)
			return;
		networkgraph3d.removeData('' + currentId);
		currentId--;
	};

	var canvas = new Canvas3D(document.getElementById('mainframe'));
	networkgraph3d = new NetworkGraph3D(canvas);
	//networkgraph3d.dotMax = 10000;
	networkgraph3d.lifeTime = 20000;
	networkgraph3d.autoTick = true;
	currentId = 0;
	addData();
	return;
	for (var i = 1000; i < 10000; i++) {
//		var data = [Math.floor(Math.random()*10),Math.floor(Math.random()*10),Math.floor(Math.random()*90+10),Math.floor(Math.random()*1000)];
		var data = [Math.floor(Math.random()*10),Math.floor(Math.random()*10),Math.floor(Math.random()*10),Math.floor(Math.random()*10)];
		//var key = '' + i;
		//var data = [key.charAt(0), key.charAt(1), key.charAt(2), key.charAt(3)];
		networkgraph3d.addData([data[0], data[0] + '' + data[1], data[0] + '' + data[1] + '' + data[2], data[0] + '' + data[1] + '' + data[2] + '' + data[3]]);
	}
	networkgraph3d.updateTick(10000);
networkgraph3d.autoFit = true;
/*	setTimeout(function() {
		networkgraph3d.selectObj(null);
		networkgraph3d.force = true;
		networkgraph3d.maxNodeLen = 0;
		networkgraph3d.maxNodeCount = 0;
		networkgraph3d.refresh();
		networkgraph3d.canvas.distance = networkgraph3d.maxNodeLen * 1.5 + 30;
		networkgraph3d.canvas.autoRotate = true;
	}, 3000);*/
	setInterval(function() {
		var dq = [];
		for (var i = 1000; i < 9000; i++) {
			var data = [Math.floor(Math.random()*10),Math.floor(Math.random()*10),Math.floor(Math.random()*10),Math.floor(Math.random()*10)];
			//networkgraph3d.addData([data[0], data[0] + '' + data[1], data[0] + '' + data[1] + '' + data[2], data[0] + '' + data[1] + '' + data[2] + '' + data[3]]);
			//var key = '' + i;
			//var data = [key.charAt(0), key.charAt(1), key.charAt(2), key.charAt(3)];
			dq.push([data[0], data[0] + '' + data[1], data[0] + '' + data[1] + '' + data[2], data[0] + '' + data[1] + '' + data[2] + '' + data[3]]);
		}
		networkgraph3d.dataQueue = dq;
		networkgraph3d.dataQueueIdx = 0;
		networkgraph3d.dataQueueTick = 10000;
	}, 10000);
	canvas.refresh();
}

if(typeof module !== 'undefined') {
    module.exports = NetworkGraph3D;
}
if (typeof require !== 'undefined') {
	var glMatrix = require('./glMatrix-0.9.5.min.js');
	var vec3 = glMatrix[0];
	var mat3 = glMatrix[1];
	var mat4 = glMatrix[2];
	var quat4 = glMatrix[3];

	var Canvas3D = require('./Canvas3D.js');
	var Buffer3D = Canvas3D.Buffer3D;
	var earcut = require('./earcut.js');
	var worldData = require('./world.js');
}
if (!Math.log10) {
	Math.log10 = function(n) {
		return Math.log(n)/Math.LN10;
	}
}

function Globe3D(canvas) {
	var shaders = {
	'globeshader_fs':
		"precision mediump float;\n"+
		"uniform vec4 uColor;\n"+
		"uniform float inv;\n"+
		"varying float fMul;\n"+
		"\n"+
		"void main(void) {\n"+
		"	if (inv > 0.0) {\n"+
		"		gl_FragColor = 1.0 - uColor.bgra * fMul;\n"+
		"	}\n"+
		"	else {\n"+
		"		gl_FragColor = uColor * fMul;\n"+
		"	}\n"+
		"	gl_FragColor.a = 1.0;\n"+
		"}\n",
	'dotshader_fs':
		"precision mediump float;\n"+
		"uniform float inv;\n"+
		"varying mediump vec4 vColor;\n"+
		"\n"+
		"void main(void) {\n"+
		"	float dist = length(gl_PointCoord.xy - vec2(0.5, 0.5))*2.0;\n"+
		"	if ( dist < 1.0 ) {\n"+
		"		dist = 1.0 - pow(dist,3.0);\n"+
		"		if (inv > 1.5) {\n"+
		"			gl_FragColor = vColor;\n"+
		"		}\n"+
		"		else if (inv > 0.5) {\n"+
		"			gl_FragColor = (1.0 - vColor) * dist * 0.6;\n"+
		"		}\n"+
		"		else {\n"+
		"			gl_FragColor = vColor * dist;\n"+
		"		}\n"+
		"		gl_FragColor.a = 1.0;\n"+
		"	}\n"+
		"	else if (inv > 1.5) {\n"+
		"		gl_FragColor = vec4(0.0, 0.0, 0.0, 0.0);\n"+
		"	}\n"+
		"	else\n"+
		"		gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);\n"+
		"}\n",
	'lineshader_fs':
		"precision mediump float;\n"+
		"varying lowp vec4 vColor;\n"+
		"uniform float fPos;\n"+
		"\n"+
		"void main(void) {\n"+
		"	gl_FragColor = vColor * (pow(fract(vColor.a + fPos),20.0) * 3.0 + 0.3);\n"+
		"	gl_FragColor.a = 1.0;\n"+
		"}\n",
	'labelshader_fs':
		"precision mediump float;\n"+
		"\n"+
		"uniform sampler2D u_texture;\n"+
		"uniform float inv;\n"+
		"varying vec2 v_texcoord2;\n"+
		"varying lowp vec4 vColor;\n"+
		"varying float z;\n"+
		"\n"+
		"void main(void) {\n"+
		"	vec4 c = texture2D(u_texture, v_texcoord2);\n"+
		"	if (inv > 0.5 && vColor.a < 0.0) {\n"+
		"		gl_FragColor = vec4(c.r * (1.0 - vColor.r) * z, c.g * (1.0 - vColor.g) * z, c.b * (1.0 - vColor.b) * z, 1.0);\n"+
		"	}\n"+
		"	else {\n"+
		"		gl_FragColor = vec4(c.r * vColor.r * z, c.g * vColor.g * z, c.b * vColor.b * z, 1.0);\n"+
		"	}\n"+
		"}\n",
	'globeshader_vs':
		"precision mediump float;\n"+
		"attribute vec3 aVertexPosition;\n"+
		"varying float fMul;\n"+
		"\n"+
		"uniform mat4 uMVMatrix;\n"+
		"uniform mat4 uPMatrix;\n"+
		"\n"+
		"void main(void) {\n"+
		"	gl_Position = uPMatrix * uMVMatrix * vec4(aVertexPosition, 1.0);\n"+
		"	fMul = clamp(200.0 / (gl_Position.z), 0.5, 1.0);\n"+
		"}\n",
	'dotshader_vs':
		"precision mediump float;\n"+
		"attribute vec3 aVertexPosition;\n"+
		"attribute vec4 aVertexColor;\n"+
		"\n"+
		"uniform mat4 uMVMatrix;\n"+
		"uniform mat4 uPMatrix;\n"+
		"\n"+
		"varying mediump vec4 vColor;\n"+
		"uniform float fPos;\n"+
		"\n"+
		"void main(void) {\n"+
		"	gl_Position = uPMatrix * uMVMatrix * vec4(aVertexPosition, 1.0);\n"+
		"	gl_PointSize = (1000.0 * aVertexColor.a) / gl_Position.z;\n"+
		"	float fP = fract(fPos + aVertexPosition.x );\n"+
		"	if ( fPos > 1.5 ) {\n"+
		"		vColor = aVertexColor;\n"+
		"	}\n"+
		"	else if ( fP > 0.5 ) {\n"+
		"		fP = 1.0 - fP;\n"+
		"		fP = fP + 0.5;\n"+
		"		vColor = vec4(aVertexColor.r*fP,aVertexColor.g*fP,aVertexColor.b*fP,aVertexColor.a);\n"+
		"	}\n"+
		"	else {\n"+
		"		fP = fP + 0.5;\n"+
		"		vColor = vec4(aVertexColor.r*fP,aVertexColor.g*fP,aVertexColor.b*fP,aVertexColor.a);\n"+
		"	}\n"+
		"}\n",
	'lineshader_vs':
		"precision mediump float;\n"+
		"attribute vec3 aVertexPosition;\n"+
		"attribute vec4 aVertexColor;\n"+
		"\n"+
		"uniform mat4 uMVMatrix;\n"+
		"uniform mat4 uPMatrix;\n"+
		"\n"+
		"varying lowp vec4 vColor;\n"+
		"\n"+
		"void main(void) {\n"+
		"	gl_Position = uPMatrix * uMVMatrix * vec4(aVertexPosition, 1.0);\n"+
		"	vColor = aVertexColor;\n"+
		"}\n",
	'labelshader_vs':
		"precision mediump float;\n"+
		"attribute vec3 aVertexPosition;\n"+
		"attribute vec3 aVertexCenter;\n"+
		"attribute vec2 a_texcoord;\n"+
		"attribute vec4 aVertexColor;\n"+
		"\n"+
		"uniform mat4 uMVMatrix;\n"+
		"uniform mat4 uPMatrix;\n"+
		"uniform vec3 u_pos;\n"+
		"\n"+
		"varying vec2 v_texcoord2;\n"+
		"varying lowp vec4 vColor;\n"+
		"varying float z;\n"+
		"\n"+
		"void main(void) {\n"+
		"	gl_Position = uPMatrix * (uMVMatrix * vec4(aVertexCenter, 1.0) + vec4(aVertexPosition, 1.0)*(length(u_pos)-80.0)/50.0);\n"+
		"	if (length(aVertexCenter - normalize(aVertexCenter - u_pos)) <= 100.0) gl_Position.z = 1000000.0;\n"+
		//"	if (gl_Position.z > u_distance) gl_Position.z = 1000000.0;\n"+
		"	v_texcoord2 = a_texcoord;\n"+
		"	vColor = aVertexColor;\n"+
		"	z = clamp(1.0 - (gl_Position.z - 100.0) / (50.0 * pow(vColor.a,4.0)), 0.0, 1.0);\n"+
		"}\n"
	};

	canvas.addProgram("globe", shaders.globeshader_vs, shaders.globeshader_fs, {
		"aVertexPosition":{"isAttrib":true, "keyName":"VertexPositionBuffer", "numItems":3},
		"uPMatrix":{"uType":"Matrix4fv", "keyName":"pMatrix"},
		"uMVMatrix":{"uType":"Matrix4fv", "keyName":"mvMatrix"},
		"uColor":{"uType":"4f"},
		"inv":{"uType":"1f"},
	});
	canvas.addProgram("dot", shaders.dotshader_vs, shaders.dotshader_fs, {
		"aVertexPosition":{"isAttrib":true, "keyName":"VertexPositionBuffer", "numItems":3},
		"aVertexColor":{"isAttrib":true, "keyName":"VertexColorBuffer", "numItems":4},
		"uPMatrix":{"uType":"Matrix4fv", "keyName":"pMatrix"},
		"uMVMatrix":{"uType":"Matrix4fv", "keyName":"mvMatrix"},
		"fPos":{"uType":"1f"},
		"inv":{"uType":"1f"},
	});
	canvas.addProgram("line", shaders.lineshader_vs, shaders.lineshader_fs, {
		"aVertexPosition":{"isAttrib":true, "keyName":"VertexPositionBuffer", "numItems":3},
		"aVertexColor":{"isAttrib":true, "keyName":"VertexColorBuffer", "numItems":4},
		"uPMatrix":{"uType":"Matrix4fv", "keyName":"pMatrix"},
		"uMVMatrix":{"uType":"Matrix4fv", "keyName":"mvMatrix"},
		"fPos":{"uType":"1f"},
	});
	canvas.addProgram("label", shaders.labelshader_vs, shaders.labelshader_fs, {
		"aVertexPosition":{"isAttrib":true, "keyName":"VertexPositionBuffer", "numItems":3},
		"aVertexCenter":{"isAttrib":true, "keyName":"VertexNormalBuffer", "numItems":3},
		"a_texcoord":{"isAttrib":true, "keyName":"TextureCoordBuffer", "numItems":2},
		"aVertexColor":{"isAttrib":true, "keyName":"VertexColorBuffer", "numItems":4},
		"uPMatrix":{"uType":"Matrix4fv", "keyName":"pMatrix"},
		"uMVMatrix":{"uType":"Matrix4fv", "keyName":"mvMatrix"},
		"u_texture":{"uType":"1i", "keyName":"textureId"},
		"u_pos":{"uType":"3f"},
		"inv":{"uType":"1f"},
	});

	this.globeBuf = new Buffer3D(canvas, {"program":"globe", "depthTest":true, "blendType":"normal", "cullFace":true, "cullFaceSide":"front", "depthMask":true, "inv":1, "uColor":[0, 0.1, 0.2, 1]});
	this.seaShoreBuf = new Buffer3D(canvas, {"program":"globe", "cullFace":false, "uColor":[0.2, 0.2, 0.2, 1]});
	this.landBuf = new Buffer3D(canvas, {"program":"globe", "cullFace":"true", "cullFaceSide":"back", "uColor":[0.1, 0.1, 0.1, 1]});
	this.lineBuf = new Buffer3D(canvas, {"program":"line", "blendType":"minus", "depthMask":false, "drawType":canvas.gl.LINES, "fPos":0});
	this.dotBuf = new Buffer3D(canvas, {"cullFace":false, "program":"dot", "drawType":canvas.gl.POINTS, "fPos":0, "inv":1});
	this.labelBuf = new Buffer3D(canvas, {"program":"label", "depthTest":false, "textureId":3, "u_pos":canvas.cameraObj.pos, "inv":1});
	canvas.drawBufs.push(this.globeBuf, this.seaShoreBuf, this.landBuf, this.lineBuf, this.dotBuf, this.labelBuf);

	this.pickBuf = new Buffer3D(canvas, {"cullFace":false, "blendType":"normal", "depthTest":true, "depthMask":false, "program":"dot", "drawType":canvas.gl.POINTS, "fPos":2, "inv":2});

	this.cbRefresh = (function() {
		//this.force = true;
		this.refresh();
	}).bind(this);
	this.cbDraw = (function() {
		if (!this.canvas.isDark) {
			this.lineBuf.blendType = "minus";
			this.globeBuf.inv = 1;
			this.dotBuf.inv = 1;
			this.labelBuf.inv = 1;
			this.landBuf.uColor = [0.1, 0.1, 0.1, 1];
		}
		else {
			this.lineBuf.blendType = "plus";
			this.globeBuf.inv = 0;
			this.dotBuf.inv = 0;
			this.labelBuf.inv = 0;
			this.landBuf.uColor = [0.3, 0.3, 0.3, 1];
		}
		this.dotBuf.fPos = this.lineBuf.fPos = 1 - (this.canvas.frame % 1000) / 1000;
		this.refresh();
		//this.cbPickDraw();
	}).bind(this);
	this.cbPickDraw = (function() {
		if (this.vertices instanceof Float32Array) {
			colors = [];
			this.objtable.forEach(function(obj, idx) {
				var i = idx + 1;
				colors[idx*4] = ((i >> 16) & 255) / 255;
				colors[idx*4 + 1] = ((i >> 8) & 255) / 255;
				colors[idx*4 + 2] = (i & 255) / 255;
				colors[idx*4 + 3] = 255 / 255;
			});
			this.pickBuf.apply(this.vertices, new Float32Array(colors), this.nulls, this.nulls);
			this.globeBuf.uColor = [0, 0, 0, 1];
			this.globeBuf.inv = 0;
			this.globeBuf.draw();
			this.globeBuf.uColor = [0, 0.1, 0.2, 1];
			this.pickBuf.draw();
		}
	}).bind(this);
	this.cbPickObj = (function(pixels) {
		var i = (pixels[0] << 16) | (pixels[1] << 8) | pixels[2];
		if (i == 0)
			return null;
		console.log(this.objtable[i - 1], pixels);
		
		return this.objtable[i - 1];	
	}).bind(this);
	this.cbMouseDown = (function(e, clientX, clientY) {
		var obj = this.canvas.pickObj(clientX, clientY);
		if (this.selObj !== obj) {
			//this.redrawAll();
			this.vertices = [];
			this.colors = [];
			this.force = true;
			this.selObj = obj;
		}
		this.canvas.refresh();
	}).bind(this);
	this.cbDblClick = (function(e, clientX, clientY) {
		this.canvas.distance = this.rGlobe * 2;
		this.canvas.autoRotate = true;
	}).bind(this);
	this.cbDestroy = (function() {
		this.globeBuf.destroy();
		this.seaShoreBuf.destroy();
		this.landBuf.destroy();
		this.lineBuf.destroy();
		this.dotBuf.destroy();
		this.labelBuf.destroy();
		this.pickBuf.destroy();
	}).bind(this);
	canvas.cbRefreshs.push(this.cbRefresh);
	canvas.cbDraws.push(this.cbDraw);
	canvas.cbPickDraws.push(this.cbPickDraw);
	canvas.cbPickObjs.push(this.cbPickObj);
	canvas.cbMouseDowns.push(this.cbMouseDown);
	canvas.cbDblClicks.push(this.cbDblClick);
	canvas.cbDestroys.push(this.cbDestroy);
	canvas.cameraMode = 1;

	this.canvas = canvas;

	this.colorset = [];
	for (var i = 0; i < 256; i++) {
		this.colorset.push([Math.random(), Math.random(), Math.random(), 1]);
	}

	this.childData = new Object();
	this.childData.data = new Object();
	this.childData.dir = [0, 0, 0];
	this.childData.pos = [0, 0, 0];
	this.childData.count = 0;
	this.depthList = [new Object()];
	this.depthList[0][''] = this.childData;
	this.selObj = null;
	this.cities = new Object();
	this.types = new Object();
	this.ids = new Object();

	this.nulls = new Float32Array(0);
	this.redrawAll();

	this.showCol = 2;

	var rGlobe = this.rGlobe = 100;

	this.canvas.cameraObj.pos[0] = 0;
	this.canvas.cameraObj.pos[1] = 0;
	this.canvas.cameraObj.pos[2] = rGlobe * 2;

	this.canvas.distance = rGlobe * 2;

	function pushglobkey(table, _d, d) {
		var key;
		var _data = [Math.round(_d[0]*10)/10,Math.round(_d[1]*10)/10];
		var data = [Math.round(d[0]*10)/10,Math.round(d[1]*10)/10];
		if ( _data[0] < data[0] ) {
			key =  '' + _data[0] + '_' + _data[1] + '_' + data[0] + '_' + data[1];
		}
		else if ( _data[0] == data[0] ) {
			if ( _data[1] < data[1] ) {
				key = '' + _data[0] + '_' + _data[1] + '_' + data[0] + '_' + data[1];
			}
			else {
				key = '' + data[0] + '_' + data[1] + '_' + _data[0] + '_' + _data[1];
			}
		}
		else {
			key = '' + data[0] + '_' + data[1] + '_' + _data[0] + '_' + _data[1];
		}
		if ( !( key in table ) ) {
			var obj = table[key] = new Object();
			obj.count = 0;
			obj.data = [_d[0], _d[1], d[0], d[1]];
		}

		table[key].count++;
	}

	var globtable = new Object();

	var rGlobet = rGlobe - 1;
	var x, y, z, cos, x1, y1, z1;
	for ( var j = 0; j < worldData.features.length; j++ ) {
		var coordinates = worldData.features[j].geometry.coordinates;
		var color = worldData.features[j].properties.mapcolor7;
		for ( var ia = 0; ia < coordinates.length; ia++ ) {
			for ( var ib = 0; ib < coordinates[ia].length; ib++ ) {
				var arr = coordinates[ia][ib];
				var elem = [];
				var _data;
				rGlobet = rGlobe - 0.1;
				for ( var i = 0; i < arr.length; i++ ) {
					var data = arr[i];
					/*cos = Math.cos(data[1]*PI/180);
					x = -Math.cos(data[0]*PI/180)*cos*rGlobet;
					y = Math.sin(data[1]*PI/180)*rGlobet;
					z = Math.sin(data[0]*PI/180)*cos*rGlobet;
					this.globeo.push( x, y, z );*/
					if ( i > 0 ) {
						//this.globeo.push( x, y, z );
						pushglobkey(globtable, _data, data);
					}
					if ( i < arr.length - 1 ) {
						elem.push( data[0], data[1] );
					}
					_data = data;
				}
				var oelem = earcut( elem );
				for ( var i = 0; i < oelem.length; i++ ) {
					var data = [elem[oelem[i]*2], elem[oelem[i]*2+1]];
					cos = Math.cos(data[1]*Math.PI/180);
					x = -Math.cos(data[0]*Math.PI/180)*cos*rGlobet;
					y = Math.sin(data[1]*Math.PI/180)*rGlobet;
					z = Math.sin(data[0]*Math.PI/180)*cos*rGlobet;
					this.landBuf.vertices.push( x, y, z );
				}
				var data = arr[0];
				/*cos = Math.cos(data[1]*PI/180);
				x = -Math.cos(data[0]*PI/180)*cos*rGlobet;
				y = Math.sin(data[1]*PI/180)*rGlobet;
				z = Math.sin(data[0]*PI/180)*cos*rGlobet;
				this.globeo.push( x, y, z );*/
				pushglobkey(globtable, _data, data);
			}
		}
	}

	var x1, y1, z1, x2, y2, z2;
	var rGlob = rGlobe - 2.6;
	for ( var key in globtable ) {
		if ( globtable[key].count > 1 )
			continue;
		var data = globtable[key].data;//key.split( "_" );
		cos = Math.cos(data[1]*Math.PI/180);
		x1 = -Math.cos(data[0]*Math.PI/180)*cos;
		y1 = Math.sin(data[1]*Math.PI/180);
		z1 = Math.sin(data[0]*Math.PI/180)*cos;
		cos = Math.cos(data[3]*Math.PI/180);
		x2 = -Math.cos(data[2]*Math.PI/180)*cos;
		y2 = Math.sin(data[3]*Math.PI/180);
		z2 = Math.sin(data[2]*Math.PI/180)*cos;
		this.seaShoreBuf.vertices.push(x1*rGlobet, y1*rGlobet, z1*rGlobet, x1*rGlob, y1*rGlob, z1*rGlob, x2*rGlob, y2*rGlob, z2*rGlob, x2*rGlob, y2*rGlob, z2*rGlob, x2*rGlobet, y2*rGlobet, z2*rGlobet, x1*rGlobet, y1*rGlobet, z1*rGlobet);
	}

	var step = Math.PI/36;
	for ( var j = -Math.PI/2; j < Math.PI/2-step; j+=step ) {
		for ( var i = -Math.PI; i < Math.PI-step; i+=step ) {
			cos = Math.cos(j);
			x = -Math.cos(i)*cos*rGlob;
			y = Math.sin(j)*rGlob;
			z = Math.sin(i)*cos*rGlob;
			this.globeBuf.vertices.push( x, y, z );

			cos = Math.cos(j);
			x1 = -Math.cos(i+step)*cos*rGlob;
			y1 = Math.sin(j)*rGlob;
			z1 = Math.sin(i+step)*cos*rGlob;

			cos = Math.cos(j+step);
			x = -Math.cos(i)*cos*rGlob;
			y = Math.sin(j+step)*rGlob;
			z = Math.sin(i)*cos*rGlob;
			this.globeBuf.vertices.push( x1, y1, z1, x, y, z, x, y, z, x1, y1, z1 );

			cos = Math.cos(j+step);
			x = -Math.cos(i+step)*cos*rGlob;
			y = Math.sin(j+step)*rGlob;
			z = Math.sin(i+step)*cos*rGlob;
			this.globeBuf.vertices.push( x, y, z );
		}
	}
	
	this.globeBuf.refresh();
	this.seaShoreBuf.refresh();
	this.landBuf.refresh();

	this.dotBuf.refresh();
	this.lineBuf.refresh();
	this.labelBuf.refresh();
};

Globe3D.prototype = {
	setShowCol: function(id) {
		this.showCol = id;
		this.redrawAll();
	},
	addData: function(array, type, id) {
		function hashstr(a, limit) {
			var hash = 12345;
			for (var i = 0; i < a.length; i++) {
				hash = hash * 1.23 + a.charCodeAt(i);
			}
			return Math.floor(hash) % limit;
		}

		var selected = false;
		var object = this.childData;
		var data = object.data;
		var frame = this.canvas.frame;
		var rGlobe = this.rGlobe;

		var isUpdate = true;

		//push single array -> ref
		var row = [frame, type];
		for (var i = 0; i < array.length; i++) {
			var arr = array[i];
			var key = '' + arr[0] + '_' + arr[1];
			row.push(key);
		}

		//row: last updated frame
		object.count++;
		for (var i = 0; i < array.length; i++) {
			if ( this.depthList.length <= i + 1 )
				this.depthList.push(new Object());

			var globalObj = this.depthList[i + 1];
			var arr = array[i];
			var key = '' + arr[0] + '_' + arr[1];
			var obj = globalObj[key];
			if (obj === undefined || obj === null) {
				obj = new Object();
				obj.data = new Object();
				obj.count = 0;

				var cos = Math.cos(arr[1]*Math.PI/180);
				var x = -Math.cos(arr[0]*Math.PI/180)*cos*rGlobe;
				var y = Math.sin(arr[1]*Math.PI/180)*rGlobe;
				var z = Math.sin(arr[0]*Math.PI/180)*cos*rGlobe;
				obj.pos = [x, y, z];
				//obj.dir = [0,0,0];
				if ( arr[2] === undefined || arr[2] === null || arr[2] == "" ) {
					obj.key = key;
				}
				else {
					obj.key = arr[2];
				}
				obj.key2 = arr.slice();
				//obj.parentObj = null;
				obj.textPos = null;
				//obj.nextObj = null;
				//obj.firstObj = null;
				//obj.curObj = null;
				obj.skip = 0;
				obj.frame = frame;
				//obj.rows = [];
				obj.br = 1;
				if (this.selObj !== null) {
					if (this.selObj.key2[0] == arr[0] && this.selObj.key2[1] == arr[1]) {
						obj.br = 0.2;
					}
					else {
						this.selObj = obj;
					}
				}
				isUpdate = false;

				globalObj[key] = obj;
			}
			else if (obj == this.selObj) {
				selected = true;
			}

			//vec3.add(cdir, dir);
			if (!(key in data)) {
				//obj.parentObj = object;
				//if ( obj.nextObj == null ) {
				//	obj.nextObj = object.firstObj;
				//	object.firstObj = obj;
				//}
				data[key] = obj;
				isUpdate = false;
			}

			var cityCounter = this.cities[key];
			if (cityCounter === undefined) {
				cityCounter = this.cities[key] = new Object();
			}
			if (!(type in cityCounter)) {
				cityCounter[type] = 0;
			}
			cityCounter[type]++;
			object = obj;
			//object.rows.push(row.slice(2));
			object.count++; //참조횟수를 증가해 줍니다.
			object.skip = 0;
			object.frame = frame;
			data = object.data;
		}
		if (!(type in this.types)) {
			isUpdate = false;
			typevalue = this.types[type] = [hashstr(''+type,this.colorset.length), 0];
		}
		this.types[type][1]++;

		if (id !== undefined && id !== null) {
			this.ids[id] = row;
		}

		this.redrawAll();
	},
	redrawAll: function() {
		this.vertices = [];
		this.colors = [];
		this.lines = [];
		this.linec = [];
		this.labels = [];
		this.labelp = [];
		this.labelc = [];
		this.labelt = [];
		this.objtable = [];
		this.force = true;
	},
	clear: function () {
		this.childData = new Object();
		this.childData.data = new Object();
		this.childData.dir = [0, 0, 0];
		this.childData.pos = [0, 0, 0];
		this.childData.count = 0;
		this.depthList = [new Object()];
		this.depthList[0][''] = this.childData;
		this.cities = new Object();
		this.types = new Object();
		this.ids = new Object();
		this.colorindex = 1;

		this.redrawAll();
	},
	kill: function () {
		this.clear();
	},
	refresh: function () {
		var box0 = [], box1 = [], box2 = [], box3 = [];

		var i3 = 0, i4 = 0, li3 = 0, li4 = 0; //array index
		var lli3 = 0, lli4 = 0, lli2 = 0;
        var vertices = this.vertices;
		var colors = this.colors;
        var lines = this.lines;
        var linec = this.linec;
		var labels = this.labels;
		var labelp = this.labelp;
		var labelc = this.labelc;
		var labelt = this.labelt;
        var globes = this.globes;
		var globel = this.globel;
		var globed = this.globed;
		var cvertices = false;
		var ccolors = false;
		var clines = false;
		var clinec = false;
		var clabels = false;
		var clabelp = false;
		var clabelc = false;
		var clabelt = false;
		var rGlobe = this.rGlobe;

		var pos = this.canvas.cameraObj.pos.slice(), camdir = this.canvas.cameraObj.dir.slice();
		var ppos = null;
		vec3.negate(camdir);

		var br = 1.0;
		if ( this.selObj ) {
			br = 0.2;
		}

		for (var depth = 0; depth < this.depthList.length; depth++ ) {
			var globalObj = this.depthList[depth];
			for (var objKey in globalObj) {
				var data = globalObj[objKey];
				var obj = data;

				var subvec = [];
				vec3.subtract( obj.pos, pos, subvec );
				var dist = vec3.length( subvec );
				var psize = Math.log10(obj.count)/2;
				if ( psize < 0.8)
					psize = 0.8;
				if ( psize > 10 )
					psize = 10;

				var svec = [], nvec = [];
				vec3.scale( subvec, 1/dist, svec );
				vec3.subtract( obj.pos, svec, nvec );
				var costh = vec3.length( nvec );

				var nbr = obj.br;

				if (depth == this.showCol && this.force) {
					var pnv = [], pv = obj.pos.slice();
					var pl = vec3.length(obj.pos);
					vec3.scale(obj.pos, 0.25/pl, pnv);
					var cityCounter = this.cities[objKey];
					for (var typeKey in cityCounter) {
						var depthi = this.types[typeKey][0];
						var c = Math.log(cityCounter[typeKey])*2+1;
						for (var i = 0; i < c; i++) {
							vertices[i3] = pv[0];
							vertices[i3+1] = pv[1];
							vertices[i3+2] = pv[2];
							vec3.add(pv, pnv);

							colors[i4] = this.colorset[depthi][0] * nbr;
							colors[i4+1] = this.colorset[depthi][1] * nbr;
							colors[i4+2] = this.colorset[depthi][2] * nbr;
							colors[i4+3] = 1;//psize;
							this.objtable[Math.floor(i3/3)] = obj;

							if ( depth > 0 && ppos != null && dist < psize * 100 )
							{
								vec3.subtract( pv, pos, subvec );
								dist = vec3.length( subvec );
								var pdot = Math.abs(vec3.dot(subvec, ppos));
								var plen = Math.sqrt(dist * dist - pdot * pdot);

								//console.log('key:'+key+' pdot:'+pdot+' dist:'+dist+' plen:'+plen+' psize:'+psize);
								if ( pdot > 1 && plen < psize * 0.5 && pdot < mdist ) {
								//if ( pdot < (500)/plen && pdot < mdist ) {
									mobj = obj;
									mdist = pdot;
								}
							}

							if ((this.selObj == obj || obj == this.mobj) && i == Math.floor(c/2)) {
								var cobj = new Object();
								this.canvas.addText(cobj, '['+typeKey+'] '+cityCounter[typeKey]);
								var slen = (cobj.textWidth-2) / (this.canvas.sztext * 2);
								var size = 1;//psize;
								box0 = [0.25, 0, 0];
								box2 = [0.25, 0.5 * size, 0];
								box1 = [0.25 + slen * size, 0, 0];
								box3 = [0.25 + slen * size, 0.5 * size, 0];

								labels[lli3] = box0[0]; labels[lli3+1] = box0[1]; labels[lli3+2] = box0[2];
								labels[lli3+3] = box1[0]; labels[lli3+4] = box1[1]; labels[lli3+5] = box1[2];
								labels[lli3+6] = box2[0]; labels[lli3+7] = box2[1]; labels[lli3+8] = box2[2];
								labels[lli3+9] = box2[0]; labels[lli3+10] = box2[1]; labels[lli3+11] = box2[2];
								labels[lli3+12] = box1[0]; labels[lli3+13] = box1[1]; labels[lli3+14] = box1[2];
								labels[lli3+15] = box3[0]; labels[lli3+16] = box3[1]; labels[lli3+17] = box3[2];

								labelp[lli3] = labelp[lli3+3] = labelp[lli3+6] = labelp[lli3+9] = labelp[lli3+12] = labelp[lli3+15] = pv[0];
								labelp[lli3+1] = labelp[lli3+4] = labelp[lli3+7] = labelp[lli3+10] = labelp[lli3+13] = labelp[lli3+16] = pv[1];
								labelp[lli3+2] = labelp[lli3+5] = labelp[lli3+8] = labelp[lli3+11] = labelp[lli3+14] = labelp[lli3+17] = pv[2];

								labelc[lli4] = labelc[lli4+4] = labelc[lli4+8] = labelc[lli4+12] = labelc[lli4+16] = labelc[lli4+20] = colors[i4];
								labelc[lli4+1] = labelc[lli4+5] = labelc[lli4+9] = labelc[lli4+13] = labelc[lli4+17] = labelc[lli4+21] = colors[i4+1];
								labelc[lli4+2] = labelc[lli4+6] = labelc[lli4+10] = labelc[lli4+14] = labelc[lli4+18] = labelc[lli4+22] = colors[i4+2];
								labelc[lli4+3] = labelc[lli4+7] = labelc[lli4+11] = labelc[lli4+15] = labelc[lli4+19] = labelc[lli4+23] = -0.7;

								if (!cobj.textPos ) {
									labelt[lli2] = labelt[lli2+1] = labelt[lli2+2] = labelt[lli2+3] = 0;
									labelt[lli2+4] = labelt[lli2+5] = labelt[lli2+6] = labelt[lli2+7] = 0;
									labelt[lli2+8] = labelt[lli2+9] = labelt[lli2+10] = labelt[lli2+11] = 0;
								}
								else {
									labelt[lli2] = cobj.textPos[0]; labelt[lli2+1] = cobj.textPos[1];
									labelt[lli2+2] = cobj.textPos[2]; labelt[lli2+3] = cobj.textPos[1];
									labelt[lli2+4] = cobj.textPos[0]; labelt[lli2+5] = cobj.textPos[3];
									labelt[lli2+6] = cobj.textPos[0]; labelt[lli2+7] = cobj.textPos[3];
									labelt[lli2+8] = cobj.textPos[2]; labelt[lli2+9] = cobj.textPos[1];
									labelt[lli2+10] = cobj.textPos[2]; labelt[lli2+11] = cobj.textPos[3];
								}
								clabels = clabelp = clabelc = clabelt = true;
								lli2 += 12;
								lli3 += 18;
								lli4 += 24;
							}

							i3 += 3;
							i4 += 4;
						}
						//depthi++;
						cvertices = ccolors = true;
					}
				}


				if (this.force) {
					if ( obj.textPos == null ) {
						this.canvas.addText(obj, obj.key);
					}
					var slen = (obj.textWidth-2) / (this.canvas.sztext * 2);
					var size = 1;//psize;
					box2 = [0.25, 0, 0];
					box0 = [0.25, -0.5 * size, 0];
					box3 = [0.25 + slen * size, 0, 0];
					box1 = [0.25 + slen * size, -0.5 * size, 0];

					labels[lli3] = box0[0]; labels[lli3+1] = box0[1]; labels[lli3+2] = box0[2];
					labels[lli3+3] = box1[0]; labels[lli3+4] = box1[1]; labels[lli3+5] = box1[2];
					labels[lli3+6] = box2[0]; labels[lli3+7] = box2[1]; labels[lli3+8] = box2[2];
					labels[lli3+9] = box2[0]; labels[lli3+10] = box2[1]; labels[lli3+11] = box2[2];
					labels[lli3+12] = box1[0]; labels[lli3+13] = box1[1]; labels[lli3+14] = box1[2];
					labels[lli3+15] = box3[0]; labels[lli3+16] = box3[1]; labels[lli3+17] = box3[2];

					labelp[lli3] = labelp[lli3+3] = labelp[lli3+6] = labelp[lli3+9] = labelp[lli3+12] = labelp[lli3+15] = obj.pos[0];
					labelp[lli3+1] = labelp[lli3+4] = labelp[lli3+7] = labelp[lli3+10] = labelp[lli3+13] = labelp[lli3+16] = obj.pos[1];
					labelp[lli3+2] = labelp[lli3+5] = labelp[lli3+8] = labelp[lli3+11] = labelp[lli3+14] = labelp[lli3+17] = obj.pos[2];

					labelc[lli4] = labelc[lli4+4] = labelc[lli4+8] = labelc[lli4+12] = labelc[lli4+16] = labelc[lli4+20] = nbr;
					labelc[lli4+1] = labelc[lli4+5] = labelc[lli4+9] = labelc[lli4+13] = labelc[lli4+17] = labelc[lli4+21] = nbr;
					labelc[lli4+2] = labelc[lli4+6] = labelc[lli4+10] = labelc[lli4+14] = labelc[lli4+18] = labelc[lli4+22] = nbr;
					labelc[lli4+3] = labelc[lli4+7] = labelc[lli4+11] = labelc[lli4+15] = labelc[lli4+19] = labelc[lli4+23] = psize;

					if (!obj.textPos ) {
						labelt[lli2] = labelt[lli2+1] = labelt[lli2+2] = labelt[lli2+3] = 0;
						labelt[lli2+4] = labelt[lli2+5] = labelt[lli2+6] = labelt[lli2+7] = 0;
						labelt[lli2+8] = labelt[lli2+9] = labelt[lli2+10] = labelt[lli2+11] = 0;
					}
					else {
						labelt[lli2] = obj.textPos[0]; labelt[lli2+1] = obj.textPos[1];
						labelt[lli2+2] = obj.textPos[2]; labelt[lli2+3] = obj.textPos[1];
						labelt[lli2+4] = obj.textPos[0]; labelt[lli2+5] = obj.textPos[3];
						labelt[lli2+6] = obj.textPos[0]; labelt[lli2+7] = obj.textPos[3];
						labelt[lli2+8] = obj.textPos[2]; labelt[lli2+9] = obj.textPos[1];
						labelt[lli2+10] = obj.textPos[2]; labelt[lli2+11] = obj.textPos[3];
					}
					clabels = clabelp = clabelc = clabelt = true;
					lli2 += 12;
					lli3 += 18;
					lli4 += 24;
				}


				if ( this.force && depth > 0 ) {
					for (var o in data.data) {
						var ob = data.data[o];
						var curv = obj.pos.slice();

						var vec = [], norv = curv.slice();
						vec3.subtract(ob.pos, obj.pos, vec);
						var tstep = vec3.length(vec);
						if (tstep == 0)
							continue;
						if ( tstep > rGlobe * 1.95 )
							tstep *= 3;
						else if ( tstep > rGlobe * 1.9 )
							tstep *= 2;
						tstep = tstep / 5;
						if ( tstep < 10 ) {
							tstep = 10;
						}
						else {
							tstep = Math.floor(tstep);
						}
						vec3.scale(vec, 1/tstep);

						if ( ob.skip + obj.skip != 2 || lines.length <= li3 + 6 || this.force ) {
						var totallen = 0;
						var oli4 = li4;
						for ( var lstep = 0; lstep < tstep; lstep++ ) {
	//						lines.push(ob.pos[0], ob.pos[1], ob.pos[2], data.pos[0], data.pos[1], data.pos[2]);
							lines[li3] = norv[0];
							lines[li3+1] = norv[1];
							lines[li3+2] = norv[2];
							vec3.add(curv, vec);
							vec3.normalize(curv, norv);
							var sin = Math.sin((lstep+1)/tstep*Math.PI);
							vec3.scale(norv, rGlobe + sin*(tstep/2-4));
							lines[li3+3] = norv[0];
							lines[li3+4] = norv[1];
							lines[li3+5] = norv[2];

							linec[li4+3] = totallen;//lstep / tstep;
							totallen+=vec3.length([lines[li3+3]-lines[li3], lines[li3+4]-lines[li3+1], lines[li3+5]-lines[li3+2]]);
							linec[li4+7] = totallen;//(lstep + 1) / tstep;
							if ( this.selObj === null ) {
	//							linec.push(0.1,0.1,0.1,1.0, 0.1,0.1,0.1,1.0);
								linec[li4] = linec[li4+1] = linec[li4+2] = linec[li4+4] = linec[li4+5] = linec[li4+6] = this.nightMode ? 1.0 : 0.3;
//								linec[li4+3] = linec[li4+7] = 1.0;
							}
							else if ( this.selObj == data || ob == this.selObj ) {
	//							linec.push(0.3,0.3,0.3,1.0, 0.3,0.3,0.3,1.0);
								linec[li4] = linec[li4+1] = linec[li4+2] = linec[li4+4] = linec[li4+5] = linec[li4+6] = this.nightMode ? 1.0 : 0.3;
//								linec[li4+3] = linec[li4+7] = 1.0;

							}
							else {
	//							linec.push(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0);
								linec[li4] = linec[li4+1] = linec[li4+2] = linec[li4+4] = linec[li4+5] = linec[li4+6] = this.nightMode ? 0.2 : 0.1;
//								linec[li4+3] = linec[li4+7] = 1.0;
							}
							li3 += 6;
							li4 += 8;
						}
						li4 = oli4;
						for ( var lstep = 0; lstep < tstep; lstep++ ) {
							linec[li4+3]/=totallen;//lstep / tstep;
							linec[li4+7]/=totallen;//(lstep + 1) / tstep;
							li4 += 8;
						}
						clines = clinec = true;
						}
					}
				}
				obj.skip = 1;

			}
		}

		this.force = false;

		if (!(this.vertices instanceof Float32Array)) {
			this.vertices = new Float32Array(this.vertices);
			this.colors = new Float32Array(this.colors);
			this.lines = new Float32Array(this.lines);
			this.linec = new Float32Array(this.linec);
			this.labels = new Float32Array(this.labels);
			this.labelp = new Float32Array(this.labelp);
			this.labelt = new Float32Array(this.labelt);
			this.labelc = new Float32Array(this.labelc);
			cvertices = clines = clabels = true;
		}	

		if (cvertices || ccolors)
			this.dotBuf.apply(this.vertices, this.colors, this.nulls, this.nulls);

		if (clines || clinec) 
			this.lineBuf.apply(this.lines, this.linec, this.nulls, this.nulls);

		if (clabels || clabelp || clabelc || clabelt)
			this.labelBuf.apply(this.labels, this.labelc, this.labelt, this.labelp);

	},
	destroy: function() {
		this.canvas.close();
	},
	removeData: function(id) {
		if (!(id in this.ids))
			return false;

		var row = this.ids[id];
		var type = row[1];
		var prevObj = this.childData;
		for (var i = 0; i < row.length - 2; i++) {
			if ( this.depthList.length <= i + 1 )
				break;

			var globalObj = this.depthList[i + 1];
			var key = row[i + 2];
			var obj = globalObj[key];
	
			if (obj === undefined || obj === null)
				break;

			obj.count--;

			if (!obj.count) {
				if (prevObj !== null) {
					delete prevObj.data[key];
				}
			}

			prevObj = obj;
		}

		for (var i = 0; i < row.length - 2; i++) {
			if ( this.depthList.length <= i + 1 )
				break;

			var globalObj = this.depthList[i + 1];
			var key = row[i + 2];
			var obj = globalObj[key];
			
			if (obj === undefined || obj === null)
				break;

			if (!obj.count) {
				delete obj.textPos;
				delete obj.data;
				delete globalObj[key];
			}
			if (key in this.cities) {
				var cityCounter = this.cities[key];

				if (type in cityCounter) {
					if (!(--cityCounter[type]))
						delete cityCounter[type];
				}
			}

			if (this.selObj === obj)
				this.selObj = null;
		}

		if (type in this.types) {
			if (!(--this.types[type][1]))
				delete this.types[type];			
		}
		delete this.ids[id]; 
		this.childData.count--;

		this.redrawAll();
		return true;
	}
};

function Globe3DTest() {
	addData = function() {
		currentId++;
		var data = [/*[Math.floor(Math.random()*360-180),Math.floor(Math.random()*180-90)]*/[0,0],[Math.floor(Math.random()*36-18)*10,Math.floor(Math.random()*18-9)*10]];
		networkgraph3d.addData(data, Math.floor(Math.random() * 5), '' + currentId);
	}

	removeData = function() {
		if (currentId <= 0)
			return;
		networkgraph3d.removeData('' + currentId);
		currentId--;
		canvas.refresh();
	}

	var canvas = new Canvas3D(document.getElementById('mainframe'));
	networkgraph3d = new Globe3D(canvas);
	currentId = 0;
	addData();
	return;
	for (var i = 0; i < 10000; i++) {
		var data = [/*[Math.floor(Math.random()*360-180),Math.floor(Math.random()*180-90)]*/[0,0],[Math.floor(Math.random()*36-18)*10,Math.floor(Math.random()*18-9)*10]];
		networkgraph3d.addData(data, Math.floor(Math.random() * 5));
	}
	canvas.refresh();
}

function toggleTheme() {
	networkgraph3d.canvas.isDark^=1;
	networkgraph3d.canvas.refresh();

	//var img = new Image();
	//img.src = networkgraph3d.canvas.takePicture();
	//document.body.appendChild(img);
}

if(typeof module !== 'undefined') {
    module.exports = Globe3D;
}
