package com.logpresso.sonar.app.sample.msgbus;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;

import org.apache.felix.ipojo.annotations.Component;
import org.apache.felix.ipojo.annotations.Requires;
import org.araqne.api.InetAddresses;
import org.araqne.geoip.GeoIpLocation;
import org.araqne.geoip.GeoIpService;
import org.araqne.httpd.FileDownloadService;
import org.araqne.logdb.query.expr.Ip2Long;
import org.araqne.logdb.query.expr.ToIp;
import org.araqne.msgbus.Request;
import org.araqne.msgbus.Response;
import org.araqne.msgbus.handler.MsgbusMethod;
import org.araqne.msgbus.handler.MsgbusPlugin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.logpresso.sonar.api.download.DownloadHandler;
import com.logpresso.sonar.api.download.DownloadHandlerFactory;

@Component(name = "sonar-public-ip-plugin")
@MsgbusPlugin
public class PublicIpPlugin {

	private final Logger slog = LoggerFactory.getLogger(PublicIpPlugin.class);

	@Requires
	private GeoIpService geoip;

	@Requires
	private FileDownloadService downloadService;

	@Requires
	private DownloadHandlerFactory downloadHandlerFactory;

	@MsgbusMethod
	public void getLocation(Request req, Response resp) {
		InetAddress ip = InetAddresses.forString(req.getString("ip"));

		GeoIpLocation location = geoip.locate(ip);

		Map<String, Object> m = getLocation(ip, location);

		resp.put("location", m);
	}

	@MsgbusMethod
	public void getLocations(Request req, Response resp) {
		String from = req.getString("from", true);
		String to = req.getString("to", true);
		Integer offset = null;
		Integer limit = 20;

		if (req.getInteger("offset") != null)
			offset = req.getInteger("offset");

		if (req.getInteger("limit") != null)
			limit = req.getInteger("limit");

		long fromLong = Ip2Long.convert(from);
		long toLong = Ip2Long.convert(to);

		List<Map<String, Object>> l = new ArrayList<Map<String, Object>>();

		long s = fromLong + offset;

		for (int i = 0; i < limit; i++) {

			if ((s + i) > toLong)
				break;

			InetAddress ip = InetAddresses.forString(ToIp.convert(s + i));

			GeoIpLocation location = geoip.locate(ip);

			Map<String, Object> m = getLocation(ip, location);

			l.add(m);

		}

		resp.put("total", toLong - fromLong);
		resp.put("locations", l);

	}

	@MsgbusMethod
	public void prepareDownload(Request req, Response resp) {
		Locale locale = Locale.KOREAN;
		if (req.get("locale") != null)
			locale = new Locale(req.getString("locale"));

		String from = req.getString("from", true);
		String to = req.getString("to", true);
		long offset = req.getLong("offset", true);
		long limit = req.getLong("limit", true);

		long fromLong = Ip2Long.convert(from);
		long toLong = Ip2Long.convert(to);
		long max = Ip2Long.convert("255.255.255.255");

		if (fromLong + offset + limit >= max)
			toLong = max;

		if (fromLong + offset >= max)
			fromLong = max;

		long count = toLong - fromLong + 1;

		Map<String, String> fieldNames = getPublicIpHeader(locale);
		Iterator<Map<String, Object>> it = new PublicIpIterator(fromLong, toLong);
		DownloadHandler handler = downloadHandlerFactory.newHandler(req, fieldNames, it, count);
		downloadService.addHandler(handler);
		resp.put("token", handler.getToken());
	}

	private class PublicIpIterator implements Iterator<Map<String, Object>> {

		private long from;
		private long to;
		private long p;

		public PublicIpIterator(long from, long to) {
			if (from < 0)
				throw new IllegalArgumentException("`from` value is out of IPv4 range.");

			if (to > Ip2Long.convert("255.255.255.255"))
				throw new IllegalArgumentException("`to` value is out of IPv4 range.");

			this.from = from;
			this.to = to;
			this.p = from;
		}

		@Override
		public boolean hasNext() {
			return p <= to;
		}

		@Override
		public Map<String, Object> next() {
			if (!hasNext())
				throw new NoSuchElementException("reached end of public ip iterator: " + p);

			InetAddress ip = InetAddresses.forString(ToIp.convert(p++));
			GeoIpLocation location = geoip.locate(ip);
			Map<String, Object> m = getLocation(ip, location);
			return m;
		}
		
		public void remove() {
	        throw new UnsupportedOperationException("remove");
	    }
	}

	private Map<String, Object> getLocation(InetAddress ip, GeoIpLocation location) {

		Map<String, Object> m = new HashMap<String, Object>();

		m.put("ip", ip.getHostAddress());

		if (location == null)
			return m;

		String asn = geoip.locateAsn(ip);
		m.put("country", location.getCountry());
		m.put("region", location.getRegion());
		m.put("city", location.getCity());
		m.put("postal_code", location.getPostalCode());
		m.put("latitude", location.getLatitude());
		m.put("longitude", location.getLongitude());
		m.put("metro_code", location.getMetroCode());
		m.put("area_code", location.getAreaCode());
		m.put("asn", asn);

		return m;
	}

	private Map<String, String> getPublicIpHeader(Locale locale) {
		Map<String, String> m = new HashMap<String, String>();
		if (locale.equals(Locale.KOREAN)) {
			m.put("ip", "IP 주소");
			m.put("country", "국가");
			m.put("region", "지역");
			m.put("city", "도시");
			m.put("postal_code", "우편번호");
			m.put("latitude", "위도");
			m.put("longitude", "경도");
			m.put("metro_code", "메트로코드");
			m.put("area_code", "지역코드");
			m.put("asn", "ASN");
		} else {
			m.put("ip", "IP Address");
			m.put("country", "Country");
			m.put("region", "Region");
			m.put("city", "City");
			m.put("postal_code", "Postal Code");
			m.put("latitude", "Latitude");
			m.put("longitude", "Longitude");
			m.put("metro_code", "Metro Code");
			m.put("area_code", "Area Code");
			m.put("asn", "ASN");
		}
		return m;
	}
}
